#!/bin/bash
# ============================================================
#  Option B: Ollama model downloader (uses `ollama pull`)
#  Pulls the exact same model set as install_models_huggingface.sh, by ollama_id instead of hf_id
#  (see model_registry.yaml). Requires a running local Ollama daemon (`ollama serve`) and the `ollama`
#  CLI (https://ollama.com) -- no torch/CUDA/transformers dependency on the client side.
#
#  Usage:
#    ollama serve &                        # if not already running
#    ./install_models_ollama.sh --tier llm     # ~130-180 GB disk (quantized, smaller than HF bfloat16)
#    ./install_models_ollama.sh --tier slm
#
#  See install_models_huggingface.sh for the exact same model set via HuggingFace/transformers instead
#  (Option A) -- both are equally supported; pick whichever backend the config you plan to run uses
#  (owner: HuggingFace|Ollama in Pipeline/{SLM,LLM}/benchmarking/config_paper_exact_*.yaml, or
#  --backend huggingface|ollama for the baselines).
# ============================================================
set -euo pipefail

TIER=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --tier) TIER="$2"; shift 2 ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
  esac
done
if [[ "$TIER" != "llm" && "$TIER" != "slm" ]]; then
  echo "Usage: $0 --tier llm|slm"
  exit 1
fi

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

if ! command -v ollama >/dev/null 2>&1; then
  echo -e "${RED}✗ 'ollama' CLI not found.${NC} Install from https://ollama.com, then re-run this script."
  exit 1
fi
if ! ollama list >/dev/null 2>&1; then
  echo -e "${RED}✗ Cannot reach the Ollama daemon.${NC} Start it first:  ollama serve &"
  exit 1
fi

if [ "$TIER" = "llm" ]; then
  MODELS=(
    "qwen2.5-coder:32b"            # LLM-A/LLM-C primary
    "qwen2.5-coder:14b"            # A1/A3 medium
    "deepseek-coder:6.7b-instruct" # A1/A3 weak; V6-H
    "phi4"                          # LLM-B primary
    "llama3.3:70b"                  # A2 medium -- NOT gated on Ollama (unlike HuggingFace)
    "qwen2.5:14b"                   # A2 weak
  )
else
  MODELS=(
    "qwen2.5-coder:7b"              # LLM-A/LLM-C primary
    "qwen2.5-coder:3b"              # A1 medium / A3 medium
    "smollm2:1.7b"                  # A1 weak
    "phi4"                          # LLM-B primary
    "llama3.2:3b"                   # A2 medium
    "gemma2:2b"                     # A2 weak
    "deepseek-coder:6.7b-instruct"  # A3 strong
    "codegemma:2b"                  # A3 weak
  )
fi

echo ""
echo -e "${CYAN}Ollama model downloader -- tier=${TIER}, ${#MODELS[@]} models${NC}"
echo ""

PASS=0; FAIL=(); TOTAL=${#MODELS[@]}; COUNT=0
for MODEL in "${MODELS[@]}"; do
  ((COUNT++))
  echo -e "${CYAN}[$COUNT/$TOTAL]${NC} ${YELLOW}↓ $MODEL${NC}"
  if ollama pull "$MODEL"; then
    echo -e "  ${GREEN}✓ Done${NC}"; ((PASS++))
  else
    echo -e "  ${RED}✗ Failed: $MODEL${NC}"; FAIL+=("$MODEL")
  fi
  echo ""
done

echo -e "${CYAN}Summary: ${GREEN}$PASS/$TOTAL pulled${NC}"
if [ ${#FAIL[@]} -gt 0 ]; then
  echo -e "${RED}Failed (${#FAIL[@]}):${NC}"
  for m in "${FAIL[@]}"; do echo "  • $m"; done
fi
TIER_UPPER=$(echo "$TIER" | tr '[:lower:]' '[:upper:]')
echo ""
echo -e "Next step: cd ../Pipeline/${TIER_UPPER}/benchmarking && python3 run_benchmark.py --config config_paper_exact_ollama.yaml"
