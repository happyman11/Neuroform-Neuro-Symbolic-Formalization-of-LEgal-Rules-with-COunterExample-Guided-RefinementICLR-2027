#!/bin/bash
# ============================================================
#  Option A: HuggingFace model downloader (uses the `hf` CLI)
#  Pulls every model in model_registry.yaml's llm_tier or slm_tier block.
#
#  Usage:
#    export HF_TOKEN=hf_xxxxxxxxxxxx      # required -- Llama models are gated
#    ./install_models_huggingface.sh --tier llm     # ~250-400 GB disk
#    ./install_models_huggingface.sh --tier slm     # ~250-350 GB disk
#
#  Merges (parametrized by --tier) the two install scripts this repo already had before this bundle:
#  scripts/LLM/my-reference/install_models_LLM.sh and scripts/SLM/my-reference/install_models_Hugging_face.sh
#  -- same models, same source, single script.
#
#  See install_models_ollama.sh for the exact same model set via a local Ollama daemon instead (Option B) --
#  both are equally supported; pick whichever backend the config you plan to run uses.
# ============================================================
set -euo pipefail

TIER=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --tier) TIER="$2"; shift 2 ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
  esac
done
if [[ "$TIER" != "llm" && "$TIER" != "slm" ]]; then
  echo "Usage: $0 --tier llm|slm"
  exit 1
fi

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

if [ -z "${HF_TOKEN:-}" ]; then
  echo -e "${RED}✗ HF_TOKEN is not set. Gated models (Meta Llama) will fail.${NC}"
  echo -e "  Export it first:  export HF_TOKEN=hf_xxxxxxxxxxxx"
  exit 1
fi

if [ "$TIER" = "llm" ]; then
  MODELS=(
    "Qwen/Qwen2.5-Coder-32B-Instruct"           # LLM-A/LLM-C primary
    "Qwen/Qwen2.5-Coder-14B-Instruct"           # A1/A3 medium
    "deepseek-ai/deepseek-coder-6.7b-instruct"  # A1/A3 weak; V6-H
    "microsoft/phi-4"                            # LLM-B primary
    "meta-llama/Llama-3.3-70B-Instruct"          # A2 medium [GATED]
    "Qwen/Qwen2.5-14B-Instruct"                  # A2 weak
  )
else
  MODELS=(
    "Qwen/Qwen2.5-Coder-7B-Instruct"     # LLM-A/LLM-C primary
    "Qwen/Qwen2.5-Coder-3B-Instruct"     # A1 medium / A3 medium
    "HuggingFaceTB/SmolLM2-1.7B"          # A1 weak
    "microsoft/phi-4"                     # LLM-B primary
    "meta-llama/Llama-3.2-3B-Instruct"   # A2 medium
    "google/gemma-2-2b-it"                # A2 weak
    "deepseek-ai/deepseek-coder-6.7b-instruct"  # A3 strong
    "google/codegemma-2b"                 # A3 weak
  )
fi

pip install -q hf_transfer 2>/dev/null || true
export HF_HUB_ENABLE_HF_TRANSFER=1

echo ""
echo -e "${CYAN}HuggingFace model downloader -- tier=${TIER}, ${#MODELS[@]} models${NC}"
if [ "$TIER" = "llm" ]; then
  echo -e "  ${YELLOW}Note:${NC} Llama-3.3-70B-Instruct is gated (Meta licence)."
  echo -e "  Request access at: huggingface.co/meta-llama/Llama-3.3-70B-Instruct"
fi
echo ""

PASS=0; FAIL=(); TOTAL=${#MODELS[@]}; COUNT=0
for MODEL in "${MODELS[@]}"; do
  ((COUNT++))
  echo -e "${CYAN}[$COUNT/$TOTAL]${NC} ${YELLOW}↓ $MODEL${NC}"
  if hf download "$MODEL" --token "$HF_TOKEN"; then
    echo -e "  ${GREEN}✓ Done${NC}"; ((PASS++))
  else
    echo -e "  ${RED}✗ Failed: $MODEL${NC}"; FAIL+=("$MODEL")
  fi
  echo ""
done

echo -e "${CYAN}Summary: ${GREEN}$PASS/$TOTAL downloaded${NC}"
if [ ${#FAIL[@]} -gt 0 ]; then
  echo -e "${RED}Failed (${#FAIL[@]}):${NC}"
  for m in "${FAIL[@]}"; do echo "  • $m"; done
  echo -e "${YELLOW}If Llama-3.3-70B failed, check gate access and HF_TOKEN.${NC}"
fi
TIER_UPPER=$(echo "$TIER" | tr '[:lower:]' '[:upper:]')   # ${TIER^^} needs bash 4+; macOS ships bash 3.2
echo ""
echo -e "Next step: cd ../Pipeline/${TIER_UPPER}/benchmarking && python3 run_benchmark.py --config config_paper_exact_hf.yaml"
