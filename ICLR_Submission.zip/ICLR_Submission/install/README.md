# Model installation

Every run in this bundle (Pipeline/SLM, Pipeline/LLM, Baseline) can use **either** backend below. Pick one --
both are fully supported, produce the same interface (`owner: HuggingFace|Ollama` in a `config_paper_exact_*.yaml`,
or `--backend huggingface|ollama` for the baselines), and `model_registry.yaml` is the single source of truth
both install scripts read from.

| | Option A: HuggingFace | Option B: Ollama |
|---|---|---|
| Client dependency | `transformers`, `torch`, `accelerate` (+ `bitsandbytes` for 4-bit) | `ollama` Python package + local `ollama` daemon |
| Install script | `install_models_huggingface.sh` | `install_models_ollama.sh` |
| Requires | `HF_TOKEN` env var (Llama models are gated) | `ollama serve` running locally |
| Disk (LLM tier, 6 models) | ~250-400 GB (bfloat16/float16) | ~130-180 GB (Ollama's default quantization) |
| Disk (SLM tier, 8 models) | ~250-350 GB | ~100-150 GB |
| Config to run after | `config_paper_exact_hf.yaml` | `config_paper_exact_ollama.yaml` |
| Baseline flag | `--backend huggingface` (default) | `--backend ollama` |

## Option A: HuggingFace

```bash
export HF_TOKEN=hf_xxxxxxxxxxxx        # required -- Llama-3.3-70B (A2 medium ablation) is gated
./install_models_huggingface.sh --tier llm     # or --tier slm
```

Downloads via the `hf` CLI (`pip install huggingface_hub` if not already present) into the standard HF cache
(`~/.cache/huggingface`). `Pipeline/{SLM,LLM}/lib/models.py`'s `HuggingFaceModel` loads from there automatically
-- no path configuration needed.

## Option B: Ollama

```bash
# 1. Install Ollama: https://ollama.com
# 2. Start the daemon (if not already running as a service)
ollama serve &
# 3. Pull the models
./install_models_ollama.sh --tier llm     # or --tier slm
```

`Pipeline/{SLM,LLM}/lib/models.py`'s `ModelCall.ollama_call_model` also lazy-pulls any model it is asked to call
that isn't already local (via `ollama.pull()`), so this step is a convenience / pre-warm, not a hard requirement
-- the first real run will pull on demand if you skip it, just slower on that first call.

## Which one should I pick?

No difference in the pipeline's behavior either way -- `algorithm_mode=paper_exact`, `theta_impl=0.80`, and every
other hyperparameter are identical between `config_paper_exact_hf.yaml` and `config_paper_exact_ollama.yaml` (see
`PAPER_CODE_CORRESPONDENCE.md`). HuggingFace gives full-precision weights and is what the paper's own headline
numbers were generated with; Ollama is lighter on disk and has no `HF_TOKEN`/gating friction, at the cost of
Ollama's own default quantization (results may differ slightly from the HuggingFace path for that reason alone,
not because of anything in this pipeline's algorithm).
