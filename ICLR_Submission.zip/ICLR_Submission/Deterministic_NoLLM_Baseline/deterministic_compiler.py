#!/usr/bin/env python3
"""
deterministic_compiler.py -- the fixed, deterministic, LLM-free compiler D: annotation -> Z3 program.

    D(a_hat_i) = phi_i^D          for i in {1, ..., 238}

No LLM/SLM call happens anywhere in this file, and it never reads S1-S6 scenario labels or the harness that
scores them (see test_deterministic_compiler.py's no-leakage check). It reads only `structured_annotation` from
AAAI-Dataset/dataset/<Act>_Act/<Section>.json and a fixed, pre-declared set of mapping rules (below), and emits
Python source implementing the exact class contract scripts/LLM/lib/promting.py's FOL_Structure prompt requires
(and every real generated Z3 file in this repo follows): `import z3`; `class <Name>:` with a docstring;
`__init__` declaring one `z3.Bool` per variable; `get_rule(self)` returning one Z3 boolean expression;
`verify_data(self, data)` with the exact boilerplate body used everywhere else in this repo, so the output is
directly loadable by the repo's own unmodified S1-S6 evaluator, HPC_ForAbstract/hpc_multiscenario_eval_s6b.py
(via its `find_class`/`get_bool_vars` duck-typing -- no fixed class name is actually required by the evaluator,
but this module still emits one for readability and for parity with existing generated code).

=====================================================================================================================
WHY THIS IS CONSERVATIVE BY DESIGN (read before extending the rule table)
=====================================================================================================================
The annotation's `structured_annotation` field has no explicit attachment/relation/scope/predicate-binding
mechanism for ~98% of the 238-provision corpus (see README.md's "What the investigation found"): `relations`/
`relationships`/`entities` keys appear in fewer than 15 files, inconsistently shaped and never ID-targeted; no
`applies_to`/`scope`/`parent`/`binding`/`argument` key exists anywhere. The only composition signal available is
co-location of `{text, label}` spans within one structural unit (one paragraph/subsection/clause's `annotations`
list) plus document order -- nothing more. This module therefore NEVER infers:
  - which of several co-located conditions/obligations/exemptions attaches to which other element,
  - AND vs OR composition among multiple same-class siblings,
  - the scope of a condition across multiple obligations,
  - polarity from prose ("if" vs "unless") beyond what the annotator's own label choice already commits to,
  - actor/predicate bindings not present as a distinct span.
Any unit whose compilation would require one of the above is marked UNDER_SPECIFIED with a specific reason code
(REASON_CODES below), never guessed. This is expected to produce low coverage; that is the answer to the
reviewer's question, not a defect to be engineered around.

=====================================================================================================================
FIXED RULE TABLE (exactly the patterns given in the task spec, plus one disclosed, directly-derived extension)
=====================================================================================================================
Rules match a single annotation UNIT's exact multiset of deontic-class cardinalities (o=obligation, p=prohibition,
pm=permission, c=condition, e=exemption) -- nothing else present in that unit. See RULES below for the registry;
see classify_unit() for the exact decision tree (no partial/fuzzy matches).

    R1  o=1                    -> self.<o>                                        "Unconditional obligation: O -> O"
    R2  p=1                    -> Not(self.<p>)                                    "Prohibition: P -> Not(P)"
    R3  c=1,o=1                -> Implies(self.<c>, self.<o>)                      "Condition + obligation"
    R4  c=1,p=1                -> Implies(self.<c>, Not(self.<p>))                 "Condition + prohibition"
    R5  c=1,e=1,o=1            -> Implies(And(self.<c>, Not(self.<e>)), self.<o>)  "Guarded obligation w/ exemption"
    R6  c=1,e=1,p=1            -> Implies(And(self.<c>, Not(self.<e>)), Not(self.<p>))  extension: same C/E
                                    substitution the task itself made going from R3(C,O) to R5(C,E,O), applied to
                                    R4(C,P) instead of R3(C,O) -- logged here explicitly, not silently added.
    R7  pm=1                   -> Or(self.<pm>, Not(self.<pm>))                    permission alone: a non-binding
                                    tautology. Matches HPC_ForAbstract/hpc_multiscenario_eval_s6b.py's own
                                    documented convention (_pick_binding_obligation_vars' docstring: permissive
                                    "may" clauses are correctly encoded as non-binding). Not in the task's example
                                    list; included because leaving every lone #permission/#right span UNDER_
                                    SPECIFIED forever would be needlessly harsh for an unambiguous "may" reading,
                                    and it is disclosed here rather than silently assumed.

Note R3/R4 apply uniformly to ANY unit labeled exactly one #condition + one #obligation/#prohibition, regardless
of whether the condition's prose reads as a trigger ("if X, then...") or a defeater ("...unless X") -- the
annotation schema has no field distinguishing these, and the task's own rule table gives Implies(C,O) for this
exact pattern unconditionally. This is a disclosed, known source of possible semantic error (a human QA study in
AAAI-Dataset/SOP_4acts.tex found #condition vs #exemption is exactly where inter-annotator agreement is weakest,
kappa concentrated at that boundary) -- not a bug this compiler tries to silently fix.

Everything else falls through to UNDER_SPECIFIED (see classify_unit()).
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

HERE = Path(__file__).resolve().parent
# ICLR supplementary: repointed from the original tree's AAAI-Dataset/dataset (2 levels up from
# scripts/additional_runs/deterministic_baseline/) to this bundle's own Benchmark/dataset (1 level up from
# Deterministic_NoLLM_Baseline/, self-contained) -- same content (this bundle's Benchmark/dataset/ IS a copy of
# AAAI-Dataset/dataset/'s 4 acts, see PAPER_CODE_CORRESPONDENCE.md), no dependency on anything outside
# ICLR_Submission/.
REPO = HERE.parents[0]              # ICLR_Submission/
DATASET = REPO / "Benchmark" / "dataset"
ACT_DIRS = {"GDPR": "GDPR_Act", "CCPA": "CCPA_Act", "DPDP": "DPDP_Act", "PIPD": "PIPD_Act"}

sys.path.insert(0, str(REPO / "Benchmark"))
from compare_qa_v2 import NORMALIZE_MAP as _BASE_NORMALIZE_MAP  # noqa: E402  -- the repo's own existing 7-class map

# ---------------------------------------------------------------------------------------------------------------
# Label normalization: base map (repo's own compare_qa_v2.NORMALIZE_MAP) + a small, hand-reviewed exact-string
# extension (12 entries, covering every remaining label seen >=3 times in a fresh corpus-wide scan of all 238
# files) + a small suffix-rule table (mirrors NORMALIZE_MAP's own "*_scope" -> condition style). Anything still
# unresolved after both is UNMAPPED -- never defaulted into one of the 7 classes by guessing. Coverage measured
# empirically (see README.md): 94/256 distinct raw labels resolved (base 41 + explicit 12 + suffix 41), covering
# 1969/2202 (89.4%) of all span occurrences in the corpus; the remaining 162 distinct labels (233 occurrences,
# 10.6%) are UNMAPPED.
# ---------------------------------------------------------------------------------------------------------------
CANON_CLASSES = ("obligation", "permission", "prohibition", "condition", "exemption")
INERT_NORMS = ("entity", "reference", "ARTIFACT", "OTHER")

_EXPLICIT_EXTENSIONS = {
    # label -> normalized class. Each entry reviewed by hand against the corpus scan in README.md; every one
    # occurred >=3 times (i.e. materially affects pilot/full-run statistics) and was NOT already resolvable by a
    # suffix rule below. OTHER = confidently non-deontic (descriptive/procedural/contextual), never blocks a rule
    # match and contributes no constraint (same treatment as #entity/#reference/#definition already in the base
    # map). A synonym mapped to one of the 5 deontic classes is a plain-English match to that class's own name
    # (analogous to the base map's own #task/#communication -> obligation, #penalty -> obligation, #factor ->
    # condition), not a fuzzy/NLP inference.
    "#requirement": "obligation", "#responsibility": "obligation",
    "#consideration": "condition", "#limitation": "condition", "#jurisdiction": "condition",
    "#information": "OTHER", "#procedure": "OTHER", "#action": "OTHER", "#measure": "OTHER",
    "#transparency": "OTHER", "#concept": "OTHER", "#information_content": "OTHER",
}
_SUFFIX_RULES = (  # (suffix of the label with leading '#' stripped, normalized class); checked in this order
    ("obligation", "obligation"), ("condition", "condition"),
    ("exemption", "exemption"), ("derogation", "exemption"),
    ("prohibition", "prohibition"), ("restriction", "prohibition"),
    ("rights", "permission"), ("right", "permission"), ("permission", "permission"),
    ("authority", "permission"), ("authorization", "permission"), ("authorisation", "permission"),
    ("entities", "entity"), ("entity", "entity"), ("actors", "entity"), ("actor", "entity"),
    ("reference", "reference"),
)


def normalize_label(raw_label: str) -> tuple[str, str]:
    """(normalized_class, provenance) where provenance is 'base'|'explicit'|'suffix:<rule>'|'unmapped'."""
    if raw_label in _BASE_NORMALIZE_MAP:
        return _BASE_NORMALIZE_MAP[raw_label], "base"
    if raw_label in _EXPLICIT_EXTENSIONS:
        return _EXPLICIT_EXTENSIONS[raw_label], "explicit"
    bare = raw_label.lstrip("#")
    for suffix, cls in _SUFFIX_RULES:
        if bare.endswith(suffix):
            return cls, f"suffix:{suffix}"
    return "UNMAPPED", "unmapped"


# ---------------------------------------------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------------------------------------------
@dataclass
class AnnotationSpan:
    text: str
    label_raw: str
    label_norm: str
    description: str = ""


@dataclass
class AnnotationUnit:
    path: str                                   # breadcrumb, e.g. "subsections[2].text[0]"
    raw_text: str
    spans: list[AnnotationSpan] = field(default_factory=list)


@dataclass
class WalkResult:
    units: list[AnnotationUnit]
    num_relations: int                           # count of relations/relationships/entities KEYS seen (metadata only)
    schema_warnings: list[str]                    # SCHEMA_WALK_FAILURE notes, never fatal


# ---------------------------------------------------------------------------------------------------------------
# Generic walker over structured_annotation (schema is NOT fixed -- see module docstring)
# ---------------------------------------------------------------------------------------------------------------
_RELATION_KEYS = ("relations", "relationships", "entities")


def _parse_span(item: dict) -> Optional[AnnotationSpan]:
    if not isinstance(item, dict):
        return None
    text, label = item.get("text"), item.get("label")
    if not isinstance(text, str) or not isinstance(label, str):
        return None
    norm, _ = normalize_label(label)
    return AnnotationSpan(text=text, label_raw=label, label_norm=norm, description=str(item.get("description", "")))


def _walk(node, path: str, units: list[AnnotationUnit], warnings: list[str], rel_counter: list[int]) -> None:
    try:
        if isinstance(node, dict):
            for k in _RELATION_KEYS:
                if k in node:
                    rel_counter[0] += 1
            ann = node.get("annotations")
            if isinstance(ann, list):
                spans = [s for s in (_parse_span(it) for it in ann) if s is not None]
                if len(spans) != len(ann):
                    warnings.append(f"SCHEMA_WALK_FAILURE at {path}.annotations: {len(ann) - len(spans)} malformed span(s) skipped")
                raw_text = node.get("text") if isinstance(node.get("text"), str) else ""
                units.append(AnnotationUnit(path=path, raw_text=raw_text, spans=spans))
            # A unit's own `text` may ALSO be a list of sub-clause dicts (CCPA (c)/(d)-style schema): always
            # recurse into it as additional SIBLING units -- never skip a level just because the parent already
            # emitted a unit, so no span is silently dropped.
            text_val = node.get("text")
            if isinstance(text_val, list):
                _walk(text_val, f"{path}.text", units, warnings, rel_counter)
            for k, v in node.items():
                if k in ("annotations", "text"):
                    continue
                if isinstance(v, (dict, list)):
                    _walk(v, f"{path}.{k}", units, warnings, rel_counter)
        elif isinstance(node, list):
            for i, item in enumerate(node):
                _walk(item, f"{path}[{i}]", units, warnings, rel_counter)
        # scalars (str/int/etc.) carry no further structure -- nothing to do, not a failure.
    except Exception as exc:                      # a single malformed node must never abort the whole walk
        warnings.append(f"SCHEMA_WALK_FAILURE at {path}: {type(exc).__name__}: {exc}")


def walk_structured_annotation(sa) -> WalkResult:
    units: list[AnnotationUnit] = []
    warnings: list[str] = []
    rel_counter = [0]
    if sa is not None:
        _walk(sa, "root", units, warnings, rel_counter)
    return WalkResult(units=units, num_relations=rel_counter[0], schema_warnings=warnings)


# ---------------------------------------------------------------------------------------------------------------
# Formula IR + Z3 source rendering
# ---------------------------------------------------------------------------------------------------------------
class Formula:
    def to_z3_src(self) -> str:
        raise NotImplementedError

    def to_summary(self) -> str:
        raise NotImplementedError

    def free_vars(self) -> list[str]:
        raise NotImplementedError


@dataclass
class FVar(Formula):
    name: str

    def to_z3_src(self):
        return f"self.{self.name}"

    def to_summary(self):
        return self.name

    def free_vars(self):
        return [self.name]


@dataclass
class FNot(Formula):
    inner: Formula

    def to_z3_src(self):
        return f"z3.Not({self.inner.to_z3_src()})"

    def to_summary(self):
        return f"Not({self.inner.to_summary()})"

    def free_vars(self):
        return self.inner.free_vars()


@dataclass
class FAnd(Formula):
    parts: list[Formula]

    def to_z3_src(self):
        return f"z3.And({', '.join(p.to_z3_src() for p in self.parts)})"

    def to_summary(self):
        return f"And({', '.join(p.to_summary() for p in self.parts)})"

    def free_vars(self):
        out = []
        for p in self.parts:
            out.extend(p.free_vars())
        return out


@dataclass
class FOr(Formula):
    parts: list[Formula]

    def to_z3_src(self):
        return f"z3.Or({', '.join(p.to_z3_src() for p in self.parts)})"

    def to_summary(self):
        return f"Or({', '.join(p.to_summary() for p in self.parts)})"

    def free_vars(self):
        out = []
        for p in self.parts:
            out.extend(p.free_vars())
        return out


@dataclass
class FImplies(Formula):
    antecedent: Formula
    consequent: Formula

    def to_z3_src(self):
        return f"z3.Implies({self.antecedent.to_z3_src()}, {self.consequent.to_z3_src()})"

    def to_summary(self):
        return f"Implies({self.antecedent.to_summary()}, {self.consequent.to_summary()})"

    def free_vars(self):
        return self.antecedent.free_vars() + self.consequent.free_vars()


# ---------------------------------------------------------------------------------------------------------------
# Variable naming: deterministic slugify of the annotation span's OWN text only (never tuned toward
# hpc_multiscenario_eval_s6b.classify_vars()'s keyword sets -- see module docstring and README's disclosed risk).
# ---------------------------------------------------------------------------------------------------------------
_SLUG_RE = re.compile(r"[^a-z0-9]+")


def slugify(text: str, max_len: int = 48) -> str:
    s = _SLUG_RE.sub("_", text.strip().lower()).strip("_")
    if not s:
        s = "v"
    if s[0].isdigit():
        s = f"v_{s}"
    if len(s) > max_len:
        cut = s.rfind("_", 0, max_len)
        s = s[:cut] if cut > 8 else s[:max_len]
        s = s.rstrip("_")
    return s


class VarNamer:
    """One instance per provision: identical span TEXT -> the same variable name; different text colliding to the
    same slug -> numeric suffix. Deterministic (no randomness, no dependence on dict/set iteration order beyond
    first-seen insertion order, which is itself fixed by the walk's document order)."""

    def __init__(self):
        self._text_to_name: dict[str, str] = {}
        self._used: set[str] = set()

    def get(self, text: str) -> str:
        if text in self._text_to_name:
            return self._text_to_name[text]
        base = slugify(text)
        name = base
        n = 2
        while name in self._used:
            name = f"{base}_{n}"
            n += 1
        self._used.add(name)
        self._text_to_name[text] = name
        return name


# ---------------------------------------------------------------------------------------------------------------
# Rule registry
# ---------------------------------------------------------------------------------------------------------------
RULES = {
    "R1": "Unconditional obligation: O -> O",
    "R2": "Prohibition: P -> Not(P)",
    "R3": "Condition + obligation: C,O -> Implies(C,O)",
    "R4": "Condition + prohibition: C,P -> Implies(C,Not(P))",
    "R5": "Guarded obligation with an explicitly attached exemption: C,E,O -> Implies(And(C,Not(E)),O)",
    "R6": "Guarded prohibition with an explicitly attached exemption (extension of R4/R5): C,E,P -> Implies(And(C,Not(E)),Not(P))",
    "R7": "Permission alone: PM -> Or(PM,Not(PM)) (non-binding, matches the evaluator's own 'may'-clause convention)",
}
REASON_CODES = {
    "NO_STRUCTURED_ANNOTATION": "The section has no usable structured_annotation at all (raw annotation string never parsed to JSON).",
    "NO_DEONTIC_CONTENT": "Every unit was inert (no obligation/prohibition/permission/condition/exemption span anywhere) -- there is nothing to encode as a Z3 constraint, so no meaningful program can be produced.",
    "SCHEMA_WALK_FAILURE": "A node in structured_annotation had a shape the generic walker could not interpret.",
    "UNMAPPED_LABEL": "A span's raw label does not resolve to a known class (7-class taxonomy, ARTIFACT, or OTHER) under the frozen normalization table; compiling would require guessing its deontic relevance.",
    "MULTI_ELEMENT_UNRESOLVED_COMPOSITION": "Two or more spans of the same deontic class co-occur in one unit; AND/OR composition among them is not encoded by the annotation.",
    "MIXED_POLARITY_UNRESOLVED": "An obligation and a prohibition co-occur in one unit with no condition/exemption distinguishing them; how they combine is not encoded.",
    "DANGLING_CONDITION_OR_EXEMPTION": "A condition and/or exemption span exists with no co-located obligation/prohibition in the same unit -- its target is not encoded (it may attach to an obligation/prohibition in a different unit of the same provision; see 'detail').",
}


def _bucket_counts(spans: list[AnnotationSpan]) -> dict[str, int]:
    counts = {c: 0 for c in CANON_CLASSES}
    for s in spans:
        if s.label_norm in counts:
            counts[s.label_norm] += 1
    return counts


def classify_unit(spans: list[AnnotationSpan]) -> dict:
    """Returns {'status': 'INERT'|'COMPILED'|'UNDER_SPECIFIED', 'rule_id':..., 'reason_code':..., 'detail':...,
    'deontic_spans': [...]} for ONE annotation unit. Exact-cardinality match only -- see module docstring."""
    unmapped = [s for s in spans if s.label_norm == "UNMAPPED"]
    deontic = [s for s in spans if s.label_norm in CANON_CLASSES]
    relevant = unmapped + deontic
    if not relevant:
        return {"status": "INERT"}
    if unmapped:
        return {"status": "UNDER_SPECIFIED", "reason_code": "UNMAPPED_LABEL",
                "detail": f"unmapped label(s): {sorted({s.label_raw for s in unmapped})}", "deontic_spans": deontic}

    counts = _bucket_counts(deontic)
    o, p, pm, c, e = (counts[k] for k in ("obligation", "prohibition", "permission", "condition", "exemption"))
    profile = (o, p, pm, c, e)
    exact = {
        (1, 0, 0, 0, 0): "R1", (0, 1, 0, 0, 0): "R2", (0, 0, 1, 0, 0): "R7",
        (1, 0, 0, 1, 0): "R3", (0, 1, 0, 1, 0): "R4",
        (1, 0, 0, 1, 1): "R5", (0, 1, 0, 1, 1): "R6",
    }
    if profile in exact:
        return {"status": "COMPILED", "rule_id": exact[profile], "deontic_spans": deontic}

    if max(profile) >= 2:
        return {"status": "UNDER_SPECIFIED", "reason_code": "MULTI_ELEMENT_UNRESOLVED_COMPOSITION",
                "detail": f"cardinalities o={o} p={p} pm={pm} c={c} e={e}", "deontic_spans": deontic}
    if o >= 1 and p >= 1:
        return {"status": "UNDER_SPECIFIED", "reason_code": "MIXED_POLARITY_UNRESOLVED",
                "detail": f"co-located obligation and prohibition, cardinalities o={o} p={p} pm={pm} c={c} e={e}",
                "deontic_spans": deontic}
    if (c >= 1 or e >= 1) and o == 0 and p == 0:
        return {"status": "UNDER_SPECIFIED", "reason_code": "DANGLING_CONDITION_OR_EXEMPTION",
                "detail": f"cardinalities o={o} p={p} pm={pm} c={c} e={e}", "deontic_spans": deontic}
    return {"status": "UNDER_SPECIFIED", "reason_code": "MULTI_ELEMENT_UNRESOLVED_COMPOSITION",
            "detail": f"unmatched combination o={o} p={p} pm={pm} c={c} e={e}", "deontic_spans": deontic}


def build_unit_formula(rule_id: str, deontic_spans: list[AnnotationSpan], namer: VarNamer) -> Formula:
    by_class: dict[str, list[str]] = {}
    for s in deontic_spans:
        by_class.setdefault(s.label_norm, []).append(namer.get(s.text))
    o = by_class.get("obligation", [None])[0]
    p = by_class.get("prohibition", [None])[0]
    pm = by_class.get("permission", [None])[0]
    c = by_class.get("condition", [None])[0]
    e = by_class.get("exemption", [None])[0]
    if rule_id == "R1":
        return FVar(o)
    if rule_id == "R2":
        return FNot(FVar(p))
    if rule_id == "R7":
        return FOr([FVar(pm), FNot(FVar(pm))])
    if rule_id == "R3":
        return FImplies(FVar(c), FVar(o))
    if rule_id == "R4":
        return FImplies(FVar(c), FNot(FVar(p)))
    if rule_id == "R5":
        return FImplies(FAnd([FVar(c), FNot(FVar(e))]), FVar(o))
    if rule_id == "R6":
        return FImplies(FAnd([FVar(c), FNot(FVar(e))]), FNot(FVar(p)))
    raise ValueError(f"unknown rule_id {rule_id!r}")


# ---------------------------------------------------------------------------------------------------------------
# Z3 class source rendering (matches scripts/LLM/lib/promting.py's FOL_Structure contract exactly)
# ---------------------------------------------------------------------------------------------------------------
_IDENT_RE = re.compile(r"[^0-9a-zA-Z_]")


def _class_name(act: str, section: str) -> str:
    # Always prefixed with "Deterministic_", so the result is a valid Python identifier regardless of `safe`.
    safe = _IDENT_RE.sub("_", f"{act}_{section}")
    return f"Deterministic_{safe}"


def render_z3_source(act: str, section: str, section_title: str, formula: Formula, var_names: list[str],
                      compiler_sha256: str) -> str:
    cname = _class_name(act, section)
    header = (
        f"# Deterministic Baseline -- annotation-to-Z3 compiler output (no LLM/SLM involved)\n"
        f"# Act       : {act}\n"
        f"# Section   : {section}\n"
        f"# Compiler  : scripts/additional_runs/deterministic_baseline/deterministic_compiler.py\n"
        f"# Compiler SHA256: {compiler_sha256}\n"
        f"# {'=' * 70}\n\n"
    )
    init_lines = "\n".join(f"        self.{v} = z3.Bool('{v}')" for v in var_names)
    body = (
        header +
        "import z3\n\n\n"
        f"class {cname}:\n"
        f'    """{section_title or (act + " " + section)} (deterministic compiler output)"""\n\n'
        "    def __init__(self):\n"
        f"{init_lines}\n\n"
        "    def get_rule(self):\n"
        f"        return {formula.to_z3_src()}\n\n"
        "    def verify_data(self, data):\n"
        "        solver = z3.Solver()\n"
        "        solver.add(self.get_rule())\n"
        "        for var_name, var_value in data.items():\n"
        "            if hasattr(self, var_name):\n"
        "                z3_var = getattr(self, var_name)\n"
        "                if isinstance(z3_var, z3.BoolRef):\n"
        "                    solver.add(z3_var == var_value)\n"
        "        return solver.check()\n\n\n"
        "if __name__ == '__main__':\n"
        f"    _section = {cname}()\n"
        f"    _data = {{{', '.join(f'{v!r}: True' for v in var_names)}}}\n"
        "    print(_section.verify_data(_data))\n"
    )
    return body


# ---------------------------------------------------------------------------------------------------------------
# Top-level API
# ---------------------------------------------------------------------------------------------------------------
def compiler_sha256() -> str:
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def section_id_from_path(p: Path) -> str:
    return p.stem


def load_provision_json(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def compile_provision(json_path: Path) -> dict:
    """The whole compiler D(a_hat) -> result dict. Pure function of the file's contents + this module's fixed
    rule table -- never reads S1-S6 labels, never calls an LLM."""
    json_path = Path(json_path)
    full = load_provision_json(json_path)
    act = full.get("act", "")
    section = section_id_from_path(json_path)
    section_title = full.get("section_title") or (full.get("source") or {}).get("title") or ""
    sha = compiler_sha256()

    base_result = {
        "act": act, "section": section, "annotation_path": str(json_path),
        "compiler_sha256": sha, "rules_applied": [], "annotation_elements_used": [],
        "compiled_formula_summary": "", "under_specified_reason": None,
        "num_units_total": 0, "num_units_deontic": 0, "num_units_compiled": 0, "num_units_under_specified": 0,
        "num_annotations": 0, "num_relations": 0,
    }

    sa = full.get("structured_annotation")
    if sa is None:
        base_result.update(status="UNDER_SPECIFIED",
                            under_specified_reason={"code": "NO_STRUCTURED_ANNOTATION",
                                                     "detail": REASON_CODES["NO_STRUCTURED_ANNOTATION"]})
        return base_result

    walk = walk_structured_annotation(sa)
    base_result["num_relations"] = walk.num_relations
    base_result["num_annotations"] = sum(len(u.spans) for u in walk.units)
    base_result["num_units_total"] = len(walk.units)

    namer = VarNamer()
    unit_formulas: list[Formula] = []
    rules_applied: list[str] = []
    elements_used: list[dict] = []
    failures: list[dict] = []

    for unit in walk.units:
        cls = classify_unit(unit.spans)
        if cls["status"] == "INERT":
            continue
        base_result["num_units_deontic"] += 1
        if cls["status"] == "COMPILED":
            base_result["num_units_compiled"] += 1
            rule_id = cls["rule_id"]
            formula = build_unit_formula(rule_id, cls["deontic_spans"], namer)
            unit_formulas.append(formula)
            rules_applied.append(f"{rule_id}@{unit.path}")
            for s in cls["deontic_spans"]:
                elements_used.append({"unit_path": unit.path, "span_text": s.text,
                                       "label_raw": s.label_raw, "label_norm": s.label_norm})
        else:
            base_result["num_units_under_specified"] += 1
            failures.append({"unit_path": unit.path, "code": cls["reason_code"], "detail": cls["detail"]})

    for w in walk.schema_warnings:
        failures.append({"unit_path": "(walk)", "code": "SCHEMA_WALK_FAILURE", "detail": w})
        base_result["num_units_under_specified"] += 1

    if failures:
        # Cross-unit enrichment: if a DANGLING_CONDITION_OR_EXEMPTION failure's spans are exemptions, and some
        # OTHER unit in this same provision independently compiled an obligation/prohibition, note the plausible
        # cross-unit attachment explicitly (diagnostic text only -- never auto-resolved/compiled).
        has_other_duty = base_result["num_units_compiled"] > 0
        for f in failures:
            if f["code"] == "DANGLING_CONDITION_OR_EXEMPTION" and has_other_duty:
                f["detail"] += (" -- this provision has an obligation/prohibition compiled from a DIFFERENT unit; "
                                 "possible cross-unit exemption/condition attachment, not resolvable from the "
                                 "annotation schema (see README's CCPA Sec1798_105 example).")
        base_result.update(status="UNDER_SPECIFIED", under_specified_reason=failures[0], rules_applied=rules_applied,
                            annotation_elements_used=elements_used)
        base_result["_all_failures"] = failures            # full list, for ambiguity_examples.md / diagnostics
        return base_result

    if not unit_formulas:
        base_result.update(status="UNDER_SPECIFIED",
                            under_specified_reason={"code": "NO_DEONTIC_CONTENT", "detail": REASON_CODES["NO_DEONTIC_CONTENT"]})
        return base_result

    formula = unit_formulas[0] if len(unit_formulas) == 1 else FAnd(unit_formulas)
    seen_vars: set = set()
    var_names: list[str] = []
    for v in formula.free_vars():                  # de-dup preserving first-occurrence order (deterministic)
        if v not in seen_vars:
            seen_vars.add(v)
            var_names.append(v)
    z3_source = render_z3_source(act, section, section_title, formula, var_names, sha)

    base_result.update(status="COMPILED", rules_applied=rules_applied, annotation_elements_used=elements_used,
                        compiled_formula_summary=formula.to_summary())
    base_result["_z3_source"] = z3_source               # not part of the CSV schema; consumed by run_all.py
    base_result["_var_names"] = var_names
    return base_result


def iter_all_provisions():
    """(act, section, path) for all 238 real section files, fixed act order, sorted filenames within each act."""
    for act, dirname in ACT_DIRS.items():
        d = DATASET / dirname
        for f in sorted(d.glob("*.json")):
            if f.name == "aggregate_metrics.json":
                continue
            yield act, f.stem, f
