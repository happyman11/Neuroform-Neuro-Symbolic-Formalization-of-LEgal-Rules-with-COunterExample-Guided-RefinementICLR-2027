# Deterministic baseline: â → φ_det (no LLM, no SLM)

> **ICLR supplementary bundle note**: `deterministic_compiler.py`'s `REPO`/`DATASET` path resolution, and every
> other script's `HPC_ForAbstract/` import, were repointed to this bundle's own `../Benchmark/dataset` and
> `../S1-S6_Evaluation/` (same content, self-contained -- no dependency on anything outside `ICLR_Submission/`).
> `evaluate_existing_s1s6.py` additionally reads `Results_S1S6_theta08/metrics/headline.json` for its
> 75.07%/78.43% comparison figures -- that results directory is not part of this bundle (it holds report
> artifacts, not code); the script's own coverage/STOP-condition output (the actual finding this study reports)
> does not depend on it and is unaffected.

**Reviewer question**: *Can the expert-verified annotation â be compiled directly and deterministically into an
executable Z3 specification, without using an LLM?*

**Answer (evidence below): no, not at scale.** A single fixed, auditable, LLM-free compiler was built exactly to
the task's own rule spec, piloted, and then run over the full annotation corpus (this measurement is itself
annotation-only, so it does not violate the "pilot before full run" spirit — see "What was actually run" below).
Coverage is **19/238 (7.98%)**. The **STOP condition fired**: 57.98% of the corpus is under-specified for reasons
in the composition/scope/attachment family (not just missing data), which is the task's own explicit STOP
criterion. No heuristics were added to inflate this number and the annotation was never modified.

## Design

`deterministic_compiler.py` implements exactly the five rules given in the task, plus one disclosed, directly-
derived extension (R6, the same C/E substitution the task itself made going from its "condition+obligation" rule
to its "guarded obligation" rule, applied to "condition+prohibition" instead), plus one small addition for lone
permissions (R7, matching the S1-S6 evaluator's own documented convention that permissive "may" clauses are
non-binding):

| Rule | Pattern | Compiled Z3 |
|---|---|---|
| R1 | `O=1` | `self.<o>` |
| R2 | `P=1` | `Not(self.<p>)` |
| R3 | `C=1,O=1` | `Implies(C,O)` |
| R4 | `C=1,P=1` | `Implies(C,Not(P))` |
| R5 | `C=1,E=1,O=1` | `Implies(And(C,Not(E)),O)` |
| R6 | `C=1,E=1,P=1` | `Implies(And(C,Not(E)),Not(P))` (extension) |
| R7 | `PM=1` | `Or(PM,Not(PM))` (non-binding tautology; addition) |

Rules match a single annotation **unit**'s exact deontic-class cardinalities — no partial matches. Anything else
(≥2 of one class, bare obligation+prohibition, a dangling condition/exemption with no target in the same unit, an
unresolved label) is `UNDER_SPECIFIED` with a specific reason code — never guessed. A whole provision is
`COMPILED` only if *every* non-inert unit compiled; its `get_rule()` is the `And` of all compiled units' formulas
(one fixed, disclosed, corpus-wide convention — not inferred per provision).

Full rule/rationale/reason-code documentation is in `deterministic_compiler.py`'s module docstring — read it
before extending anything.

## Files

| File | Role |
|---|---|
| `deterministic_compiler.py` | The whole compiler: generic annotation walker, label normalizer, R1–R7 rule engine, Z3-source renderer, `compile_provision()`. Single source of truth — imported, never copy-pasted, by every other script here. |
| `run_pilot.py` | Phase 2/3: stratified ~16-provision selection + a full read-only 238-provision population scan (both annotation-only). Writes `pilot_results.csv`, `ambiguity_examples.md`, `rules_ledger.json`. |
| `run_all.py` | Phase 4: applies the frozen compiler to all 238, gated behind a compiler-hash check and an explicit confirmation flag; refuses to run without an explicit override when the ledger's recommendation is `STOP` (as it is here — **not run for real**). |
| `evaluate_existing_s1s6.py` | Phase 5: runs every `COMPILED` output through the repo's own unmodified `HPC_ForAbstract/hpc_multiscenario_eval_s6b.py:load_and_evaluate`. **Not run for real** — nothing to evaluate since Phase 4 did not run. |
| `test_deterministic_compiler.py` | Offline, no GPU: per-rule + per-reason-code fixtures (several round-tripped through the real evaluator), a no-leakage check, a determinism check, a corpus-wide label-coverage sweep. |
| `pilot_results.csv`, `ambiguity_examples.md`, `rules_ledger.json` | Phase 2/3 outputs (present). |
| `compilation_results.csv` | Phase 4/5 output — **does not exist**, because Phase 4 did not run (STOP). |

## What was actually run (and why the population scan isn't "running all 238 first")

The task's stratified-pilot categories (single-obligation, single-prohibition, condition+X, exemption+X, ...) are
themselves defined by *which rule or reason fired* on a provision. Building a category-diverse sample of ~16
provisions therefore requires compiling all 238 once to know which category each one falls into — this is a
read-only pass over the *annotation files only* (`deterministic_compiler.compile_provision`, which never opens
`HPC_ForAbstract/` or `Results_S1S6_theta08/` — see `test_deterministic_compiler.py`'s no-leakage check), not an
S1–S6 run. `run_pilot.py` reports two numbers, kept clearly separate:

- **Pilot selection** (16 provisions): deliberately over-samples the rule patterns so every one is demonstrated at
  least once — its own coverage % (56.25% in the current run) is **not** a population estimate.
- **Population** (all 238): the real, unbiased, annotation-only Phase-3 decision statistic (7.98% coverage).

## Deliberate deviations / disclosed decisions

- **AND-of-units default.** A provision's independently-drafted subsections are conjoined; this is a single,
  global, disclosed convention, not inferred per provision.
- **Raw (no E4v-guard) evaluation** would be used in Phase 5, matching how this repo already scores baselines
  (b1–b9), never how it scores NeuroFORM itself — the deterministic compiler is an external method, not NeuroFORM.
- **Pure span-text variable naming**, with no class-tag prefix. Because the evaluator's `classify_vars()`
  classifies exception/obligation variables purely by keyword substrings in the *name*, adding a prefix like
  `exempt_...` would silently and predictably shift S3–S6 scores — this is named explicitly as a risk, not
  "fixed."
- **R3/R4 apply uniformly regardless of "if" vs. "unless" phrasing.** The annotation schema has no field for this
  polarity; the task's own rule table gives `Implies(C,O)` unconditionally for a bare condition+obligation pair.
  A concrete consequence: CCPA `Sec1798_105(c)(1)`'s defeater ("...unless this proves impossible...") is labeled
  `#condition`, not `#exemption`, so it compiles via R3 as a trigger, not a defeater — a known, disclosed
  labeling/schema limitation (see the worked example below), not something this compiler silently "corrects."
- **A bare prohibition (R2) structurally cannot pass S1 or S2** under the evaluator's fixed scenario semantics: S1
  needs the all-True assignment to be `sat`, but `Not(P)` with `P=True` is inherently `unsat`; S2 needs all-False
  to be `unsat`, but `Not(P)` with `P=False` is inherently `sat`. This was caught by `test_deterministic_compiler.py`
  and is an inherent mismatch between S1/S2's obligation-shaped design and a bare prohibition rule, not a bug.
- **The <15-file `relations`/`relationships`/`entities` fields are deliberately unused** — relying on them would
  make the compiler's leniency depend on which file happened to get one.

## Read the result with these caveats

- The corpus's label vocabulary is open (256 distinct raw labels found by this module's own walker); the frozen
  normalization table resolves 94 of them (base 41 + 12 hand-reviewed exact-string additions + 41 via simple
  suffix rules), covering 89.9% of all span *occurrences* — the remaining 10.1% are `UNMAPPED` and block any unit
  they appear in (conservatively, by design).
- A blind human re-annotation QA study (`AAAI-Dataset/SOP_4acts.tex`, 30/238 sections) found 81.3% span-label
  agreement / κ=0.79, with disagreement concentrated exactly on `#condition` vs. `#exemption` and `#right` vs.
  `#permission` — precisely the boundaries this compiler's rules are most sensitive to.
- `deterministic_compiler.py`'s own module docstring is the canonical rule/reason-code reference; this README
  summarizes it, not the other way around.

## Worked example: CCPA Sec1798_105 (two kinds of ambiguity in one provision)

`AAAI-Dataset/dataset/CCPA_Act/Sec1798_105.json` — subsection (b) alone compiles via R1; subsection (c)(1) compiles
via R3 (the "unless...impossible" defeater mislabeled `#condition`, see above). But the provision as a whole is
`UNDER_SPECIFIED`: subsection (a) has a co-located `#right`+`#obligation` (`MULTI_ELEMENT_UNRESOLVED_COMPOSITION`
— AND or OR?), and subsection (d)(1)–(8) has **eight separate `#exemption`-labeled clauses**, each in its own
sibling unit, with no field linking any of them back to (c)'s obligation (`DANGLING_CONDITION_OR_EXEMPTION`, with
this compiler's own diagnostic correctly noting "this provision has an obligation compiled from a different
unit" — i.e. a plausible but unencoded cross-unit exemption attachment). Two competing, equally schema-consistent
Z3 programs exist for (d): one where each exemption gates (c)'s obligation, one where the exemptions are inert —
nothing in the annotation distinguishes them. `ambiguity_examples.md` has a second, independently-found instance
of the same cross-unit pattern in a DPDP provision, confirming this is a recurring, not one-off, gap.

## Run

```bash
cd scripts/additional_runs/deterministic_baseline
python3 test_deterministic_compiler.py            # offline, no GPU, run this first
python3 run_pilot.py --n 16                        # writes pilot_results.csv, ambiguity_examples.md, rules_ledger.json
# read rules_ledger.json's "recommendation" -- STOP means the below are gated and were not run for real here:
python3 run_all.py --confirm-continue-from-pilot                    # refuses: recommendation is STOP
python3 evaluate_existing_s1s6.py                                   # not run: run_all.py never produced output
```

## What is reported

- **Compilation Coverage** = compiled/238, computed purely from `compile_provision()`, never from S1–S6.
- **Behavioral Accuracy**, if Phase 4/5 ever ran, would use the fixed 238×6=1428 denominator (uncompiled/errored
  sections count 0/6), exactly mirroring `Results_S1S6_theta08/scripts/metrics.py`'s own `pct_strict` convention,
  read live against `Results_S1S6_theta08/metrics/headline.json`'s 75.07%/78.43% NeuroFORM figures rather than
  hardcoding them — kept visibly separate from "accuracy on the compiled subset only."

## Local test

```bash
python3 test_deterministic_compiler.py
```
