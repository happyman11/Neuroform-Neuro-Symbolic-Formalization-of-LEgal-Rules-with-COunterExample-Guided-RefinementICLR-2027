#!/usr/bin/env python3
"""
evaluate_existing_s1s6.py -- Phase 5: run EVERY output of run_all.py through the repo's existing, UNMODIFIED
S1-S6 evaluator (HPC_ForAbstract/hpc_multiscenario_eval_s6b.py's load_and_evaluate()) and compute:

  Compilation Coverage = #COMPILED / 238                       (compile-time, independent of S1-S6)
  Behavioral Accuracy  = sum(passed over ALL 238) / (238 * 6)  (fixed 238x6=1428 denominator, uncompiled/errored
                                                                 sections contribute 0/6 -- mirrors exactly how
                                                                 Results_S1S6_theta08/scripts/metrics.py computes
                                                                 the headline SLM/LLM pct_strict figures)

plus, separately and never conflated with the above, "accuracy on the compiled subset only" (num_correct /
(num_compiled*6)). Evaluated RAW (no E4v guard) -- the deterministic compiler is a from-scratch external method,
scored the same way this repo already scores its baselines (b1-b9), never the way it scores NeuroFORM itself.
Reads the 75.07%/78.43% comparison figures LIVE from Results_S1S6_theta08/metrics/headline.json at runtime,
never hardcoded.

Rewrites compilation_results.csv in place with evaluation_status/num_scenarios/num_correct/behavioral_accuracy
filled in.

    python3 evaluate_existing_s1s6.py
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import deterministic_compiler as DC  # noqa: E402

# ICLR supplementary: repointed from the original tree's HPC_ForAbstract/ to this bundle's own
# S1-S6_Evaluation/ (same file, see that folder's README).
sys.path.insert(0, str(DC.REPO / "S1-S6_Evaluation"))
import hpc_multiscenario_eval_s6b as H  # noqa: E402

OUT_ROOT = DC.REPO / "DeterministicBaseline_Output"


def main() -> int:
    csv_path = HERE / "compilation_results.csv"
    if not csv_path.exists():
        print(f"REFUSING: {csv_path} does not exist. Run run_all.py first.", file=sys.stderr)
        return 2
    if not OUT_ROOT.exists():
        print(f"REFUSING: {OUT_ROOT} does not exist. Run run_all.py first.", file=sys.stderr)
        return 2

    with open(csv_path, encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))

    n_correct_total = 0
    n_compiled = 0
    n_correct_compiled = 0
    for row in rows:
        prog = OUT_ROOT / row["act"] / row["section"] / "Deterministic" / "05_final_code.py"
        if row["status"] != "COMPILED" or not prog.exists():
            row["evaluation_status"] = "NOT_COMPILED"
            row["num_scenarios"] = 6
            row["num_correct"] = 0
            row["behavioral_accuracy"] = 0.0
            continue
        n_compiled += 1
        res = H.load_and_evaluate(prog)
        if "error" in res:
            row["evaluation_status"] = f"EVAL_ERROR:{res['error']}"
            row["num_scenarios"] = 6
            row["num_correct"] = 0
        else:
            row["evaluation_status"] = "EVALUATED"
            row["num_scenarios"] = 6
            row["num_correct"] = res["passed"]
            n_correct_compiled += res["passed"]
        row["behavioral_accuracy"] = round(100 * int(row["num_correct"]) / 6, 2)
        n_correct_total += int(row["num_correct"])

    n_total = len(rows)
    coverage_pct = round(100 * n_compiled / n_total, 2) if n_total else 0.0
    behavioral_accuracy_pct = round(100 * n_correct_total / (n_total * 6), 2) if n_total else 0.0
    compiled_subset_accuracy_pct = (round(100 * n_correct_compiled / (n_compiled * 6), 2) if n_compiled else None)

    with open(csv_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    headline_path = DC.REPO / "Results_S1S6_theta08" / "metrics" / "headline.json"
    nf_slm = nf_llm = None
    if headline_path.exists():
        hl = json.loads(headline_path.read_text(encoding="utf-8"))
        # read live rather than hardcode -- structure per prior investigation: guard/headline/<tier>|theta08/filled238
        try:
            nf_slm = hl["guard"]["headline"]["slm|theta08"]["filled238"]["pct"]
            nf_llm = hl["guard"]["headline"]["llm|theta08"]["filled238"]["pct"]
        except Exception:
            pass

    print(f"Compilation Coverage: {n_compiled}/{n_total} ({coverage_pct}%)")
    print(f"Behavioral Accuracy (denominator = {n_total}*6 = {n_total * 6}, fixed, matching the repo's own "
          f"headline convention): {n_correct_total}/{n_total * 6} ({behavioral_accuracy_pct}%)")
    if compiled_subset_accuracy_pct is not None:
        print(f"  (accuracy on the COMPILED SUBSET ONLY, denominator = {n_compiled}*6 = {n_compiled * 6} -- "
              f"NOT comparable to the figure above or to NeuroFORM's 238-denominator numbers): "
              f"{n_correct_compiled}/{n_compiled * 6} ({compiled_subset_accuracy_pct}%)")
    print()
    print("| Method | Provisions | Compilation Coverage | Behavioral Accuracy |")
    print("|---|---:|---:|---:|")
    print(f"| Deterministic a_hat -> Z3 (raw, no E4v guard) | {n_total} | {n_compiled}/{n_total} ({coverage_pct}%) | {behavioral_accuracy_pct}% |")
    if nf_slm is not None:
        print(f"| NeuroFORM SLM | {n_total} | {n_total}/{n_total} | {nf_slm}% |")
    if nf_llm is not None:
        print(f"| NeuroFORM LLM | {n_total} | {n_total}/{n_total} | {nf_llm}% |")
    if nf_slm is None or nf_llm is None:
        print(f"(NeuroFORM comparison figures not read live -- {headline_path} missing or unexpected shape.)")
    print(f"\nWrote {csv_path}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
