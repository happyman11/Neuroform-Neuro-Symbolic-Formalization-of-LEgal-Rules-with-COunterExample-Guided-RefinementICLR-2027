#!/usr/bin/env python3
"""
run_pilot.py -- Phase 2/3 driver: pilot deterministic_compiler.py on ~N representative provisions and report
whether full-corpus (238) deterministic compilation is scientifically justified.

Selection method (deterministic, NOT random, NEVER touches S1-S6 scenario labels or HPC_ForAbstract/
Results_S1S6_theta08 -- see test_deterministic_compiler.py's no-leakage check):

  1. Compile all 238 provisions once (read-only; this only exercises deterministic_compiler.py against the
     annotation files, the same operation the full run would do -- it is not "peeking" at any ground truth).
  2. Tag each provision with every CATEGORY (below) it matches, derived purely from its own compile_provision()
     result (which rule/reason fired, unit counts) -- never from expected scenario verdicts.
  3. Walk CATEGORIES in a fixed order; for each, pick one not-yet-selected representative, preferring the next
     unused act in a fixed round-robin (GDPR, CCPA, DPDP, PIPD) so the pilot spans all four acts. Two passes
     (second pass adds a second representative per category, different act) run until --n is reached or every
     (category, act) combination is exhausted. Within an act, the tie-break is alphabetical section id -- fixed,
     reproducible, not chosen to make any particular outcome look better.

Outputs: pilot_results.csv, ambiguity_examples.md, rules_ledger.json (the Phase-4 freeze receipt).

    python3 run_pilot.py [--n 16]
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import deterministic_compiler as DC  # noqa: E402

ACT_ORDER = ["GDPR", "CCPA", "DPDP", "PIPD"]

# Category -> predicate(compile_result) -> bool. Order is the fixed pick order (Phase-2's requested spread:
# obligation, prohibition, condition, permission, exemption/exception, multiple conditions, multiple obligations,
# nested/compound structures, plus the cross-unit and data-availability categories this corpus actually has).
def _rule_ids(r):
    return {x.split("@")[0] for x in r.get("rules_applied", [])}


def _reason(r):
    return (r.get("under_specified_reason") or {}).get("code")


CATEGORIES: list[tuple[str, callable]] = [
    ("single_obligation", lambda r: r["status"] == "COMPILED" and _rule_ids(r) == {"R1"}),
    ("single_prohibition", lambda r: r["status"] == "COMPILED" and _rule_ids(r) == {"R2"}),
    ("single_permission", lambda r: r["status"] == "COMPILED" and _rule_ids(r) == {"R7"}),
    ("condition_plus_obligation", lambda r: r["status"] == "COMPILED" and "R3" in _rule_ids(r)),
    ("condition_plus_prohibition", lambda r: r["status"] == "COMPILED" and "R4" in _rule_ids(r)),
    ("exemption_guarded_obligation", lambda r: r["status"] == "COMPILED" and "R5" in _rule_ids(r)),
    ("exemption_guarded_prohibition", lambda r: r["status"] == "COMPILED" and "R6" in _rule_ids(r)),
    ("nested_multi_unit_compiled", lambda r: r["status"] == "COMPILED" and r["num_units_total"] >= 3),
    ("multi_element_composition", lambda r: r["status"] == "UNDER_SPECIFIED" and _reason(r) == "MULTI_ELEMENT_UNRESOLVED_COMPOSITION"),
    ("cross_unit_exemption_attachment", lambda r: r["status"] == "UNDER_SPECIFIED" and _reason(r) == "DANGLING_CONDITION_OR_EXEMPTION"
                                                    and "cross-unit" in (r["under_specified_reason"].get("detail") or "")),
    ("mixed_polarity", lambda r: r["status"] == "UNDER_SPECIFIED" and _reason(r) == "MIXED_POLARITY_UNRESOLVED"),
    ("unmapped_label", lambda r: r["status"] == "UNDER_SPECIFIED" and _reason(r) == "UNMAPPED_LABEL"),
    ("no_structured_annotation", lambda r: r["status"] == "UNDER_SPECIFIED" and _reason(r) == "NO_STRUCTURED_ANNOTATION"),
]


def compile_all() -> dict[tuple[str, str], dict]:
    out = {}
    for act, sec, path in DC.iter_all_provisions():
        out[(act, sec)] = DC.compile_provision(path)
    return out


def select_pilot(all_results: dict, n_target: int) -> list[tuple[str, str, str]]:
    """[(act, section, category)] -- deterministic, act-diverse, two-pass round-robin. See module docstring."""
    by_cat_act: dict[str, dict[str, list[str]]] = {cat: defaultdict(list) for cat, _ in CATEGORIES}
    for (act, sec), r in all_results.items():
        for cat, pred in CATEGORIES:
            if pred(r):
                by_cat_act[cat][act].append(sec)
    for cat in by_cat_act:
        for act in by_cat_act[cat]:
            by_cat_act[cat][act].sort()

    selected: list[tuple[str, str, str]] = []
    used: set[tuple[str, str]] = set()

    def pick_pass(pass_idx: int):
        for cat_idx, (cat, _pred) in enumerate(CATEGORIES):
            if len(selected) >= n_target:
                return
            acts_for_cat = by_cat_act[cat]
            rotated = ACT_ORDER[(cat_idx + pass_idx) % 4:] + ACT_ORDER[:(cat_idx + pass_idx) % 4]
            for act in rotated:
                secs = [s for s in acts_for_cat.get(act, []) if (act, s) not in used]
                if secs:
                    sec = secs[0]
                    selected.append((act, sec, cat))
                    used.add((act, sec))
                    break

    pick_pass(0)
    pick_pass(1)
    pick_pass(2)
    return selected[:n_target]


def make_ambiguity_examples(all_results: dict, selection: list[tuple[str, str, str]]) -> str:
    """2-3 concrete UNDER_SPECIFIED cases from the pilot, preferring distinct reason codes, richest detail first."""
    candidates = []
    for act, sec, cat in selection:
        r = all_results[(act, sec)]
        if r["status"] != "UNDER_SPECIFIED":
            continue
        n_fail = len(r.get("_all_failures", [r["under_specified_reason"]]))
        candidates.append((n_fail, act, sec, r))
    candidates.sort(key=lambda x: -x[0])
    seen_codes: set[str] = set()
    chosen = []
    for n_fail, act, sec, r in candidates:
        code = r["under_specified_reason"]["code"]
        if code in seen_codes and len(chosen) >= 2:
            continue
        seen_codes.add(code)
        chosen.append((act, sec, r))
        if len(chosen) >= 3:
            break

    lines = ["# Ambiguity examples (from the Phase-2 pilot)\n",
             "Each case: the annotation elements involved, two literally-competing Z3 interpretations neither of",
             "which the annotation schema can distinguish, and the exact missing information.\n"]
    for act, sec, r in chosen:
        path = DC.DATASET / DC.ACT_DIRS[act] / f"{sec}.json"
        full = DC.load_provision_json(path)
        title = full.get("section_title") or (full.get("source") or {}).get("title") or ""
        lines.append(f"\n## {act} / {sec} -- {title}\n")
        lines.append(f"`annotation_path`: `{path.relative_to(DC.REPO)}`\n")
        reason = r["under_specified_reason"]
        lines.append(f"**Reason code**: `{reason['code']}` -- {DC.REASON_CODES[reason['code']]}\n")
        lines.append(f"**Detail**: {reason['detail']}\n")
        failures = r.get("_all_failures", [reason])
        if len(failures) > 1:
            lines.append(f"\nThis provision has {len(failures)} under-specified units in total; showing the primary one above "
                          f"plus a second below for contrast.\n")
        walk = DC.walk_structured_annotation(full.get("structured_annotation"))
        target_path = reason["unit_path"]
        unit = next((u for u in walk.units if u.path == target_path), None)
        if unit is not None:
            lines.append(f"\n**Annotation** (`{unit.path}`):\n")
            if unit.raw_text:
                lines.append(f"> {unit.raw_text}\n")
            for s in unit.spans:
                lines.append(f"- `{s.label_raw}` (-> `{s.label_norm}`): \"{s.text}\"")
            lines.append("")
            if reason["code"] == "MULTI_ELEMENT_UNRESOLVED_COMPOSITION":
                lines.append("**Candidate interpretation A** (AND):\n```\nAnd(" +
                              ", ".join(f"self.{DC.slugify(s.text)}" for s in unit.spans if s.label_norm in DC.CANON_CLASSES) +
                              ")\n```")
                lines.append("**Candidate interpretation B** (OR):\n```\nOr(" +
                              ", ".join(f"self.{DC.slugify(s.text)}" for s in unit.spans if s.label_norm in DC.CANON_CLASSES) +
                              ")\n```")
                lines.append("**Missing information**: AND vs. OR composition among same-class siblings -- the "
                              "schema gives no field distinguishing these.\n")
            elif reason["code"] == "DANGLING_CONDITION_OR_EXEMPTION":
                other = next((u for u in walk.units if u.path != target_path and
                               any(s.label_norm in ("obligation", "prohibition") for s in u.spans)), None)
                other_o = next((s for s in (other.spans if other else []) if s.label_norm in ("obligation", "prohibition")), None)
                if other_o is not None:
                    lines.append(f"**Candidate interpretation A** (exemption attaches to the obligation/prohibition in "
                                  f"unit `{other.path}`):\n```\nImplies(Not(self.{DC.slugify(unit.spans[0].text)}), "
                                  f"self.{DC.slugify(other_o.text)})\n```")
                    lines.append("**Candidate interpretation B** (exemption attaches to nothing -- it is inert / a "
                                  "definition, not a live defeater in this program):\n```\n(no constraint added)\n```")
                    lines.append("**Missing information**: exemption/condition-to-obligation attachment -- the "
                                  "schema has no field linking a condition/exemption span in one structural unit "
                                  "to an obligation/prohibition span in a different one.\n")
            elif reason["code"] == "MIXED_POLARITY_UNRESOLVED":
                o_span = next((s for s in unit.spans if s.label_norm == "obligation"), None)
                p_span = next((s for s in unit.spans if s.label_norm == "prohibition"), None)
                if o_span and p_span:
                    lines.append(f"**Candidate interpretation A** (independent, conjoined duties):\n```\nAnd(self.{DC.slugify(o_span.text)}, "
                                  f"Not(self.{DC.slugify(p_span.text)}))\n```")
                    lines.append(f"**Candidate interpretation B** (the prohibition qualifies/limits the obligation):\n```\n"
                                  f"Implies(self.{DC.slugify(o_span.text)}, Not(self.{DC.slugify(p_span.text)}))\n```")
                    lines.append("**Missing information**: whether the obligation and prohibition are independent "
                                  "requirements or one conditions the other.\n")
    return "\n".join(lines) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--n", type=int, default=16, help="target pilot size (default 16)")
    args = ap.parse_args()

    all_results = compile_all()
    selection = select_pilot(all_results, args.n)

    # ---- population statistics (all 238, unbiased) -----------------------------------------------------------
    # The stratified pilot SELECTION below is deliberately skewed toward showing every rule/failure pattern at
    # least once (that is its purpose: exercise the compiler on diverse structures, per the task's request) --
    # its own coverage % is therefore NOT a valid estimate of the true corpus-wide compilability rate. Computing
    # deterministic_compiler.compile_provision() over all 238 files is itself annotation-only (no S1-S6 access
    # whatsoever -- see the no-leakage test), so this population figure is exactly as leakage-free as the pilot
    # and is what Phase 3's STOP/CONTINUE decision is actually based on, not the biased selection below.
    pop_n = len(all_results)
    pop_compiled = sum(1 for r in all_results.values() if r["status"] == "COMPILED")
    pop_coverage_pct = round(100 * pop_compiled / pop_n, 2) if pop_n else 0.0
    pop_reason_hist: dict[str, int] = defaultdict(int)
    for r in all_results.values():
        if r["status"] == "UNDER_SPECIFIED":
            pop_reason_hist[r["under_specified_reason"]["code"]] += 1

    rows = []
    for act, sec, cat in selection:
        r = all_results[(act, sec)]
        reason = r.get("under_specified_reason") or {}
        rows.append({
            "act": act, "section": sec, "annotation_path": r["annotation_path"], "status": r["status"],
            "reason": reason.get("code", ""), "num_annotations": r["num_annotations"],
            "num_relations": r["num_relations"], "compiled_formula_summary": r["compiled_formula_summary"],
            "_category": cat,
        })

    out_csv = HERE / "pilot_results.csv"
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["act", "section", "annotation_path", "status", "reason",
                                            "num_annotations", "num_relations", "compiled_formula_summary"])
        w.writeheader()
        for row in rows:
            w.writerow({k: row[k] for k in w.fieldnames})

    n_compiled = sum(1 for row in rows if row["status"] == "COMPILED")
    n_under = len(rows) - n_compiled
    coverage_pct = round(100 * n_compiled / len(rows), 2) if rows else 0.0
    reason_hist: dict[str, int] = defaultdict(int)
    for row in rows:
        if row["status"] == "UNDER_SPECIFIED":
            reason_hist[row["reason"]] += 1
    STRUCTURAL_FAMILY = {"MULTI_ELEMENT_UNRESOLVED_COMPOSITION", "MIXED_POLARITY_UNRESOLVED",
                          "DANGLING_CONDITION_OR_EXEMPTION"}
    n_structural = sum(v for k, v in reason_hist.items() if k in STRUCTURAL_FAMILY)
    structural_fraction = round(100 * n_structural / len(rows), 2) if rows else 0.0

    (HERE / "ambiguity_examples.md").write_text(make_ambiguity_examples(all_results, selection), encoding="utf-8")

    pop_structural = sum(v for k, v in pop_reason_hist.items() if k in STRUCTURAL_FAMILY)
    pop_structural_fraction = round(100 * pop_structural / pop_n, 2) if pop_n else 0.0
    recommendation = "STOP" if pop_structural_fraction >= 25.0 else "CONTINUE"

    ledger = {
        "compiler_sha256": DC.compiler_sha256(),
        "rules": DC.RULES, "reason_codes": DC.REASON_CODES,
        "selection_method": __doc__.split("Selection method")[1].split("Outputs:")[0].strip(),
        "pilot": {
            "n_pilot": len(rows), "n_compiled": n_compiled, "n_under_specified": n_under,
            "coverage_pct": coverage_pct, "reason_histogram": dict(reason_hist),
            "structural_ambiguity_fraction_pct": structural_fraction,
            "note": "This selection is deliberately stratified to exercise every rule/failure pattern at least "
                    "once -- its coverage_pct is NOT a population estimate. See 'population_238' for that.",
        },
        "population_238": {
            "n": pop_n, "n_compiled": pop_compiled, "coverage_pct": pop_coverage_pct,
            "reason_histogram": dict(pop_reason_hist), "structural_ambiguity_fraction_pct": pop_structural_fraction,
        },
        "structural_ambiguity_family": sorted(STRUCTURAL_FAMILY),
        "recommendation": recommendation,
        "recommendation_rule": "STOP if population_238.structural_ambiguity_fraction_pct >= 25% (composition/"
                                "scope/attachment gaps, the family the task's STOP condition is about -- "
                                "data-availability gaps like NO_STRUCTURED_ANNOTATION/UNMAPPED_LABEL/"
                                "SCHEMA_WALK_FAILURE are counted separately and do not drive this threshold).",
        "categories_selected": [{"act": a, "section": s, "category": c} for a, s, c in selection],
    }
    (HERE / "rules_ledger.json").write_text(json.dumps(ledger, indent=2), encoding="utf-8")

    print(f"Pilot SELECTION (stratified, not a coverage estimate): {len(rows)} provisions, "
          f"{len(set(r[0] for r in selection))} acts, {len(set(c for _, _, c in selection))} categories.")
    print(f"  COMPILED: {n_compiled}  UNDER_SPECIFIED: {n_under}  reason histogram: {dict(reason_hist)}")
    print()
    print(f"POPULATION (all {pop_n} provisions, the real decision statistic):")
    print(f"  Coverage: {pop_coverage_pct}%  ({pop_compiled}/{pop_n} COMPILED)")
    print(f"  Reason histogram: {dict(pop_reason_hist)}")
    print(f"  Structural-ambiguity family fraction (composition/scope/attachment gaps): {pop_structural_fraction}%")
    print()
    print(f"RECOMMENDATION: {recommendation}  (rule: {ledger['recommendation_rule']})")
    print(f"Wrote {out_csv}, ambiguity_examples.md, rules_ledger.json (compiler_sha256={DC.compiler_sha256()[:16]}...)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
