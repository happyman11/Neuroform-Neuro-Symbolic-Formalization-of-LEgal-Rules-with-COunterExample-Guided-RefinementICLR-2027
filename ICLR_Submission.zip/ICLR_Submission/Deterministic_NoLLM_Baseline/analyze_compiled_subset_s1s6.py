#!/usr/bin/env python3
"""
analyze_compiled_subset_s1s6.py -- DIAGNOSTIC ONLY, not Phase 5. Evaluates the 19/238 provisions that COMPILED
in the STOPPED pilot (see README.md -- the population-wide recommendation is STOP, run_all.py was never invoked
for real, DeterministicBaseline_Output/ does not exist) through the repo's real, unmodified S1-S6 evaluator
(HPC_ForAbstract/hpc_multiscenario_eval_s6b.py:load_and_evaluate), purely in-memory (nothing written under any
scanned output root), and reports act-wise and S1-S6-wise pass counts.

This answers "what do the ones that DID compile actually score" -- it is NOT a claim that the deterministic
compiler achieves this accuracy as a method (the method's real coverage is 7.98%; this is 100% conditioned on
having already compiled, and n=19 is far too small to read behaviorally beyond "does anything even pass").

    python3 analyze_compiled_subset_s1s6.py
"""
from __future__ import annotations

import sys
import tempfile
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import deterministic_compiler as DC  # noqa: E402

# ICLR supplementary: repointed from the original tree's HPC_ForAbstract/ to this bundle's own
# S1-S6_Evaluation/ (same file, see that folder's README).
sys.path.insert(0, str(DC.REPO / "S1-S6_Evaluation"))
import hpc_multiscenario_eval_s6b as H  # noqa: E402

SCENARIOS = ["S1", "S2", "S3", "S4", "S5", "S6"]


def main() -> int:
    per_act_rows = defaultdict(list)   # act -> [(section, res_dict_or_None)]
    with tempfile.TemporaryDirectory() as tmp:
        for act, sec, path in DC.iter_all_provisions():
            r = DC.compile_provision(path)
            if r["status"] != "COMPILED":
                continue
            p = Path(tmp) / f"{act}_{sec}.py"
            p.write_text(r["_z3_source"], encoding="utf-8")
            res = H.load_and_evaluate(p)
            per_act_rows[act].append((sec, res))

    all_acts = ["GDPR", "CCPA", "DPDP", "PIPD"]
    n_total = sum(len(v) for v in per_act_rows.values())

    print(f"Compiled subset: {n_total}/238 provisions (this is the {round(100*n_total/238,2)}% coverage figure; "
          f"the table below is scenario behavior CONDITIONED on having compiled, n={n_total}).\n")

    # ---- act x scenario pass-count table --------------------------------------------------------------------
    header = f"| Act | n compiled | " + " | ".join(SCENARIOS) + " | passed/possible |"
    sep = "|---|---:|" + "---:|" * len(SCENARIOS) + "---:|"
    print(header)
    print(sep)
    tot_pass = defaultdict(int)
    tot_n = 0
    tot_passed_cells = 0
    for act in all_acts:
        rows = per_act_rows.get(act, [])
        n = len(rows)
        tot_n += n
        pass_counts = {s: 0 for s in SCENARIOS}
        errors = 0
        for sec, res in rows:
            if "error" in res:
                errors += 1
                continue
            for s in SCENARIOS:
                if res[s]:
                    pass_counts[s] += 1
                    tot_pass[s] += 1
        passed_cells = sum(pass_counts.values())
        tot_passed_cells += passed_cells
        possible = n * 6
        cells = " | ".join(f"{pass_counts[s]}/{n}" for s in SCENARIOS)
        err_note = f" ({errors} load/eval error)" if errors else ""
        print(f"| {act} | {n}{err_note} | {cells} | {passed_cells}/{possible} |")
    poss = tot_n * 6
    cells = " | ".join(f"{tot_pass[s]}/{tot_n}" for s in SCENARIOS)
    print(f"| **ALL** | **{tot_n}** | {cells} | **{tot_passed_cells}/{poss} ({round(100*tot_passed_cells/poss,2) if poss else 0}%)** |")

    print("\nPer-provision detail:")
    print("| Act | Section | " + " | ".join(SCENARIOS) + " | passed |")
    print("|---|---|" + "---:|" * len(SCENARIOS) + "---:|")
    for act in all_acts:
        for sec, res in per_act_rows.get(act, []):
            if "error" in res:
                print(f"| {act} | {sec} | " + " | ".join("ERR" for _ in SCENARIOS) + f" | ERROR: {res['error']} |")
                continue
            cells = " | ".join("Y" if res[s] else "." for s in SCENARIOS)
            print(f"| {act} | {sec} | {cells} | {res['passed']}/6 |")

    print(f"\nCaveat (repeat of README.md): denominator here is {tot_n}*6={poss}, NOT 238*6=1428 -- this is NOT "
          f"comparable to NeuroFORM's 75.07%/78.43% figures, which are over all 238 provisions. n={tot_n} is also "
          f"too small for any per-act or per-scenario rate to be statistically meaningful; read this as case-by-"
          f"case detail, not a rate estimate.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
