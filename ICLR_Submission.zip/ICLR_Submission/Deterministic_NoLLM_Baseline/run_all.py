#!/usr/bin/env python3
"""
run_all.py -- Phase 4 driver: apply the SAME frozen deterministic_compiler.py to all 238 provisions and write
per-provision output. Only meaningful if run_pilot.py's pilot justified it (see rules_ledger.json).

Refuses to run unless:
  1. rules_ledger.json exists (i.e. run_pilot.py has been run),
  2. deterministic_compiler.py's current SHA-256 matches the hash recorded in that ledger (the rules were not
     edited after the pilot -- "freeze the rules before the full run"),
  3. --confirm-continue-from-pilot is passed, AND
  4. the ledger's own "recommendation" is "CONTINUE" -- unless --override-stop-recommendation is ALSO passed,
     which requires --override-reason and logs it prominently into every output file, because overriding a STOP
     finding is not something this script does quietly.

Writes ICLR_Submission/DeterministicBaseline_Output/<ACT>/<Section>/Deterministic/{05_final_code.py, compile_status.json}
(a new top-level directory, confirmed outside every root Results_S1S6_theta08/scripts/nf_config.py scans -- never
touches SLM_Output/, LLM_Output/, Final_LLM_Output/, or IO_Examples/) and compilation_results.csv.

    python3 run_all.py --confirm-continue-from-pilot
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import deterministic_compiler as DC  # noqa: E402

OUT_ROOT = DC.REPO / "DeterministicBaseline_Output"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--confirm-continue-from-pilot", action="store_true",
                     help="required; refuses to run without it")
    ap.add_argument("--override-stop-recommendation", action="store_true",
                     help="required IN ADDITION to the above if rules_ledger.json's recommendation is STOP")
    ap.add_argument("--override-reason", default="",
                     help="required with --override-stop-recommendation: a logged justification string")
    args = ap.parse_args()

    ledger_path = HERE / "rules_ledger.json"
    if not ledger_path.exists():
        print(f"REFUSING: {ledger_path} does not exist. Run run_pilot.py first.", file=sys.stderr)
        return 2
    ledger = json.loads(ledger_path.read_text(encoding="utf-8"))

    current_sha = DC.compiler_sha256()
    if current_sha != ledger["compiler_sha256"]:
        print(f"REFUSING: deterministic_compiler.py has changed since the pilot ran.\n"
              f"  pilot compiler_sha256:   {ledger['compiler_sha256']}\n"
              f"  current compiler_sha256: {current_sha}\n"
              f"Re-run run_pilot.py first so the frozen rules match what is actually being applied to all 238.",
              file=sys.stderr)
        return 2

    if not args.confirm_continue_from_pilot:
        print("REFUSING: pass --confirm-continue-from-pilot to run Phase 4.", file=sys.stderr)
        return 2

    if ledger.get("recommendation") != "CONTINUE":
        if not (args.override_stop_recommendation and args.override_reason.strip()):
            print(f"REFUSING: rules_ledger.json's recommendation is {ledger.get('recommendation')!r}, not CONTINUE.\n"
                  f"  population_238: {ledger.get('population_238')}\n"
                  f"The pilot found this is not scientifically justified (see README.md). To override anyway, pass "
                  f"BOTH --override-stop-recommendation and --override-reason \"<why>\" (this is logged verbatim "
                  f"into every output file).", file=sys.stderr)
            return 3
        print(f"WARNING: overriding a STOP recommendation. Reason (logged): {args.override_reason!r}", file=sys.stderr)

    if OUT_ROOT.exists():
        print(f"REFUSING: {OUT_ROOT} already exists; delete it yourself first if you intend to regenerate "
              f"(this script never silently overwrites a prior full run).", file=sys.stderr)
        return 2

    rows = []
    n_compiled = n_under = 0
    for act, sec, path in DC.iter_all_provisions():
        r = DC.compile_provision(path)
        prov_dir = OUT_ROOT / act / sec / "Deterministic"
        prov_dir.mkdir(parents=True, exist_ok=True)
        status_doc = {k: v for k, v in r.items() if not k.startswith("_")}
        (prov_dir / "compile_status.json").write_text(json.dumps(status_doc, indent=2), encoding="utf-8")
        if r["status"] == "COMPILED":
            n_compiled += 1
            (prov_dir / "05_final_code.py").write_text(r["_z3_source"], encoding="utf-8")
        else:
            n_under += 1
        reason = r.get("under_specified_reason") or {}
        rows.append({
            "act": act, "section": sec, "annotation_path": r["annotation_path"], "status": r["status"],
            "reason": reason.get("code", ""), "num_annotations": r["num_annotations"],
            "num_relations": r["num_relations"], "compiled_formula_summary": r["compiled_formula_summary"],
            "evaluation_status": "NOT_EVALUATED", "num_scenarios": "", "num_correct": "", "behavioral_accuracy": "",
        })

    out_csv = HERE / "compilation_results.csv"
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["act", "section", "annotation_path", "status", "reason",
                                            "num_annotations", "num_relations", "compiled_formula_summary",
                                            "evaluation_status", "num_scenarios", "num_correct", "behavioral_accuracy"])
        w.writeheader()
        w.writerows(rows)

    print(f"Phase 4 complete: {n_compiled}/{len(rows)} COMPILED ({round(100 * n_compiled / len(rows), 2)}%), "
          f"{n_under} UNDER_SPECIFIED.")
    print(f"Wrote {OUT_ROOT}/<ACT>/<Section>/Deterministic/ for all {len(rows)} provisions, and {out_csv}.")
    print("Run evaluate_existing_s1s6.py next to fill in the evaluation_status/num_scenarios/num_correct/"
          "behavioral_accuracy columns.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
