#!/usr/bin/env python3
"""
test_deterministic_compiler.py -- offline checks for deterministic_compiler.py. No GPU, no model, no network.

    python3 test_deterministic_compiler.py
"""
from __future__ import annotations

import ast
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import deterministic_compiler as DC  # noqa: E402

REPO = DC.REPO
# ICLR supplementary: repointed from the original tree's HPC_ForAbstract/ to this bundle's own
# S1-S6_Evaluation/ (same file, see that folder's README).
sys.path.insert(0, str(REPO / "S1-S6_Evaluation"))
import hpc_multiscenario_eval_s6b as H  # noqa: E402

fails: list[str] = []


def check(cond, msg):
    if not cond:
        fails.append(msg)
    return cond


def span(text, label):
    return {"text": text, "label": label, "description": ""}


def unit(text, spans):
    return {"text": text, "annotations": spans}


# =====================================================================================================================
# T1: per-rule tests on synthetic fixtures, with a round-trip through the REAL evaluator for a subset
# =====================================================================================================================
def run_fixture(sa: dict, act="TESTACT", section="TestSec1", section_title="Test"):
    """Compile a synthetic structured_annotation without touching the real dataset. Mirrors compile_provision()'s
    body but takes `sa` directly instead of a file path."""
    walk = DC.walk_structured_annotation(sa)
    namer = DC.VarNamer()
    unit_formulas = []
    rules_applied = []
    for u in walk.units:
        cls = DC.classify_unit(u.spans)
        if cls["status"] == "COMPILED":
            unit_formulas.append(DC.build_unit_formula(cls["rule_id"], cls["deontic_spans"], namer))
            rules_applied.append(cls["rule_id"])
        elif cls["status"] == "UNDER_SPECIFIED":
            return {"status": "UNDER_SPECIFIED", "reason_code": cls["reason_code"], "rules_applied": rules_applied}
    if not unit_formulas:
        return {"status": "UNDER_SPECIFIED", "reason_code": "NO_DEONTIC_CONTENT", "rules_applied": rules_applied}
    formula = unit_formulas[0] if len(unit_formulas) == 1 else DC.FAnd(unit_formulas)
    seen, var_names = set(), []
    for v in formula.free_vars():
        if v not in seen:
            seen.add(v)
            var_names.append(v)
    src = DC.render_z3_source(act, section, section_title, formula, var_names, DC.compiler_sha256())
    return {"status": "COMPILED", "formula": formula, "var_names": var_names, "src": src, "rules_applied": rules_applied}


def eval_src(src: str) -> dict:
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / "gen.py"
        p.write_text(src, encoding="utf-8")
        return H.load_and_evaluate(p)


# R1 -- unconditional obligation. get_rule() returns the bare Bool, so verify_data pins it: {O:True} is consistent
# with "solver.add(O)" -> sat; {O:False} contradicts it -> unsat. S1 expects sat (pass), S2 expects unsat (pass).
r = run_fixture({"paragraphs": [unit("x", [span("business shall delete data", "#obligation")])]})
check(r["status"] == "COMPILED" and r["rules_applied"] == ["R1"], f"T1.R1 status/rule: {r}")
check(r["formula"].to_summary() == "business_shall_delete_data", f"T1.R1 formula: {r['formula'].to_summary()}")
ev = eval_src(r["src"])
check("error" not in ev, f"T1.R1 round-trip errored: {ev}")
check(ev["S1"] is True and ev["S2"] is True, f"T1.R1 S1/S2: {ev}")

# R2 -- prohibition alone. rule = Not(P). {P:True} contradicts Not(P) -> unsat, but S1 expects SAT -> S1 fails.
# {P:False} is consistent with Not(P) -> sat, but S2 expects UNSAT -> S2 also fails. This is an inherent, disclosed
# consequence of the harness's fixed S1/S2 semantics (calibrated around obligation-shaped rules) applied to a bare
# prohibition, not a compiler bug -- see README's "Read the result with these caveats".
r = run_fixture({"paragraphs": [unit("x", [span("business shall not sell data", "#prohibition")])]})
check(r["status"] == "COMPILED" and r["rules_applied"] == ["R2"], f"T1.R2 status/rule: {r}")
check(r["formula"].to_summary() == "Not(business_shall_not_sell_data)", f"T1.R2 formula: {r['formula'].to_summary()}")
ev = eval_src(r["src"])
check("error" not in ev, f"T1.R2 round-trip errored: {ev}")
check(ev["S1"] is False and ev["S2"] is False, f"T1.R2 S1/S2: {ev}")

# R3 -- condition + obligation
r = run_fixture({"paragraphs": [unit("x", [span("upon request", "#condition"), span("shall notify", "#obligation")])]})
check(r["status"] == "COMPILED" and r["rules_applied"] == ["R3"], f"T1.R3: {r}")
check(r["formula"].to_summary() == "Implies(upon_request, shall_notify)", f"T1.R3 formula: {r['formula'].to_summary()}")
check("error" not in eval_src(r["src"]), "T1.R3 round-trip errored")

# R4 -- condition + prohibition
r = run_fixture({"paragraphs": [unit("x", [span("if minor", "#condition"), span("shall not process", "#prohibition")])]})
check(r["status"] == "COMPILED" and r["rules_applied"] == ["R4"], f"T1.R4: {r}")
check(r["formula"].to_summary() == "Implies(if_minor, Not(shall_not_process))", f"T1.R4 formula: {r['formula'].to_summary()}")
check("error" not in eval_src(r["src"]), "T1.R4 round-trip errored")

# R5 -- condition + exemption + obligation
r = run_fixture({"paragraphs": [unit("x", [span("upon request", "#condition"), span("for research purposes", "#exemption"),
                                            span("shall delete", "#obligation")])]})
check(r["status"] == "COMPILED" and r["rules_applied"] == ["R5"], f"T1.R5: {r}")
check(r["formula"].to_summary() == "Implies(And(upon_request, Not(for_research_purposes)), shall_delete)", f"T1.R5 formula: {r['formula'].to_summary()}")
ev = eval_src(r["src"])
check("error" not in ev, f"T1.R5 round-trip errored: {ev}")
# all-False: And(C=F, Not(E=F))=And(F,T)=F -> Implies(F, O) is vacuously TRUE regardless of O -> sat, so S2 (which
# expects unsat) legitimately fails here too -- standard vacuous-truth behavior of Implies, not a compiler bug.
check(ev["S2"] is False, f"T1.R5 S2: {ev}")

# R6 -- condition + exemption + prohibition
r = run_fixture({"paragraphs": [unit("x", [span("upon request", "#condition"), span("for research purposes", "#exemption"),
                                            span("shall not disclose", "#prohibition")])]})
check(r["status"] == "COMPILED" and r["rules_applied"] == ["R6"], f"T1.R6: {r}")
check("error" not in eval_src(r["src"]), "T1.R6 round-trip errored")

# R7 -- permission alone (non-binding tautology)
r = run_fixture({"paragraphs": [unit("x", [span("may retain records", "#permission")])]})
check(r["status"] == "COMPILED" and r["rules_applied"] == ["R7"], f"T1.R7: {r}")
ev = eval_src(r["src"])
check("error" not in ev, f"T1.R7 round-trip errored: {ev}")
# Or(v, Not(v)) is a tautology: it never constrains anything, so verify_data is sat for ANY assignment. S1 (expects
# sat) therefore passes; S2 (expects UNSAT for all-False) cannot pass -- a genuinely non-binding permission can
# never make "everything false" infeasible, which is the correct/expected behavior, not a bug.
check(ev["S1"] is True and ev["S2"] is False, f"T1.R7: {ev}")

# =====================================================================================================================
# T2: per-reason-code negative fixtures
# =====================================================================================================================
r = run_fixture({"paragraphs": [unit("x", [span("shall notify", "#obligation"), span("shall also register", "#obligation")])]})
check(r["status"] == "UNDER_SPECIFIED" and r["reason_code"] == "MULTI_ELEMENT_UNRESOLVED_COMPOSITION", f"T2.multi_obl: {r}")

r = run_fixture({"paragraphs": [unit("x", [span("cond A", "#condition"), span("cond B", "#condition"), span("shall act", "#obligation")])]})
check(r["status"] == "UNDER_SPECIFIED" and r["reason_code"] == "MULTI_ELEMENT_UNRESOLVED_COMPOSITION", f"T2.multi_cond: {r}")

r = run_fixture({"paragraphs": [unit("x", [span("shall provide", "#obligation"), span("shall not sell", "#prohibition")])]})
check(r["status"] == "UNDER_SPECIFIED" and r["reason_code"] == "MIXED_POLARITY_UNRESOLVED", f"T2.mixed_polarity: {r}")

r = run_fixture({"paragraphs": [unit("x", [span("some obscure label", "#some_totally_unknown_label_xyz")])]})
check(r["status"] == "UNDER_SPECIFIED" and r["reason_code"] == "UNMAPPED_LABEL", f"T2.unmapped: {r}")

# dangling condition (no target obligation/prohibition in the same unit)
r = run_fixture({"paragraphs": [unit("x", [span("for research purposes", "#exemption")])]})
check(r["status"] == "UNDER_SPECIFIED" and r["reason_code"] == "DANGLING_CONDITION_OR_EXEMPTION", f"T2.dangling: {r}")

# NO_STRUCTURED_ANNOTATION at the compile_provision() level (needs a real file path, so test the short-circuit directly)
tmp_dir = Path(tempfile.mkdtemp())
fake = tmp_dir / "Fake.json"
fake.write_text('{"act": "TESTACT", "section_title": "x", "structured_annotation": null}', encoding="utf-8")
res = DC.compile_provision(fake)
check(res["status"] == "UNDER_SPECIFIED" and res["under_specified_reason"]["code"] == "NO_STRUCTURED_ANNOTATION",
      f"T2.no_structured_annotation: {res}")

# CCPA (c)/(d)-shaped fixture: cross-unit exemption attachment, WITH the enrichment note present
cross_unit_sa = {
    "subsections": [
        {"number": "(a)", "text": "x", "annotations": [span("shall delete", "#obligation")]},
        {"number": "(b)", "text": [
            {"clause": "(1)", "text": "y", "annotations": [span("for research", "#exemption")]},
        ]},
    ]
}
fake2 = tmp_dir / "Fake2.json"
fake2.write_text('{"act": "TESTACT", "section_title": "x", "structured_annotation": ' +
                  __import__("json").dumps(cross_unit_sa) + '}', encoding="utf-8")
res2 = DC.compile_provision(fake2)
check(res2["status"] == "UNDER_SPECIFIED", f"T2.cross_unit status: {res2}")
check(res2["num_units_compiled"] == 1, f"T2.cross_unit num_compiled: {res2}")
detail = res2["under_specified_reason"]["detail"]
check(res2["under_specified_reason"]["code"] == "DANGLING_CONDITION_OR_EXEMPTION" and "cross-unit" in detail,
      f"T2.cross_unit enrichment missing: {res2['under_specified_reason']}")

# =====================================================================================================================
# T3: label-coverage sweep over the REAL 238-file corpus (fresh, independent of run_pilot.py's own scan)
# =====================================================================================================================
n_labels_seen = 0
n_resolved = 0
for act, sec, path in DC.iter_all_provisions():
    full = DC.load_provision_json(path)
    sa = full.get("structured_annotation")
    if sa is None:
        continue
    walk = DC.walk_structured_annotation(sa)
    for u in walk.units:
        for s in u.spans:
            n_labels_seen += 1
            if s.label_norm != "UNMAPPED":
                n_resolved += 1
check(n_labels_seen > 2000, f"T3: expected >2000 span occurrences across the corpus, saw {n_labels_seen}")
resolved_pct = round(100 * n_resolved / n_labels_seen, 1) if n_labels_seen else 0
print(f"[info] T3 label coverage over the real corpus: {n_resolved}/{n_labels_seen} ({resolved_pct}%) resolved, "
      f"{n_labels_seen - n_resolved} UNMAPPED occurrences")

# =====================================================================================================================
# T4: no-leakage -- the compiler module must never IMPORT the S1-S6 evaluator or its data (mentioning the
# evaluator's name in a docstring/comment to document the output CONTRACT it must satisfy is fine and expected --
# this checks actual import statements via the AST, not a blunt text search that would false-positive on comments).
# =====================================================================================================================
src_text = Path(DC.__file__).read_text(encoding="utf-8")
tree = ast.parse(src_text)
FORBIDDEN_MODULE_SUBSTRINGS = ("hpc_multiscenario_eval", "Results_S1S6_theta08", "scenario_worker")
n_import_nodes = 0
for node in ast.walk(tree):
    if isinstance(node, ast.Import):
        n_import_nodes += 1
        for alias in node.names:
            check(not any(f in alias.name for f in FORBIDDEN_MODULE_SUBSTRINGS), f"T4: forbidden import {alias.name}")
    elif isinstance(node, ast.ImportFrom):
        n_import_nodes += 1
        check(not any(f in (node.module or "") for f in FORBIDDEN_MODULE_SUBSTRINGS), f"T4: forbidden import-from {node.module}")
check(n_import_nodes >= 5, f"T4: sanity check -- expected several import statements, AST walk found {n_import_nodes}")

# =====================================================================================================================
# T5: determinism -- compiling the same fixture twice gives byte-identical formula/var-names/rules
# =====================================================================================================================
sa_fixture = {"paragraphs": [unit("x", [span("upon request", "#condition"), span("for research purposes", "#exemption"),
                                         span("shall delete", "#obligation")])]}
r_a = run_fixture(sa_fixture)
r_b = run_fixture(sa_fixture)
check(r_a["formula"].to_summary() == r_b["formula"].to_summary(), "T5: formula summary not deterministic")
check(r_a["var_names"] == r_b["var_names"], "T5: var_names not deterministic")
check(r_a["src"] == r_b["src"], "T5: rendered source not byte-identical across two compiles of the same fixture")

# =====================================================================================================================
# T6: slugify / VarNamer sanity (collision handling, identifier validity)
# =====================================================================================================================
namer = DC.VarNamer()
n1 = namer.get("shall notify the consumer")
n2 = namer.get("shall notify the consumer")  # identical text -> same name
n3 = namer.get("shall  notify   the CONSUMER!!")  # different text, same slug -> must NOT collide silently
check(n1 == n2, f"T6: identical span text got different variable names ({n1} vs {n2})")
check(n3 != n1, f"T6: different span text collapsed to the same variable name ({n1})")
check(n1.isidentifier() and n3.isidentifier(), f"T6: generated names must be valid Python identifiers: {n1!r} {n3!r}")

print()
for m in fails:
    print("FAIL:", m)
print(f"{'ALL CHECKS PASSED' if not fails else str(len(fails)) + ' CHECK(S) FAILED'} "
      f"({len(fails)} failures)")
raise SystemExit(0 if not fails else 1)
