# Ambiguity examples (from the Phase-2 pilot)

Each case: the annotation elements involved, two literally-competing Z3 interpretations neither of
which the annotation schema can distinguish, and the exact missing information.


## CCPA / Sec1798_105 -- Consumers’ Right to Delete Personal Information

`annotation_path`: `AAAI-Dataset/dataset/CCPA_Act/Sec1798_105.json`

**Reason code**: `MULTI_ELEMENT_UNRESOLVED_COMPOSITION` -- Two or more spans of the same deontic class co-occur in one unit; AND/OR composition among them is not encoded by the annotation.

**Detail**: unmatched combination o=1 p=0 pm=1 c=0 e=0


This provision has 11 under-specified units in total; showing the primary one above plus a second below for contrast.


**Annotation** (`root.subsections[0]`):

> A consumer shall have the right to request that a business delete any personal information about the consumer which the business has collected from the consumer.

- `#right` (-> `permission`): "shall have the right to request"
- `#obligation` (-> `obligation`): "business delete any personal information"

**Candidate interpretation A** (AND):
```
And(self.shall_have_the_right_to_request, self.business_delete_any_personal_information)
```
**Candidate interpretation B** (OR):
```
Or(self.shall_have_the_right_to_request, self.business_delete_any_personal_information)
```
**Missing information**: AND vs. OR composition among same-class siblings -- the schema gives no field distinguishing these.


## DPDP / ChII_Sec10 -- 

`annotation_path`: `AAAI-Dataset/dataset/DPDP_Act/ChII_Sec10.json`

**Reason code**: `DANGLING_CONDITION_OR_EXEMPTION` -- A condition and/or exemption span exists with no co-located obligation/prohibition in the same unit -- its target is not encoded (it may attach to an obligation/prohibition in a different unit of the same provision; see 'detail').

**Detail**: cardinalities o=0 p=0 pm=0 c=1 e=0 -- this provision has an obligation/prohibition compiled from a DIFFERENT unit; possible cross-unit exemption/condition attachment, not resolvable from the annotation schema (see README's CCPA Sec1798_105 example).


This provision has 6 under-specified units in total; showing the primary one above plus a second below for contrast.


**Annotation** (`root.subsections[0].clauses[0]`):

> the volume and sensitivity of personal data processed;

- `#condition` (-> `condition`): "volume and sensitivity of personal data"

**Candidate interpretation A** (exemption attaches to the obligation/prohibition in unit `root.subsections[0]`):
```
Implies(Not(self.volume_and_sensitivity_of_personal_data), self.may_notify)
```
**Candidate interpretation B** (exemption attaches to nothing -- it is inert / a definition, not a live defeater in this program):
```
(no constraint added)
```
**Missing information**: exemption/condition-to-obligation attachment -- the schema has no field linking a condition/exemption span in one structural unit to an obligation/prohibition span in a different one.


## DPDP / ChV_Sec20 -- 

`annotation_path`: `AAAI-Dataset/dataset/DPDP_Act/ChV_Sec20.json`

**Reason code**: `MIXED_POLARITY_UNRESOLVED` -- An obligation and a prohibition co-occur in one unit with no condition/exemption distinguishing them; how they combine is not encoded.

**Detail**: co-located obligation and prohibition, cardinalities o=1 p=1 pm=0 c=1 e=0


This provision has 2 under-specified units in total; showing the primary one above plus a second below for contrast.


**Annotation** (`root.subsections[0]`):

> The salary, allowances and other terms and conditions of service of the allowances Chairperson and other Members shall be such as may be prescribed, and shall not be varied to their disadvantage after their appointment.

- `#obligation` (-> `obligation`): "shall be such as may be prescribed"
- `#prohibition` (-> `prohibition`): "shall not be varied to their disadvantage after their appointment"
- `#condition` (-> `condition`): "after their appointment"

**Candidate interpretation A** (independent, conjoined duties):
```
And(self.shall_be_such_as_may_be_prescribed, Not(self.shall_not_be_varied_to_their_disadvantage_after))
```
**Candidate interpretation B** (the prohibition qualifies/limits the obligation):
```
Implies(self.shall_be_such_as_may_be_prescribed, Not(self.shall_not_be_varied_to_their_disadvantage_after))
```
**Missing information**: whether the obligation and prohibition are independent requirements or one conditions the other.

