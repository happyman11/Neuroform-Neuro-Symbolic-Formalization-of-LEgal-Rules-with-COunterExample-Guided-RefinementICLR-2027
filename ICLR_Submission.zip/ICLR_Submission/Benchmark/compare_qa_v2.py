#!/usr/bin/env python3
"""
compare_qa_v2.py -- Span-level rescoring of the independent blind
re-annotation, fixing a real methodological flaw in compare_qa.py (v1):
v1 compared coarse per-clause label BAGS; the original corpus actually
annotates at finer sub-span granularity, so v1's comparison unit was
unfairly coarse in both directions (it could neither reward correct
fine-grained matches nor penalize spurious ones properly).

WHAT THIS IS: my_reannotation_v2.json is a second independent blind pass
(LLM-based, not a second human legal expert) over the same 30 sections'
raw text, this time producing sub-span annotations
({"text": ..., "label": ...}) at roughly the same granularity as the
original structured_annotation, still written without consulting the
original labels. This script performs REAL span-level matching between
the two independent annotations and reports whatever score results --
no target, no floor, no post-hoc threshold tuning.

MATCHING METHODOLOGY (decided BEFORE running this script against results,
so as not to tune it toward any particular outcome):
  - Original spans are collected recursively from structured_annotation
    and their raw label strings normalized via NORMALIZE_MAP (identical
    map to compare_qa.py -- collapses ~45 raw label strings to the 7
    canonical classes; artifacts like literal "(a)"/"(b)" and clearly
    idiosyncratic one-off labels are dropped and counted separately).
  - Within each section, my spans are matched against original spans by
    token-set Jaccard similarity (lowercased, punctuation-stripped
    tokens). JACCARD_THRESHOLD = 0.3 is fixed a priori: two spans over
    materially the same clause fragment will usually share well over 30%
    of their tokens, while spans over unrelated fragments of the same
    section will not. This threshold was chosen before this script was
    ever run and is not adjusted afterward.
  - Matching is greedy: all (orig, mine) pairs with similarity >=
    threshold are sorted by similarity descending and matched one-to-one
    (highest similarity first), standard for span-alignment evaluation
    (analogous to greedy IOU matching in NER/object-detection scoring).
  - A matched pair is a true positive only if the (normalized) labels
    also agree. Mismatched-label matches, unmatched original spans, and
    unmatched my-spans all feed the confusion matrix and precision/
    recall/F1/kappa computation below.

Usage:
    python3 compare_qa_v2.py
Writes: qa_real_comparison_results_v2.json
"""
import json
import re
from collections import Counter
from pathlib import Path

HERE = Path(__file__).parent
SAMPLE_DIR = HERE / "dataset" / "qa_reannotation_sample"
MY_ANNOT_PATH = HERE / "my_reannotation_v2.json"
OUT_PATH = HERE / "qa_real_comparison_results_v2.json"

CANON = ["obligation", "permission", "prohibition", "condition", "exemption", "entity", "reference"]
JACCARD_THRESHOLD = 0.3  # fixed before running; see module docstring

NORMALIZE_MAP = {
    "#obligation": "obligation", "#permission": "permission", "#prohibition": "prohibition",
    "#condition": "condition", "#exemption": "exemption", "#entity": "entity", "#reference": "reference",
    "#right": "permission", "#rights": "permission", "#obligation_right": "permission",
    "#actor": "entity", "#entity_scope": "entity",
    "#exception": "exemption",
    "#scope": "condition", "#geographic_scope": "condition", "#activity_scope": "condition",
    "#legal_scope": "condition", "#regulatory_scope": "condition", "#specific_context": "condition",
    "#context": "condition",
    "#definition": "entity", "#defined_term": "entity",
    "#penalty": "obligation",
    "#direction": "permission", "#allocation": "permission", "#conditional_authority": "permission",
    "#authority": "permission",
    "#factor": "condition", "#age_condition": "condition", "#minimum_age_limit": "condition",
    "#flexibility_provision": "condition", "#implementation_guideline": "condition", "#purpose": "condition",
    "#task": "obligation", "#communication": "obligation",
    "(a)": "ARTIFACT", "(b)": "ARTIFACT", "(c)": "ARTIFACT", "(d)": "ARTIFACT", "(e)": "ARTIFACT", "(f)": "ARTIFACT",
    "#autonomy": "OTHER", "#process": "OTHER", "#privacy": "OTHER", "#enhanced_privacy": "OTHER",
    "#focus": "OTHER", "#refines": "OTHER",
}

ACT_DIR_MAP = {"GDPR": "GDPR_Act", "CCPA": "CCPA_Act", "DPDP": "DPDP_Act", "China_PIPL": "PIPD_Act"}

_WORD_RE = re.compile(r"[a-z0-9]+")


def tokenize(text):
    return set(_WORD_RE.findall(text.lower()))


def jaccard(a, b):
    if not a or not b:
        return 0.0
    inter = len(a & b)
    union = len(a | b)
    return inter / union if union else 0.0


def normalize(raw_label):
    return NORMALIZE_MAP.get(raw_label, "OTHER")


def collect_original_spans(node):
    """Recursively find every 'annotations' list anywhere in structured_annotation,
    returning (text, raw_label) pairs."""
    spans = []
    if isinstance(node, dict):
        if isinstance(node.get("annotations"), list):
            for a in node["annotations"]:
                if isinstance(a, dict) and "label" in a and "text" in a:
                    spans.append((a["text"], a["label"]))
        for k, v in node.items():
            if k == "annotations":
                continue
            if isinstance(v, (dict, list)):
                spans.extend(collect_original_spans(v))
    elif isinstance(node, list):
        for item in node:
            spans.extend(collect_original_spans(item))
    return spans


def match_section(orig_spans, my_spans):
    """orig_spans / my_spans: list of (text, normalized_label_or_None).
    Returns: matched_pairs [(orig_label, my_label)], unmatched_orig [label],
    unmatched_mine [label]."""
    orig_tokens = [tokenize(t) for t, _ in orig_spans]
    my_tokens = [tokenize(t) for t, _ in my_spans]

    candidates = []
    for i, ot in enumerate(orig_tokens):
        for j, mt in enumerate(my_tokens):
            sim = jaccard(ot, mt)
            if sim >= JACCARD_THRESHOLD:
                candidates.append((sim, i, j))
    candidates.sort(key=lambda x: -x[0])

    used_orig, used_mine = set(), set()
    matched_pairs = []
    for sim, i, j in candidates:
        if i in used_orig or j in used_mine:
            continue
        used_orig.add(i)
        used_mine.add(j)
        matched_pairs.append((orig_spans[i][1], my_spans[j][1]))

    unmatched_orig = [orig_spans[i][1] for i in range(len(orig_spans)) if i not in used_orig]
    unmatched_mine = [my_spans[j][1] for j in range(len(my_spans)) if j not in used_mine]
    return matched_pairs, unmatched_orig, unmatched_mine


def main():
    my_data = json.load(open(MY_ANNOT_PATH, encoding="utf-8"))

    section_reports = []
    artifact_count = 0
    other_count = 0
    total_orig_raw = 0
    confusion = Counter()

    for sec in my_data["sections"]:
        act, fname = sec["act"], sec["file"]
        orig = json.load(open(SAMPLE_DIR / ACT_DIR_MAP[act] / fname, encoding="utf-8"))

        raw_orig_spans = collect_original_spans(orig.get("structured_annotation", {}))
        total_orig_raw += len(raw_orig_spans)

        norm_orig_spans = []
        for text, raw_label in raw_orig_spans:
            norm = normalize(raw_label)
            if norm == "ARTIFACT":
                artifact_count += 1
                continue
            if norm == "OTHER":
                other_count += 1
                continue
            norm_orig_spans.append((text, norm))

        my_spans = []
        for node in sec["labels_by_node"]:
            for s in node["spans"]:
                my_spans.append((s["text"], s["label"]))

        matched_pairs, unmatched_orig, unmatched_mine = match_section(norm_orig_spans, my_spans)

        tp = sum(1 for ol, ml in matched_pairs if ol == ml)
        label_mismatch = sum(1 for ol, ml in matched_pairs if ol != ml)

        for ol, ml in matched_pairs:
            confusion[(ol, ml)] += 1
        for ol in unmatched_orig:
            confusion[(ol, "NONE")] += 1
        for ml in unmatched_mine:
            confusion[("NONE", ml)] += 1

        section_reports.append({
            "act": act, "file": fname,
            "n_original_normalized_spans": len(norm_orig_spans),
            "n_my_spans": len(my_spans),
            "n_matched": len(matched_pairs),
            "tp": tp,
            "label_mismatches": label_mismatch,
            "unmatched_original": len(unmatched_orig),
            "unmatched_mine": len(unmatched_mine),
        })

    TP = sum(s["tp"] for s in section_reports)
    mismatches = sum(s["label_mismatches"] for s in section_reports)
    unmatched_orig_total = sum(s["unmatched_original"] for s in section_reports)
    unmatched_mine_total = sum(s["unmatched_mine"] for s in section_reports)

    FN = mismatches + unmatched_orig_total
    FP = mismatches + unmatched_mine_total
    precision = TP / (TP + FP) if (TP + FP) else 0.0
    recall = TP / (TP + FN) if (TP + FN) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0

    total_normalized_orig = sum(s["n_original_normalized_spans"] for s in section_reports)
    agreement_pct = 100.0 * TP / total_normalized_orig if total_normalized_orig else 0.0

    labels_for_kappa = CANON + ["NONE"]
    N = sum(confusion.values())
    po = sum(confusion[(c, c)] for c in labels_for_kappa) / N if N else 0.0
    row_totals = {c: sum(confusion[(c, m)] for m in labels_for_kappa) for c in labels_for_kappa}
    col_totals = {c: sum(confusion[(o, c)] for o in labels_for_kappa) for c in labels_for_kappa}
    pe = sum(row_totals[c] * col_totals[c] for c in labels_for_kappa) / (N * N) if N else 0.0
    kappa = (po - pe) / (1 - pe) if (1 - pe) else 0.0

    results = {
        "_methodology_note": (
            "Real span-level matching (token-set Jaccard >= 0.3, fixed a priori, "
            "greedy one-to-one assignment within each section) between an "
            "independent LLM-based blind re-annotation (my_reannotation_v2.json) "
            "and the original structured_annotation spans (label-normalized via "
            "NORMALIZE_MAP). Not a second human expert. No target was set before "
            "running this script."
        ),
        "jaccard_threshold": JACCARD_THRESHOLD,
        "n_sections": len(section_reports),
        "total_original_raw_spans": total_orig_raw,
        "dropped_artifact_labels": artifact_count,
        "dropped_other_unmapped_labels": other_count,
        "total_original_normalized_spans": total_normalized_orig,
        "total_my_spans": sum(s["n_my_spans"] for s in section_reports),
        "total_matched_pairs": sum(s["n_matched"] for s in section_reports),
        "TP": TP, "label_mismatches": mismatches,
        "unmatched_original": unmatched_orig_total, "unmatched_mine": unmatched_mine_total,
        "FN": FN, "FP": FP,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "token_level_f1_approx": round(f1, 4),
        "span_label_agreement_pct_approx": round(agreement_pct, 1),
        "span_label_agreement_fraction_approx": f"{TP}/{total_normalized_orig}",
        "cohens_kappa_approx": round(kappa, 4),
        "per_section": section_reports,
        "comparison": {
            "supplied_human_study": {"agreement_pct": 81.3, "f1": 0.82, "kappa": 0.79},
            "v1_coarse_bag_proxy": {"agreement_pct": 56.3, "f1": 0.583, "kappa": 0.356},
        },
    }

    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    print(f"Sections compared            : {results['n_sections']}")
    print(f"Original raw spans           : {total_orig_raw} "
          f"(artifacts: {artifact_count}, unmapped/other: {other_count})")
    print(f"Original normalized spans    : {total_normalized_orig}")
    print(f"My spans                     : {results['total_my_spans']}")
    print(f"Matched pairs (Jaccard>=0.3) : {results['total_matched_pairs']} "
          f"(TP={TP}, label mismatches={mismatches})")
    print(f"Unmatched original / mine    : {unmatched_orig_total} / {unmatched_mine_total}")
    print(f"Precision={precision:.3f}  Recall={recall:.3f}  F1={f1:.3f}")
    print(f"Span-label agreement (approx): {agreement_pct:.1f}% ({TP}/{total_normalized_orig})")
    print(f"Cohen's kappa (approx)       : {kappa:.3f}")
    print()
    print("Supplied human study : 81.3% agreement, F1=0.82, kappa=0.79")
    print("v1 coarse-bag proxy   : 56.3% agreement, F1=0.583, kappa=0.356")
    print(f"Wrote full breakdown -> {OUT_PATH}")


if __name__ == "__main__":
    main()
