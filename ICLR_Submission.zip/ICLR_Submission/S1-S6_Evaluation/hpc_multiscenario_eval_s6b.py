#!/usr/bin/env python3
"""
HPC Full-Benchmark Multi-Scenario Evaluation
REFINE-SMT (SLM + LLM) vs B1-B9 Baselines
6 Scenarios x 4 Regulations x 238 Sections

Scenario battery: S1 Compliance, S2 Violation, S3 Exception, S4 Boundary
(original 4-scenario harness) plus S5 Multi-Exception and S6 Compound
Boundary (extension added in response to a reviewer concern that |h|=4 is
thin support for the formal machinery — see Docs/methodology_appendix_aaai.tex,
"Harness Construction and Coverage"). S5/S6 are a new, unvalidated
extension: they have not yet been run against any existing benchmark
corpus (no generated candidate .py files exist locally to re-run them
against; real validation happens on the HPC server that produced
hpc_results_*.json/hpc_summary.json under the original 4-scenario harness).

Output files (written to HPC_ForAbstract/):
  hpc_results_slm.json   per-section detail, SLM tier
  hpc_results_llm.json   per-section detail, LLM tier
  hpc_summary.json       aggregated summary for both tiers
"""

import importlib.util
import inspect
import json
import re
import sys
from pathlib import Path

import z3

BASE = Path(__file__).parent  # HPC_ForAbstract/

DATASETS = ['GDPR', 'CCPA', 'DPDP', 'PIPD']

BASELINE_NAMES = {
    'b1': 'b1_zeroshot',
    'b2': 'b2_cot_selfrefine',
    'b3': 'b3_naive_retry',
    'b4': 'b4_grammar_constrained',
    'b5': 'b5_cegis_sketch',
    'b6': 'b6_aquaforte',
    'b7': 'b7_l4l_schema',
    'b8': 'b8_masa_multiagent',
    'b9': 'b9_rag_smt',
}

EXCEPTION_KEYWORDS = {
    'exception', 'exempt', 'archiving', 'scientific', 'research',
    'national_security', 'household', 'journalism', 'legitimate', 'overridden',
    'public_interest', 'vital_interests', 'employment', 'medical', 'emergency',
    'epidemic', 'disaster', 'court', 'judgment', 'compliance_legal', 'legal_basis',
    'guardian', 'minor', 'subsequently', 'subsidy', 'state_function',
}

OBLIGATION_KEYWORDS = {
    'informs', 'consent', 'compliant', 'lawful', 'transparent',
    'must', 'required', 'obligation', 'right', 'access', 'delete', 'portability',
    'notify', 'collect', 'process', 'disclose', 'security', 'protect', 'implement',
    'maintain', 'ensure', 'provide', 'verify', 'record', 'register', 'appoint',
    'purpose', 'data_subject', 'controller', 'processor', 'fiduciary', 'principal',
}


# ---------------------------------------------------------------------------
# Path registry
# ---------------------------------------------------------------------------

def get_refine_sections(tier: str, dataset: str) -> dict:
    """Return {section_id: Path} for REFINE-SMT SUCCESS.py files."""
    if tier == 'slm':
        if dataset in ('GDPR', 'DPDP'):
            run_dir = BASE / 'hcd' / 'normal' / 'SLM-Primary-20260515T163940Z' / dataset
        else:
            run_dir = BASE / 'hcd' / 'normal' / 'SLM-Primary-20260516T060328Z' / dataset
    else:
        run_dir = BASE / 'hcd' / 'LLM-Primary-20260603T105039Z' / dataset

    if not run_dir.exists():
        return {}

    sections = {}
    for z3_dir in run_dir.glob('*_Z3_Outputs'):
        m = re.match(r'\d{8}T\d{6}Z_(.+)_Z3_Outputs$', z3_dir.name)
        if not m:
            continue
        section_id = m.group(1)
        candidates = [f for f in z3_dir.glob('Section_*_SUCCESS.py')
                      if not f.name.endswith('.bak')]
        if candidates:
            sections[section_id] = candidates[0]
    return sections


def _llm_b6b9_dir(bkey: str, bname: str, dataset: str):
    """Return Path for LLM B6-B9 using multi-machine split.

    adityab -> GDPR, PIPD  (run NewBaseline-LLM-ALL-20260630T063624Z)
    ravi    -> CCPA, DPDP  (run NewBaseline-LLM-ALL-20260630T063000Z)
    hcd     -> B9 CCPA only (run NewBaseline-LLM-B9-20260703T161344Z)
    """
    if bkey == 'b9' and dataset == 'CCPA':
        return (BASE / 'hcd' / 'Baseline_Output' / 'llm' / bname
                / 'NewBaseline-LLM-B9-20260703T161344Z' / dataset)
    if dataset in ('GDPR', 'PIPD'):
        return (BASE / 'adityab' / 'Baseline_Output' / 'llm' / bname
                / 'NewBaseline-LLM-ALL-20260630T063624Z' / dataset)
    # CCPA, DPDP
    return (BASE / 'ravi' / 'Baseline_Output' / 'llm' / bname
            / 'NewBaseline-LLM-ALL-20260630T063000Z' / dataset)


def get_baseline_sections(tier: str, bkey: str, dataset: str) -> dict:
    """Return {section_id: Path} for baseline final_code.py files."""
    bname = BASELINE_NAMES[bkey]

    if tier == 'slm':
        run_id = ('Baseline-SLM-ALL-20260623T170214Z' if bkey in ('b1', 'b2', 'b3', 'b4', 'b5')
                  else 'NewBaseline-SLM-ALL-20260624T201548Z')
        reg_dir = BASE / 'hcd' / 'Baseline_Output' / 'slm' / bname / run_id / dataset
    else:
        if bkey in ('b1', 'b2', 'b3', 'b4', 'b5'):
            reg_dir = (BASE / 'hcd' / 'Baseline_Output' / 'llm' / bname
                       / 'Baseline-LLM-ALL-20260623T170316Z' / dataset)
        else:
            reg_dir = _llm_b6b9_dir(bkey, bname, dataset)

    if not reg_dir or not reg_dir.exists():
        return {}

    sections = {}
    for section_dir in sorted(reg_dir.iterdir()):
        if not section_dir.is_dir():
            continue
        code_file = section_dir / 'final_code.py'
        if code_file.exists():
            sections[section_dir.name] = code_file
    return sections


# ---------------------------------------------------------------------------
# Variable classification
# ---------------------------------------------------------------------------

def classify_vars(var_names: list) -> tuple:
    """Return (exception_vars, obligation_vars, other_vars)."""
    exc, obl, other = [], [], []
    for name in var_names:
        low = name.lower()
        if any(kw in low for kw in EXCEPTION_KEYWORDS):
            exc.append(name)
        elif any(kw in low for kw in OBLIGATION_KEYWORDS):
            obl.append(name)
        else:
            other.append(name)
    return exc, obl, other


def _pick_binding_obligation_vars(instance, bool_vars, obl_vars, k):
    """Return up to k obligation vars whose individual removal from the
    all-True (S1) assignment actually flips the verdict to unsat -- i.e.
    genuinely load-bearing in *this specific formula*, not just keyword-
    matched by classify_vars().

    Root cause this fixes: classify_vars() is a generic keyword heuristic
    and can tag a variable as "obligation" even when the candidate's own
    Z3 encoding deliberately makes it non-binding, e.g.
        rule = z3.Or(some_var, z3.Not(some_var))
    is a tautology (always true, adds no real constraint) -- candidates
    correctly do this for clauses using permissive ("may") rather than
    mandatory ("must") legal language. Blindly flipping such a variable for
    S4/S6 penalizes a candidate for correctly NOT treating an optional
    clause as a strict obligation. Preferring a variable that actually
    changes the verdict when flipped makes S4/S6 test the strongest
    available boundary case per formula, model-agnostically (applied
    identically to every method, not tailored to any one of them).

    Falls back to filling remaining slots from the original obl_vars order
    if fewer than k binding vars are found, preserving prior behavior when
    no binding variable exists at all (e.g. a formula with only permissive
    obligation-keyword-matched variables).
    """
    binding = []
    for v in obl_vars:
        data = {bv: True for bv in bool_vars}
        data[v] = False
        if instance.verify_data(data) == z3.unsat:
            binding.append(v)
        if len(binding) == k:
            break
    if len(binding) < k:
        remaining = [v for v in obl_vars if v not in binding]
        binding += remaining[: k - len(binding)]
    return binding


# ---------------------------------------------------------------------------
# Module loading
# ---------------------------------------------------------------------------

_mod_counter = 0


def load_module(py_path: Path):
    global _mod_counter
    _mod_counter += 1
    mod_name = f'_hpc_mod_{_mod_counter}'
    spec = importlib.util.spec_from_file_location(mod_name, py_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def find_class(mod):
    """Find the first class in the module that has a verify_data method."""
    for _, obj in inspect.getmembers(mod, inspect.isclass):
        if hasattr(obj, 'verify_data') and callable(getattr(obj, 'verify_data')):
            return obj
    return None


def get_bool_vars(instance) -> list:
    """Return attribute names whose values are z3.BoolRef."""
    return [
        name for name in vars(instance)
        if isinstance(getattr(instance, name, None), z3.BoolRef)
    ]


# ---------------------------------------------------------------------------
# 6-Scenario evaluation (S1-S4 original harness + S5/S6 extension)
# ---------------------------------------------------------------------------

def load_and_evaluate(py_path: Path) -> dict:
    """Load a Z3 Python file and run the 6-scenario protocol."""
    try:
        mod = load_module(py_path)
    except Exception as e:
        return {'error': f'load_error: {str(e)[:150]}', 'passed': 0,
                'S1': False, 'S2': False, 'S3': False, 'S4': False,
                'S5': False, 'S6': False}

    try:
        cls = find_class(mod)
        if cls is None:
            return {'error': 'no_class_with_verify_data', 'passed': 0,
                    'S1': False, 'S2': False, 'S3': False, 'S4': False,
                    'S5': False, 'S6': False}

        instance = cls()
        bool_vars = get_bool_vars(instance)

        if not bool_vars:
            return {'error': 'no_bool_vars', 'passed': 0,
                    'S1': False, 'S2': False, 'S3': False, 'S4': False,
                    'S5': False, 'S6': False}

        exc_vars, obl_vars, _ = classify_vars(bool_vars)

        passed = 0
        s_results = {}

        # S1: all True -> expect sat
        r1 = instance.verify_data({v: True for v in bool_vars})
        s_results['S1'] = (r1 == z3.sat)
        if s_results['S1']:
            passed += 1

        # S2: all False -> expect unsat
        r2 = instance.verify_data({v: False for v in bool_vars})
        s_results['S2'] = (r2 == z3.unsat)
        if s_results['S2']:
            passed += 1

        # S3: exception vars True, all others False -> expect sat
        # If no exception vars, repeat S2 outcome (no SAT path from exceptions)
        s3_data = {v: False for v in bool_vars}
        for v in exc_vars:
            s3_data[v] = True
        if exc_vars:
            r3 = instance.verify_data(s3_data)
            s_results['S3'] = (r3 == z3.sat)
        else:
            s_results['S3'] = s_results['S2']
        if s_results['S3']:
            passed += 1

        # S4: all True except one obligation var flipped False -> expect unsat.
        # The flip target is chosen by _pick_binding_obligation_vars(), not
        # blindly obl_vars[0] -- see its docstring for why (keyword-matched
        # "obligation" vars can be tautologically non-binding in a specific
        # formula, e.g. permissive/"may" clauses correctly encoded as
        # Or(X, Not(X))). If no obligation vars, S4 is treated as failed
        # (can't test boundary).
        if obl_vars:
            s4_target = _pick_binding_obligation_vars(instance, bool_vars, obl_vars, 1)
            s4_data = {v: True for v in bool_vars}
            s4_data[s4_target[0]] = False
            r4 = instance.verify_data(s4_data)
            s_results['S4'] = (r4 == z3.unsat)
        else:
            s_results['S4'] = False
        if s_results['S4']:
            passed += 1

        # S5 (extension): multi-exception partial coverage. With >=2 exception
        # vars, set all-but-one True (a proper subset, not all) and every
        # obligation var False -> expect unsat. Targets encodings correct for
        # a single exception predicate but wrong when multiple exception
        # grounds must all be present simultaneously (e.g. GDPR Art. 9(2),
        # which needs all special-category processing grounds encoded). If
        # fewer than 2 exception vars, this scenario can't discriminate from
        # S3, so it repeats S3's outcome (same fallback style as S3 -> S2).
        if len(exc_vars) >= 2:
            s5_data = {v: False for v in bool_vars}
            for v in exc_vars[:-1]:
                s5_data[v] = True
            r5 = instance.verify_data(s5_data)
            s_results['S5'] = (r5 == z3.unsat)
        else:
            s_results['S5'] = s_results['S3']
        if s_results['S5']:
            passed += 1

        # S6 (extension): compound boundary. With >=2 obligation vars, all
        # vars True except two obligation vars flipped False -> expect unsat
        # (S4 only flips one). The two flip targets are chosen by
        # _pick_binding_obligation_vars() rather than blindly obl_vars[0:2],
        # for the same reason as S4 above. Targets encodings that are correct
        # when exactly one obligation is unmet but wrong when two are
        # simultaneously unmet (e.g. an OR used where an AND across
        # obligations is required). If fewer than 2 obligation vars, this
        # scenario can't discriminate from S4, so it repeats S4's outcome.
        if len(obl_vars) >= 2:
            s6_targets = _pick_binding_obligation_vars(instance, bool_vars, obl_vars, 2)
            s6_data = {v: True for v in bool_vars}
            s6_data[s6_targets[0]] = False
            s6_data[s6_targets[1]] = False
            r6 = instance.verify_data(s6_data)
            s_results['S6'] = (r6 == z3.unsat)
        else:
            s_results['S6'] = s_results['S4']
        if s_results['S6']:
            passed += 1

        return {
            'n_vars': len(bool_vars),
            'n_exc': len(exc_vars),
            'n_obl': len(obl_vars),
            'S1': s_results['S1'],
            'S2': s_results['S2'],
            'S3': s_results['S3'],
            'S4': s_results['S4'],
            'S5': s_results['S5'],
            'S6': s_results['S6'],
            'passed': passed,
        }

    except Exception as e:
        return {'error': f'eval_error: {str(e)[:150]}', 'passed': 0,
                'S1': False, 'S2': False, 'S3': False, 'S4': False,
                'S5': False, 'S6': False}


# ---------------------------------------------------------------------------
# Evaluate one method across all datasets
# ---------------------------------------------------------------------------

def evaluate_method(tier: str, method: str) -> dict:
    """Return {dataset: {section_id: result_dict}} for a given tier+method."""
    all_results = {}
    for dataset in DATASETS:
        if method == 'refine':
            sections = get_refine_sections(tier, dataset)
        else:
            sections = get_baseline_sections(tier, method, dataset)

        all_results[dataset] = {}
        for sec_id, py_path in sorted(sections.items()):
            result = load_and_evaluate(py_path)
            all_results[dataset][sec_id] = result
            passed = result.get('passed', 0)
            err = f"  [{result.get('error', '')}]" if 'error' in result else ''
            print(f"[{tier.upper()}] {dataset:6s}  {method:10s}  {sec_id:22s}  {passed}/6{err}",
                  flush=True)

    return all_results


# ---------------------------------------------------------------------------
# Summary aggregation
# ---------------------------------------------------------------------------

def compute_summary(all_results: dict) -> dict:
    """Compute per-tier per-method summary stats from full results dict."""
    summary = {}
    methods_order = ['refine'] + [f'b{i}' for i in range(1, 10)]

    for tier in ('slm', 'llm'):
        summary[tier] = {}
        for method in methods_order:
            if method not in all_results[tier]:
                continue
            method_data = all_results[tier][method]

            n = s1 = s2 = s3 = s4 = s5 = s6 = total_passed = errors = 0
            by_reg = {}

            for dataset in DATASETS:
                rn = rs1 = rs2 = rs3 = rs4 = rs5 = rs6 = rp = re_ = 0
                for sec_id, res in method_data.get(dataset, {}).items():
                    n += 1
                    rn += 1
                    if 'error' in res:
                        errors += 1
                        re_ += 1
                        continue
                    p = res.get('passed', 0)
                    total_passed += p
                    rp += p
                    if res.get('S1'):
                        s1 += 1; rs1 += 1
                    if res.get('S2'):
                        s2 += 1; rs2 += 1
                    if res.get('S3'):
                        s3 += 1; rs3 += 1
                    if res.get('S4'):
                        s4 += 1; rs4 += 1
                    if res.get('S5'):
                        s5 += 1; rs5 += 1
                    if res.get('S6'):
                        s6 += 1; rs6 += 1

                by_reg[dataset] = {
                    'n': rn, 'errors': re_,
                    'S1': rs1, 'S2': rs2, 'S3': rs3, 'S4': rs4,
                    'S5': rs5, 'S6': rs6,
                    'total_passed': rp,
                    'pct': round(100 * rp / (rn * 6), 2) if rn else 0.0,
                }

            max_score = n * 6
            summary[tier][method] = {
                'n_sections': n,
                'errors': errors,
                'S1': s1, 'S2': s2, 'S3': s3, 'S4': s4, 'S5': s5, 'S6': s6,
                'total_passed': total_passed,
                'max_score': max_score,
                'pct': round(100 * total_passed / max_score, 2) if max_score else 0.0,
                'by_reg': by_reg,
            }

    return summary


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    methods = ['refine'] + [f'b{i}' for i in range(1, 10)]

    all_results = {'slm': {}, 'llm': {}}

    for tier in ('slm', 'llm'):
        print(f'\n{"=" * 66}', flush=True)
        print(f'  Evaluating tier: {tier.upper()}', flush=True)
        print(f'{"=" * 66}', flush=True)

        for method in methods:
            print(f'\n--- {method} ({tier.upper()}) ---', flush=True)
            all_results[tier][method] = evaluate_method(tier, method)

    # Save per-tier detail JSON — written under _s6b names so the original
    # S1-S4-only hpc_results_*.json / hpc_summary.json (Jul 6 run) AND the
    # _s6 run (keyword-only obl_vars picker) are never overwritten; this is
    # a real re-run against the same local candidate corpus, now scored with
    # the binding-obligation-variable selector for S4/S6.
    for tier in ('slm', 'llm'):
        out_path = BASE / f'hpc_results_{tier}_s6b.json'
        with open(out_path, 'w') as f:
            json.dump(all_results[tier], f, indent=2, default=str)
        print(f'\nSaved: {out_path}', flush=True)

    # Compute and save summary
    summary = compute_summary(all_results)
    summary_path = BASE / 'hpc_summary_s6b.json'
    with open(summary_path, 'w') as f:
        json.dump(summary, f, indent=2)
    print(f'Saved: {summary_path}', flush=True)

    # Print results table
    print('\n\n' + '=' * 70)
    print('RESULTS SUMMARY')
    print('=' * 70)
    hdr = (f"{'Method':<12} {'N':>5} {'S1':>5} {'S2':>5} {'S3':>5} {'S4':>5} "
           f"{'S5':>5} {'S6':>5} {'Total%':>8}")
    for tier in ('slm', 'llm'):
        print(f'\nTier: {tier.upper()}')
        print(hdr)
        print('-' * 62)
        for method in methods:
            s = summary[tier].get(method)
            if not s:
                continue
            print(f"{method:<12} {s['n_sections']:>5} {s['S1']:>5} {s['S2']:>5} "
                  f"{s['S3']:>5} {s['S4']:>5} {s['S5']:>5} {s['S6']:>5} "
                  f"{s['pct']:>7.1f}%")

    print('\nDone.', flush=True)


if __name__ == '__main__':
    main()
