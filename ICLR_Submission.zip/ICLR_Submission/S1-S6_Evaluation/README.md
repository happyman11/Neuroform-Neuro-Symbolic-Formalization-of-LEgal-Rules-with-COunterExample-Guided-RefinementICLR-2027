# S1-S6 behavioral evaluation

`hpc_multiscenario_eval_s6b.py` is the canonical post-hoc evaluator that produced this paper's S1-S6
(Compliance/Violation/Exception/Boundary/Multi-Exception/Compound-Boundary) numbers. It is included here
**for reference and reuse**, credited by name in `Pipeline/{SLM,LLM}/lib/paper_harness.py`'s own module
docstring -- `paper_harness.py` ports this file's `classify_vars`/binding-obligation-variable/scenario-
construction logic (not imported, matching this repo's per-tier self-containment convention) into a real,
per-candidate `h_rep`/`h_eval` construction used *during* synthesis (`algorithm_mode="paper_exact"`), rather
than only after the fact.

## What runs out of the box vs. what doesn't

- **`main()`** (bottom of the file) hardcodes specific collaborator run-output directories
  (`hcd/`, `adityab/`, `ravi/` subfolders with fixed run-timestamp names) that are raw multi-GB evidence dumps,
  not code, and are **not included in this bundle** (see the top-level README's Files table). Running `main()`
  as-is will fail to find those directories.
- **The reusable functions** -- `load_and_evaluate(py_path)`, `classify_vars(var_names)`,
  `find_class(mod)`, `get_bool_vars(instance)` -- work standalone against **any** `Section_*_SUCCESS.py` file,
  including ones a reviewer generates by actually running `Pipeline/SLM` or `Pipeline/LLM` on this bundle's own
  `Benchmark/dataset/`. Example:

  ```python
  import sys
  sys.path.insert(0, ".")
  from hpc_multiscenario_eval_s6b import load_and_evaluate
  from pathlib import Path

  result = load_and_evaluate(Path("path/to/Section_ChIII_Sec11_SUCCESS.py"))
  print(result)   # {'S1': True, 'S2': True, ..., 'passed': 5, ...}
  ```

## Relationship to `algorithm_mode="paper_exact"`

This script's scenario semantics (6 categories, all-True/all-False/exception-subset/obligation-flip witnesses)
are reproduced **exactly** by `Pipeline/{SLM,LLM}/lib/paper_harness.py::build_hrep()` -- verified during this
bundle's construction across 440+ real candidate files with zero mismatches after a fix to the Boundary/
Compound-Boundary "not testable" fallback (see `PAPER_CODE_CORRESPONDENCE.md` and `paper_harness.py`'s own
`ScenarioEntry.auto_fail` docstring for the exact bug that fix addresses). Use this file to independently
verify S1-S6 verdicts on any finished candidate; use `paper_harness.py`/`paper_diagnostics.py` to see the same
logic wired into the live synthesis/repair loop.
