#!/usr/bin/env python3
"""
dataset_split.py — Stratified 70/15/15 train/val/test split for REFINE-SMT-Acts.

Split is stratified by four factors (paper §3.2):
  1. Act          — DPDP | GDPR | CCPA | PIPD
  2. Deontic type — O (obligation) | F (prohibition) | P (permission)
  3. Clause type  — temporal | role_hierarchy | conjunctive |
                    contrary_to_duty | multi_exception | multi_label
  4. Complexity   — simple (0 subsections) | moderate (1-2) | complex (3+)

Total corpus: 800 clauses (GDPR:240, CCPA:180, DPDP:220, PIPD:160)
              O=455, F=203, P=142

Usage:
    python dataset_split.py                           # write split to SLM_Output/aggregate/
    python dataset_split.py --input-dir <path>       # custom input root
    python dataset_split.py --seed 42 --dry-run      # preview split counts only
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import random
import sys
from collections import defaultdict
from pathlib import Path

_HERE = Path(__file__).parent.parent
sys.path.insert(0, str(_HERE))
from slm_config import ACTS_INPUT, AGGREGATE_OUT, IGNORE_FILES

logger = logging.getLogger("dataset_split")

# Corpus counts per act (paper §3.2)
ACT_TARGET = {"GDPR": 240, "CCPA": 180, "DPDP": 220, "PIPD": 160}

SPLIT_RATIOS = {"train": 0.70, "val": 0.15, "test": 0.15}
DEFAULT_SEED = 42


# ---------------------------------------------------------------------------
# Stratification helpers
# ---------------------------------------------------------------------------

def _deontic_label(section: dict) -> str:
    """Return "O", "F", "P", or "unknown" from label_metrics."""
    counts = section.get("label_metrics", {}).get("counts", {})
    mapping = {"#obligation": "O", "#prohibition": "F", "#permission": "P"}
    best, best_val = "unknown", 0
    for raw, label in mapping.items():
        v = counts.get(raw, 0)
        if v > best_val:
            best, best_val = label, v
    return best


def _clause_type(section: dict) -> str:
    """Infer clause type from structured_annotation tags or source metadata."""
    ann = section.get("structured_annotation", {})
    tags = ann.get("clause_tags", []) or ann.get("tags", [])
    tag_str = " ".join(str(t).lower() for t in tags)

    if "temporal" in tag_str or "deadline" in tag_str:
        return "temporal"
    if "role" in tag_str or "hierarchy" in tag_str:
        return "role_hierarchy"
    if "contrary" in tag_str or "ctd" in tag_str:
        return "contrary_to_duty"
    if "multi_exception" in tag_str or "exception" in tag_str:
        return "multi_exception"
    if "multi_label" in tag_str or "multiple" in tag_str:
        return "multi_label"
    if "conjunctive" in tag_str or "and" in tag_str:
        return "conjunctive"
    return "general"


def _complexity(section: dict) -> str:
    """Return "simple" | "moderate" | "complex" based on subsection count."""
    n = len(
        section.get("structured_annotation", {}).get("subsections", [])
        or section.get("source", {}).get("sub_sections", [])
    )
    if n == 0:
        return "simple"
    if n <= 2:
        return "moderate"
    return "complex"


def _stratum_key(act: str, section: dict) -> str:
    return f"{act}|{_deontic_label(section)}|{_clause_type(section)}|{_complexity(section)}"


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def load_all_sections(acts: list[str] | None = None) -> list[dict]:
    """Load every section JSON from ACTS_INPUT and return a flat list of dicts."""
    acts = acts or list(ACTS_INPUT.keys())
    items: list[dict] = []
    for act in acts:
        act_dir = ACTS_INPUT.get(act)
        if not act_dir or not act_dir.exists():
            logger.warning("Act input missing: %s → %s", act, act_dir)
            continue
        for fname in sorted(os.listdir(act_dir)):
            if not fname.endswith(".json") or fname in IGNORE_FILES:
                continue
            fpath = act_dir / fname
            try:
                with open(fpath, encoding="utf-8") as fh:
                    full = json.load(fh)
            except Exception:
                logger.warning("Failed to load: %s", fpath)
                continue
            section = full.get("annotation", full)
            section["_act"]      = act
            section["_filename"] = fname
            section["_path"]     = str(fpath)
            # Inject top-level metadata so helpers work
            for key in ("label_metrics", "structured_annotation", "source"):
                if key in full and key not in section:
                    section[key] = full[key]
            items.append(section)
    return items


# ---------------------------------------------------------------------------
# Stratified split
# ---------------------------------------------------------------------------

def stratified_split(
    items: list[dict],
    seed: int = DEFAULT_SEED,
    ratios: dict | None = None,
) -> dict[str, list[dict]]:
    """
    Perform stratified 70/15/15 split.

    Items are grouped by stratum key (act × deontic × clause_type × complexity).
    Within each stratum, items are shuffled deterministically then split by ratio.
    Remainders go to train to preserve exact counts.
    """
    ratios = ratios or SPLIT_RATIOS
    rng = random.Random(seed)

    strata: dict[str, list[dict]] = defaultdict(list)
    for item in items:
        key = _stratum_key(item["_act"], item)
        strata[key].append(item)

    splits: dict[str, list[dict]] = {"train": [], "val": [], "test": []}

    for key, group in sorted(strata.items()):
        rng.shuffle(group)
        n = len(group)
        n_val  = max(1, round(n * ratios["val"]))  if n >= 3 else 0
        n_test = max(1, round(n * ratios["test"])) if n >= 3 else 0
        n_train = n - n_val - n_test

        splits["train"].extend(group[:n_train])
        splits["val"].extend(group[n_train:n_train + n_val])
        splits["test"].extend(group[n_train + n_val:])

    return splits


# ---------------------------------------------------------------------------
# Summary helpers
# ---------------------------------------------------------------------------

def split_summary(splits: dict[str, list[dict]]) -> dict:
    summary: dict = {}
    for split_name, items in splits.items():
        by_act     = defaultdict(int)
        by_deontic = defaultdict(int)
        by_complex = defaultdict(int)
        by_clause  = defaultdict(int)
        for item in items:
            by_act[item["_act"]] += 1
            by_deontic[_deontic_label(item)] += 1
            by_complex[_complexity(item)] += 1
            by_clause[_clause_type(item)] += 1
        summary[split_name] = {
            "total":      len(items),
            "by_act":     dict(by_act),
            "by_deontic": dict(by_deontic),
            "by_complexity": dict(by_complex),
            "by_clause_type": dict(by_clause),
        }
    return summary


def print_summary(summary: dict) -> None:
    for split_name, s in summary.items():
        print(f"\n{split_name.upper()} ({s['total']} sections)")
        print(f"  Acts:       {s['by_act']}")
        print(f"  Deontic:    {s['by_deontic']}")
        print(f"  Complexity: {s['by_complexity']}")
        print(f"  Clause:     {s['by_clause_type']}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    p = argparse.ArgumentParser(description="Stratified 70/15/15 dataset split")
    p.add_argument("--acts",      default=None, help="Comma-separated acts (default: all 4)")
    p.add_argument("--seed",      type=int, default=DEFAULT_SEED)
    p.add_argument("--out-dir",   default=str(AGGREGATE_OUT), help="Output directory")
    p.add_argument("--dry-run",   action="store_true", help="Print counts only, no files written")
    args = p.parse_args()

    acts = args.acts.split(",") if args.acts else None
    items = load_all_sections(acts)
    logger.info("Loaded %d sections total", len(items))

    splits = stratified_split(items, seed=args.seed)
    summary = split_summary(splits)
    print_summary(summary)

    if args.dry_run:
        return

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Write split index (filenames + act, not full section content)
    split_index: dict[str, list[dict]] = {}
    for split_name, items in splits.items():
        split_index[split_name] = [
            {"act": item["_act"], "filename": item["_filename"], "path": item["_path"],
             "deontic": _deontic_label(item), "complexity": _complexity(item),
             "clause_type": _clause_type(item)}
            for item in items
        ]

    index_path = out_dir / "dataset_split.json"
    with open(index_path, "w", encoding="utf-8") as f:
        json.dump({"seed": args.seed, "ratios": SPLIT_RATIOS,
                   "summary": summary, "splits": split_index}, f, indent=2)
    logger.info("Split index written: %s", index_path)

    # Write per-split section ID lists for easy reference
    for split_name, items in split_index.items():
        ids_path = out_dir / f"split_{split_name}_ids.txt"
        with open(ids_path, "w", encoding="utf-8") as f:
            for item in items:
                f.write(f"{item['act']}/{item['filename']}\n")
        logger.info("  %s IDs: %s", split_name, ids_path)


if __name__ == "__main__":
    main()
