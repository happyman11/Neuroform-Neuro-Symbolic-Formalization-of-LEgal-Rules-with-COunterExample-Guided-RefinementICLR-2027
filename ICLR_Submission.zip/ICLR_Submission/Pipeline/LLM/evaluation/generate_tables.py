#!/usr/bin/env python3
"""
generate_tables.py — Produce AAAI-ready LaTeX + CSV tables from evaluation output.

Generates:
  table_main_results.tex       — Main results (acts × metrics)
  table_ablation_A1.tex/A2/A3 — Model-tier ablation (variant × metrics)
  table_5_error_class.tex      — Per-error-class repair rates (E1–E5)
  table_6_cegar_convergence.tex— CEGAR convergence profile
  table_7_full_ablation.tex    — All variants × core metrics (Table 7)
  all_tables.csv               — Machine-readable combined CSV

Usage:
    python generate_tables.py \\
        --benchmark SLM_Output/normal/SLM-Primary-.../ \\
        --ablation  SLM_Output/ablation/ \\
        --output    SLM_Output/aggregate/
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent.parent))


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_ACTS = ["DPDP", "GDPR", "CCPA", "PIPD"]

_MAIN_METRICS = [
    ("end_to_end_success_rate",  "Success"),
    ("deontic_consistency_rate", "Aligned"),
    ("oracle_pass_rate",         "Oracle"),
    ("repair_success_rate",      "Repair"),
    ("mean_convergence_iters",   "CEGAR↓"),
    ("mean_wall_time_sec",       "Time(s)↓"),
]

_ABLATION_METRICS_A1 = [
    ("syntax_validity_rate",      "SynVal"),
    ("oracle_pass_rate",          "Oracle"),
    ("beam_diversity",            "BeamDiv"),
    ("symbolic_consistency_rate", "SymCon"),
    ("end_to_end_success_rate",   "E2E"),
]

_ABLATION_METRICS_A2 = [
    ("e3_detection_rate",        "E3Det"),
    ("deontic_consistency_rate", "Deont"),
    ("false_alignment_rate",     "FalseAl"),
    ("mean_semantic_alignment",  "Align"),
    ("end_to_end_success_rate",  "E2E"),
]

_ABLATION_METRICS_A3 = [
    ("repair_success_rate",      "RepSuc"),
    ("mean_convergence_iters",   "CEGARitr↓"),
    ("repair_stability_score",   "RepStab"),
    ("end_to_end_success_rate",  "E2E"),
]

_ABLATION_METRIC_MAP = {
    "A1_generation_scaling": _ABLATION_METRICS_A1,
    "A2_semantic_verifier":  _ABLATION_METRICS_A2,
    "A3_repair_capability":  _ABLATION_METRICS_A3,
}

# Error classes E1–E5 (paper §4.4 / Table 5)
_ERROR_CLASSES = ["E1_syntax", "E2_z3_encoding", "E3_semantic_inversion",
                  "E4_incomplete", "E5_overconstrained"]
_ERROR_SHORT = ["E1 Syntax", "E2 Z3-Enc", "E3 Sem-Inv", "E4 Incompl", "E5 OverCon"]

# All ablation study names for Table 7
_ALL_STUDIES = [
    "A1_generation_scaling", "A2_semantic_verifier", "A3_repair_capability",
    "M1_beam_width", "M2_oracle_variant", "M3_llm_b_variant",
    "M4_feedback_mode", "M5_cegar_budget", "V6_model_family",
]

# Core metrics for Table 7 (compact)
_TABLE7_METRICS = [
    ("end_to_end_success_rate",  "Success%"),
    ("semantic_alignment_rate",  "Align%"),
    ("mean_convergence_iters",   "AvgCEGAR↓"),
    ("mean_llm_calls",           "LLMcalls↓"),
    ("mean_wall_time_sec",       "Time(s)↓"),
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_eval(path: Path) -> dict:
    p = path / "evaluation_metrics.json"
    if not p.exists():
        try:
            from evaluator import evaluate_run
            return evaluate_run(path)
        except Exception as e:
            print(f"[WARN] No evaluation_metrics.json at {path}: {e}")
            return {}
    with open(p) as f:
        return json.load(f)


def _load_section_logs(run_dir: Path) -> list[dict]:
    logs = []
    for p in sorted(run_dir.rglob("section_metrics.json")):
        try:
            with open(p, encoding="utf-8") as f:
                logs.append(json.load(f))
        except Exception:
            pass
    return logs


def _fmt(v: Any, pct: bool = True) -> str:
    if v is None:
        return "--"
    if pct and isinstance(v, float) and 0 <= v <= 1:
        return f"{v:.1%}"
    if isinstance(v, float):
        return f"{v:.2f}"
    return str(v)


def _latex_table(label: str, caption: str, header: list[str], body_rows: list[str],
                 footnote: str = "") -> str:
    col_spec = "l" + "c" * (len(header) - 1)
    head_line = " & ".join(r"\textbf{" + h + "}" for h in header) + r" \\"
    lines = [
        r"\begin{table}[h]",
        r"\centering",
        r"\small",
        rf"\begin{{tabular}}{{{col_spec}}}",
        r"\toprule",
        head_line,
        r"\midrule",
        *body_rows,
        r"\bottomrule",
        r"\end{tabular}",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
    ]
    if footnote:
        lines.insert(-1, rf"\footnotesize{{{footnote}}}")
    lines.append(r"\end{table}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main results table
# ---------------------------------------------------------------------------

def build_main_table(bench_dir: Path) -> tuple[str, list[dict]]:
    eval_data = _load_eval(bench_dir)
    if not eval_data:
        return "", []

    per_act = eval_data.get("per_act", {})
    agg     = eval_data.get("aggregate", {})
    header_cols = ["Act"] + [label for _, label in _MAIN_METRICS]
    rows_tex, rows_csv = [], []

    for act in _ACTS + ["All"]:
        m = agg if act == "All" else per_act.get(act, {})
        if not m:
            continue
        tex_row = [act if act != "All" else r"\textit{All}"]
        csv_row = {"act": act}
        for key, label in _MAIN_METRICS:
            v = m.get(key)
            tex_row.append(_fmt(v))
            csv_row[label] = v
        if act == "All":
            rows_tex.append(r"\midrule")
        rows_tex.append(" & ".join(tex_row) + r" \\")
        rows_csv.append(csv_row)

    model_info = eval_data.get("models", {})
    caption = (
        r"REFINE-SMT SLM Primary Results across four privacy acts. "
        rf"LLM-A=\texttt{{{model_info.get('llm_a',{}).get('model','?')}}}, "
        rf"LLM-B=\texttt{{{model_info.get('llm_b',{}).get('model','?')}}}, "
        rf"LLM-C=\texttt{{{model_info.get('llm_c',{}).get('model','?')}}}."
    )
    tex = _latex_table("tab:main_results", caption, header_cols, rows_tex)
    return tex, rows_csv


# ---------------------------------------------------------------------------
# Ablation tables (A1 / A2 / A3)
# ---------------------------------------------------------------------------

def build_ablation_table(ablation_dir: Path, study: str) -> tuple[str, list[dict]]:
    study_dir = ablation_dir / study
    if not study_dir.exists():
        return "", []

    metric_defs = _ABLATION_METRIC_MAP.get(study, _MAIN_METRICS)
    variants = ["weak", "medium", "strong"]

    full_tex_blocks, all_csv = [], []
    header_cols = ["Variant"] + _ACTS + ["Avg"]

    for metric_key, metric_label in metric_defs:
        body_rows = []
        for variant in variants:
            vdir = study_dir / variant
            if not vdir.exists():
                continue
            eval_data = _load_eval(vdir)
            if not eval_data:
                continue
            per_act = eval_data.get("per_act", {})
            agg     = eval_data.get("aggregate", {})
            values  = [per_act.get(a, {}).get(metric_key) for a in _ACTS]
            avg     = agg.get(metric_key)
            row = [variant.capitalize()] + [_fmt(v) for v in values] + [_fmt(avg)]
            body_rows.append(" & ".join(row) + r" \\")
            csv_row = {"study": study, "variant": variant, "metric": metric_key}
            for act, v in zip(_ACTS, values):
                csv_row[act] = v
            csv_row["avg"] = avg
            all_csv.append(csv_row)

        if body_rows:
            sub_tex = _latex_table(
                label=f"tab:{study}_{metric_key}",
                caption=f"{study.replace('_', ' ')} — {metric_label}",
                header=header_cols,
                body_rows=body_rows,
            )
            full_tex_blocks.append(sub_tex)

    return "\n\n".join(full_tex_blocks), all_csv


# ---------------------------------------------------------------------------
# Table 5: Per-error-class repair rates  (E1–E5)
# ---------------------------------------------------------------------------

def build_table5_error_class(bench_dir: Path, ablation_dir: Path) -> tuple[str, list[dict]]:
    """
    Table 5: Occurrence%, Repair% and mean iterations per error class.
    Uses benchmark logs; optionally also shows best vs worst variant from A3.
    """
    logs = _load_section_logs(bench_dir)
    if not logs:
        return "", []

    # Count occurrences and repair outcomes per error class
    class_stats: dict[str, dict] = {ec: {"occur": 0, "repaired": 0, "iters": []}
                                     for ec in _ERROR_CLASSES}
    total = len(logs)

    for lg in logs:
        err_seq  = lg.get("error_analysis", {}).get("error_type_sequence", [])
        success  = lg.get("results", {}).get("final_success", False)
        cegar_it = lg.get("slm_extra", {}).get("cegar_iter_scores", [])

        for ec in _ERROR_CLASSES:
            if ec in err_seq:
                class_stats[ec]["occur"] += 1
                if success:
                    class_stats[ec]["repaired"] += 1
                    class_stats[ec]["iters"].append(len(cegar_it))

    header_cols = ["Error Class", "Occur%", "Repair%", "Avg Iters"]
    body_rows, all_csv = [], []

    for ec, short in zip(_ERROR_CLASSES, _ERROR_SHORT):
        stats    = class_stats[ec]
        occur_r  = stats["occur"] / total if total > 0 else 0.0
        repair_r = stats["repaired"] / stats["occur"] if stats["occur"] > 0 else 0.0
        avg_iter = sum(stats["iters"]) / len(stats["iters"]) if stats["iters"] else 0.0
        row = [short, _fmt(occur_r), _fmt(repair_r), f"{avg_iter:.2f}"]
        body_rows.append(" & ".join(row) + r" \\")
        all_csv.append({
            "error_class": ec, "occurrence_rate": occur_r,
            "repair_rate": repair_r, "avg_iters": avg_iter,
        })

    tex = _latex_table(
        label="tab:error_class_repair",
        caption=(
            r"Per-error-class statistics. Occur\% = fraction of sections exhibiting "
            r"each error; Repair\% = fraction successfully resolved by LLM-C."
        ),
        header=header_cols,
        body_rows=body_rows,
    )
    return tex, all_csv


# ---------------------------------------------------------------------------
# Table 6: CEGAR convergence profile
# ---------------------------------------------------------------------------

def build_table6_cegar_convergence(bench_dir: Path) -> tuple[str, list[dict]]:
    """
    Table 6: Cumulative fix rate and marginal gain at each CEGAR iteration.
    """
    logs = _load_section_logs(bench_dir)
    if not logs:
        return "", []

    # Determine max iterations across all sections
    max_k = 0
    for lg in logs:
        scores = lg.get("slm_extra", {}).get("cegar_iter_scores", [])
        max_k = max(max_k, len(scores))

    if max_k == 0:
        return "", []

    threshold = 0.7
    # For each iteration k: how many sections had their best score cross threshold by iter k?
    sections_with_cegar = [
        lg for lg in logs
        if lg.get("slm_extra", {}).get("cegar_iter_scores")
    ]
    n = len(sections_with_cegar)
    if n == 0:
        return "", []

    cumulative = []
    for k in range(1, max_k + 1):
        fixed = sum(
            1 for lg in sections_with_cegar
            if any(s >= threshold
                   for s in lg["slm_extra"]["cegar_iter_scores"][:k])
        )
        cumulative.append(fixed / n)

    marginal = [cumulative[0]] + [cumulative[i] - cumulative[i-1]
                                   for i in range(1, len(cumulative))]

    header_cols = ["Iter k"] + [f"Cumul@k={k}" for k in range(1, max_k + 1)] + ["Total"]
    # Single row with all values
    body_rows = [
        "Cumul. Fix\\% & " + " & ".join(_fmt(c) for c in cumulative) + r" \\",
        "Marginal & " + " & ".join(_fmt(m) for m in marginal) + r" \\",
    ]

    all_csv = [{"metric": "cumulative_fix_rate", **{f"k{i+1}": v for i, v in enumerate(cumulative)}}]
    all_csv.append({"metric": "marginal_gain",    **{f"k{i+1}": v for i, v in enumerate(marginal)}})

    tex = _latex_table(
        label="tab:cegar_convergence",
        caption=(
            rf"CEGAR convergence profile (n={n} sections with $\geq$1 repair iteration). "
            r"Cumul.\ Fix\% = fraction of sections reaching oracle score $\geq 0.7$ "
            r"within $k$ iterations."
        ),
        header=["Metric"] + [f"k={k}" for k in range(1, max_k + 1)],
        body_rows=body_rows,
    )
    return tex, all_csv


# ---------------------------------------------------------------------------
# Table 7: Full ablation summary — all variants × core metrics
# ---------------------------------------------------------------------------

def build_table7_full_ablation(ablation_dir: Path) -> tuple[str, list[dict]]:
    """
    Table 7: One row per (study, variant) across all ablation studies.
    Columns: Study | Variant | Success% | Align% | AvgCEGAR | LLMcalls | Time(s)
    """
    header_cols = ["Study", "Variant"] + [label for _, label in _TABLE7_METRICS]
    body_rows, all_csv = [], []
    prev_study = None

    for study in _ALL_STUDIES:
        study_dir = ablation_dir / study
        if not study_dir.exists():
            continue

        # Collect variant dirs alphabetically
        variant_dirs = sorted(
            d for d in study_dir.iterdir() if d.is_dir()
        )
        if not variant_dirs:
            continue

        for vdir in variant_dirs:
            variant = vdir.name
            eval_data = _load_eval(vdir)
            if not eval_data:
                # Try aggregate metrics directly
                agg_files = list(vdir.glob("*_aggregate_metrics.json"))
                if agg_files:
                    try:
                        with open(agg_files[0]) as f:
                            eval_data = {"aggregate": json.load(f)}
                    except Exception:
                        continue
                else:
                    continue

            agg = eval_data.get("aggregate", eval_data)
            study_label = study.replace("_", "-") if study != prev_study else r"\ditto"
            prev_study  = study

            row = [study_label, variant]
            csv_row = {"study": study, "variant": variant}
            for key, label in _TABLE7_METRICS:
                v = agg.get(key)
                row.append(_fmt(v))
                csv_row[label] = v
            body_rows.append(" & ".join(row) + r" \\")
            all_csv.append(csv_row)

        body_rows.append(r"\midrule")

    # Remove trailing midrule
    if body_rows and body_rows[-1] == r"\midrule":
        body_rows.pop()

    if not body_rows:
        return "", []

    tex = _latex_table(
        label="tab:full_ablation",
        caption=(
            r"Full ablation summary across all study variants (A1–A3, M1–M5, V6). "
            r"Success\% = end-to-end success rate; Align\% = semantic alignment rate; "
            r"AvgCEGAR = mean CEGAR repair iterations."
        ),
        header=header_cols,
        body_rows=body_rows,
        footnote=r"↓ = lower is better. \textit{ditto} = same study as preceding row.",
    )
    return tex, all_csv


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="Generate AAAI tables from SLM evaluation")
    p.add_argument("--benchmark", type=Path, required=True, help="Path to benchmark run dir")
    p.add_argument("--ablation",  type=Path, required=True, help="Path to SLM_Output/ablation/")
    p.add_argument("--output",    type=Path, required=True, help="Output directory for tables")
    args = p.parse_args()

    args.output.mkdir(parents=True, exist_ok=True)
    all_csv_rows: list[dict] = []

    # Table: Main results
    tex, rows = build_main_table(args.benchmark)
    if tex:
        (args.output / "table_main_results.tex").write_text(tex, encoding="utf-8")
        print("Written: table_main_results.tex")
        for r in rows:
            r["table"] = "main_results"
        all_csv_rows.extend(rows)

    # Tables: A1/A2/A3 ablation
    for study in ["A1_generation_scaling", "A2_semantic_verifier", "A3_repair_capability"]:
        short = study.split("_")[0]
        tex, rows = build_ablation_table(args.ablation, study)
        if tex:
            fname = f"table_ablation_{short}.tex"
            (args.output / fname).write_text(tex, encoding="utf-8")
            print(f"Written: {fname}")
            for r in rows:
                r["table"] = f"ablation_{short}"
            all_csv_rows.extend(rows)

    # Table 5: Per-error-class repair rates
    tex, rows = build_table5_error_class(args.benchmark, args.ablation)
    if tex:
        (args.output / "table_5_error_class.tex").write_text(tex, encoding="utf-8")
        print("Written: table_5_error_class.tex")
        for r in rows:
            r["table"] = "table_5"
        all_csv_rows.extend(rows)

    # Table 6: CEGAR convergence profile
    tex, rows = build_table6_cegar_convergence(args.benchmark)
    if tex:
        (args.output / "table_6_cegar_convergence.tex").write_text(tex, encoding="utf-8")
        print("Written: table_6_cegar_convergence.tex")
        for r in rows:
            r["table"] = "table_6"
        all_csv_rows.extend(rows)

    # Table 7: Full ablation summary
    tex, rows = build_table7_full_ablation(args.ablation)
    if tex:
        (args.output / "table_7_full_ablation.tex").write_text(tex, encoding="utf-8")
        print("Written: table_7_full_ablation.tex")
        for r in rows:
            r["table"] = "table_7"
        all_csv_rows.extend(rows)

    # Combined CSV
    if all_csv_rows:
        all_keys = sorted({k for r in all_csv_rows for k in r.keys()})
        csv_path = args.output / "all_tables.csv"
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=all_keys, extrasaction="ignore")
            w.writeheader()
            w.writerows(all_csv_rows)
        print(f"Written: all_tables.csv ({len(all_csv_rows)} rows)")

    print(f"\nAll tables written to {args.output}")


if __name__ == "__main__":
    main()
