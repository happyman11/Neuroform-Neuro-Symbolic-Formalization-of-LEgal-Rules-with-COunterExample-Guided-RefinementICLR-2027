#!/usr/bin/env python3
"""
evaluator.py — Process SLM output directories and compute AAAI evaluation metrics.

Usage:
    # Evaluate a benchmark run
    python evaluator.py --run-dir SLM_Output/normal/SLM-Primary-20260513T/

    # Evaluate a specific ablation variant
    python evaluator.py --run-dir SLM_Output/ablation/A1_generation_scaling/weak/

    # Evaluate all ablation variants for one study
    python evaluator.py --ablation-dir SLM_Output/ablation/A1_generation_scaling/

    # Compare two run dirs side-by-side
    python evaluator.py --compare dir1 dir2

Output:
    evaluation_metrics.json  — structured metrics
    evaluation_metrics.csv   — flat CSV for spreadsheets
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from evaluation.metrics import compute_all

SECTION_LOG_GLOB = "*_log.json"      # per-section SLM logs
SECTION_METRICS  = "section_metrics.json"  # original pipeline output


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def _load_logs_from_dir(run_dir: Path) -> list[dict]:
    """Recursively find all section_metrics.json under run_dir."""
    logs = []
    for p in sorted(run_dir.rglob(SECTION_METRICS)):
        try:
            with open(p, encoding="utf-8") as f:
                logs.append(json.load(f))
        except Exception as e:
            print(f"[WARN] Could not load {p}: {e}")
    return logs


def _group_by_act(logs: list[dict]) -> dict[str, list[dict]]:
    grouped: dict[str, list[dict]] = {}
    for lg in logs:
        act = lg.get("slm_metadata", {}).get("act", "unknown")
        grouped.setdefault(act, []).append(lg)
    return grouped


# ---------------------------------------------------------------------------
# Evaluate a single run directory
# ---------------------------------------------------------------------------

def evaluate_run(run_dir: Path) -> dict:
    logs = _load_logs_from_dir(run_dir)
    if not logs:
        print(f"[WARN] No section logs found under {run_dir}")
        return {}

    run_cfg: dict = {}
    cfg_path = run_dir / "run_config.json"
    if cfg_path.exists():
        with open(cfg_path) as f:
            run_cfg = json.load(f)

    grouped   = _group_by_act(logs)
    per_act   = {act: compute_all(act_logs) for act, act_logs in grouped.items()}
    aggregate = compute_all(logs)

    result = {
        "run_id":          run_cfg.get("run_id", run_dir.name),
        "experiment":      run_cfg.get("experiment", "unknown"),
        "variant":         run_cfg.get("variant", "unknown"),
        "models":          run_cfg.get("models", {}),
        "hyperparameters": run_cfg.get("hyperparameters", {}),
        "aggregate":       aggregate,
        "per_act":         per_act,
    }

    # Write outputs
    out_json = run_dir / "evaluation_metrics.json"
    out_csv  = run_dir / "evaluation_metrics.csv"

    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    _write_csv(result, out_csv)

    print(f"[OK] {run_dir.name} → {aggregate['n_sections']} sections | "
          f"success={aggregate['end_to_end_success_rate']:.2%} | "
          f"alignment={aggregate['deontic_consistency_rate']:.2%}")
    return result


# ---------------------------------------------------------------------------
# Evaluate a full ablation study directory (all variants)
# ---------------------------------------------------------------------------

def evaluate_ablation(ablation_dir: Path) -> dict:
    all_results: dict[str, dict] = {}
    for variant_dir in sorted(ablation_dir.iterdir()):
        if not variant_dir.is_dir() or variant_dir.name.startswith("."):
            continue
        res = evaluate_run(variant_dir)
        if res:
            all_results[variant_dir.name] = res

    if not all_results:
        print(f"[WARN] No variant results under {ablation_dir}")
        return {}

    # Side-by-side comparison
    comparison = _build_comparison(all_results)
    comp_path  = ablation_dir / "ablation_comparison.json"
    with open(comp_path, "w", encoding="utf-8") as f:
        json.dump(comparison, f, indent=2)
    print(f"\nAblation comparison written: {comp_path}")
    return comparison


def _build_comparison(results_by_variant: dict[str, dict]) -> dict:
    """Build a flat comparison dict keyed by metric, variant, act."""
    key_metrics = [
        "end_to_end_success_rate", "syntax_validity_rate", "oracle_pass_rate",
        "beam_diversity", "e3_detection_rate", "deontic_consistency_rate",
        "false_alignment_rate", "repair_success_rate", "mean_convergence_iters",
        "repair_stability_score", "mean_wall_time_sec", "mean_llm_calls",
    ]
    comparison: dict = {"variants": list(results_by_variant.keys()), "metrics": {}}
    for metric in key_metrics:
        comparison["metrics"][metric] = {}
        for variant, result in results_by_variant.items():
            comparison["metrics"][metric][variant] = {
                "aggregate": result.get("aggregate", {}).get(metric),
                "per_act": {
                    act: per.get(metric)
                    for act, per in result.get("per_act", {}).items()
                },
            }
    return comparison


# ---------------------------------------------------------------------------
# Side-by-side compare two run directories
# ---------------------------------------------------------------------------

def compare_runs(dir_a: Path, dir_b: Path) -> None:
    res_a = evaluate_run(dir_a)
    res_b = evaluate_run(dir_b)

    metrics = [
        "end_to_end_success_rate", "syntax_validity_rate", "oracle_pass_rate",
        "deontic_consistency_rate", "repair_success_rate", "mean_convergence_iters",
        "mean_wall_time_sec",
    ]
    print(f"\n{'Metric':<35} {dir_a.name:<20} {dir_b.name:<20} {'Δ':>8}")
    print("-" * 90)
    for m in metrics:
        va = res_a.get("aggregate", {}).get(m, 0) or 0
        vb = res_b.get("aggregate", {}).get(m, 0) or 0
        delta = vb - va
        print(f"  {m:<33} {va:<20.4f} {vb:<20.4f} {delta:>+8.4f}")


# ---------------------------------------------------------------------------
# CSV writer
# ---------------------------------------------------------------------------

def _write_csv(result: dict, out_path: Path) -> None:
    rows = []
    agg = result.get("aggregate", {})
    for k, v in agg.items():
        if isinstance(v, (int, float)):
            rows.append({"scope": "aggregate", "act": "all", "metric": k, "value": v})
    for act, per in result.get("per_act", {}).items():
        for k, v in per.items():
            if isinstance(v, (int, float)):
                rows.append({"scope": "per_act", "act": act, "metric": k, "value": v})

    if rows:
        with open(out_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["scope", "act", "metric", "value"])
            writer.writeheader()
            writer.writerows(rows)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="REFINE-SMT SLM Evaluator")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--run-dir",      type=Path, help="Evaluate a single run directory")
    g.add_argument("--ablation-dir", type=Path, help="Evaluate all variants in an ablation directory")
    g.add_argument("--compare",      nargs=2, type=Path, metavar=("DIR_A", "DIR_B"),
                   help="Compare two run directories")
    args = p.parse_args()

    if args.run_dir:
        evaluate_run(args.run_dir)
    elif args.ablation_dir:
        evaluate_ablation(args.ablation_dir)
    elif args.compare:
        compare_runs(args.compare[0], args.compare[1])


if __name__ == "__main__":
    main()
