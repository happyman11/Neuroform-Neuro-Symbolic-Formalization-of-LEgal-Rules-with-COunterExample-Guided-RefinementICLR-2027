#!/usr/bin/env python3
"""
test_ollama_backend.py -- offline (no real Ollama daemon) verification that owner="Ollama" is call-for-call
parameter-equivalent to owner="HuggingFace": same per-role temperature/max_tokens/system_message/seed resolution,
just routed to lib/models.py::ModelCall.ollama_call_model instead of HuggingFaceModel.call. Mocks the `ollama`
package itself (chat/list/pull), so this runs with no daemon, no GPU, no network.

    python3 test_ollama_backend.py
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "lib"))

from llm_pipeline import LLMRefineSMT  # noqa: E402
import models as models_mod  # noqa: E402

fails: list[str] = []


def check(cond, msg):
    if not cond:
        fails.append(msg)
    return cond


tmp = tempfile.mkdtemp()
pipe = LLMRefineSMT(
    # LLM-A and LLM-C deliberately use DIFFERENT model strings here (unlike the real paper-exact configs,
    # which do share "qwen2.5-coder:32b" for both roles) so _resolve_system_message's role lookup is
    # unambiguous for this test -- real runs disambiguate by call site, not by model string.
    output_path=tmp, model_owner="Ollama", model="qwen2.5-coder:32b",
    agnostic_model_owner="Ollama", agnostic_model="phi4",
    corrector_owner="Ollama", corrector_model="qwen2.5-coder:32b-corrector",
    max_outer_attempts=1, max_cegar_iterations=1, beam_width=1,
    oracle_pass_threshold=0.80, experiment="test", variant="test", act_name="TEST",
    seed=1234,
)

chat_calls = []


class FakeOllama:
    @staticmethod
    def list():
        return {"models": [{"model": "qwen2.5-coder:32b"}]}   # phi4 NOT present -> exercises the pull() path

    @staticmethod
    def pull(model):
        chat_calls.append(("pull", model))

    @staticmethod
    def chat(model, messages, options):
        chat_calls.append(("chat", model, messages, options))
        return {"message": {"content": "```python\nprint('ok')\n```"}}


with mock.patch.object(models_mod, "OLLAMA_AVAILABLE", True), \
     mock.patch.object(models_mod, "ollama", FakeOllama):
    models_mod.ModelCall._ollama_pulled = set()  # isolate from any other test's process-level cache
    out_a = pipe._call_llm("PROMPT-A", "Ollama", "qwen2.5-coder:32b", role="llm_a")
    out_b = pipe._call_llm("PROMPT-B", "Ollama", "phi4", role="llm_b")

check(out_a == "```python\nprint('ok')\n```", "T1: ollama_call_model did not return the mocked chat content")

chat_events = [c for c in chat_calls if c[0] == "chat"]
check(len(chat_events) == 2, f"T2: expected 2 ollama.chat() calls, got {len(chat_events)}")

_, model_a, messages_a, options_a = chat_events[0]
check(model_a == "qwen2.5-coder:32b", f"T3: LLM-A call routed to the wrong model: {model_a}")
check(messages_a[0]["role"] == "system" and messages_a[0]["content"] == pipe._LLM_A_SYSTEM_MSG,
      "T4: LLM-A system message not passed through to Ollama the same way as HuggingFace")
check(messages_a[-1] == {"role": "user", "content": "PROMPT-A"}, "T5: LLM-A user prompt malformed")
check(options_a["temperature"] == pipe._llm_a_temperature,
      f"T6: LLM-A temperature mismatch: {options_a['temperature']} != {pipe._llm_a_temperature}")
check(options_a["num_predict"] == pipe._llm_a_max_tokens, "T7: LLM-A max_tokens not passed as num_predict")
check(options_a["seed"] == 1234, f"T8: LLM-A seed should be the base seed (first call): got {options_a.get('seed')}")

_, model_b, messages_b, options_b = chat_events[1]
check(model_b == "phi4", f"T9: LLM-B call routed to the wrong model: {model_b}")
check(messages_b[0]["content"] == pipe._LLM_B_SYSTEM_MSG, "T10: LLM-B system message mismatch")
check(options_b["temperature"] == pipe._llm_b_temperature,
      f"T11: LLM-B temperature mismatch: {options_b['temperature']} != {pipe._llm_b_temperature}")
check(options_b["seed"] == 1235, f"T12: LLM-B seed should increment from the LLM-A call: got {options_b.get('seed')}")

pull_events = [c for c in chat_calls if c[0] == "pull"]
check(pull_events == [("pull", "phi4")],
      f"T13: expected exactly one pull() for the not-yet-local phi4 model, got {pull_events}")

print()
for m in fails:
    print("FAIL:", m)
print(f"{'ALL CHECKS PASSED' if not fails else str(len(fails)) + ' CHECK(S) FAILED'}")
raise SystemExit(0 if not fails else 1)
