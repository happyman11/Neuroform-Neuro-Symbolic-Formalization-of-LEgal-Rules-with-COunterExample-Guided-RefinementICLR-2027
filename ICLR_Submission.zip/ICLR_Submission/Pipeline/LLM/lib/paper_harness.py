"""
paper_harness.py -- real, per-candidate hrep/heval construction (Eq 1/3/10/11), used only when
algorithm_mode="paper_exact" (see RefineSMT.__init__). Ported (not imported, matching this repo's existing
per-tier self-containment convention) from HPC_ForAbstract/hpc_multiscenario_eval_s6b.py's
classify_vars/_pick_binding_obligation_vars/scenario-construction logic -- that module already implements
exactly the paper's six categories (S1..S6 = Compliance/Violation/Exception/Boundary/Multi-Exception/
Compound-Boundary), it was simply never wired into the repair loop; it only ever scored already-finished files
after the fact. This file reuses its scenario semantics verbatim and adds a genuinely-disjoint `heval` variant
plus a `run_harness()` that returns the Eq 2/4 quantities the paper's algorithm needs during synthesis.

P_s (Eq 3's "Boolean interface propositions relevant to the tested rule") is candidate-relative here, exactly as
the ported evaluator already assumed: it is whatever z3.Bool attributes the CURRENT candidate under test has
declared, discovered via get_bool_vars() below -- there is no provision-fixed interface in this codebase to read
instead, and the paper's own Q_φ ∩ P_s framing is itself candidate-relative.

Disclosed, not silently patched: under Eq 1, Compliance (all interface props True) and Violation (all False) are
each a SINGLETON assignment -- there is exactly one way to construct them for a given variable set. hrep's and
heval's S1/S2 are therefore necessarily the SAME concrete instance; X_rep ∩ X_eval = ∅ (Eq 11) cannot hold for
those two categories under this construction, and no alternative "all-true"/"all-false" assignment is defined by
Eq 1 to make them differ. This is a property of the paper's own formalization for these two categories, not a
gap in this port. For the remaining four categories (Exception/Boundary/Multi-Exception/Compound-Boundary) this
module deliberately picks a different concrete witness for heval than for hrep whenever the candidate's own
variable set gives it room to (see build_heval()'s docstring for the exact rule); when a category's activation
condition allows only one possible witness (e.g. exactly one exception variable), hrep/heval necessarily coincide
there too -- also disclosed via the `heval_disjoint_from_hrep` field `run_harness()` reports, never hidden.
"""
from __future__ import annotations

import importlib.util
import inspect
from dataclasses import dataclass, field
from pathlib import Path

import z3

# ---------------------------------------------------------------------------------------------------------------
# Variable classification -- byte-identical to HPC_ForAbstract/hpc_multiscenario_eval_s6b.py (credited above)
# ---------------------------------------------------------------------------------------------------------------
EXCEPTION_KEYWORDS = {
    'exception', 'exempt', 'archiving', 'scientific', 'research',
    'national_security', 'household', 'journalism', 'legitimate', 'overridden',
    'public_interest', 'vital_interests', 'employment', 'medical', 'emergency',
    'epidemic', 'disaster', 'court', 'judgment', 'compliance_legal', 'legal_basis',
    'guardian', 'minor', 'subsequently', 'subsidy', 'state_function',
}
OBLIGATION_KEYWORDS = {
    'informs', 'consent', 'compliant', 'lawful', 'transparent',
    'must', 'required', 'obligation', 'right', 'access', 'delete', 'portability',
    'notify', 'collect', 'process', 'disclose', 'security', 'protect', 'implement',
    'maintain', 'ensure', 'provide', 'verify', 'record', 'register', 'appoint',
    'purpose', 'data_subject', 'controller', 'processor', 'fiduciary', 'principal',
}

# The paper's own six category names (Section 4.2.1 scenario list), in order S1..S6.
CATEGORIES = ("Compliance", "Violation", "Exception", "Boundary", "Multi-Exception", "Compound-Boundary")


def classify_vars(var_names: list[str]) -> tuple[list[str], list[str], list[str]]:
    """Return (exception_vars, obligation_vars, other_vars)."""
    exc, obl, other = [], [], []
    for name in var_names:
        low = name.lower()
        if any(kw in low for kw in EXCEPTION_KEYWORDS):
            exc.append(name)
        elif any(kw in low for kw in OBLIGATION_KEYWORDS):
            obl.append(name)
        else:
            other.append(name)
    return exc, obl, other


def _binding_obligation_vars(instance, bool_vars: list[str], obl_vars: list[str], k: int) -> list[str]:
    """Up to k obligation vars whose individual removal from the all-True assignment actually flips the verdict
    to unsat -- i.e. genuinely load-bearing in THIS formula, not just keyword-matched (see
    hpc_multiscenario_eval_s6b.py's identically-named helper's docstring for the full rationale: a permissive
    "may" clause can be correctly, tautologically non-binding, and penalizing that would be wrong)."""
    binding = []
    for v in obl_vars:
        data = {bv: True for bv in bool_vars}
        data[v] = False
        try:
            if instance.verify_data(data) == z3.unsat:
                binding.append(v)
        except Exception:
            pass
        if len(binding) == k:
            break
    if len(binding) < k:
        remaining = [v for v in obl_vars if v not in binding]
        binding += remaining[: k - len(binding)]
    return binding[:k]


# ---------------------------------------------------------------------------------------------------------------
# Module loading -- byte-identical pattern to hpc_multiscenario_eval_s6b.py
# ---------------------------------------------------------------------------------------------------------------
_mod_counter = 0


def load_module_from_source(code_str: str):
    """Loads a candidate's source from a STRING (candidates live in memory during synthesis, not on disk yet --
    unlike the post-hoc evaluator, which always loads from a finished .py file)."""
    global _mod_counter
    _mod_counter += 1
    mod_name = f"_paper_harness_mod_{_mod_counter}"
    spec = importlib.util.spec_from_loader(mod_name, loader=None)
    mod = importlib.util.module_from_spec(spec)
    exec(compile(code_str, f"<candidate:{mod_name}>", "exec"), mod.__dict__)
    return mod


def find_class(mod):
    for _, obj in inspect.getmembers(mod, inspect.isclass):
        if hasattr(obj, "verify_data") and callable(getattr(obj, "verify_data")):
            return obj
    return None


def get_bool_vars(instance) -> list[str]:
    return [name for name in vars(instance) if isinstance(getattr(instance, name, None), z3.BoolRef)]


def instantiate(code_str: str):
    """(instance, bool_vars) or (None, []) on any failure -- never raises. This is `e_init`'s test (Eq 17's
    "successful import/initialization"): a candidate class that instantiates and exposes >=1 z3.Bool var."""
    try:
        mod = load_module_from_source(code_str)
        cls = find_class(mod)
        if cls is None:
            return None, []
        inst = cls()
        bvars = get_bool_vars(inst)
        if not bvars:
            return None, []
        return inst, bvars
    except Exception:
        return None, []


# ---------------------------------------------------------------------------------------------------------------
# Scenario data structures
# ---------------------------------------------------------------------------------------------------------------
@dataclass
class ScenarioEntry:
    category: str                    # one of CATEGORIES
    assignment: dict[str, bool]      # Gamma(x_i) -- Eq 1, as a var->bool dict (paper's total valuation)
    expected: str                    # 'sat' | 'unsat'
    own: bool                        # True iff this category had a genuine witness for THIS candidate (not a
                                      # fallback repeat of another category's assignment -- see build_h*'s docstrings)
    auto_fail: bool = False          # True iff this category is not testable at all for this candidate (e.g.
                                      # Boundary with zero obligation variables) -- matches the canonical
                                      # post-hoc evaluator's own "S4 is treated as failed" rule EXACTLY: a
                                      # hardcoded fail, never a verify_data() call against a placeholder
                                      # assignment. Getting this wrong (reusing Compliance's all-True assignment
                                      # with expected='unsat') was caught by a 440-candidate parity sweep against
                                      # the canonical evaluator: a self-contradictory formula (Compliance itself
                                      # already unsat) made the placeholder spuriously "pass" Boundary by
                                      # coincidence -- run_harness() must force this to fail unconditionally.


@dataclass
class Harness:
    entries: list[ScenarioEntry] = field(default_factory=list)   # always length 6, index i = S(i+1) = CATEGORIES[i]


def _build(bool_vars: list[str], instance, exc_vars: list[str], obl_vars: list[str], variant: str) -> Harness:
    """variant: 'rep' (hrep's own witness choice) or 'eval' (heval's, deliberately different where the candidate's
    own variable set gives room -- see build_heval())."""
    h = Harness()

    # S1 Compliance: all True -> expect sat. Singleton assignment (Eq 1) -- identical for 'rep' and 'eval'.
    h.entries.append(ScenarioEntry("Compliance", {v: True for v in bool_vars}, "sat", own=True))

    # S2 Violation: all False -> expect unsat. Singleton assignment -- identical for 'rep' and 'eval'.
    h.entries.append(ScenarioEntry("Violation", {v: False for v in bool_vars}, "unsat", own=True))

    # S3 Exception: exception var(s) True, rest False -> expect sat.
    #   'rep'  witness: ALL exception vars True.
    #   'eval' witness: only the FIRST exception var True (a genuinely different assignment whenever >=2 exception
    #                   vars exist; necessarily the same single assignment when exactly 1 exists -- disclosed via
    #                   `own`/the module docstring, not hidden).
    #   No exception vars at all: repeat S2's assignment/expectation (matches the post-hoc evaluator's own
    #   documented fallback -- "no SAT path from exceptions" -- own=False, since this is not this candidate's own
    #   witness for the category).
    if exc_vars:
        s3 = {v: False for v in bool_vars}
        chosen = exc_vars if variant == "rep" else exc_vars[:1]
        for v in chosen:
            s3[v] = True
        h.entries.append(ScenarioEntry("Exception", s3, "sat", own=True))
    else:
        s2 = h.entries[1]
        h.entries.append(ScenarioEntry("Exception", dict(s2.assignment), s2.expected, own=False))

    # S4 Boundary: all True except one binding obligation var flipped False -> expect unsat.
    #   'rep'  witness: the 1st binding obligation var.
    #   'eval' witness: the 2nd binding obligation var, when a 2nd genuinely-binding one exists for this candidate
    #                   (computed once, up front, via k=2 -- see build_heval()); otherwise the same var as 'rep'.
    #   No obligation vars: not testable -- a hardcoded, unconditional fail (auto_fail=True), exactly matching
    #   the post-hoc evaluator's own "S4 is treated as failed" rule (it never even calls verify_data in this
    #   case). NOT a verify_data() call against a placeholder assignment -- see ScenarioEntry.auto_fail's
    #   docstring for the real bug that placeholder approach caused.
    if obl_vars and instance is not None:
        binding2 = _binding_obligation_vars(instance, bool_vars, obl_vars, 2)
        idx = 0 if (variant == "rep" or len(binding2) < 2) else 1
        target = binding2[idx] if binding2 else obl_vars[0]
        s4 = {v: True for v in bool_vars}
        s4[target] = False
        h.entries.append(ScenarioEntry("Boundary", s4, "unsat", own=True))
    else:
        h.entries.append(ScenarioEntry("Boundary", {v: True for v in bool_vars}, "unsat", own=False, auto_fail=True))

    # S5 Multi-Exception: with >=2 exception vars, all-but-one True (a proper subset) and all obligations False
    # -> expect unsat.
    #   'rep'  witness: exc_vars[:-1] True (all but the LAST).
    #   'eval' witness: exc_vars[1:] True (all but the FIRST) -- a genuinely different subset whenever >=3 exist;
    #                   the SAME subset as 'rep' when exactly 2 exist (both reduce to "the other one"; disclosed).
    #   Fewer than 2 exception vars: repeat S3's assignment/expectation (matches the post-hoc evaluator's own
    #   fallback), own=False.
    if len(exc_vars) >= 2:
        s5 = {v: False for v in bool_vars}
        chosen = exc_vars[:-1] if variant == "rep" else exc_vars[1:]
        for v in chosen:
            s5[v] = True
        h.entries.append(ScenarioEntry("Multi-Exception", s5, "unsat", own=True))
    else:
        s3 = h.entries[2]
        h.entries.append(ScenarioEntry("Multi-Exception", dict(s3.assignment), s3.expected, own=False))

    # S6 Compound-Boundary: with >=2 obligation vars, all True except TWO binding obligation vars flipped False
    # -> expect unsat.
    #   'rep'  witness: the 1st and 2nd binding obligation vars (k=2).
    #   'eval' witness: the 2nd and 3rd binding obligation vars (k=3), when a 3rd genuinely-binding one exists;
    #                   otherwise the SAME pair as 'rep' (disclosed -- only 2 binding vars exist for this
    #                   candidate, so there is only one possible pair).
    #   Fewer than 2 obligation vars: repeat S4's OUTCOME exactly (matches the post-hoc evaluator's own
    #   fallback `s_results['S6'] = s_results['S4']`) -- own=False, AND propagate S4's own auto_fail flag: if S4
    #   itself was not testable (zero obligation vars), S6 is not testable either (auto_fail=True, unconditional
    #   fail, never a placeholder verify_data() call); if S4 had exactly one real obligation var, S6 genuinely
    #   repeats that same real single-flip assignment.
    if len(obl_vars) >= 2 and instance is not None:
        binding3 = _binding_obligation_vars(instance, bool_vars, obl_vars, 3)
        if variant == "rep" or len(binding3) < 3:
            pair = binding3[:2] if len(binding3) >= 2 else obl_vars[:2]
        else:
            pair = binding3[1:3]
        s6 = {v: True for v in bool_vars}
        for v in pair:
            s6[v] = False
        h.entries.append(ScenarioEntry("Compound-Boundary", s6, "unsat", own=True))
    else:
        s4 = h.entries[3]
        h.entries.append(ScenarioEntry("Compound-Boundary", dict(s4.assignment), s4.expected, own=False,
                                        auto_fail=s4.auto_fail))

    return h


def build_hrep(code_str: str) -> tuple[Harness | None, object, list[str]]:
    """h_rep(s) -- Eq 3. Returns (harness, instance, bool_vars); harness is None if the candidate does not even
    instantiate (that is e_init's own failure, reported separately by the paper-exact oracle, not by this
    function)."""
    instance, bool_vars = instantiate(code_str)
    if instance is None:
        return None, None, []
    exc_vars, obl_vars, _ = classify_vars(bool_vars)
    return _build(bool_vars, instance, exc_vars, obl_vars, "rep"), instance, bool_vars


def build_heval(code_str: str) -> tuple[Harness | None, object, list[str]]:
    """h_eval(s) -- Eq 10, the DISJOINT held-out companion (see module docstring for exactly which categories
    achieve genuine disjointness and which cannot by construction)."""
    instance, bool_vars = instantiate(code_str)
    if instance is None:
        return None, None, []
    exc_vars, obl_vars, _ = classify_vars(bool_vars)
    return _build(bool_vars, instance, exc_vars, obl_vars, "eval"), instance, bool_vars


def harness_disjoint_fraction(hrep: Harness, heval: Harness) -> float:
    """Fraction of the 6 entries whose concrete assignment differs between hrep and heval (X_rep ∩ X_eval = ∅
    would require this to be 1.0 -- see the module docstring for why S1/S2 make that unreachable in general)."""
    n_diff = sum(1 for a, b in zip(hrep.entries, heval.entries) if a.assignment != b.assignment)
    return n_diff / len(hrep.entries)


# ---------------------------------------------------------------------------------------------------------------
# Running a harness against an already-instantiated candidate -- Eq 2 (V), Eq 4 (A_beh)
# ---------------------------------------------------------------------------------------------------------------
@dataclass
class HarnessResult:
    verdicts: list[str] = field(default_factory=list)     # V(phi, x_i) in {'sat','unsat','unknown','error'}, len 6
    matched: list[bool] = field(default_factory=list)      # len 6, True iff verdicts[i] == expected[i]
    definitive: list[bool] = field(default_factory=list)   # len 6, True iff verdicts[i] in {'sat','unsat'}

    @property
    def a_beh(self) -> float:                              # Eq 4
        return sum(self.matched) / len(self.matched) if self.matched else 0.0

    @property
    def e_solver(self) -> float:                            # Eq 17's e_solver component
        return sum(self.definitive) / len(self.definitive) if self.definitive else 0.0

    def mismatch_indices(self) -> list[int]:                # M(phi) -- Eq 49, definitive but wrong verdicts only
        return [i for i in range(len(self.verdicts))
                 if self.definitive[i] and not self.matched[i]]


def run_harness(instance, bool_vars: list[str], harness: Harness) -> HarnessResult:
    r = HarnessResult()
    for entry in harness.entries:
        if entry.auto_fail:
            r.verdicts.append("not_tested")
            r.definitive.append(False)
            r.matched.append(False)
            continue
        try:
            v = instance.verify_data(dict(entry.assignment))
            if v == z3.sat:
                verdict = "sat"
            elif v == z3.unsat:
                verdict = "unsat"
            elif v == z3.unknown:
                verdict = "unknown"
            else:
                verdict = "error"
        except Exception:
            verdict = "error"
        r.verdicts.append(verdict)
        r.definitive.append(verdict in ("sat", "unsat"))
        r.matched.append(verdict == entry.expected)
    return r
