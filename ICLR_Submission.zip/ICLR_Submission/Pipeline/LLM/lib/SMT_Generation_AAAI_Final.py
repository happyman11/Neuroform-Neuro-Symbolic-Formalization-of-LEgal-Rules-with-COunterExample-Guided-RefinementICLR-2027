from __future__ import annotations


import io
import os
import re
import time
import json
import logging
import argparse
from models import *
from tqdm import tqdm
from enum import Enum
from utility import *
from promting import *
from legal_text import raw_legal_text
from typing import Optional
from dotenv import load_dotenv
from contextlib import redirect_stdout
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict
load_dotenv()

logger = logging.getLogger(__name__)
logging.basicConfig(
                    level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(name)s – %(message)s",
                   )

# ---------------------------------------------------------------------------
# Beam-specific logger — writes every candidate to beam_candidates.log
# so beam output can be filtered without polluting the terminal.
# ---------------------------------------------------------------------------
beam_logger = logging.getLogger("BEAM")
beam_logger.propagate = False  # Do NOT forward to root (terminal) logger

_beam_fh = logging.FileHandler("beam_candidates.log")
_beam_fh.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
beam_logger.addHandler(_beam_fh)


def _log_candidate(
    section_id: str,
    outer: int,
    beam_width: int,
    idx: int,
    candidate: "Candidate",
) -> None:
    """
    Emit a structured INFO block for a single beam candidate.
    Called after the Semantic Oracle has scored the candidate.
    """
    sep = "─" * 60
    code_preview = (
        "\n".join(candidate.code_blocks)[:800].strip()
        if candidate.code_blocks
        else "<no code extracted>"
    )
    beam_logger.info(
        "\n%s\n"
        "[BEAM] Section=%-20s  Outer=%d  Candidate=%d/%d\n"
        "  Oracle Score : %.2f / 1.00\n"
        "  Z3 Verdict   : %s\n"
        "  Exec Success : %s\n"
        "  Error Type   : %s\n"
        "  Error Msg    : %s\n"
        "  Exec Output  : %s\n"
        "  Code Preview :\n%s\n"
        "%s",
        sep,
        section_id, outer, idx, beam_width,
        candidate.semantic_score,
        candidate.z3_verdict or "not reached",
        candidate.execution_success,
        candidate.error_type.value if hasattr(candidate.error_type, "value") else candidate.error_type,
        (candidate.error_message[:300] if candidate.error_message else "none"),
        (candidate.execution_output[:300] if candidate.execution_output else "none"),
        code_preview,
        sep,
    )


# ---------------------------------------------------------------------------
# Error Taxonomy
# ---------------------------------------------------------------------------

class ErrorType(str, Enum):
    NONE          = "E0_none"
    SYNTAX        = "E1_syntax"
    Z3_ENCODING   = "E2_z3_encoding"
    SEMANTIC_INV  = "E3_semantic_inversion"
    INCOMPLETE    = "E4_incomplete_encoding"
    E4_VACUOUS    = "E4v_vacuous_antecedent"
    OVER_CONSTRAINED = "E5_over_constrained"


def classify_error(error_msg: str, z3_output: str = "") -> ErrorType:
    """
    Rule-based classifier mapping raw error strings to the taxonomy.
    This classification is passed to LLM C as structured feedback,
    enabling targeted repair instead of generic retry.
    """
    msg = (error_msg + " " + z3_output).lower()

    if any(k in msg for k in ["syntaxerror", "indentationerror", "import", "modulenotfounderror", "nameerror"]):
        return ErrorType.SYNTAX
    if any(k in msg for k in ["z3types", "sort", "typeerror", "argtypeerror", "z3exception"]):
        return ErrorType.Z3_ENCODING
    if "unsat" in msg and "expected sat" in msg:
        return ErrorType.SEMANTIC_INV
    if "sat" in msg and "expected unsat" in msg:
        return ErrorType.SEMANTIC_INV
    if "unsat" in msg and "constraints" not in msg:
        return ErrorType.OVER_CONSTRAINED
    if any(k in msg for k in ["missing", "incomplete", "not captured", "omitted"]):
        return ErrorType.INCOMPLETE
    # fallback — treat as Z3 encoding if execution failed
    if error_msg:
        return ErrorType.Z3_ENCODING
    return ErrorType.NONE


# ---------------------------------------------------------------------------
# E4v — Vacuous-Antecedent Detection
# ---------------------------------------------------------------------------

_OBLIGATION_KW = {
    'informs', 'notifies', 'discloses', 'provides', 'obtains', 'consent',
    'verifiable', 'compliant', 'complies', 'implements', 'accountable',
    'responsible', 'registered', 'secure', 'security', 'adequate', 'appropriate',
    'reasonable', 'proportional', 'necessary', 'lawful', 'transparent', 'accurate',
    'obligation', 'must', 'required', 'shall', 'comply', 'maintained', 'documented',
    'processed_lawfully',
}
_EXCEPTION_KW = {
    'exception', 'exempt', 'exemption', 'waiver', 'override', 'derogation',
    'archiving', 'scientific', 'research', 'statistical', 'public_interest',
    'vital_interests', 'legal_obligation', 'not_applicable', 'not_required',
    'freedom_expression', 'national_security', 'historical', 'welfare',
}


def detect_e4_vacuous(code_str: str) -> bool:
    """
    Returns True if verify_data({all vars: False}) produces z3.sat.
    A formula that is SAT when every Boolean is False encodes obligations as
    Implies(obligation_var, clause) — vacuously True when the antecedent is False.
    This is E4-Vacuous: the obligation disappears instead of being enforced.
    """
    try:
        glb: dict = {}
        exec(compile(code_str, "<e4v_check>", "exec"), glb)
        cls = next(
            (v for v in glb.values()
             if isinstance(v, type) and hasattr(v, "verify_data")),
            None,
        )
        if cls is None:
            return False
        inst = cls()
        var_names = [k for k in vars(inst) if not k.startswith("_")]
        import z3 as _z3
        result = inst.verify_data({v: False for v in var_names})
        return result == _z3.sat
    except Exception:
        return False


def detect_e4v_static(code_str: str) -> list[str]:
    """
    AST scan of get_rule() for Implies(X, Y) where X is an obligation or
    exception variable used as the *antecedent* (wrong position).

    Two forbidden patterns:
      PATTERN-A: Implies(obligation_var, C)  — obligation silently drops when var=False
      PATTERN-B: Implies(exception_var, C)   — exception should be Or(E, C), not Implies
    """
    import ast as _ast

    findings: list[str] = []
    try:
        tree = _ast.parse(code_str)
    except SyntaxError:
        return findings

    rule_body: list[_ast.stmt] = []
    for node in _ast.walk(tree):
        if isinstance(node, _ast.FunctionDef) and node.name == "get_rule":
            rule_body = node.body
            break
    if not rule_body:
        return findings

    for node in _ast.walk(_ast.Module(body=rule_body, type_ignores=[])):
        if not isinstance(node, _ast.Call):
            continue
        func = node.func
        is_implies = (
            (isinstance(func, _ast.Attribute) and func.attr == "Implies")
            or (isinstance(func, _ast.Name) and func.id == "Implies")
        )
        if not is_implies or len(node.args) < 2:
            continue

        antecedent = node.args[0]
        var_name: str | None = None
        if isinstance(antecedent, _ast.Attribute):
            var_name = antecedent.attr
        elif isinstance(antecedent, _ast.Name):
            var_name = antecedent.id

        if var_name is None:
            continue

        vl = var_name.lower()
        is_exc = any(kw in vl for kw in _EXCEPTION_KW)
        is_obl = any(kw in vl for kw in _OBLIGATION_KW)

        if is_obl and not is_exc:
            msg = (
                f"PATTERN-A: Implies({var_name}, ...) — '{var_name}' is an obligation "
                f"variable; the obligation silently vanishes when {var_name}=False. "
                f"Fix: assert the obligation clause unconditionally in And(...)."
            )
        elif is_exc and not is_obl:
            msg = (
                f"PATTERN-B: Implies({var_name}, ...) — '{var_name}' is an exception "
                f"variable used as antecedent; the obligation disappears when "
                f"{var_name}=False. Fix: use Or({var_name}, obligation_clause) instead."
            )
        else:
            continue

        if msg not in findings:
            findings.append(msg)

    return findings


_E4V_GAP_BASE = (
    "E4-Vacuous: the formula returns SAT when ALL Boolean variables are False. "
    "Obligations encoded as Implies(obligation_var, clause) are vacuously satisfied "
    "when obligation_var=False — the obligation disappears. "
    "PATTERN-A fix: assert obligation clauses unconditionally in And(). "
    "PATTERN-B fix: for exception variable E use Or(E, obligation_clause) — "
    "when E=True the exemption applies; when E=False the obligation must hold."
)


def build_e4v_gap(code_str: str) -> str:
    """Combines static AST findings with the base gap text for LLM-C repair."""
    findings = detect_e4v_static(code_str)
    if findings:
        detail = (
            "\nSpecific violations found by static scan:\n"
            + "\n".join(f"  • {f}" for f in findings)
        )
        return _E4V_GAP_BASE + detail
    return _E4V_GAP_BASE


# ---------------------------------------------------------------------------
# Data Structures
# ---------------------------------------------------------------------------

@dataclass
class Candidate:
    """A single Z3 program candidate produced by LLM A."""
    code_blocks: list[str]
    raw_response: str
    execution_success: bool = False
    execution_output: str = ""
    z3_verdict: str = ""          # "sat" | "unsat" | "unknown" | "error"
    semantic_score: float = 0.0   # 0.0–1.0 from Semantic Oracle
    error_type: ErrorType = ErrorType.NONE
    error_message: str = ""


@dataclass
class SectionMetric:
    """All metrics for a single section — directly usable in ablation tables."""
    section_id: str
    timestamp: str
    beam_width: int
    candidates_generated: int
    llm_a_attempts: int = 0
    llm_b_semantic_flags: int = 0      # times LLM B found a semantic issue
    llm_c_attempts: int = 0
    error_type_sequence: list[str] = field(default_factory=list)
    final_error_type: str = ErrorType.NONE
    final_success: bool = False
    semantic_alignment_confirmed: float = 0.0   # 0.0–1.0 alignment confidence
    wall_time_sec: float = 0.0


# ---------------------------------------------------------------------------
# Semantic Oracle
# ---------------------------------------------------------------------------

class SemanticOracle:
    """
    Scores a Z3 candidate by executing it and inspecting the solver verdict.

    Scoring rubric (0–1):
      +0.5  code executes without exception
      +0.2  Z3 Solver.check() was reached (no pre-solver crash)
      +0.2  solver produced a definitive verdict (sat or unsat, not unknown)
      +0.1  model/proof was extractable (sat → model, unsat → proof attempt)

    The oracle is intentionally lightweight so it can score k candidates
    in the beam without expensive LLM calls.
    """

    def score(self, candidate: Candidate) -> float:
        if not candidate.code_blocks:
            return 0.0

        score = 0.0
        full_code = "\n".join(candidate.code_blocks)
        output_buf = io.StringIO()
        # Set __name__ = "__main__" so the `if __name__ == "__main__":` block
        # executes during exec(), allowing verify_data() to be called and
        # the Z3 solver to produce a sat/unsat verdict in the output.
        namespace: dict = {"__name__": "__main__"}

        try:
            with redirect_stdout(output_buf):
                exec(compile(full_code, "<candidate>", "exec"), namespace)
            score += 0.5
            candidate.execution_success = True
        except Exception as exc:
            candidate.error_message = f"{type(exc).__name__}: {exc}"
            candidate.error_type = classify_error(candidate.error_message)
            candidate.execution_output = candidate.error_message
            return score

        output = output_buf.getvalue()
        candidate.execution_output = output

        # Check if solver verdict is present in output
        score += 0.2  # reached check()
        lower = output.lower()
        if "sat" in lower or "unsat" in lower:
            score += 0.2
            if "unsat" in lower:
                candidate.z3_verdict = "unsat"
            else:
                candidate.z3_verdict = "sat"

            # Check if model/proof was shown
            if any(k in lower for k in ["model", "proof", "implies", "=>"]):
                score += 0.1
        elif "unknown" in lower:
            candidate.z3_verdict = "unknown"
        else:
            candidate.z3_verdict = "error"

        return min(score, 1.0)

    def execute_and_score(self, candidate: Candidate) -> Candidate:
        candidate.semantic_score = self.score(candidate)
        return candidate


# ---------------------------------------------------------------------------
# Core REFINE-SMT Pipeline
# ---------------------------------------------------------------------------

class RefineSMT:
    """
    Implements the REFINE-SMT algorithm:

        for outer in range(max_outer_attempts):
            BEAM: generate k candidates with LLM A
            ORACLE: score each candidate; select best
            if best passes oracle threshold:
                LLM B: semantic alignment check
                if aligned:
                    return success
                else:
                    feed semantic gap to CEGAR loop
            CEGAR: classify error → targeted LLM C repair
            feed corrected code back as context for next outer iteration
    """

    ORACLE_PASS_THRESHOLD = 0.7   # minimum score to proceed to LLM B

    def __init__(
        self,
        output_path: str,
        model_owner: str,
        model: str,
        agnostic_model_owner: str,
        agnostic_model: str,
        corrector_owner: str,
        corrector_model: str,
        max_outer_attempts: int = 5,
        max_cegar_iterations: int = 5,
        beam_width: int = 3,
        e4v_detection_enabled: bool = True,
        input_mode: str = "structured",
        # ICLR supplementary: the pipeline's ONLY algorithm. "paper_exact" activates the faithful Algorithm 1/3
        # + sigma_impl (Eq 17) + Gap_i/Cov/Over_i diagnostic classifier (Eq 49-52) + phi_best-tracking repair +
        # g_sem re-check-after-repair, per PAPER_CODE_CORRESPONDENCE.md. The prior "legacy" mode has been
        # removed as a selectable option; every run uses this algorithm unconditionally. (Some ablation-variant
        # override methods -- M2/M3/M4 -- target machinery this algorithm does not call; see
        # PAPER_CODE_CORRESPONDENCE.md for which ablation axes remain live.)
        algorithm_mode: str = "paper_exact",
    ):
        self.base_output_path = output_path
        self.output_dir = ""
        if algorithm_mode != "paper_exact":
            raise ValueError(f"algorithm_mode must be 'paper_exact' (the only supported algorithm), got {algorithm_mode!r}")
        self.algorithm_mode = algorithm_mode
        # scripts/additional_runs/'s "Full NeuroFORM vs Without E4v" ablation --
        # False disables BOTH E4v call sites (this file's own CEGAR loop below,
        # and llm_pipeline.py's post-LLM-B check) without touching detection
        # logic itself. Default True preserves exact prior behavior.
        self.e4v_detection_enabled = e4v_detection_enabled
        # scripts/benchmarking's "raw text vs annotated" experiment pair --
        # "structured" (default) preserves exact prior behavior (the full section
        # dict, incl. deontic/graph-of-thought annotation, is stringified into the
        # LLM-A/B/C prompts). "text" makes _prompt_section() return only the raw
        # legal text, bypassing the structured annotation entirely.
        self.input_mode = input_mode

        self.model_owner = model_owner
        self.model = model
        self.agnostic_model_owner = agnostic_model_owner
        self.agnostic_model = agnostic_model
        self.corrector_owner = corrector_owner
        self.corrector_model = corrector_model

        self.max_outer_attempts = max_outer_attempts
        self.max_cegar_iterations = max_cegar_iterations
        self.beam_width = beam_width

        self.prompter = Prompt()
        self.model_call = ModelCall()
        self.oracle = SemanticOracle()
        self.all_metrics: list[SectionMetric] = []

    def _prompt_section(self, section: dict):
        """
        View of `section` to interpolate into the LLM-A/B/C prompts.

        input_mode == "structured" (default): return `section` unchanged (exact
        prior behavior -- the full dict, incl. deontic/structured annotation).
        input_mode == "text": return only the raw legal section text
        (source.full_text), bypassing the structured annotation. Ground-truth
        fields on `section` itself (label_metrics, structured_annotation) are
        untouched -- this only changes what is shown to the LLMs.
        """
        if self.input_mode != "text":
            return section
        # The four acts keep the law text under different `source` schemas (PIPD text, CCPA full_text, DPDP text +
        # sub_sections, GDPR paragraphs); reading one key sent an EMPTY prompt for 194/238 sections -- see legal_text.py.
        text, _schema = raw_legal_text(section)
        if not text.strip():
            raise ValueError(
                "input_mode=text but the section has no raw legal text in section['source'] "
                "(refusing to send an empty prompt to LLM-A/B/C)."
            )
        return text

    # ------------------------------------------------------------------
    # Model dispatch
    # ------------------------------------------------------------------

    def _call_llm(self, prompt: str, owner: str, model: str, role: str | None = None) -> str:
        if owner == "OpenAI":
            return self.model_call.openai_model_call(
                prompt=prompt, model=model, key=os.getenv("openai")
            )
        elif owner == "Ollama":
            return self.model_call.ollama_call_model(prompt=prompt, model=model)
        elif owner == "Github":
            return self.model_call.github_model_call(
                prompt=prompt,
                model=model,
                github_endpoint=os.getenv("github_endpoint"),
                key=os.getenv("github_metaollama"),
            )
        raise ValueError(f"Unknown model owner: {owner!r}")

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def sanitize(name: str) -> str:
        return re.sub(r"[^A-Za-z0-9._-]", "_", name)[:200]

    def save_file(self, path: str, content: str) -> None:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    # Matches any language tag after the opening fence (python, Python, py,
    # python3, z3, or bare ```), then captures everything up to the closing ```.
    _FENCE_RE: re.Pattern = re.compile(
        r"```(?:[A-Za-z0-9_+\-.]*)\s*\n(.*?)```",
        re.DOTALL,
    )
    # Used by the raw-code fallback: looks for a Z3/Python import at line-start.
    _PYTHON_IMPORT_RE: re.Pattern = re.compile(
        r"^\s*(from z3|import z3|import )", re.MULTILINE
    )
    # Matches "FULL CORRECTED CODE:", "corrected code:", "updated code:", etc.
    _CODE_HEADER_RE: re.Pattern = re.compile(
        r"(?:full\s+corrected\s+code|corrected\s+code|updated\s+code|fixed\s+code)"
        r"\s*[:\-]?\s*\n+(.*)",
        re.IGNORECASE | re.DOTALL,
    )
    # Matches Z3-specific API calls that only appear in Z3 programs.
    # Note: patterns ending with () use no trailing \b because ) is non-word.
    _Z3_PATTERN_RE: re.Pattern = re.compile(
        r"(?:Solver\(\)|solver\.add\b|z3\.Solver\b|\bBoolVal\b|\bIntVal\b"
        r"|\bForAll\b|\bExists\b|solver\.check\b|s\.add\b|s\.check\b)",
        re.MULTILINE,
    )

    @classmethod
    def extract_code(cls, text: str) -> list[str]:
        """
        Extract fenced code blocks from an LLM response.

        Handles all common fence styles emitted by GPT-family models:
          ```python / ```Python / ```py / ```python3 / ```z3 / ``` (bare)

        Falls back progressively:
          1. Fenced code blocks (primary)
          2. Full response starts with a Python/Z3 import
          3. Content after a "CORRECTED CODE:" section header
          4. Response contains Z3 API calls — trim prose, return code portion
        """
        blocks = [m.strip() for m in cls._FENCE_RE.findall(text) if m.strip()]
        if blocks:
            return blocks

        stripped = text.strip()

        # Fallback 2: full response is a raw Python/Z3 script with import at line start.
        if cls._PYTHON_IMPORT_RE.search(stripped):
            return [stripped]

        # Fallback 3: code follows a "corrected code" / "updated code" header.
        header_match = cls._CODE_HEADER_RE.search(stripped)
        if header_match:
            candidate = header_match.group(1).strip()
            if cls._PYTHON_IMPORT_RE.search(candidate) or cls._Z3_PATTERN_RE.search(candidate):
                return [candidate]

        # Fallback 4: response contains Z3 API calls but is preceded by prose.
        # Find the first line that looks like code and return from there.
        if cls._Z3_PATTERN_RE.search(stripped):
            lines = stripped.splitlines()
            code_start = next(
                (i for i, line in enumerate(lines)
                 if cls._PYTHON_IMPORT_RE.match(line) or cls._Z3_PATTERN_RE.search(line)),
                None,
            )
            if code_start is not None:
                return ["\n".join(lines[code_start:])]

        return []

    # ------------------------------------------------------------------
    # Phase 1 – Beam Generation
    # ------------------------------------------------------------------

    def _generate_beam(
        self,
        section: dict,
        context_error: str,
        context_code: str,
    ) -> list[Candidate]:
        """
        Generate `beam_width` candidate Z3 programs from LLM A.
        Each call uses a slightly varied prompt (temperature variation
        is handled inside ModelCall; here we vary the error context).
        """
        candidates = []
        for i in range(self.beam_width):
            variation_hint = f"[Variation {i+1}/{self.beam_width}] " if i > 0 else ""
            prompt = self.prompter.get_FOL_acts(
                self._prompt_section(section),
                f"{variation_hint}{context_error}" if context_error else variation_hint,
                prior_code=context_code if i == 0 else "",  # only first sees prior code
            )
            logger.info(
                "[BEAM-GEN] Generating candidate %d/%d for section '%s'",
                i + 1, self.beam_width, section.get("section_number", "?"),
            )
            raw = self._call_llm(prompt, self.model_owner, self.model, role="llm_a")
            blocks = self.extract_code(raw)
            logger.info(
                "[BEAM-GEN] Candidate %d/%d — extracted %d code block(s)",
                i + 1, self.beam_width, len(blocks),
            )
            c = Candidate(code_blocks=blocks, raw_response=raw)
            candidates.append(c)
        return candidates

    def _select_best_candidate(
        self,
        candidates: list[Candidate],
        section_id: str,
        outer: int,
        log: list[str],
    ) -> Candidate:
        """
        Score all candidates with the Semantic Oracle, emit per-candidate
        beam logs (both to beam_logger and to the run-log list), and
        return the highest-scoring candidate.
        """
        sep = "=" * 70
        log.append(f"\n{sep}\n[BEAM SCORING] Outer={outer}  — {len(candidates)} candidate(s)\n{sep}\n")

        for idx, c in enumerate(candidates, start=1):
            self.oracle.execute_and_score(c)

            # ── Structured logger output (goes to beam_candidates.log only) ──
            _log_candidate(section_id, outer, self.beam_width, idx, c)

            # ── Append full detail to the human-readable run log ──────────
            code_str = "\n".join(c.code_blocks) if c.code_blocks else "<no code>"
            log.append(
                f"  ┌─ Candidate {idx}/{len(candidates)}\n"
                f"  │  Oracle Score : {c.semantic_score:.2f} / 1.00\n"
                f"  │  Z3 Verdict   : {c.z3_verdict or 'not reached'}\n"
                f"  │  Exec Success : {c.execution_success}\n"
                f"  │  Error Type   : {c.error_type.value if hasattr(c.error_type, 'value') else c.error_type}\n"
                f"  │  Error Msg    : {c.error_message[:200] or 'none'}\n"
                f"  │  Exec Output  : {c.execution_output[:200] or 'none'}\n"
                f"  │  Code:\n{code_str}\n"
                f"  └{'─' * 60}\n"
            )

        best = max(candidates, key=lambda c: c.semantic_score)
        best_idx = candidates.index(best) + 1

        summary_line = (
            f"[BEAM SUMMARY] Outer={outer}  Best=Candidate-{best_idx}  "
            f"Score={best.semantic_score:.2f}  Verdict={best.z3_verdict or 'n/a'}\n"
            f"  Scores: {[round(c.semantic_score, 2) for c in candidates]}\n"
        )
        log.append(summary_line)
        logger.info(
            "[%s] %s",
            section_id,
            summary_line.strip(),
        )

        return best

    # ------------------------------------------------------------------
    # Phase 2 – Semantic Alignment (LLM B)
    # ------------------------------------------------------------------

    def _semantic_alignment_check(
        self, section: dict, candidate: Candidate
    ) -> tuple[bool, str, float]:
        """
        Ask LLM B whether the Z3 encoding is semantically faithful to the
        source section. Returns (is_aligned, gap_description).

        LLM B is prompted to respond with a structured JSON:
          {"aligned": true/false, "gaps": ["...", ...], "revised_code": "..."}
        """
        prompt = self.prompter.get_Logic_Validation(self._prompt_section(section), candidate.code_blocks)
        raw_b = self._call_llm(prompt, self.agnostic_model_owner, self.agnostic_model, role="llm_b")

        # Try to parse structured response
        json_match = re.search(r"\{.*\}", raw_b, flags=re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())
                aligned = bool(parsed.get("aligned", False))
                gaps = parsed.get("gaps", [])
                revised_blocks = self.extract_code(parsed.get("revised_code", ""))
                gap_desc = "; ".join(gaps) if gaps else ""
                if revised_blocks:
                    candidate.code_blocks = revised_blocks
                # Numeric score: 1.0 for perfect alignment, -0.15 per gap,
                # floor at 0.5 when aligned, floor at 0.0 when not aligned.
                if aligned:
                    align_score = round(max(0.5, 1.0 - 0.15 * len(gaps)), 2)
                else:
                    align_score = round(max(0.0, 0.4 - 0.1 * len(gaps)), 2)
                return aligned, gap_desc, align_score
            except json.JSONDecodeError:
                pass

        # Fallback: keyword detection -- lower confidence, fixed scores
        lower = raw_b.lower()
        aligned = any(k in lower for k in ["correct", "aligned", "faithful", "accurate"])
        not_aligned = any(k in lower for k in ["missing", "incorrect", "wrong", "gap", "incomplete"])
        if not_aligned:
            aligned = False

        revised_blocks = self.extract_code(raw_b)
        if revised_blocks:
            candidate.code_blocks = revised_blocks

        gap_desc = raw_b[:400] if not aligned else ""
        align_score = 0.6 if aligned else 0.2   # fallback: lower confidence
        return aligned, gap_desc, align_score

    # ------------------------------------------------------------------
    # Phase 3 – CEGAR Correction Loop (LLM C)
    # ------------------------------------------------------------------

    def _cegar_loop(
        self,
        section: dict,
        candidate: Candidate,
        semantic_gap: str,
        metric: SectionMetric,
    ) -> tuple[bool, Candidate]:
        """
        Counterexample-Guided iterative correction.

        Each iteration:
          1. Classify the error type from current candidate state.
          2. Build a structured error report (error type + Z3 verdict +
             execution output + semantic gap) as the 'counterexample'.
          3. Prompt LLM C with the counterexample for targeted repair.
          4. Re-score the repaired candidate with the Semantic Oracle.
          5. If oracle passes threshold, exit loop (success).
        """
        current = candidate
        error_type = classify_error(current.error_message, current.execution_output)
        if semantic_gap:
            error_type = ErrorType.INCOMPLETE

        # Early-termination state.
        # Rationale: LLM-C runs at T=0.0 (deterministic). If the repaired
        # candidate scores 0.00 for two consecutive iterations the model is in
        # a fixed-point failure: identical input → identical broken output.
        # Additional iterations are information-theoretically redundant.
        _stall_count   = 0          # consecutive zero-score iterations
        _STALL_PATIENCE = 2         # break after this many stalled iters

        for iteration in range(self.max_cegar_iterations):
            metric.llm_c_attempts += 1
            metric.error_type_sequence.append(error_type.value)

            # Build structured counterexample for LLM C
            counterexample = self._build_counterexample(
                current, error_type, semantic_gap
            )

            logger.info(
                "[%s] CEGAR iter %d/%d — ErrorType: %s",
                metric.section_id, iteration + 1,
                self.max_cegar_iterations, error_type.value,
            )

            # Dispatch prompt based on error type.
            # Subclasses may override _build_repair_prompt (M4 ablation).
            # E4 (incomplete encoding) needs to ADD legal constraints — not fix syntax.
            # The execution-validation prompt explicitly says "DO NOT ALTER THE LOGIC"
            # which directly contradicts E4's repair goal and confuses smaller models.
            if hasattr(self, "_build_repair_prompt"):
                prompt_c = self._build_repair_prompt(
                    section, current, semantic_gap, iteration
                )
            elif (error_type == ErrorType.INCOMPLETE
                    and hasattr(self.prompter, "get_completion_repair")):
                prompt_c = self.prompter.get_completion_repair(
                    self._prompt_section(section), current.code_blocks, semantic_gap or counterexample
                )
            else:
                prompt_c = self.prompter.get_execution_validation(
                    self._prompt_section(section), current.code_blocks, counterexample
                )
            raw_c = self._call_llm(prompt_c, self.corrector_owner, self.corrector_model, role="llm_c")
            blocks_c = self.extract_code(raw_c)

            if not blocks_c:
                logger.warning("[%s] LLM C returned no code at iter %d.", metric.section_id, iteration + 1)
                continue

            repaired = Candidate(code_blocks=blocks_c, raw_response=raw_c)
            self.oracle.execute_and_score(repaired)

            logger.info(
                "[%s] CEGAR iter %d — repaired candidate score=%.2f  verdict=%s  error=%s",
                metric.section_id, iteration + 1,
                repaired.semantic_score,
                repaired.z3_verdict or "n/a",
                repaired.error_type.value if hasattr(repaired.error_type, "value") else repaired.error_type,
            )

            if repaired.semantic_score >= self.ORACLE_PASS_THRESHOLD:
                _code = "\n".join(repaired.code_blocks) if repaired.code_blocks else ""
                if self.e4v_detection_enabled and _code and detect_e4_vacuous(_code):
                    logger.info(
                        "[%s] CEGAR iter %d: oracle passed but E4v detected — "
                        "routing to vacuous-antecedent repair.",
                        metric.section_id, iteration + 1,
                    )
                    error_type = ErrorType.E4_VACUOUS
                    semantic_gap = build_e4v_gap(_code)
                    current = repaired
                    continue
                logger.info(
                    "[%s] CEGAR succeeded at iter %d (score=%.2f).",
                    metric.section_id, iteration + 1, repaired.semantic_score,
                )
                return True, repaired

            # Early-termination check: track consecutive zero-score iterations.
            if repaired.semantic_score == 0.0:
                _stall_count += 1
                if _stall_count >= _STALL_PATIENCE:
                    logger.info(
                        "[%s] CEGAR stalled: score=0.00 for %d consecutive "
                        "iters (error=%s) — early exit at iter %d/%d.",
                        metric.section_id, _stall_count, error_type.value,
                        iteration + 1, self.max_cegar_iterations,
                    )
                    break
            else:
                _stall_count = 0  # any positive score resets the stall counter

            # Update error classification for next iteration
            error_type = classify_error(repaired.error_message, repaired.execution_output)
            semantic_gap = ""  # semantic gap addressed in first iteration
            current = repaired

        return False, current

    @staticmethod
    def _build_counterexample(
        candidate: Candidate, error_type: ErrorType, semantic_gap: str
    ) -> str:
        """
        Builds a structured counterexample report — the core of the
        CEGAR feedback loop. This is what distinguishes REFINE-SMT from
        naive retry: corrections are targeted to the specific error class.
        """
        repair_hints = {
            ErrorType.SYNTAX: (
                "Fix all Python syntax errors. Ensure Z3 is imported correctly. "
                "Do not use undefined variables. All code must be inside the "
                "```python block."
            ),
            ErrorType.Z3_ENCODING: (
                "The Z3 sort or type is incorrect. Check that: (1) Int/Real/Bool "
                "sorts match the domain, (2) quantifiers use correct bound variables, "
                "(3) ForAll/Exists arguments are well-typed, "
                "(4) arithmetic operations are not mixed with Bool terms."
            ),
            ErrorType.SEMANTIC_INV: (
                "The solver produced the opposite verdict to what is expected. "
                "Review whether the constraints correctly ENCODE the legal/logical "
                "obligation. Consider whether negation or implication direction is flipped."
            ),
            ErrorType.INCOMPLETE: (
                f"The following semantic gaps were identified by the logic validator: "
                f"{semantic_gap}. Add missing constraints to fully capture the "
                "regulatory requirements."
            ),
            ErrorType.OVER_CONSTRAINED: (
                "The constraint set is unsatisfiable (always UNSAT). This usually means "
                "two constraints contradict each other. Identify the minimal conflicting "
                "subset and relax or rewrite one of them."
            ),
            ErrorType.NONE: "General refinement: improve precision and completeness.",
        }

        hint = repair_hints.get(error_type, repair_hints[ErrorType.NONE])

        return (
            f"=== REFINE-SMT Structured Counterexample ===\n"
            f"Error Class     : {error_type.value}\n"
            f"Repair Strategy : {hint}\n\n"
            f"Z3 Solver Output:\n{candidate.execution_output[:600]}\n\n"
            f"Python Exception:\n{candidate.error_message[:400]}\n"
            f"Z3 Verdict      : {candidate.z3_verdict or 'not reached'}\n"
            f"Oracle Score    : {candidate.semantic_score:.2f} / 1.00\n"
        )

    # ------------------------------------------------------------------
    # Main entry point per section
    # ------------------------------------------------------------------

    def generate_and_execute(self, section: dict) -> SectionMetric:
        """Algorithm 1 (paper_exact) is this pipeline's only algorithm -- see _generate_and_execute_paper_exact
        below. The pre-paper_exact "legacy" cascade this method used to run has been removed as a selectable
        option; its helper methods (_cegar_loop, classify_error, SemanticOracle.score, the base
        _semantic_alignment_check) are left in place below only because some ablation-variant override methods
        (M2/M3/M4) still reference them, even though no entry point reaches them anymore -- see
        PAPER_CODE_CORRESPONDENCE.md for exactly which ablation axes remain live under paper_exact."""
        return self._generate_and_execute_paper_exact(section)

    def _unused_legacy_generate_and_execute(self, section: dict) -> SectionMetric:
        section_id =  section.get("section_number", "Section")
        safe_id = self.sanitize(section_id)
        start_time = time.time()

        metric = SectionMetric(
            section_id=section_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            beam_width=self.beam_width,
            candidates_generated=0,
        )

        log: list[str] = [
            f"REFINE-SMT Run\n"
            f"Section : {section_id}\n"
            f"Time    : {metric.timestamp}\n"
            f"Models  : A={self.model} | B={self.agnostic_model} | C={self.corrector_model}\n"
            f"{'='*70}\n\n"
        ]

        context_error = ""
        context_code  = ""
        best_candidate: Optional[Candidate] = None

        for outer in range(self.max_outer_attempts):
            metric.llm_a_attempts += 1
            logger.info(
                "[%s] ════════ Outer attempt %d/%d ════════",
                section_id, outer + 1, self.max_outer_attempts,
            )
            log.append(
                f"\n{'═'*70}\n"
                f"OUTER ATTEMPT {outer+1}/{self.max_outer_attempts}  |  Section: {section_id}\n"
                f"{'═'*70}\n"
            )

            # ── Phase 1: Beam Generation ──────────────────────────────────
            candidates = self._generate_beam(section, context_error, context_code)
            metric.candidates_generated += len(candidates)

            # ── Score every candidate + log each one ──────────────────────
            best = self._select_best_candidate(candidates, section_id, outer + 1, log)

            if best.semantic_score < 0.3:
                # Beam entirely failed — no point going to LLM B
                context_error = classify_error(best.error_message).value
                context_code  = ""
                logger.warning(
                    "[%s] Beam score too low (%.2f) — best error_type=%s. Regenerating.",
                    section_id, best.semantic_score,
                    best.error_type.value if hasattr(best.error_type, "value") else best.error_type,
                )
                log.append(
                    f"[Outer {outer+1}] ⚠ Beam score too low ({best.semantic_score:.2f}). "
                    f"Regenerating with error context: {context_error}\n"
                )
                continue

            # ── Phase 2: Semantic Alignment (LLM B) ──────────────────────
            if best.semantic_score >= self.ORACLE_PASS_THRESHOLD:
                logger.info("[%s] Oracle threshold passed (%.2f). Running LLM B alignment check...", section_id, best.semantic_score)
                aligned, gap, align_score = self._semantic_alignment_check(section, best)

                log.append(
                    f"[Outer {outer+1}] LLM B semantic alignment: "
                    f"{'✔ ALIGNED' if aligned else '✘ GAP FOUND'} (score={align_score:.2f})\n"
                    f"Gap description: {gap or 'none'}\n\n"
                )

                if aligned:
                    logger.info("[%s] Semantically aligned. Done. (align_score=%.2f)", section_id, align_score)
                    metric.final_success = True
                    metric.semantic_alignment_confirmed = align_score
                    best_candidate = best
                    break

                metric.llm_b_semantic_flags += 1
                # Proceed to CEGAR with the semantic gap as the counterexample
                cegar_success, repaired = self._cegar_loop(section, best, gap, metric)
                log.append(
                    f"[Outer {outer+1}] CEGAR result: {'✔ SUCCESS' if cegar_success else '✘ FAILED'}\n"
                    f"Error sequence: {metric.error_type_sequence}\n\n"
                )

                if cegar_success:
                    metric.final_success = True
                    best_candidate = repaired
                    break

                context_error = repaired.error_message or gap
                context_code  = "\n".join(repaired.code_blocks)

            else:
                # Below threshold: run CEGAR directly (no LLM B yet)
                cegar_success, repaired = self._cegar_loop(section, best, "", metric)
                if cegar_success:
                    # Re-check alignment after repair
                    aligned, gap, align_score = self._semantic_alignment_check(section, repaired)
                    metric.llm_b_semantic_flags += 1 if not aligned else 0
                    metric.final_success = aligned
                    metric.semantic_alignment_confirmed = align_score
                    best_candidate = repaired
                    if aligned:
                        break
                context_error = best.error_message
                context_code  = "\n".join(repaired.code_blocks)

        # ── Final Recording ───────────────────────────────────────────────
        metric.wall_time_sec = round(time.time() - start_time, 2)
        metric.final_error_type = (
            ErrorType.NONE.value if metric.final_success
            else (metric.error_type_sequence[-1] if metric.error_type_sequence else "E1_syntax")
        )

        status = "SUCCESS" if metric.final_success else "FAIL"
        log.append(
            f"\n{'='*70}\n"
            f"FINAL STATUS     : {status}\n"
            f"Wall Time        : {metric.wall_time_sec}s\n"
            f"LLM A Attempts   : {metric.llm_a_attempts}\n"
            f"LLM B Flags      : {metric.llm_b_semantic_flags}\n"
            f"LLM C Iterations : {metric.llm_c_attempts}\n"
            f"Error Sequence   : {metric.error_type_sequence}\n"
            f"Semantic Aligned : {metric.semantic_alignment_confirmed}\n"
        )

        if best_candidate:
            log.append(
                f"\n=== Final Z3 Program ===\n"
                + "\n".join(best_candidate.code_blocks) + "\n\n"
                f"=== Final Execution Output ===\n"
                + (best_candidate.execution_output or "") + "\n"
            )

        # ── Save human-readable run log ──
        final_path = os.path.join(
            self.output_dir,
            f"Section_{safe_id}_{status}.txt"
        )
        self.save_file(final_path, "\n".join(log))
        logger.info("[%s] Log saved → %s", section_id, final_path)

        # ── Save final Z3 code as a clean, runnable .py file ──
        if best_candidate and best_candidate.code_blocks:
            code_header = (
                f"# REFINE-SMT — Final Generated Z3 Code\n"
                f"# Section   : {section_id}\n"
                f"# Status    : {status}\n"
                f"# Timestamp : {metric.timestamp}\n"
                f"# LLM A     : {self.model}\n"
                f"# LLM B     : {self.agnostic_model}\n"
                f"# LLM C     : {self.corrector_model}\n"
                f"# Oracle Score (final) : {best_candidate.semantic_score:.2f}\n"
                f"# Z3 Verdict (final)   : {best_candidate.z3_verdict}\n"
                f"# Semantic Aligned     : {metric.semantic_alignment_confirmed}\n"
                f"# {'='*60}\n\n"
            )
            final_code_str = "\n\n".join(best_candidate.code_blocks)
            code_path = os.path.join(
                self.output_dir,
                f"Section_{safe_id}_{status}.py"
            )
            self.save_file(code_path, code_header + final_code_str)
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)
        else:
            logger.warning("[%s] No valid code to save — all attempts exhausted.", section_id)

        return metric

    # ------------------------------------------------------------------
    # ICLR supplementary: paper-exact Algorithm 1/3 (algorithm_mode="paper_exact" only)
    #
    # These three methods are the ONLY place algorithm_mode="paper_exact" takes effect. They are additive: no
    # method above this point is modified, and every legacy-mode code path (this class's own methods above, and
    # every tier subclass's overrides such as LLMRefineSMT.generate_and_execute's cascade) is reached exactly as
    # before whenever algorithm_mode="legacy" (the default). See PAPER_CODE_CORRESPONDENCE.md for the full
    # equation-by-equation mapping and every disclosed operational choice these methods make.
    # ------------------------------------------------------------------

    def _semantic_alignment_check_paper_exact(
        self, section: dict, candidate: Candidate
    ) -> tuple[bool, str, float]:
        """g_sem (Eq 21) as a PURE accept/reject signal. Same prompt/model/JSON-parsing as the legacy
        _semantic_alignment_check, but -- unlike it -- NEVER substitutes candidate.code_blocks from the model's
        own 'revised_code' field: the paper defines g_sem as a consistency check over an already-fixed
        candidate, not a code mutator (Section 4.2.4: "Semantic failure is an outer rejection condition ...
        does not itself generate a diagnostic counterexample"). pi_align is also a genuinely TOTAL BINARY
        parser (Eq 21), so the returned score is exactly 1.0 or 0.0, not a graded confidence value."""
        prompt = self.prompter.get_Logic_Validation(self._prompt_section(section), candidate.code_blocks)
        raw_b = self._call_llm(prompt, self.agnostic_model_owner, self.agnostic_model, role="llm_b")

        json_match = re.search(r"\{.*\}", raw_b, flags=re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())
                aligned = bool(parsed.get("aligned", False))
                gaps = parsed.get("gaps", [])
                gap_desc = "; ".join(gaps) if gaps else ""
                return aligned, gap_desc, (1.0 if aligned else 0.0)
            except json.JSONDecodeError:
                pass

        lower = raw_b.lower()
        aligned = any(k in lower for k in ["correct", "aligned", "faithful", "accurate"])
        not_aligned = any(k in lower for k in ["missing", "incorrect", "wrong", "gap", "incomplete"])
        if not_aligned:
            aligned = False
        gap_desc = raw_b[:400] if not aligned else ""
        return aligned, gap_desc, (1.0 if aligned else 0.0)

    def _diagnostic_repair_paper_exact(self, section: dict, candidate: "Candidate", entry_eval,
                                        metric: SectionMetric):
        """Algorithm 3 (Appendix B.6.1), faithfully:
          - D=E0 -> return immediately.
          - D=E1 -> return phi_best immediately; an E1 repair attempt can NEVER overwrite the incumbent.
          - D=E4v -> a STRUCTURAL diagnostic repair (reuses the existing build_e4v_gap() text), not a scenario
            counterexample.
          - otherwise -> pick i*=min(I_d(phi)) under the fixed harness order (paper_diagnostics.classify_paper_
            exact already returns this as `mismatch_index`) and build the self-contained counterexample (x_i*,
            y_i*, yhat_i*, d_phi) -- Eq 54.
          - After repair: D'=E1 -> return phi_best immediately (never overwritten). S'>=theta_impl and A'=1 and
            D'=E0 -> return phi' immediately. S'>S_best (STRICT inequality -- ties preserve the earlier
            incumbent) -> update phi_best. ALWAYS propagate phi<-phi', D<-D' regardless of whether phi_best was
            updated, every iteration.
        Returns (phi_best_candidate, phi_best_evaluation, human_readable_log_text)."""
        import paper_diagnostics as PD  # local import: this module is only needed under algorithm_mode="paper_exact"

        def _code(c):
            return "\n".join(c.code_blocks) if c and c.code_blocks else ""

        log_lines: list[str] = []
        phi_best, S_best = candidate, entry_eval.sigma_impl
        phi, ev = candidate, entry_eval

        for j in range(self.max_cegar_iterations):
            if ev.diagnostic == "E0":
                log_lines.append(f"  [repair j={j}] D=E0 -- returning immediately.\n")
                return phi, ev, "".join(log_lines)
            if ev.diagnostic == "E1":
                log_lines.append(f"  [repair j={j}] D=E1 -- aborting, returning incumbent phi_best "
                                  f"(sigma_impl={S_best:.3f}).\n")
                return phi_best, PD.evaluate_candidate_paper_exact(section, _code(phi_best)), "".join(log_lines)

            metric.llm_c_attempts += 1
            metric.error_type_sequence.append(ev.diagnostic)

            if ev.diagnostic == "E4v":
                gap_text = build_e4v_gap(_code(phi))
                prompt_c = self.prompter.get_completion_repair(self._prompt_section(section), phi.code_blocks, gap_text)
                log_lines.append(f"  [repair j={j}] D=E4v -- structural diagnostic repair.\n")
            else:
                i_star = ev.mismatch_index if ev.mismatch_index is not None else 0
                entry = ev.hrep.entries[i_star] if ev.hrep else None
                y_hat = ev.result.verdicts[i_star] if ev.result else "n/a"
                counterexample = (
                    "=== Paper-exact self-contained counterexample (Eq 54) ===\n"
                    f"Diagnostic class        : {ev.diagnostic}\n"
                    f"Detail                  : {ev.diagnostic_detail}\n"
                    f"Scenario category       : {entry.category if entry else 'n/a'}\n"
                    f"Assignment Gamma(x_i*)  : {entry.assignment if entry else {}}\n"
                    f"Expected verdict y_i*   : {entry.expected if entry else 'n/a'}\n"
                    f"Observed verdict yhat_i*: {y_hat}\n"
                )
                if ev.diagnostic == "E4" and hasattr(self.prompter, "get_completion_repair"):
                    prompt_c = self.prompter.get_completion_repair(
                        self._prompt_section(section), phi.code_blocks, counterexample)
                else:
                    prompt_c = self.prompter.get_execution_validation(
                        self._prompt_section(section), phi.code_blocks, counterexample)
                log_lines.append(f"  [repair j={j}] D={ev.diagnostic} i*={i_star} -- counterexample repair.\n")

            raw_c = self._call_llm(prompt_c, self.corrector_owner, self.corrector_model, role="llm_c")
            blocks_c = self.extract_code(raw_c)
            if not blocks_c:
                log_lines.append(f"  [repair j={j}] LLM-C returned no code -- no progress, continuing.\n")
                continue

            phi_prime = Candidate(code_blocks=blocks_c, raw_response=raw_c)
            ev_prime = PD.evaluate_candidate_paper_exact(section, "\n".join(blocks_c))
            phi_prime.semantic_score = ev_prime.sigma_impl
            log_lines.append(f"  [repair j={j}] repaired sigma_impl={ev_prime.sigma_impl:.3f} D'={ev_prime.diagnostic}\n")

            if ev_prime.diagnostic == "E1":
                log_lines.append(f"  [repair j={j}] D'=E1 -- returning incumbent phi_best immediately "
                                  f"(never overwritten).\n")
                return phi_best, PD.evaluate_candidate_paper_exact(section, _code(phi_best)), "".join(log_lines)

            if (ev_prime.sigma_impl >= self.ORACLE_PASS_THRESHOLD and ev_prime.e_verdict >= 1.0
                    and ev_prime.diagnostic == "E0"):
                log_lines.append(f"  [repair j={j}] behaviorally correct and D'=E0 -- returning immediately.\n")
                return phi_prime, ev_prime, "".join(log_lines)

            if ev_prime.sigma_impl > S_best:      # STRICT inequality -- equal-score ties preserve the incumbent
                phi_best, S_best = phi_prime, ev_prime.sigma_impl

            phi, ev = phi_prime, ev_prime          # ALWAYS propagate, every iteration, regardless of phi_best

        log_lines.append(f"  repair budget exhausted -- returning phi_best (sigma_impl={S_best:.3f}).\n")
        return phi_best, PD.evaluate_candidate_paper_exact(section, _code(phi_best)), "".join(log_lines)

    def _generate_and_execute_paper_exact(self, section: dict) -> SectionMetric:
        """Algorithm 1 (Section 4.2, Appendix B.1-B.2), faithfully: candidates sorted by sigma_impl (Eq 17,
        descending, stable); the FIRST candidate with S>=theta_impl and A_beh=1 and D=E0 is checked against
        g_sem (Eq 21) and returned if aligned, else the scan continues to the next candidate (a semantic
        rejection, never a counterexample); the FIRST remaining candidate with A_beh<1 or D!=E0 becomes the
        SOLE repair target for this outer iteration (not every above-threshold candidate in turn, unlike the
        legacy cascade); after DIAGNOSTICREPAIR returns, g_sem is invoked FRESH on the repaired candidate
        before any acceptance -- never reusing its oracle score as an alignment proxy."""
        import paper_diagnostics as PD  # local import: only needed under algorithm_mode="paper_exact"

        section_id = section.get("section_number", "Section")
        safe_id = self.sanitize(section_id)
        start_time = time.time()
        metric = SectionMetric(section_id=section_id, timestamp=datetime.now(timezone.utc).isoformat(),
                                beam_width=self.beam_width, candidates_generated=0)
        log: list[str] = [
            f"REFINE-SMT Run (algorithm_mode=paper_exact)\n"
            f"Section : {section_id}\nTime    : {metric.timestamp}\n"
            f"Models  : A={self.model} | B={self.agnostic_model} | C={self.corrector_model}\n{'=' * 70}\n\n"
        ]
        context_error = ""
        context_code = ""
        best_candidate: Candidate | None = None
        final_g_sem = 0.0

        for outer in range(self.max_outer_attempts):
            metric.llm_a_attempts += 1
            log.append(f"\n{'=' * 70}\nOUTER ATTEMPT {outer + 1}/{self.max_outer_attempts} (paper_exact)  |  "
                       f"Section: {section_id}\n{'=' * 70}\n")

            candidates = self._generate_beam(section, context_error, context_code)
            metric.candidates_generated += len(candidates)

            evals = []
            for c in candidates:
                ev = PD.evaluate_candidate_paper_exact(section, "\n".join(c.code_blocks) if c.code_blocks else "")
                c.semantic_score = ev.sigma_impl
                evals.append((c, ev))
            evals.sort(key=lambda ce: ce[1].sigma_impl, reverse=True)   # stable: Python's sort is stable

            log.append("[BEAM SCORING] (paper_exact)\n" + "".join(
                f"  candidate {i + 1}: sigma_impl={ev.sigma_impl:.3f}  A_beh={ev.e_verdict:.3f}  "
                f"diagnostic={ev.diagnostic}\n" for i, (c, ev) in enumerate(evals)))

            repair_target, repair_target_ev = None, None
            for c, ev in evals:
                if ev.diagnostic == "E1":
                    continue
                if ev.sigma_impl >= self.ORACLE_PASS_THRESHOLD and ev.e_verdict >= 1.0 and ev.diagnostic == "E0":
                    aligned, gap_desc, align_score = self._semantic_alignment_check_paper_exact(section, c)
                    log.append(f"[Outer {outer + 1}] g_sem on E0 candidate: "
                               f"{'ALIGNED' if aligned else 'REJECTED (semantic, not a counterexample)'} "
                               f"(score={align_score:.1f})\n")
                    if aligned:
                        metric.final_success = True
                        metric.semantic_alignment_confirmed = align_score
                        best_candidate = c
                        final_g_sem = align_score
                        break
                    continue
                if repair_target is None:
                    repair_target, repair_target_ev = c, ev
            if best_candidate is not None:
                break

            if repair_target is None:
                context_error, context_code = "E1_all_candidates_failed_to_instantiate", ""
                log.append(f"[Outer {outer + 1}] every candidate was E1 -- regenerating beam.\n")
                continue

            repaired, repaired_ev, repair_log = self._diagnostic_repair_paper_exact(
                section, repair_target, repair_target_ev, metric)
            log.append(f"[Outer {outer + 1}] DIAGNOSTICREPAIR:\n{repair_log}")

            if (repaired_ev.sigma_impl >= self.ORACLE_PASS_THRESHOLD and repaired_ev.e_verdict >= 1.0
                    and repaired_ev.diagnostic in ("E0", "E4v")):
                aligned, gap_desc, align_score = self._semantic_alignment_check_paper_exact(section, repaired)
                log.append(f"[Outer {outer + 1}] g_sem re-checked fresh after repair: "
                           f"{'ALIGNED' if aligned else 'REJECTED'} (score={align_score:.1f})\n")
                if aligned:
                    metric.final_success = True
                    metric.semantic_alignment_confirmed = align_score
                    best_candidate = repaired
                    final_g_sem = align_score
                    break

            context_error = repaired_ev.diagnostic_detail or repaired_ev.diagnostic
            context_code = "\n".join(repaired.code_blocks) if repaired and repaired.code_blocks else ""

        metric.wall_time_sec = round(time.time() - start_time, 2)
        metric.final_error_type = (ErrorType.NONE.value if metric.final_success
                                    else (metric.error_type_sequence[-1] if metric.error_type_sequence else "E1_syntax"))
        status = "SUCCESS" if metric.final_success else "FAIL"
        log.append(f"\n{'=' * 70}\nFINAL STATUS     : {status}\nWall Time        : {metric.wall_time_sec}s\n"
                   f"LLM A Attempts   : {metric.llm_a_attempts}\nLLM C Iterations : {metric.llm_c_attempts}\n"
                   f"Error Sequence   : {metric.error_type_sequence}\n"
                   f"Semantic Aligned : {metric.semantic_alignment_confirmed}\n")
        if best_candidate:
            log.append(f"\n=== Final Z3 Program ===\n" + "\n".join(best_candidate.code_blocks) + "\n\n"
                       f"=== Final Execution Output ===\n" + (best_candidate.execution_output or "") + "\n")

        final_path = os.path.join(self.output_dir, f"Section_{safe_id}_{status}.txt")
        self.save_file(final_path, "\n".join(log))
        logger.info("[%s] (paper_exact) Log saved -> %s", section_id, final_path)

        if best_candidate and best_candidate.code_blocks:
            code_header = (
                f"# REFINE-SMT (paper_exact) -- Final Generated Z3 Code\n"
                f"# Section   : {section_id}\n# Status    : {status}\n# Timestamp : {metric.timestamp}\n"
                f"# LLM A     : {self.model}\n# LLM B     : {self.agnostic_model}\n"
                f"# LLM C     : {self.corrector_model}\n"
                f"# sigma_impl (final) : {best_candidate.semantic_score:.4f}\n"
                f"# g_sem (final)      : {final_g_sem}\n# {'=' * 60}\n\n"
            )
            code_path = os.path.join(self.output_dir, f"Section_{safe_id}_{status}.py")
            self.save_file(code_path, code_header + "\n\n".join(best_candidate.code_blocks))
            logger.info("[%s] (paper_exact) Final Z3 code saved -> %s", section_id, code_path)
        else:
            logger.warning("[%s] (paper_exact) No valid code to save -- all attempts exhausted.", section_id)

        return metric

    # ------------------------------------------------------------------
    # Per-file entry point
    # ------------------------------------------------------------------

    def process_act(self, section: dict, filename: str) -> None:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        safe = self.sanitize(filename)
        self.output_dir = os.path.join(
            self.base_output_path, f"{timestamp}_{safe}_Z3_Outputs"
        )
        os.makedirs(self.output_dir, exist_ok=True)

        # ── Experiment config (hyperparameters + model IDs for reproducibility) ──
        config = {
            "algorithm": "REFINE-SMT",
            "version": "1.0",
            "section_file": filename,
            "llm_a": {"owner": self.model_owner, "model": self.model},
            "llm_b": {"owner": self.agnostic_model_owner, "model": self.agnostic_model},
            "llm_c": {"owner": self.corrector_owner, "model": self.corrector_model},
            "hyperparameters": {
                "max_outer_attempts": self.max_outer_attempts,
                "max_cegar_iterations": self.max_cegar_iterations,
                "beam_width": self.beam_width,
                "oracle_pass_threshold": self.ORACLE_PASS_THRESHOLD,
            },
            "timestamp": timestamp,
        }
        self.save_file(
            os.path.join(self.output_dir, "experiment_config.json"),
            json.dumps(config, indent=2),
        )

        # ── Run the pipeline ──
        metric = self.generate_and_execute(section)
        self.all_metrics.append(metric)

        act_metric_data = {
            "algorithm": "REFINE-SMT",
            "act_file": filename,
            "timestamp": metric.timestamp,
            "models": {
                "llm_a": self.model,
                "llm_b": self.agnostic_model,
                "llm_c": self.corrector_model,
            },
            "hyperparameters": {
                "beam_width": self.beam_width,
                "max_outer_attempts": self.max_outer_attempts,
                "max_cegar_iterations": self.max_cegar_iterations,
                "oracle_pass_threshold": self.ORACLE_PASS_THRESHOLD,
            },
            "results": {
                "final_success": metric.final_success,
                "semantic_alignment_confirmed": metric.semantic_alignment_confirmed,
                "final_error_type": metric.final_error_type,
                "wall_time_sec": metric.wall_time_sec,
            },
            "attempt_counts": {
                "llm_a_outer_attempts": metric.llm_a_attempts,
                "llm_b_semantic_flags": metric.llm_b_semantic_flags,
                "llm_c_cegar_iterations": metric.llm_c_attempts,
                "beam_candidates_generated": metric.candidates_generated,
            },
            "error_analysis": {
                "error_type_sequence": metric.error_type_sequence,
                "error_type_counts": {
                    e: metric.error_type_sequence.count(e)
                    for e in set(metric.error_type_sequence)
                },
            },
        }
        self.save_file(
            os.path.join(self.output_dir, "section_metrics.json"),
            json.dumps(act_metric_data, indent=2),
        )
        logger.info(
            "[%s] section_metrics.json saved (success=%s, wall_time=%.1fs)",
            filename, metric.final_success, metric.wall_time_sec,
        )

        self.save_aggregate_metrics(log=False)

    # ------------------------------------------------------------------
    # Aggregate metrics (for results tables)
    # ------------------------------------------------------------------

    def _build_aggregate_summary(self) -> dict:
        """Compute the aggregate summary dict from self.all_metrics."""
        total     = len(self.all_metrics)
        successes = sum(1 for m in self.all_metrics if m.final_success)
        aligned   = sum(1 for m in self.all_metrics if m.semantic_alignment_confirmed >= 0.5)

        error_dist: dict[str, int] = {}
        for m in self.all_metrics:
            for e in m.error_type_sequence:
                error_dist[e] = error_dist.get(e, 0) + 1

        return {
            "algorithm": "REFINE-SMT",
            "acts_processed": total,
            "successful": successes,
            "failed": total - successes,
            "success_rate": round(successes / total, 4) if total else 0,
            "semantic_alignment_rate": round(aligned / total, 4) if total else 0,
            "mean_llm_a_attempts": round(
                sum(m.llm_a_attempts for m in self.all_metrics) / total, 2
            ) if total else 0,
            "mean_llm_c_iterations": round(
                sum(m.llm_c_attempts for m in self.all_metrics) / total, 2
            ) if total else 0,
            "mean_wall_time_sec": round(
                sum(m.wall_time_sec for m in self.all_metrics) / total, 2
            ) if total else 0,
            "total_wall_time_sec": round(
                sum(m.wall_time_sec for m in self.all_metrics), 2
            ),
            "error_type_distribution": error_dist,
            # Full per-section breakdown for ablation tables
            "per_act": [asdict(m) for m in self.all_metrics],
        }

    def save_aggregate_metrics(self, log: bool = True) -> None:
        """
        Write aggregate_metrics.json to base_output_path.

        Called automatically after every act (rolling update) and once more
        explicitly at the end of main().  The `log` flag suppresses the
        INFO line on intermediate updates to keep the console clean.
        """
        if not self.all_metrics:
            return

        summary = self._build_aggregate_summary()
        os.makedirs(self.base_output_path, exist_ok=True)
        out = os.path.join(self.base_output_path, "aggregate_metrics.json")
        with open(out, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)

        if log:
            total     = summary["acts_processed"]
            successes = summary["successful"]
            logger.info("Aggregate metrics → %s", out)
            logger.info(
                "Success rate: %d/%d (%.1f%%) | Semantic alignment: %.1f%% | "
                "Mean LLM C iters: %.2f | Total time: %.1fs",
                successes, total,
                100 * summary["success_rate"],
                100 * summary["semantic_alignment_rate"],
                summary["mean_llm_c_iterations"],
                summary["total_wall_time_sec"],
            )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="REFINE-SMT: Counterexample-Guided LLM Z3 Formalization"
    )
    # Model arguments
    parser.add_argument("--modelowner",    choices=["Ollama", "OpenAI", "Github"], default="OpenAI")
    parser.add_argument("--model",         type=str, default="gpt-4o",             help="LLM A — primary Z3 generator")
    parser.add_argument("--modelowneragnostic",choices=["Ollama", "OpenAI", "Github"], default="OpenAI")
    parser.add_argument("--modelagnostic", type=str, default="gpt-4o-mini",        help="LLM B — logic/semantic validator")
    parser.add_argument("--correctorowner",choices=["Ollama", "OpenAI", "Github"], default="OpenAI")
    parser.add_argument("--correctormodel",type=str, default="gpt-4o-mini",        help="LLM C — CEGAR corrector")

    # Algorithm hyperparameters (ablation-friendly)
    parser.add_argument("--max_outer",  type=int, default=5, help="Max outer generation attempts (LLM A)")
    parser.add_argument("--max_cegar", type=int, default=5, help="Max CEGAR correction iterations (LLM C)")
    parser.add_argument("--beam_width", type=int, default=3, help="Candidates per beam (LLM A)")

    # I/O
    parser.add_argument("--ActJSON", type=str, required=True,  help="Directory of input Act JSONs")
    parser.add_argument("--SaveZ3",  type=str, required=True,  help="Directory for Z3 outputs and metrics")
    args = parser.parse_args()

    utility = Utility()

    if not os.path.exists(args.ActJSON):
        logger.error("Input directory not found: %s", args.ActJSON)
        return

    uml_files = [f for f in os.listdir(args.ActJSON) if f != ".DS_Store"]
    logger.info("Files to process: %d | Beam width: %d | Max outer: %d | Max CEGAR: %d",
                len(uml_files), args.beam_width, args.max_outer, args.max_cegar)

    pipeline = RefineSMT(
        output_path=args.SaveZ3,
        model_owner=args.modelowner,
        model=args.model,
        agnostic_model_owner=args.modelowneragnostic,
        agnostic_model=args.modelagnostic,
        corrector_owner=args.correctorowner,
        corrector_model=args.correctormodel,
        max_outer_attempts=args.max_outer,
        max_cegar_iterations=args.max_cegar,
        beam_width=args.beam_width,
    )
    IGNORE_FILES = {"sections","aggregate_metric.json", "metrics_extract.log", "run.log",".DS_Store"}
    with tqdm(total=len(uml_files), desc="REFINE-SMT") as pbar:
        for filename in uml_files:
            if filename not in IGNORE_FILES:
                full_path = os.path.join(args.ActJSON, filename)
                try:
                    section = utility.extract_json_robust(full_path)
                    print(filename, filename.split(".")[0])
                    pipeline.process_act(section, filename.split(".")[0])
                except Exception:
                    logger.exception("Failed: %s", filename)
                pbar.update(1)
                time.sleep(1)

    pipeline.save_aggregate_metrics()


# Example:
# python3 SMT_Generation_AAAI.py \
#   --modelowner OpenAI --model gpt-4o \
#   --modelowneragnostic OpenAI --modelagnostic gpt-4o-mini \
#   --correctorowner OpenAI --correctormodel gpt-4o-mini \
#   --beam_width 3 --max_outer 5 --max_cegar 5 \
#   --ActJSON /path/to/input --SaveZ3 /path/to/output

if __name__ == "__main__":
    main()

"""
python3 SMT_Generation_AAAI-codesave.py \
  --modelowner OpenAI --model gpt-5 \
  --modelowneragnostic OpenAI --modelagnostic gpt-4 \
  --correctorowner OpenAI --correctormodel gpt-5.2 \
  --beam_width 3 --max_outer 7 --max_cegar 7 \
  --ActJSON /Users/apple/Desktop/CODES/PHD/Final_Implementation/UML_Annotated_Act/Updated/DPDP_Act --SaveZ3 /Users/apple/Desktop/CODES/PHD/Final_Implementation/Z3-SMT/updated/DPDP_Act
    
    
python3 SMT_Generation_AAAI_Final.py --modelowner OpenAI --model gpt-5 --modelowneragnostic OpenAI --modelagnostic gpt-4 --correctorowner OpenAI --correctormodel gpt-5 --beam_width 3 --max_outer 7 --max_cegar 7 --ActJSON /Users/apple/Desktop/CODES/PHD/Final_Implementation/UML_Annotated_Act/Updated/CCPA_Act --SaveZ3 /Users/apple/Desktop/CODES/PHD/Final_Implementation/Z3-SMT/updated/CCPA_Act

python3 SMT_Generation_AAAI_Final.py --modelowner OpenAI --model gpt-5 --modelowneragnostic OpenAI --modelagnostic gpt-4 --correctorowner OpenAI --correctormodel gpt-5 --beam_width 3 --max_outer 7 --max_cegar 7 --ActJSON /Users/apple/Desktop/CODES/PHD/Final_Implementation/UML_Annotated_Act/Updated/GDPR_Act --SaveZ3 /Users/apple/Desktop/CODES/PHD/Final_Implementation/Z3-SMT/updated/GDPR_Act

python3 SMT_Generation_AAAI_Final.py --modelowner OpenAI --model gpt-5 --modelowneragnostic OpenAI --modelagnostic gpt-4 --correctorowner OpenAI --correctormodel gpt-5 --beam_width 3 --max_outer 7 --max_cegar 7 --ActJSON /Users/apple/Desktop/CODES/PHD/Final_Implementation/UML_Annotated_Act/Updated/PIPD_Act --SaveZ3 /Users/apple/Desktop/CODES/PHD/Final_Implementation/Z3-SMT/updated/PIPD_Act

"""
