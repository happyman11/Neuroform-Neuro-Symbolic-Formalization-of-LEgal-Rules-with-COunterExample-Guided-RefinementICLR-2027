"""
legal_text.py -- render a section's RAW legal text (no annotation) from its dataset `source` field.

Used by RefineSMT._prompt_section() when input_mode == "text" (config_threshold_08_raw_text.yaml) and by the
benchmark runners' pre-flight coverage check. The four acts store the law text under different `source`
schemas, so reading a single key (the earlier `source.full_text`) silently produced an empty prompt for every
DPDP, GDPR and PIPD section:

    PIPD  source = {article_number, text}
    CCPA  source = {section_id, title, full_text, subdivisions, word_count}      (Sec1798_194: title only)
    DPDP  source = {section_number, title, chapter_*, text, sub_sections[], illustrations[]}
                   text = lead / sub-section (1) (may be empty); sub_sections[] = {sub_section, text, clauses[], illustrations[]}
    GDPR  source = {article, title, paragraphs[]}      paragraphs[] = {paragraph, text, [items[] = {letter, text}]}

Only `source` is read -- never `structured_annotation`, `label_metrics` or the parsed annotation -- so nothing
from the expert annotation can leak into the raw-text arm.

This file is kept byte-identical in scripts/SLM/lib and scripts/LLM/lib.
"""
from __future__ import annotations

import hashlib


def _s(x) -> str:
    return x.strip() if isinstance(x, str) else ""


def _clauses(clauses) -> list[str]:
    out = []
    for c in clauses or []:
        if isinstance(c, dict) and _s(c.get("text")):
            lab = _s(c.get("clause")) or _s(c.get("letter"))
            out.append(f"({lab}) {_s(c['text'])}" if lab else _s(c["text"]))
    return out


def _illustrations(ills) -> list[str]:
    return [_s(i) for i in (ills or []) if _s(i)]


def raw_legal_text(section: dict) -> tuple[str, str]:
    """
    Return (text, schema) for `section` (the dict the benchmark runner passes around; only section["source"] is used).
    `schema` is one of 'gdpr_paragraphs', 'dpdp_sub_sections', 'ccpa_full_text', 'pipd_text', 'title_only', 'none'
    -- a label for the coverage report. `text` is '' only when the source genuinely holds no text.
    """
    src = (section or {}).get("source")
    if not isinstance(src, dict):
        return "", "none"

    title = _s(src.get("title"))
    lines: list[str] = []
    schema = "none"

    if isinstance(src.get("paragraphs"), list):                              # GDPR
        schema = "gdpr_paragraphs"
        for p in src["paragraphs"]:
            if not isinstance(p, dict):
                continue
            num = p.get("paragraph")
            body = _s(p.get("text"))
            if body:
                lines.append(f"{num}. {body}" if num not in (None, "") else body)
            for it in p.get("items") or []:
                if isinstance(it, dict) and _s(it.get("text")):
                    lab = _s(it.get("letter"))
                    lines.append(f"   ({lab}) {_s(it['text'])}" if lab else f"   {_s(it['text'])}")
    elif isinstance(src.get("sub_sections"), list):                          # DPDP
        schema = "dpdp_sub_sections"
        if _s(src.get("text")):
            lines.append(_s(src["text"]))
        for ss in src["sub_sections"]:
            if not isinstance(ss, dict):
                continue
            num = _s(ss.get("sub_section"))
            body = _s(ss.get("text"))
            if body:
                lines.append(f"({num}) {body}" if num else body)
            lines.extend(f"   {c}" for c in _clauses(ss.get("clauses")))
            lines.extend(f"   Illustration: {i}" for i in _illustrations(ss.get("illustrations")))
        lines.extend(f"Illustration: {i}" for i in _illustrations(src.get("illustrations")))
    elif _s(src.get("full_text")):                                           # CCPA
        schema = "ccpa_full_text"
        lines.append(_s(src["full_text"]))
    elif _s(src.get("text")):                                                # PIPD
        schema = "pipd_text"
        lines.append(_s(src["text"]))

    body = "\n".join(lines).strip()
    if not body and title:                                                   # e.g. CCPA Sec1798_194: the provision IS its title
        return title, "title_only"
    if body and title:
        return f"{title}\n\n{body}", schema
    return body, schema


def text_sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
