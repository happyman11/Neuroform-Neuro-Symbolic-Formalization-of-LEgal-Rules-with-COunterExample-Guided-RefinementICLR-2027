"""
paper_diagnostics.py -- sigma_impl (Eq 17) and the corrected diagnostic classifier (Section 4.2.3 + Appendix B.6:
Gap_i/Cov(F_phi)/Unsupported/Over_i, precedence E1>E2>E4>E5>E3>E4v>E0), used only when
algorithm_mode="paper_exact" (see RefineSMT.__init__ and paper_harness.py's module docstring, which this file
builds directly on top of).

Operational choices, disclosed here once rather than re-derived at every call site:
  - Cov(F_phi) / R_i(s,a_hat): R_i is the set of slugified annotation-span texts (same slugify convention as
    scripts/additional_runs/deterministic_baseline/deterministic_compiler.py, reused for cross-study terminology
    consistency -- but this module is otherwise fully independent of that separate study's code, on purpose, so
    the two reviewer questions never silently couple) labeled #obligation/#prohibition (for
    Violation/Boundary/Compound-Boundary/Compliance) or #exemption (for Exception/Multi-Exception). Cov(F_phi) is
    the subset of R_i that appears as a substring of the candidate's own declared Z3 Bool variable names -- a
    documented, bounded approximation of "the diagnostic localization stage identifies a corresponding
    constraint," not a full natural-language entailment check.
  - Over_i / Unsupported(r;s,a_hat): F_phi is decomposed only at its OWN top level (if get_rule() returns
    z3.And(...), each direct child is one "candidate constraint" r; if it returns a single expression, no
    decomposition is attempted and Over_i is reported False for that candidate). This is the same bounded,
    documented approximation the plan describes -- clause-level, not full sub-formula, decomposition.
  - E4v's P_s (Eq 47's source-interface set): every z3.Bool attribute the candidate declares. This codebase has
    no formal auxiliary-vs-interface distinction (the paper's own definition -- "constrained by an acyclic
    defining equivalence" -- has no detector here and none was requested), so P_s = all declared Booleans;
    behavior-identical to the common case of no true auxiliaries, correctly scoped when one exists.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

import z3

import paper_harness as PH

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slugify(text: str, max_len: int = 48) -> str:
    s = _SLUG_RE.sub("_", text.strip().lower()).strip("_")
    return s[:max_len] if s else ""


# ---------------------------------------------------------------------------------------------------------------
# R_i(s, a_hat) / Cov(F_phi) -- walked directly from the annotation, independent of deterministic_compiler.py
# ---------------------------------------------------------------------------------------------------------------
_CATEGORY_LABELS = {
    "Compliance": ("#obligation", "#prohibition"),
    "Violation": ("#obligation", "#prohibition"),
    "Boundary": ("#obligation", "#prohibition"),
    "Compound-Boundary": ("#obligation", "#prohibition"),
    "Exception": ("#exemption",),
    "Multi-Exception": ("#exemption",),
}


def _walk_annotation_spans(node, out: list[tuple[str, str]]) -> None:
    if isinstance(node, dict):
        ann = node.get("annotations")
        if isinstance(ann, list):
            for item in ann:
                if isinstance(item, dict) and isinstance(item.get("text"), str) and isinstance(item.get("label"), str):
                    out.append((item["label"], item["text"]))
        for k, v in node.items():
            if k != "annotations" and isinstance(v, (dict, list)):
                _walk_annotation_spans(v, out)
    elif isinstance(node, list):
        for item in node:
            _walk_annotation_spans(item, out)


def required_predicates(section: dict, category: str) -> set[str]:
    """R_i(s, a_hat) -- Eq 50. Empty set (never raises) if the section has no usable annotation."""
    sa = (section or {}).get("structured_annotation")
    if sa is None:
        return set()
    spans: list[tuple[str, str]] = []
    try:
        _walk_annotation_spans(sa, spans)
    except Exception:
        return set()
    wanted = _CATEGORY_LABELS.get(category, ())
    return {_slugify(text) for label, text in spans if label in wanted and _slugify(text)}


def _coverage_hit(required: set[str], names_lower_joined: str) -> set[str]:
    return {r for r in required if r and r in names_lower_joined}


def has_gap(section: dict, category: str, bool_var_names: list[str]) -> bool:
    """Gap_i -- Eq 50: R_i \\ Cov(F_phi) != empty. Conservative: an empty R_i (annotation gives nothing to check
    for this category) is never itself treated as a gap -- there is nothing to be missing."""
    req = required_predicates(section, category)
    if not req:
        return False
    names_joined = " ".join(v.lower() for v in bool_var_names)
    return bool(req - _coverage_hit(req, names_joined))


# ---------------------------------------------------------------------------------------------------------------
# Over_i / Unsupported(r; s, a_hat) -- Eq 51, a real constraint-removal re-solve, not a keyword guess
# ---------------------------------------------------------------------------------------------------------------
def _top_level_conjuncts(formula) -> list:
    try:
        if formula.decl().kind() == z3.Z3_OP_AND:
            return list(formula.children())
    except Exception:
        pass
    return [formula]


def _vars_in(expr, _depth: int = 0) -> set[str]:
    if _depth > 60:
        return set()
    out: set[str] = set()
    try:
        if z3.is_const(expr) and expr.decl().kind() == z3.Z3_OP_UNINTERPRETED:
            out.add(str(expr))
            return out
        for c in expr.children():
            out |= _vars_in(c, _depth + 1)
    except Exception:
        pass
    return out


def over_constrained(instance, bool_var_names: list[str], formula, entry: "PH.ScenarioEntry",
                      required: set[str]) -> tuple[bool, int | None]:
    """(is_over, index_of_removed_conjunct). Only meaningful for expected='sat', observed='unsat' mismatches
    (Eq 51's own precondition) -- the caller is responsible for only invoking this on such entries."""
    if entry.expected != "sat":
        return False, None
    conjuncts = _top_level_conjuncts(formula)
    if len(conjuncts) < 2:
        return False, None
    for idx, r in enumerate(conjuncts):
        remaining = [c for j, c in enumerate(conjuncts) if j != idx]
        try:
            s = z3.Solver()
            s.add(z3.And(*remaining) if len(remaining) > 1 else remaining[0])
            for var, val in entry.assignment.items():
                if var in bool_var_names:
                    s.add(getattr(instance, var) == val)
            if s.check() != z3.sat:
                continue
        except Exception:
            continue
        r_vars = {v.lower() for v in _vars_in(r)}
        r_joined = " ".join(r_vars)
        if required and any(req in r_joined for req in required):
            continue                      # the removed conjunct IS source-supported -- not "Unsupported"
        return True, idx
    return False, None


# ---------------------------------------------------------------------------------------------------------------
# E4v -- Eq 48, now with the Imp(F_phi) != empty precondition via direct Z3 AST inspection (not source-text regex)
# ---------------------------------------------------------------------------------------------------------------
def _has_implies_node(expr, _depth: int = 0) -> bool:
    if _depth > 60:
        return False
    try:
        if expr.decl().kind() == z3.Z3_OP_IMPLIES:
            return True
        return any(_has_implies_node(c, _depth + 1) for c in expr.children())
    except Exception:
        return False


def detect_e4v_paper_exact(instance, bool_var_names: list[str]) -> bool:
    try:
        formula = instance.get_rule()
    except Exception:
        return False
    if not _has_implies_node(formula):
        return False
    try:
        return instance.verify_data({v: False for v in bool_var_names}) == z3.sat
    except Exception:
        return False


# ---------------------------------------------------------------------------------------------------------------
# Classifier -- Eq 49-52, correct precedence E1>E2>E4>E5>E3>E4v>E0 (E1/E4v are handled by the caller: E1 has no
# harness to classify against at all, E4v is tested only after this function would otherwise return E0)
# ---------------------------------------------------------------------------------------------------------------
@dataclass
class Diagnostic:
    d_class: str                        # 'E0'|'E2'|'E3'|'E4'|'E5' (E1/E4v assigned by the caller)
    detail: str = ""
    mismatch_index: int | None = None   # i* -- Eq 54's min(I_d(phi)), already the minimum for this class


def classify_paper_exact(section: dict, instance, bool_var_names: list[str], formula,
                          hrep: "PH.Harness", result: "PH.HarnessResult") -> Diagnostic:
    # E2: non-definitive verdict (unknown/error) on a scenario that WAS actually testable (auto_fail entries are
    # never scenario-level errors -- they are handled entirely by their own hardcoded outcome).
    e2_idx = [i for i, e in enumerate(hrep.entries) if not e.auto_fail and not result.definitive[i]]
    if e2_idx:
        i0 = min(e2_idx)
        return Diagnostic("E2", detail=f"non-definitive verdict '{result.verdicts[i0]}' at scenario {i0} "
                                        f"({hrep.entries[i0].category})", mismatch_index=i0)

    mismatch = result.mismatch_indices()          # M(phi) -- Eq 49
    if not mismatch:
        return Diagnostic("E0")

    e4_idx: list[int] = []
    e5_idx: list[int] = []
    e5_detail = {}
    for i in mismatch:
        entry = hrep.entries[i]
        if has_gap(section, entry.category, bool_var_names):
            e4_idx.append(i)
            continue
        req = required_predicates(section, entry.category)
        is_over, removed = over_constrained(instance, bool_var_names, formula, entry, req)
        if is_over:
            e5_idx.append(i)
            e5_detail[i] = removed

    if e4_idx:
        i0 = min(e4_idx)
        e = hrep.entries[i0]
        return Diagnostic("E4", detail=f"Gap_i at scenario {i0} ({e.category}): required predicate(s) not "
                                        f"covered by any declared Z3 variable", mismatch_index=i0)
    if e5_idx:
        i0 = min(e5_idx)
        return Diagnostic("E5", detail=f"Over_i at scenario {i0} ({hrep.entries[i0].category}): removing "
                                        f"top-level conjunct #{e5_detail[i0]} flips the verdict to sat and that "
                                        f"conjunct's variables are not source-supported", mismatch_index=i0)
    i0 = min(mismatch)
    return Diagnostic("E3", detail=f"residual polarity/operator mismatch at scenario {i0} "
                                    f"({hrep.entries[i0].category}): expected {hrep.entries[i0].expected}, "
                                    f"observed {result.verdicts[i0]}", mismatch_index=i0)


# ---------------------------------------------------------------------------------------------------------------
# Top-level entry point: one call evaluates a candidate exactly as the paper's Algorithm 1/3 need
# ---------------------------------------------------------------------------------------------------------------
@dataclass
class PaperExactEvaluation:
    ok: bool                            # False only when the candidate never even instantiated (e_init=0)
    e_init: float
    e_solver: float
    e_verdict: float                    # = A_beh(phi, hrep) -- Eq 4
    e_diag: float
    sigma_impl: float                   # Eq 17
    diagnostic: str                     # 'E0'|'E1'|'E2'|'E3'|'E4'|'E4v'|'E5'
    diagnostic_detail: str
    mismatch_index: int | None
    hrep: "PH.Harness | None"
    result: "PH.HarnessResult | None"
    instance: object                    # kept so the caller (Algorithm 3) can build the self-contained
                                          # counterexample (x_i*, y_i*, y_hat_i*, d_phi) -- Eq 54 -- without
                                          # re-instantiating the candidate a second time


def evaluate_candidate_paper_exact(section: dict, code_str: str) -> PaperExactEvaluation:
    """The one function scripts/{SLM,LLM}/lib/SMT_Generation_AAAI_Final.py's paper_exact code path calls per
    candidate (initial or repaired -- identical treatment, matching Algorithm 3's ORACLE re-invocation)."""
    hrep, instance, bool_vars = PH.build_hrep(code_str)
    if instance is None:
        return PaperExactEvaluation(False, 0.0, 0.0, 0.0, 0.0, 0.0, "E1",
                                     "candidate did not instantiate (import/init failure, or no z3.Bool "
                                     "attributes were declared)", None, None, None, None)
    result = PH.run_harness(instance, bool_vars, hrep)
    try:
        formula = instance.get_rule()
    except Exception as exc:
        return PaperExactEvaluation(False, 1.0, result.e_solver, result.a_beh, 0.0, 0.0, "E1",
                                     f"get_rule() raised {type(exc).__name__}: {exc}", None, hrep, result, instance)

    diag = classify_paper_exact(section, instance, bool_vars, formula, hrep, result)
    if diag.d_class == "E0" and detect_e4v_paper_exact(instance, bool_vars):
        diag = Diagnostic("E4v", detail="all-source-interface-False probe is sat and an Implies node is present "
                                          "in get_rule()'s top-level formula")

    # e_diag: whether a well-formed diagnostic record was produced -- Eq 17's own note is that this measures
    # "availability of diagnostic feedback," not logical/semantic correctness, so it is 1.0 whenever classify_
    # paper_exact/detect_e4v_paper_exact ran to completion (as they just did) without raising, regardless of
    # which class was returned, including E0.
    e_diag = 1.0
    sigma = round(0.5 * 1.0 + 0.2 * result.e_solver + 0.2 * result.a_beh + 0.1 * e_diag, 4)
    return PaperExactEvaluation(True, 1.0, result.e_solver, result.a_beh, e_diag, sigma,
                                 diag.d_class, diag.detail, diag.mismatch_index, hrep, result, instance)
