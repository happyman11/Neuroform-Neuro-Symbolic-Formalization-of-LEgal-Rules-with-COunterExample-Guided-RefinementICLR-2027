"""
step_trace.py -- opt-in, per-section step log for REFINE-SMT runs (hyperparameters.detailed_logging: true).

The normal transcript (Section_*_{SUCCESS,FAIL}.txt) records candidates, oracle scores and one-line LLM-B / CEGAR outcomes,
but NOT the prompts, the raw model responses or the text the models were shown -- so an input-mode ablation cannot be audited
from it. With detailed_logging on, every section directory additionally gets

    trace.jsonl      one JSON object per line, in order:
                       section_input     input_mode, schema, chars, sha256, act, file
                       llm_call          role (llm_a|llm_b|llm_c), model, temperature, max_new_tokens, seed, system message id,
                                         FULL prompt, FULL raw response, latency, error (if the call raised)
                       candidate_scored  phase (beam|cegar), outer, candidate/iteration, oracle score, Z3 verdict, exec ok,
                                         error class + message, execution output, code
                       llm_b             aligned, alignment score, gaps, whether LLM-B rewrote the code (+ the rewritten code)
                       cegar_start/_end  entry error class, gap fed to the repairer, scores per iteration, success
                       section_final     status, counters, wall time      (section_error: exception + traceback)
    input_text.txt   exactly the text/dict placed into the LLM-A/B/C prompts for this section

Everything is installed by wrapping bound methods on the pipeline INSTANCE (install_step_trace), so with the flag off no existing
code path changes. A logging failure never breaks a run: it is warned about once and skipped.

This file is kept byte-identical in scripts/SLM/lib and scripts/LLM/lib.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import traceback
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class StepTrace:
    def __init__(self) -> None:
        self.path: str | None = None
        self.seq = 0
        self.ctx: dict = {"phase": "beam", "outer": None, "cand": 0, "iter": 0, "metric": None}
        self._warned = False

    def start(self, out_dir: str) -> None:
        self.path = os.path.join(out_dir, "trace.jsonl")
        self.seq = 0
        self.ctx = {"phase": "beam", "outer": None, "cand": 0, "iter": 0, "metric": None}
        with open(self.path, "w", encoding="utf-8"):
            pass

    def stop(self) -> None:
        self.path = None

    def event(self, kind: str, **fields) -> None:
        if not self.path:
            return
        try:
            self.seq += 1
            rec = {"seq": self.seq, "t": datetime.now(timezone.utc).isoformat(), "kind": kind, **fields}
            with open(self.path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
        except Exception as exc:                                   # logging must never break a run
            if not self._warned:
                self._warned = True
                logger.warning("step_trace: could not write %s (%s); further trace errors suppressed.", self.path, exc)


def _code(c) -> str:
    return "\n".join(getattr(c, "code_blocks", None) or [])


def _role_of(p, model: str) -> str:
    """Fallback only -- call sites pass role= explicitly (A and C share a model id in both tiers)."""
    return "llm_b" if model == p.agnostic_model and model != p.model else "unknown"


def _system_msg_id(p, model: str) -> str | None:
    """Mirror of the branch order in the tier's _call_llm (so the log states what was ACTUALLY sent)."""
    if model == p.corrector_model:
        return "llm_c"
    if model == p.model:
        return "llm_a"
    if model == p.agnostic_model:
        return "llm_b"
    return None


def install_step_trace(p) -> StepTrace:
    """Wrap the pipeline instance's methods so that every step of every section is appended to trace.jsonl."""
    tr = StepTrace()
    p._trace = tr

    # ---- one LLM call (prompt + raw response) ----------------------------------------------------------------------------
    orig_call = p._call_llm

    def traced_call(prompt, owner, model, role=None):
        counter = getattr(p, "_call_counter", 0)
        t0 = time.time()
        out, err = "", None
        try:
            out = orig_call(prompt, owner, model, role=role)
            return out
        except Exception as exc:
            err = repr(exc)
            raise
        finally:
            # ICLR supplementary: widened from HuggingFace-only to include Ollama -- both backends resolve
            # temperature/max_tokens/seed/system_message identically via the same shared helpers
            # (_resolve_temperature/_resolve_max_tokens/_resolve_system_message), so both are worth logging.
            resolvable = owner in ("HuggingFace", "Ollama")
            seed = getattr(p, "_seed", None)
            tr.event(
                "llm_call", role=role or _role_of(p, model), owner=owner, model=model,
                temperature=p._resolve_temperature(model) if resolvable else None,
                max_new_tokens=p._resolve_max_tokens(model) if resolvable else None,
                seed=(seed + counter) if (resolvable and seed is not None) else None,
                system_message=_system_msg_id(p, model) if resolvable else None,
                latency_s=round(time.time() - t0, 3), prompt_chars=len(prompt), prompt=prompt,
                response_chars=len(out), response=out, error=err,
                phase=tr.ctx["phase"], outer=tr.ctx["outer"],
            )

    p._call_llm = traced_call

    # ---- LLM-B verdict ---------------------------------------------------------------------------------------------------
    orig_align = p._semantic_alignment_check

    def traced_align(section, candidate):
        before = _code(candidate)
        aligned, gap, score = orig_align(section, candidate)
        after = _code(candidate)
        extra = getattr(p, "_slm_extra_data", {}) or {}
        tr.event(
            "llm_b", aligned=aligned, align_score=score, gap=gap, oracle_score_at_check=candidate.semantic_score,
            code_revised_by_llm_b=(before != after), revised_code=after if before != after else None,
            deontic_type_predicted=extra.get("deontic_type_predicted"), deontic_confirmed=extra.get("deontic_confirmed"),
            outer=tr.ctx["outer"],
        )
        return aligned, gap, score

    p._semantic_alignment_check = traced_align

    # ---- oracle scoring (beam candidates and every CEGAR iteration) ----------------------------------------------------------
    orig_score = p.oracle.execute_and_score

    def traced_score(c):
        r = orig_score(c)
        ctx = tr.ctx
        if ctx["phase"] == "cegar":
            ctx["iter"] += 1
            idx = ctx["iter"]
            m = ctx.get("metric")
            seq = getattr(m, "error_type_sequence", None) or []
            repair_class = seq[-1] if seq else None
        else:
            ctx["cand"] += 1
            idx = ctx["cand"]
            repair_class = None
        et = c.error_type.value if hasattr(c.error_type, "value") else c.error_type
        tr.event(
            "candidate_scored", phase=ctx["phase"], outer=ctx["outer"], index=idx, oracle_score=c.semantic_score,
            z3_verdict=c.z3_verdict, exec_success=c.execution_success, error_type=et, error_message=c.error_message,
            execution_output=c.execution_output, repair_error_class=repair_class, code=_code(c),
        )
        return r

    p.oracle.execute_and_score = traced_score

    # ---- phase context: beam scoring (outer attempt) and CEGAR ---------------------------------------------------------------
    orig_select = p._select_best_candidate

    def traced_select(candidates, section_id, outer, log):
        tr.ctx.update(phase="beam", outer=outer, cand=0)
        return orig_select(candidates, section_id, outer, log)

    p._select_best_candidate = traced_select

    orig_cegar = p._cegar_loop

    def traced_cegar(section, candidate, semantic_gap, metric):
        tr.ctx.update(phase="cegar", iter=0, metric=metric)
        tr.event("cegar_start", outer=tr.ctx["outer"], entry_gap=semantic_gap, start_score=candidate.semantic_score,
                 start_code=_code(candidate))
        ok, final = False, candidate
        try:
            ok, final = orig_cegar(section, candidate, semantic_gap, metric)
            return ok, final
        finally:
            tr.event("cegar_end", outer=tr.ctx["outer"], success=ok, final_score=getattr(final, "semantic_score", None),
                     iterations_scored=tr.ctx["iter"], iter_scores=list(getattr(p, "_cegar_iter_scores", []) or []),
                     error_type_sequence=list(getattr(metric, "error_type_sequence", []) or []))
            tr.ctx.update(phase="beam", metric=None)

    p._cegar_loop = traced_cegar

    # ---- whole section: input provenance, final status ---------------------------------------------------------------------
    orig_gen = p.generate_and_execute

    def traced_gen(section):
        out_dir = p.output_dir
        shown = p._prompt_section(section)                       # raises in text mode if there is no source text
        text = shown if isinstance(shown, str) else str(shown)
        digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
        prov = {"input_mode": p.input_mode, "input_text_chars": len(text), "input_text_sha256": digest,
                "input_schema": _schema_of(section, p.input_mode)}
        p._input_provenance = prov
        tr.start(out_dir)
        try:
            with open(os.path.join(out_dir, "input_text.txt"), "w", encoding="utf-8") as fh:
                fh.write(text)
            cfg_path = os.path.join(out_dir, "experiment_config.json")
            if os.path.exists(cfg_path):
                with open(cfg_path, encoding="utf-8") as fh:
                    cfg = json.load(fh)
                cfg["input"] = prov
                with open(cfg_path, "w", encoding="utf-8") as fh:
                    json.dump(cfg, fh, indent=2)
        except Exception as exc:
            logger.warning("step_trace: could not write input provenance (%s).", exc)
        tr.event("section_input", act=getattr(p, "act_name", None), section_dir=os.path.basename(out_dir), **prov)
        t0 = time.time()
        try:
            metric = orig_gen(section)
        except Exception as exc:
            tr.event("section_error", error=repr(exc), traceback=traceback.format_exc())
            tr.stop()
            raise
        tr.event(
            "section_final", status="SUCCESS" if metric.final_success else "FAIL", final_error_type=str(metric.final_error_type),
            llm_a_attempts=metric.llm_a_attempts, llm_b_semantic_flags=metric.llm_b_semantic_flags,
            llm_c_attempts=metric.llm_c_attempts, error_type_sequence=list(metric.error_type_sequence),
            semantic_alignment_confirmed=metric.semantic_alignment_confirmed, wall_time_sec=round(time.time() - t0, 2),
        )
        tr.stop()
        return metric

    p.generate_and_execute = traced_gen
    return tr


def _schema_of(section: dict, input_mode: str) -> str:
    if input_mode != "text":
        return "structured_section_dict"
    from legal_text import raw_legal_text
    return raw_legal_text(section)[1]
