from typing import Callable, List, Dict, Tuple
from langchain_core.prompts import PromptTemplate

class Prompt:
    def __init__(self):
        self.UML_Structure = PromptTemplate(
            template="""You are an expert legal data annotator using a Graph-of-Thought (GOT) reasoning model. Your task is to analyze the provided legal section and convert it into a structured JSON annotation.
                     Instead of a linear process, you must first build an internal "thought graph" to map the text's components and their inter-dependencies.
                    ### 1. Reasoning Graph Construction (Internal Monologue)
                    First, you will analyze the text to create the following nodes:
                    * **Node A (Structural Decomposition):** Identify all structural elements: section numbers, titles, subsections, clauses (e.g., (a), (b)), and illustrations.
                    * **Node B (Semantic Entity Analysis):** Concurrently, identify all key actors mentioned (e.g., 'Data Fiduciary', 'Data Principal', 'Board') and any defined terms.
                    * **Node C (Relational & Thematic Analysis):** Concurrently, identify the core semantic themes and the relationships they create:
                        * **Obligations:** (e.g., "shall," "must," "is required to")
                        * **Rights:** (e.g., "shall have the right to")
                        * **Prohibitions:** (e.g., "shall not," "may not")
                        * **Conditions:** (e.g., "unless," "if," "subject to")
                        * **Penalties:** (e.g., "shall be liable for")
                    ### 2. Graph Assembly (Merging Nodes)
                    Next, you will mentally connect these nodes to understand the full picture. For example:
                    * "Node A (Subsection 4)" is linked to "Node C (Right)" which belongs to "Node B (Data Principal)".
                    * "Node A (Clause 2a)" is a "Node C (Condition)" for the "Node C (Obligation)" in "Node A (Subsection 2)".
                    ### 3. Final Output (Rendered Graph)
                    After building this complete internal graph, render its structured output as a JSON object. The JSON must synthesize all identified nodes (structure, entities, relations) into the required format.
                    ---
                    ### Example JSON Format to follow:
                    {ExampleJSON}
                    ---
                    ### Legal Section to Analyze:
                    {Section}
                    ---
                    """,
                    input_variables=["ExampleJSON", "Section"]
                    )
        self.FOL_Structure = PromptTemplate(
            template="""You are an expert in legal reasoning, formal methods, and SMT solving using Z3.
            Your task is to convert the given *legal section text* into **Python Z3 logic code** that runs without syntax or semantic errors.
            ### Requirements:
                1. The generated code **must** define a Python class named according to the section (e.g., `class DPDPSection3:`).
                2. The class must include:
                    * A docstring with the section title.
                    * An `__init__` method defining all relevant `z3.Bool` variables.
                    * A `get_rule(self)` method returning the Z3 logical rule as a valid Z3 expression.
                    * A `verify_data(self, data)` method that:
                    * Initializes a Z3 solver.
                    * Adds the rule using `solver.add(self.get_rule())`.
                    * Iterates through the `data` dictionary, assigning boolean values using `solver.add(variable == value)`.
                    * Returns `solver.check()` as the compliance result.
                3. Always include `import z3` at the top.
                4. The logic must be consistent and executable.
                5. Initiate the class object and call the function.

                {PriorCodeContext}

                If the previously generated code failed with the following error:
                {Error}

                then correct and regenerate the code accordingly.

                ### Input Section
                "{Section}"

                ### Output Format Example:

                ```python
                import z3

                class DPDPSection3:
                    \"\"\"Section 3 - Application of Act\"\"\"
                    def __init__(self):
                        self.processed_by_individual = z3.Bool('processed_by_individual')
                        self.made_publicly_available_by_principal = z3.Bool('made_publicly_available_by_principal')
                        self.made_publicly_available_by_other = z3.Bool('made_publicly_available_by_other')
                        self.apply_act = z3.Bool('apply_act')

                    def get_rule(self):
                        does_not_apply = z3.Or(
                            self.processed_by_individual,
                            z3.Or(self.made_publicly_available_by_principal, self.made_publicly_available_by_other)
                        )
                        return z3.Implies(does_not_apply, z3.Not(self.apply_act))

                    def verify_data(self, data):
                        solver = z3.Solver()
                        solver.add(self.get_rule())
                        for var_name, var_value in data.items():
                            if hasattr(self, var_name):
                                z3_var = getattr(self, var_name)
                                if isinstance(z3_var, z3.BoolRef):
                                    solver.add(z3_var == var_value)
                        return solver.check()
                ```
            """,
            input_variables=["Section", "Error", "PriorCodeContext"]
            )
        
        self.LOGIC_VALIDATION_PROMPT = PromptTemplate(
            template="""You are an expert in legal reasoning, formal logic, and Z3/SMT verification.
            Your task is to check whether the **generated Z3 logic code** is a **correct logical representation** of the **original legal text**.
            ### You must verify:
                1. All conditions in the legal text are captured in the code
                2. All exceptions and constraints are logically represented
                3. No important meaning is lost, reversed, or overgeneralized
                4. The final rule in `get_rule()` correctly reflects the section
                5. Variable names semantically match the original legal concepts
                6. There is no logical contradiction with the text
            ---
            ### Legal Text:
            "{Section}"
            ---
            ### Generated Z3 Logic Code:
            ```python
            {Code}
            ```
            ---

            OUTPUT RULES (VERY STRICT):
            You MUST respond with ONLY a single valid JSON object — no prose, no markdown fences around the JSON.

            If the code is logically correct:
            {{
                "aligned": true,
                "gaps": [],
                "explanation": "<brief explanation of why it is correct>",
                "revised_code": ""
            }}

            If the code has semantic gaps or errors:
            {{
                "aligned": false,
                "gaps": ["<gap 1 description>", "<gap 2 description>"],
                "explanation": "<what is wrong and why>",
                "revised_code": "```python\\n<full corrected code here>\\n```"
            }}
            """,
            input_variables=["Section", "Code"]
        )

        self.GeneratefunctionMetadata = PromptTemplate(
                template="""You are the exper in Python function/class mapping and Predicate Extraction.
                            ##Task 
                            Extract class attributes into a JSON predicate mapping.
                            ##Input
                            A Python class using z3 variables.
                            ##Instructions
                                - Identify the section number from the class name (e.g., DPDPSection6 -> "6").
                                - Locate all z3.Bool variable names defined in the __init__ method.
                                - Format the output as a JSON object where the section number is the key.
                                - The value must be an array containing an object with a "Predicates" key, listing all identified variable names as strings.
                            ##Constraint 
                            Only include the final JSON. Do not include explanations or code.
                            ## Example Input
                            ```
                            class DPDPSection6:
                                    def __init__(self):
                                        self.is_free = z3.Bool('is_free')
                                        self.is_specific = z3.Bool('is_specific')
                                        self.is_informed = z3.Bool('is_informed')
                                        self.is_unconditional = z3.Bool('is_unconditional')
                                        self.is_unambiguous = z3.Bool('is_unambiguous')
                                        self.has_affirmative_action = z3.Bool('has_affirmative_action')
                                        self.is_for_specified_purpose = z3.Bool('is_for_specified_purpose')
                                        self.is_limited_to_necessary_data = z3.Bool('is_limited_to_necessary_data')

                                    def get_rule(self):
                                        return z3.And(
                                            self.is_free, self.is_specific, self.is_informed, self.is_unconditional, self.is_unambiguous,
                                            self.has_affirmative_action, self.is_for_specified_purpose, self.is_limited_to_necessary_data
                                        )
                            ```
                            ### Example Output
                            ```
                            {{
                                    '6':[
                                        {{
                                        "Predicates":["is_free","is_specific","is_informed","is_unconditional","is_unambiguous",
                                                    "has_affirmative_action","is_for_specified_purpose","is_limited_to_necessary_data"]
                                        }}
                                    ]
                            }}
                            ```
                            ## Input Code
                            {function}
                    """,
                    input_variables=["function"]

                )
        self.Execution_VALIDATION_PROMPT = PromptTemplate(template="""You are an expert Python developer and Formal Verification Engineer. 
    Your sole mission is to fix **Python execution errors, Z3 API misuses, or environment crashes** in the provided script.

    ### THE GOLDEN RULE:
    **DO NOT ALTER THE LOGIC.** You are a "Compiler/Debugger," not a "Legal Expert." 
    - Keep all constraints ($Bool$, $Int$, etc.) exactly as intended by the previous agent.
    - Only fix the **wrapping**, **declarations**, **syntax**, or **type-casting** needed to make the code run.
    - If the error is a `Z3Exception` regarding type mismatches, fix the types, not the logic.

    ### Verification Checklist:
    1. **Environment:** Ensure all imports (e.g., `from z3 import *`) are present.
    2. **Declarations:** Ensure every variable used in a constraint is initialized.
    3. **Syntax:** Fix indentation, missing colons, or mismatched parentheses.
    4. **Z3 Types:** Ensure Boolean logic is not being compared to Integer logic in ways Z3 forbids.
    5. **Output Integrity:** The script must produce a result (sat/unsat) when executed.

    ---
    ### INPUT DATA:
    **Context Section:** "{Section}"

    **Broken Code:**
    ```python
    {Code}
    ```

    **Error/Traceback:**
    "{Error}"
    ---

    ### OUTPUT FORMAT (MANDATORY):

    1. **STATUS:** (YES if it runs, NO if it needs fixes)
    2. **CRITICAL FIXES:** (Bullet points of what was syntactically wrong)
    3. **LOGIC PRESERVATION:** (Confirm that the legal constraints remain identical to the original code)
    4. **FULL CORRECTED CODE:** Provide the complete, runnable Python script. It must include:
    - All necessary imports.
    - The full logic logic inside its functions.
    - A main execution block at the bottom to verify the solver works.

    ```python
    # Full runnable code here
    ```
    """,
    input_variables=["Section", "Code", "Error"]
)
        self.CEGAR_COMPLETION_PROMPT = PromptTemplate(template="""You are a Formal Verification Engineer and Legal Logic Expert.
The Z3 Python script below is syntactically correct and executes without errors,
but it is SEMANTICALLY INCOMPLETE: it does not encode all the legal obligations
described in the section.

### Legal Section:
{Section}

### Current (Incomplete) Z3 Code:
```python
{Code}
```

### Missing Semantic Coverage (identified by logic validator):
{Gap}

### YOUR TASK:
1. Read the missing coverage list above carefully.
2. Add Z3 constraints to encode every missing legal obligation.
3. Do NOT remove or alter any existing constraints.
4. Output the COMPLETE updated Z3 script in a single fenced code block.

```python
# Complete updated code with missing constraints added
```
""",
    input_variables=["Section", "Code", "Gap"]
)

    def get_execution_validation(self, section, code, error):
        # code may be a list of blocks — join for the prompt
        code_str = "\n\n".join(code) if isinstance(code, list) else str(code)
        return self.Execution_VALIDATION_PROMPT.format(Section=section, Code=code_str, Error=error)

    def get_completion_repair(self, section, code, gap):
        """Prompt for E4 (incomplete encoding): ask LLM-C to ADD missing constraints."""
        code_str = "\n\n".join(code) if isinstance(code, list) else str(code)
        return self.CEGAR_COMPLETION_PROMPT.format(Section=section, Code=code_str, Gap=gap)

    def get_metadfata_acts(self, function):
        return self.GeneratefunctionMetadata.format(function=function)

    def get_FOL_acts(self, section, error="", prior_code=""):
        """
        Build the Z3 generation prompt.

        Parameters
        ----------
        section    : legal section dict or text
        error      : error string from previous attempt (empty on first call)
        prior_code : best code from previous outer iteration (empty on first call)
        """
        if prior_code:
            context_block = (
                "### Context from Previous Attempt\n"
                "The following code was the best candidate from the prior iteration. "
                "Use it as a reference but address the error above:\n"
                f"```python\n{prior_code}\n```"
            )
        else:
            context_block = ""
        return self.FOL_Structure.format(Section=section, Error=error, PriorCodeContext=context_block)

    def get_UML_Structure(self, example, section):
        return self.UML_Structure.format(ExampleJSON=example, Section=section)

    def get_Logic_Validation(self, section, code):
        """
        Build the LLM B semantic alignment prompt.

        Parameters
        ----------
        code : list of code block strings OR a single string
        """
        code_str = "\n\n".join(code) if isinstance(code, list) else str(code)
        return self.LOGIC_VALIDATION_PROMPT.format(Section=section, Code=code_str)
