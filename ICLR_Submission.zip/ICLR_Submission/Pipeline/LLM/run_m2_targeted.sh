#!/usr/bin/env bash
# run_m2_targeted.sh — Fresh run of one M2 oracle variant against one act.
#
# Usage:
#   ./scripts/LLM/run_m2_targeted.sh <variant> <act>
#
# Examples:
#   ./scripts/LLM/run_m2_targeted.sh exec_only      GDPR
#   ./scripts/LLM/run_m2_targeted.sh sigma_d        CCPA
#   ./scripts/LLM/run_m2_targeted.sh no_proof_bonus DPDP
#   ./scripts/LLM/run_m2_targeted.sh theta_0_5      PIPD
#   ./scripts/LLM/run_m2_targeted.sh full           GDPR
#
# Variants: pass_all  exec_only  no_proof_bonus  theta_0_5  theta_0_9  full  sigma_d
# Acts:     GDPR  CCPA  DPDP  PIPD
#
# For a dry-run or resume, call the Python script directly:
#   python3 scripts/LLM/ablation/run_ablation_M2_targeted.py --variant exec_only --act GDPR --dry-run
#   python3 scripts/LLM/ablation/run_ablation_M2_targeted.py --variant sigma_d   --act CCPA --resume

set -euo pipefail

VARIANT="${1:?Error: variant required. Usage: $0 <variant> <act>}"
ACT="${2:?Error: act required.     Usage: $0 <variant> <act>}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/../.."

echo "=== M2 targeted run | variant=$VARIANT | act=$ACT ==="
python3 scripts/LLM/ablation/run_ablation_M2_targeted.py \
    --variant "$VARIANT" \
    --act     "$ACT"
