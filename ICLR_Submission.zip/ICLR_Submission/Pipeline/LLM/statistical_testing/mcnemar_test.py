#!/usr/bin/env python3
"""
mcnemar_test.py — McNemar test for pairwise REFINE-SMT SLM model comparisons.

Compares per-section binary success between two ablation variants (e.g. A1-strong vs A1-weak).
McNemar's test is the correct choice here: paired binary outcomes on the same test sections.

Usage:
    python mcnemar_test.py \\
        --dir-a SLM_Output/ablation/A1_generation_scaling/strong/ \\
        --dir-b SLM_Output/ablation/A1_generation_scaling/weak/ \\
        --output SLM_Output/aggregate/mcnemar_results.json

    # Run all pairs in an ablation study automatically
    python mcnemar_test.py --ablation-dir SLM_Output/ablation/A1_generation_scaling/ \\
        --output SLM_Output/aggregate/mcnemar_A1.json
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from itertools import combinations
from pathlib import Path
from typing import NamedTuple


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def _load_section_successes(run_dir: Path) -> dict[str, bool]:
    """
    Return {section_key: final_success} for every section_metrics.json under run_dir.
    section_key = "{act}/{section_id}" for unambiguous matching.
    """
    results: dict[str, bool] = {}
    for p in sorted(run_dir.rglob("section_metrics.json")):
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
            act = data.get("slm_metadata", {}).get("act", "unknown")
            sec = data.get("act_file", p.parent.name)
            key = f"{act}/{sec}"
            results[key] = data.get("results", {}).get("final_success", False)
        except Exception as e:
            print(f"[WARN] {p}: {e}")
    return results


# ---------------------------------------------------------------------------
# McNemar test (manual implementation — no scipy required)
# ---------------------------------------------------------------------------

class McNemarResult(NamedTuple):
    variant_a:  str
    variant_b:  str
    n:          int     # matched pairs
    n_both_success:  int
    n_a_only_success: int
    n_b_only_success: int
    n_both_fail: int
    chi2:        float
    p_value:     float
    significant: bool   # p < 0.05
    interpretation: str


def mcnemar_test(
    results_a: dict[str, bool],
    results_b: dict[str, bool],
    name_a: str = "A",
    name_b: str = "B",
    alpha: float = 0.05,
) -> McNemarResult:
    common_keys = sorted(set(results_a) & set(results_b))
    n = len(common_keys)
    if n == 0:
        raise ValueError("No matching section keys between the two run directories.")

    both_succ = sum(1 for k in common_keys if results_a[k] and results_b[k])
    a_only    = sum(1 for k in common_keys if results_a[k] and not results_b[k])
    b_only    = sum(1 for k in common_keys if not results_a[k] and results_b[k])
    both_fail = sum(1 for k in common_keys if not results_a[k] and not results_b[k])

    discordant = a_only + b_only
    if discordant == 0:
        chi2    = 0.0
        p_value = 1.0
    else:
        # McNemar chi-squared with continuity correction (Yates)
        chi2    = (abs(a_only - b_only) - 1) ** 2 / discordant
        p_value = _chi2_p(chi2, df=1)

    significant = p_value < alpha
    if significant:
        winner = name_a if a_only > b_only else name_b
        interpretation = (
            f"Statistically significant difference (p={p_value:.4f} < {alpha}). "
            f"{winner} performs better on discordant sections."
        )
    else:
        interpretation = (
            f"No statistically significant difference (p={p_value:.4f} >= {alpha}). "
            f"Models perform comparably on matched sections."
        )

    return McNemarResult(
        variant_a=name_a, variant_b=name_b, n=n,
        n_both_success=both_succ, n_a_only_success=a_only,
        n_b_only_success=b_only, n_both_fail=both_fail,
        chi2=round(chi2, 4), p_value=round(p_value, 6),
        significant=significant, interpretation=interpretation,
    )


def _chi2_p(chi2: float, df: int = 1) -> float:
    """Approximate p-value for chi-squared distribution (df=1) using regularised gamma."""
    try:
        import scipy.stats
        return float(scipy.stats.chi2.sf(chi2, df))
    except ImportError:
        # Manual approximation using the error function (accurate to ~4 decimal places for df=1)
        # P(chi2 > x | df=1) = erfc(sqrt(x/2))
        return _erfc(math.sqrt(chi2 / 2))


def _erfc(x: float) -> float:
    """Complementary error function via continued fraction approximation."""
    if x < 0:
        return 2.0 - _erfc(-x)
    t = 1.0 / (1.0 + 0.3275911 * x)
    poly = t * (0.254829592
                + t * (-0.284496736
                       + t * (1.421413741
                              + t * (-1.453152027
                                     + t * 1.061405429))))
    return poly * math.exp(-(x ** 2))


# ---------------------------------------------------------------------------
# Batch: all pairs within an ablation study
# ---------------------------------------------------------------------------

def run_all_pairs(ablation_dir: Path) -> list[dict]:
    variant_dirs = sorted(
        d for d in ablation_dir.iterdir() if d.is_dir() and not d.name.startswith(".")
    )
    all_results = []
    for dir_a, dir_b in combinations(variant_dirs, 2):
        try:
            res_a = _load_section_successes(dir_a)
            res_b = _load_section_successes(dir_b)
            r = mcnemar_test(res_a, res_b, name_a=dir_a.name, name_b=dir_b.name)
            all_results.append(r._asdict())
            print(f"  {dir_a.name} vs {dir_b.name}: chi2={r.chi2:.3f} p={r.p_value:.4f} "
                  f"sig={r.significant}")
        except Exception as e:
            print(f"  [ERR] {dir_a.name} vs {dir_b.name}: {e}")
    return all_results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="McNemar test for REFINE-SMT SLM comparisons")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--dir-a",        type=Path, help="Run directory A")
    g.add_argument("--ablation-dir", type=Path, help="Ablation study dir (auto all-pairs)")
    p.add_argument("--dir-b",   type=Path, help="Run directory B (required with --dir-a)")
    p.add_argument("--output",  type=Path, required=True, help="Output JSON path")
    p.add_argument("--alpha",   type=float, default=0.05, help="Significance threshold")
    args = p.parse_args()

    if args.dir_a:
        if not args.dir_b:
            p.error("--dir-b required when using --dir-a")
        res_a = _load_section_successes(args.dir_a)
        res_b = _load_section_successes(args.dir_b)
        result = mcnemar_test(res_a, res_b,
                              name_a=args.dir_a.name, name_b=args.dir_b.name,
                              alpha=args.alpha)
        results = [result._asdict()]
        print(result.interpretation)
    else:
        results = run_all_pairs(args.ablation_dir)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print(f"\nMcNemar results written: {args.output}")


if __name__ == "__main__":
    main()
