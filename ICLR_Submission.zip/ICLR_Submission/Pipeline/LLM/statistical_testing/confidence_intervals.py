#!/usr/bin/env python3
"""
confidence_intervals.py — Bootstrap 95% confidence intervals for SLM evaluation metrics.

Bootstraps from per-section binary outcomes to produce CIs for:
  success_rate, semantic_alignment_rate, repair_success_rate, oracle_pass_rate

Usage:
    python confidence_intervals.py \\
        --run-dir SLM_Output/normal/SLM-Primary-.../ \\
        --output  SLM_Output/aggregate/confidence_intervals.json \\
        [--samples 10000] [--ci 0.95]
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def _load_section_data(run_dir: Path) -> list[dict]:
    rows = []
    for p in sorted(run_dir.rglob("section_metrics.json")):
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
            act = data.get("slm_metadata", {}).get("act", "unknown")
            r   = data.get("results", {})
            at  = data.get("attempt_counts", {})
            rows.append({
                "act":              act,
                "section":          data.get("act_file", "?"),
                "success":          bool(r.get("final_success", False)),
                "aligned":          r.get("semantic_alignment_confirmed", 0.0) >= 0.5,
                "repaired":         at.get("llm_c_cegar_iterations", 0) > 0,
                "repair_success":   bool(r.get("final_success", False)) if at.get("llm_c_cegar_iterations", 0) > 0 else None,
                "oracle_pass":      bool(r.get("final_success", False)) or r.get("semantic_alignment_confirmed", 0.0) >= 0.7,
            })
        except Exception as e:
            print(f"[WARN] {p}: {e}")
    return rows


# ---------------------------------------------------------------------------
# Bootstrap CI
# ---------------------------------------------------------------------------

def _bootstrap_rate(flags: list[bool], n_samples: int, ci: float, seed: int = 42) -> tuple[float, float, float]:
    """Return (point_estimate, lower, upper) for a binary rate via bootstrap."""
    rng = random.Random(seed)
    n   = len(flags)
    if n == 0:
        return 0.0, 0.0, 0.0

    point_est = sum(flags) / n
    boot_means = []
    for _ in range(n_samples):
        sample = [rng.choice(flags) for _ in range(n)]
        boot_means.append(sum(sample) / n)

    boot_means.sort()
    alpha   = (1.0 - ci) / 2
    lo_idx  = max(0, int(alpha * n_samples))
    hi_idx  = min(n_samples - 1, int((1.0 - alpha) * n_samples))
    return round(point_est, 4), round(boot_means[lo_idx], 4), round(boot_means[hi_idx], 4)


def compute_cis(
    rows: list[dict],
    n_samples: int = 10_000,
    ci: float = 0.95,
) -> dict:
    acts   = sorted({r["act"] for r in rows})
    result: dict = {"overall": {}, "per_act": {}}

    metrics = {
        "end_to_end_success_rate":   [r["success"]  for r in rows],
        "semantic_alignment_rate":   [r["aligned"]  for r in rows],
        "oracle_pass_rate":          [r["oracle_pass"] for r in rows],
        "repair_success_rate":       [r["repair_success"] for r in rows if r["repair_success"] is not None],
    }

    for metric, flags in metrics.items():
        if not flags:
            continue
        est, lo, hi = _bootstrap_rate(flags, n_samples, ci)
        result["overall"][metric] = {"estimate": est, "lower": lo, "upper": hi,
                                     "ci": ci, "n": len(flags)}

    for act in acts:
        act_rows = [r for r in rows if r["act"] == act]
        result["per_act"][act] = {}
        act_metrics = {
            "end_to_end_success_rate": [r["success"] for r in act_rows],
            "semantic_alignment_rate": [r["aligned"] for r in act_rows],
            "oracle_pass_rate":        [r["oracle_pass"] for r in act_rows],
        }
        for metric, flags in act_metrics.items():
            if not flags:
                continue
            est, lo, hi = _bootstrap_rate(flags, n_samples, ci)
            result["per_act"][act][metric] = {
                "estimate": est, "lower": lo, "upper": hi,
                "ci": ci, "n": len(flags),
            }

    return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="Bootstrap CIs for REFINE-SMT SLM metrics")
    p.add_argument("--run-dir",  type=Path, required=True, help="Run directory (or ablation variant)")
    p.add_argument("--output",   type=Path, required=True, help="Output JSON path")
    p.add_argument("--samples",  type=int,   default=10_000, help="Bootstrap samples")
    p.add_argument("--ci",       type=float, default=0.95,   help="Confidence level")
    args = p.parse_args()

    rows = _load_section_data(args.run_dir)
    if not rows:
        print(f"[ERR] No section data found under {args.run_dir}")
        sys.exit(1)

    print(f"Loaded {len(rows)} sections from {args.run_dir.name}")
    cis = compute_cis(rows, n_samples=args.samples, ci=args.ci)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(cis, f, indent=2)
    print(f"CIs written: {args.output}")

    # Print summary
    print(f"\n{'Metric':<35} {'Est':>6} {'Lower':>8} {'Upper':>8}")
    print("-" * 60)
    for metric, vals in cis.get("overall", {}).items():
        print(f"  {metric:<33} {vals['estimate']:>6.3f} [{vals['lower']:.3f}, {vals['upper']:.3f}]")


if __name__ == "__main__":
    main()
