#!/usr/bin/env python3
"""
statistical_report.py — Consolidate McNemar tests + CIs into a single AAAI-ready report.

Usage:
    python statistical_report.py \\
        --ablation-dir SLM_Output/ablation/ \\
        --benchmark    SLM_Output/normal/SLM-Primary-.../ \\
        --output       SLM_Output/aggregate/

Output:
    statistical_report.json  — machine-readable
    statistical_report.md    — paste-ready for AAAI paper
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from statistical_testing.mcnemar_test import run_all_pairs, _load_section_successes, mcnemar_test
from statistical_testing.confidence_intervals import _load_section_data, compute_cis
from statistical_testing.additional_tests import load_section_logs, run_all_additional


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

def build_report(
    ablation_dir: Path,
    benchmark_dir: Path | None,
    output_dir: Path,
    n_samples: int = 10_000,
    ci: float = 0.95,
    alpha: float = 0.05,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    report: dict = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "mcnemar": {},
        "confidence_intervals": {},
        "additional_tests": {},
        "summary": [],
    }

    # ── McNemar tests for each ablation study ────────────────────────────────
    for study_dir in sorted(ablation_dir.iterdir()):
        if not study_dir.is_dir():
            continue
        study = study_dir.name
        print(f"\nMcNemar tests: {study}")
        pairs = run_all_pairs(study_dir)
        report["mcnemar"][study] = pairs

    # ── CIs for benchmark primary run ─────────────────────────────────────────
    if benchmark_dir and benchmark_dir.exists():
        print(f"\nBootstrap CIs: {benchmark_dir.name}")
        rows = _load_section_data(benchmark_dir)
        if rows:
            cis = compute_cis(rows, n_samples=n_samples, ci=ci)
            report["confidence_intervals"]["benchmark"] = cis

    # ── CIs for each ablation strong variant (primary config) ─────────────────
    for study_dir in sorted(ablation_dir.iterdir()):
        if not study_dir.is_dir():
            continue
        strong_dir = study_dir / "strong"
        if strong_dir.exists():
            rows = _load_section_data(strong_dir)
            if rows:
                cis = compute_cis(rows, n_samples=n_samples, ci=ci)
                report["confidence_intervals"][f"{study_dir.name}_strong"] = cis

    # ── Table 8: additional tests (Wilcoxon, Mann-Whitney, paired-t, chi2, McNemar/deontic)
    for study_dir in sorted(ablation_dir.iterdir()):
        if not study_dir.is_dir():
            continue
        strong_dir = study_dir / "strong"
        weak_dir   = study_dir / "weak"
        if strong_dir.exists() and weak_dir.exists():
            print(f"\nAdditional tests: {study_dir.name} (strong vs weak)")
            logs_s = load_section_logs(strong_dir)
            logs_w = load_section_logs(weak_dir)
            if logs_s and logs_w:
                report["additional_tests"][study_dir.name] = run_all_additional(
                    logs_s, logs_w,
                    name_a=f"{study_dir.name}_strong",
                    name_b=f"{study_dir.name}_weak",
                    alpha=alpha,
                )

    # ── Natural language summary ───────────────────────────────────────────────
    report["summary"] = _build_summary(report, alpha)

    # Write JSON
    json_path = output_dir / "statistical_report.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(f"\nReport JSON: {json_path}")

    # Write Markdown
    md_path = output_dir / "statistical_report.md"
    md_path.write_text(_render_markdown(report, alpha, ci), encoding="utf-8")
    print(f"Report MD:   {md_path}")

    return report


# ---------------------------------------------------------------------------
# Summary builder
# ---------------------------------------------------------------------------

def _build_summary(report: dict, alpha: float) -> list[str]:
    lines = []
    for study, pairs in report.get("mcnemar", {}).items():
        sig   = [p for p in pairs if p.get("significant")]
        insig = [p for p in pairs if not p.get("significant")]
        if sig:
            lines.append(
                f"[{study}] Significant differences found: "
                + ", ".join(f"{p['variant_a']} vs {p['variant_b']} (p={p['p_value']:.4f})"
                            for p in sig)
            )
        if insig:
            lines.append(
                f"[{study}] No significant differences: "
                + ", ".join(f"{p['variant_a']} vs {p['variant_b']}" for p in insig)
            )
    return lines


# ---------------------------------------------------------------------------
# Markdown renderer
# ---------------------------------------------------------------------------

def _render_markdown(report: dict, alpha: float, ci: float) -> str:
    lines = [
        "# REFINE-SMT SLM Statistical Analysis Report",
        f"\nGenerated: {report.get('generated_at', 'N/A')}",
        "\n---\n",
        "## Summary\n",
    ]
    for s in report.get("summary", []):
        lines.append(f"- {s}")

    lines.append("\n---\n")
    lines.append("## McNemar Tests (pairwise ablation comparisons)\n")
    lines.append(f"Significance threshold: α = {alpha}\n")

    for study, pairs in report.get("mcnemar", {}).items():
        lines.append(f"### {study}\n")
        lines.append(f"| Variant A | Variant B | n | χ² | p-value | Significant |")
        lines.append(f"|-----------|-----------|---|-----|---------|-------------|")
        for p in pairs:
            sig_str = "✓" if p.get("significant") else "✗"
            lines.append(
                f"| {p['variant_a']} | {p['variant_b']} | {p['n']} "
                f"| {p['chi2']:.3f} | {p['p_value']:.4f} | {sig_str} |"
            )
        lines.append("")

    lines.append("\n---\n")
    lines.append(f"## Bootstrap Confidence Intervals ({int(ci * 100)}% CI)\n")

    for label, cis in report.get("confidence_intervals", {}).items():
        lines.append(f"### {label}\n")
        overall = cis.get("overall", {})
        if overall:
            lines.append("| Metric | Estimate | Lower | Upper | n |")
            lines.append("|--------|----------|-------|-------|---|")
            for metric, vals in overall.items():
                lines.append(
                    f"| {metric} | {vals['estimate']:.3f} | {vals['lower']:.3f} "
                    f"| {vals['upper']:.3f} | {vals['n']} |"
                )
        lines.append("")

    # ── Table 8: Additional tests ─────────────────────────────────────────────
    additional = report.get("additional_tests", {})
    if additional:
        lines.append("\n---\n")
        lines.append("## Table 8 — Additional Statistical Tests\n")
        lines.append(f"Significance threshold: α = {alpha} (Bonferroni α/3 for deontic tests)\n")

        for study, res in additional.items():
            lines.append(f"### {study} (strong vs weak)\n")
            n_pairs = res.get("n_matched_pairs", "?")
            lines.append(f"Matched pairs: {n_pairs}\n")

            lines.append("| Test | Statistic | p-value | Significant |")
            lines.append("|------|-----------|---------|-------------|")

            def _row(name: str, d: dict) -> str:
                stat_key = next((k for k in ("W_stat", "U1", "t_stat", "chi2") if k in d), None)
                stat_val = f"{d[stat_key]:.3f}" if stat_key else "—"
                sig = "✓" if d.get("significant") or d.get("significant_bonferroni") else "✗"
                return f"| {name} | {stat_val} | {d.get('p_value', '?'):.4f} | {sig} |"

            lines.append(_row("Wilcoxon (alignment scores)", res.get("wilcoxon_alignment_scores", {})))
            lines.append(_row("Mann-Whitney U (CEGAR iters)", res.get("mann_whitney_cegar_iters", {})))
            lines.append(_row("Paired-t log (wall time)", res.get("paired_t_wall_time", {})))
            lines.append(_row("χ² error distribution", res.get("chi2_error_distribution", {})))

            mc = res.get("mcnemar_per_deontic", {}).get("per_deontic", {})
            b_alpha = res.get("mcnemar_per_deontic", {}).get("bonferroni_alpha", alpha / 3)
            for dt, mr in mc.items():
                lines.append(
                    f"| McNemar [{dt}] (Bonferroni α={b_alpha:.4f}) "
                    f"| χ²={mr.get('chi2', 0):.3f} | {mr.get('p_value', 1.0):.4f} "
                    f"| {'✓' if mr.get('significant_bonferroni') else '✗'} |"
                )
            lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="Consolidated statistical report for REFINE-SMT SLM")
    p.add_argument("--ablation-dir", type=Path, required=True, help="SLM_Output/ablation/")
    p.add_argument("--benchmark",    type=Path, default=None,  help="Benchmark run dir (optional)")
    p.add_argument("--output",       type=Path, required=True, help="Output directory")
    p.add_argument("--samples",      type=int,   default=10_000)
    p.add_argument("--ci",           type=float, default=0.95)
    p.add_argument("--alpha",        type=float, default=0.05)
    args = p.parse_args()

    build_report(
        ablation_dir=args.ablation_dir,
        benchmark_dir=args.benchmark,
        output_dir=args.output,
        n_samples=args.samples,
        ci=args.ci,
        alpha=args.alpha,
    )


if __name__ == "__main__":
    main()
