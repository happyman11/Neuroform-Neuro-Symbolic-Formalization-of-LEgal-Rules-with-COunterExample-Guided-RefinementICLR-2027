#!/usr/bin/env python3
"""
additional_tests.py — Supplementary statistical tests for REFINE-SMT SLM (AAAI-2026).

Covers Table 8 of the AAAI paper:
  - Wilcoxon signed-rank test     (paired alignment scores, continuous)
  - Mann-Whitney U test            (CEGAR iteration counts, ordinal)
  - Paired t-test (log-transform)  (wall-clock times, log-normal)
  - Chi-squared goodness-of-fit    (error class distribution vs. expected)
  - McNemar per deontic type       (O / F / P binary success, with Bonferroni)

All tests are self-contained (no scipy required). Bonferroni correction is applied
wherever multiple comparisons are made within a family.

Usage (standalone):
    python additional_tests.py \\
        --dir-a SLM_Output/ablation/A1/strong/ \\
        --dir-b SLM_Output/ablation/A1/weak/ \\
        --output SLM_Output/aggregate/additional_tests.json
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Loading helpers
# ---------------------------------------------------------------------------

def load_section_logs(run_dir: Path) -> list[dict]:
    """Return list of section_metrics dicts from all section_metrics.json under run_dir."""
    rows = []
    for p in sorted(run_dir.rglob("section_metrics.json")):
        try:
            with open(p, encoding="utf-8") as f:
                rows.append(json.load(f))
        except Exception as e:
            print(f"[WARN] {p}: {e}")
    return rows


def _pair_by_key(logs_a: list[dict], logs_b: list[dict]) -> list[tuple[dict, dict]]:
    """
    Match logs from two runs by section key (act/filename).
    Returns only sections present in both runs.
    """
    def _key(lg: dict) -> str:
        act = lg.get("slm_metadata", {}).get("act", "?")
        sec = lg.get("act_file", "?")
        return f"{act}/{sec}"

    map_a = {_key(lg): lg for lg in logs_a}
    map_b = {_key(lg): lg for lg in logs_b}
    common = sorted(set(map_a) & set(map_b))
    return [(map_a[k], map_b[k]) for k in common]


# ---------------------------------------------------------------------------
# Math helpers  (no scipy dependency)
# ---------------------------------------------------------------------------

def _normal_p(z: float) -> float:
    """Two-tailed p-value from z-score using Abramowitz & Stegun approximation."""
    a1, a2, a3, a4, a5 = 0.319381530, -0.356563782, 1.781477937, -1.821255978, 1.330274429
    p = 0.2316419
    k = 1.0 / (1.0 + p * abs(z))
    poly = k * (a1 + k * (a2 + k * (a3 + k * (a4 + k * a5))))
    one_tail = poly * math.exp(-0.5 * z * z) / math.sqrt(2 * math.pi)
    return min(1.0, 2 * one_tail)


def _t_p(t: float, df: int) -> float:
    """Two-tailed p-value for t-distribution via incomplete beta (approximation for df>=2)."""
    try:
        from scipy.stats import t as tdist
        return float(tdist.sf(abs(t), df) * 2)
    except ImportError:
        # Normal approximation — acceptable for df > 30
        return _normal_p(t)


def _chi2_p(chi2: float, df: int) -> float:
    """p-value for chi-squared distribution."""
    try:
        import scipy.stats
        return float(scipy.stats.chi2.sf(chi2, df))
    except ImportError:
        # Single-df case: use erfc shortcut
        if df == 1:
            x = math.sqrt(chi2 / 2)
            t = 1.0 / (1.0 + 0.3275911 * x)
            poly = t * (0.254829592 + t * (-0.284496736 + t * (1.421413741 + t * (-1.453152027 + t * 1.061405429))))
            return poly * math.exp(-(x ** 2))
        # For df > 1, use Wilson-Hilferty approximation
        k = df
        z = ((chi2 / k) ** (1 / 3) - (1 - 2 / (9 * k))) / math.sqrt(2 / (9 * k))
        return _normal_p(z)


# ---------------------------------------------------------------------------
# Wilcoxon signed-rank test  (paired alignment scores)
# ---------------------------------------------------------------------------

def wilcoxon_signed_rank_test(
    scores_a: list[float],
    scores_b: list[float],
    alpha: float = 0.05,
) -> dict:
    """
    Wilcoxon signed-rank test for paired continuous measurements (e.g. alignment scores).
    Uses normal approximation with continuity correction (valid for n >= 10).
    """
    assert len(scores_a) == len(scores_b), "Paired lists must be equal length."
    diffs = [a - b for a, b in zip(scores_a, scores_b)]
    nonzero = [(abs(d), math.copysign(1, d)) for d in diffs if d != 0]
    n = len(nonzero)

    if n == 0:
        return {"statistic": 0.0, "p_value": 1.0, "n": 0, "significant": False,
                "interpretation": "All differences are zero — no effect."}

    # Rank by absolute value
    ranked = sorted(enumerate(nonzero), key=lambda x: x[1][0])
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j < n - 1 and ranked[j + 1][1][0] == ranked[i][1][0]:
            j += 1
        avg_rank = (i + j) / 2 + 1
        for k in range(i, j + 1):
            ranks[ranked[k][0]] = avg_rank
        i = j + 1

    w_plus  = sum(ranks[i] for i, (_, sign) in enumerate(nonzero) if sign > 0)
    w_minus = sum(ranks[i] for i, (_, sign) in enumerate(nonzero) if sign < 0)
    w_stat  = min(w_plus, w_minus)

    # Normal approximation
    mu    = n * (n + 1) / 4
    sigma = math.sqrt(n * (n + 1) * (2 * n + 1) / 24)
    z     = (w_stat - mu + 0.5) / sigma  # continuity correction
    p     = _normal_p(z)
    significant = p < alpha

    direction = "A > B" if w_plus > w_minus else ("A < B" if w_minus > w_plus else "no difference")
    return {
        "test": "wilcoxon_signed_rank",
        "n_pairs": n,
        "W_plus": w_plus, "W_minus": w_minus, "W_stat": w_stat,
        "z": round(z, 4), "p_value": round(p, 6),
        "significant": significant,
        "direction": direction,
        "interpretation": (
            f"{'Significant' if significant else 'No significant'} difference "
            f"(W={w_stat}, z={z:.3f}, p={p:.4f}). Direction: {direction}."
        ),
    }


# ---------------------------------------------------------------------------
# Mann-Whitney U test  (unpaired ordinal counts)
# ---------------------------------------------------------------------------

def mann_whitney_u_test(
    counts_a: list[int],
    counts_b: list[int],
    alpha: float = 0.05,
) -> dict:
    """
    Mann-Whitney U test for two independent samples (e.g. CEGAR iteration counts).
    Uses normal approximation with continuity correction.
    """
    n1, n2 = len(counts_a), len(counts_b)
    if n1 == 0 or n2 == 0:
        return {"p_value": 1.0, "significant": False, "interpretation": "Empty sample."}

    u1 = sum(
        (1.0 if a > b else 0.5 if a == b else 0.0)
        for a in counts_a for b in counts_b
    )
    u2 = n1 * n2 - u1

    mu_u = n1 * n2 / 2
    sigma_u = math.sqrt(n1 * n2 * (n1 + n2 + 1) / 12)
    z = (min(u1, u2) - mu_u + 0.5) / sigma_u
    p = _normal_p(z)
    significant = p < alpha

    return {
        "test": "mann_whitney_u",
        "n_a": n1, "n_b": n2,
        "U1": round(u1, 2), "U2": round(u2, 2),
        "z": round(z, 4), "p_value": round(p, 6),
        "significant": significant,
        "interpretation": (
            f"{'Significant' if significant else 'No significant'} difference "
            f"(U={min(u1,u2):.1f}, z={z:.3f}, p={p:.4f})."
        ),
    }


# ---------------------------------------------------------------------------
# Paired t-test with log-transform  (wall-clock times)
# ---------------------------------------------------------------------------

def paired_t_test_log(
    times_a: list[float],
    times_b: list[float],
    alpha: float = 0.05,
) -> dict:
    """
    Paired t-test on log-transformed wall-clock times (log-normal assumption).
    Sections with time <= 0 in either run are excluded.
    """
    pairs = [(math.log(a), math.log(b)) for a, b in zip(times_a, times_b)
             if a > 0 and b > 0]
    n = len(pairs)
    if n < 2:
        return {"p_value": 1.0, "significant": False,
                "interpretation": "Insufficient data for t-test."}

    diffs = [a - b for a, b in pairs]
    mean_d = sum(diffs) / n
    var_d  = sum((d - mean_d) ** 2 for d in diffs) / (n - 1)
    se     = math.sqrt(var_d / n)
    t_stat = mean_d / se if se > 0 else 0.0
    p      = _t_p(t_stat, df=n - 1)
    significant = p < alpha

    return {
        "test": "paired_t_log_transform",
        "n_pairs": n,
        "mean_log_diff": round(mean_d, 4),
        "t_stat": round(t_stat, 4), "df": n - 1,
        "p_value": round(p, 6),
        "significant": significant,
        "interpretation": (
            f"{'Significant' if significant else 'No significant'} difference in "
            f"log-time (t={t_stat:.3f}, df={n-1}, p={p:.4f}). "
            f"Mean log-ratio A/B = {mean_d:.3f} ({'A slower' if mean_d > 0 else 'A faster'})."
        ),
    }


# ---------------------------------------------------------------------------
# Chi-squared goodness-of-fit  (error class distribution)
# ---------------------------------------------------------------------------

def chi2_goodness_of_fit(
    observed: dict[str, int],
    expected: dict[str, float] | None = None,
    alpha: float = 0.05,
) -> dict:
    """
    Chi-squared goodness-of-fit test.

    observed : {error_class: count}
    expected : {error_class: expected_proportion} — if None, uniform distribution.

    Tests whether the observed error class distribution differs from expected.
    """
    classes = sorted(observed)
    obs = [observed[c] for c in classes]
    n_total = sum(obs)

    if n_total == 0:
        return {"chi2": 0.0, "p_value": 1.0, "significant": False,
                "interpretation": "No observations."}

    if expected is None:
        exp_counts = [n_total / len(classes)] * len(classes)
    else:
        total_exp = sum(expected.values())
        exp_counts = [(expected.get(c, 0) / total_exp) * n_total for c in classes]

    chi2 = sum(
        (o - e) ** 2 / e for o, e in zip(obs, exp_counts) if e > 0
    )
    df = len([e for e in exp_counts if e > 0]) - 1
    p = _chi2_p(chi2, df) if df > 0 else 1.0
    significant = p < alpha

    return {
        "test": "chi2_goodness_of_fit",
        "classes": classes,
        "observed": obs,
        "expected": [round(e, 2) for e in exp_counts],
        "chi2": round(chi2, 4), "df": df,
        "p_value": round(p, 6),
        "significant": significant,
        "interpretation": (
            f"{'Significant' if significant else 'No significant'} deviation from "
            f"expected distribution (χ²={chi2:.3f}, df={df}, p={p:.4f})."
        ),
    }


# ---------------------------------------------------------------------------
# McNemar per deontic type  (with Bonferroni correction)
# ---------------------------------------------------------------------------

def mcnemar_per_deontic_type(
    logs_a: list[dict],
    logs_b: list[dict],
    alpha: float = 0.05,
) -> dict:
    """
    Three paired McNemar tests: one per deontic type (O / F / P).
    Bonferroni correction applied: adjusted α = alpha / 3.

    Returns a dict with keys "O", "F", "P", each containing a McNemar result,
    plus "bonferroni_alpha".
    """
    pairs = _pair_by_key(logs_a, logs_b)
    bonferroni_alpha = alpha / 3

    results: dict[str, dict] = {}
    for deontic_type in ("O", "F", "P"):
        subset = [
            (a, b) for a, b in pairs
            if a.get("slm_extra", {}).get("ground_truth_deontic") == deontic_type
        ]
        if not subset:
            results[deontic_type] = {
                "n": 0, "p_value": 1.0, "significant": False,
                "interpretation": f"No sections with deontic type {deontic_type}.",
            }
            continue

        n_both_succ = sum(1 for a, b in subset if
                          a.get("results", {}).get("final_success", False) and
                          b.get("results", {}).get("final_success", False))
        n_a_only    = sum(1 for a, b in subset if
                          a.get("results", {}).get("final_success", False) and
                          not b.get("results", {}).get("final_success", False))
        n_b_only    = sum(1 for a, b in subset if
                          not a.get("results", {}).get("final_success", False) and
                          b.get("results", {}).get("final_success", False))
        n_both_fail = sum(1 for a, b in subset if
                          not a.get("results", {}).get("final_success", False) and
                          not b.get("results", {}).get("final_success", False))

        discordant = n_a_only + n_b_only
        if discordant == 0:
            chi2, p = 0.0, 1.0
        else:
            chi2 = (abs(n_a_only - n_b_only) - 1) ** 2 / discordant
            p    = _chi2_p(chi2, df=1)

        significant = p < bonferroni_alpha
        results[deontic_type] = {
            "deontic_type": deontic_type,
            "n": len(subset),
            "n_both_success": n_both_succ,
            "n_a_only": n_a_only,
            "n_b_only": n_b_only,
            "n_both_fail": n_both_fail,
            "chi2": round(chi2, 4),
            "p_value": round(p, 6),
            "significant_bonferroni": significant,
            "interpretation": (
                f"[{deontic_type}] "
                + (f"Significant difference after Bonferroni (p={p:.4f} < α/3={bonferroni_alpha:.4f})."
                   if significant
                   else f"No significant difference (p={p:.4f} >= α/3={bonferroni_alpha:.4f}).")
            ),
        }

    return {"bonferroni_alpha": round(bonferroni_alpha, 6), "per_deontic": results}


# ---------------------------------------------------------------------------
# Batch runner — run all supplementary tests for two paired run directories
# ---------------------------------------------------------------------------

def run_all_additional(
    logs_a: list[dict],
    logs_b: list[dict],
    name_a: str = "A",
    name_b: str = "B",
    alpha: float = 0.05,
) -> dict:
    """
    Run all additional tests for a paired comparison (A vs B).
    Returns a dict suitable for JSON serialisation.
    """
    pairs = _pair_by_key(logs_a, logs_b)
    n = len(pairs)

    def _field(lg: dict, *keys) -> float:
        obj = lg
        for k in keys:
            obj = obj.get(k, {}) if isinstance(obj, dict) else {}
        return float(obj) if isinstance(obj, (int, float)) else 0.0

    align_a = [_field(a, "results", "semantic_alignment_confirmed") for a, _ in pairs]
    align_b = [_field(b, "results", "semantic_alignment_confirmed") for _, b in pairs]
    iters_a = [int(_field(a, "attempt_counts", "llm_c_cegar_iterations")) for a, _ in pairs]
    iters_b = [int(_field(b, "attempt_counts", "llm_c_cegar_iterations")) for _, b in pairs]
    time_a  = [_field(a, "results", "wall_time_sec") for a, _ in pairs]
    time_b  = [_field(b, "results", "wall_time_sec") for _, b in pairs]

    # Error class distribution (chi2 gof — does A's distribution match B's?)
    def _err_dist(logs: list[dict]) -> dict[str, int]:
        dist: dict[str, int] = {}
        for lg in logs:
            for e in lg.get("error_analysis", {}).get("error_type_sequence", []):
                dist[e] = dist.get(e, 0) + 1
        return dist

    obs_a = _err_dist(logs_a)
    exp_b_proportions: dict[str, float] = {}
    total_b = sum(_err_dist(logs_b).values())
    if total_b > 0:
        exp_b_proportions = {k: v / total_b for k, v in _err_dist(logs_b).items()}

    return {
        "comparison": f"{name_a} vs {name_b}",
        "n_matched_pairs": n,
        "wilcoxon_alignment_scores": wilcoxon_signed_rank_test(align_a, align_b, alpha),
        "mann_whitney_cegar_iters": mann_whitney_u_test(iters_a, iters_b, alpha),
        "paired_t_wall_time": paired_t_test_log(time_a, time_b, alpha),
        "chi2_error_distribution": chi2_goodness_of_fit(obs_a, exp_b_proportions, alpha),
        "mcnemar_per_deontic": mcnemar_per_deontic_type(logs_a, logs_b, alpha),
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser(
        description="Supplementary statistical tests for REFINE-SMT SLM (AAAI Table 8)"
    )
    p.add_argument("--dir-a",  type=Path, required=True, help="Run directory A")
    p.add_argument("--dir-b",  type=Path, required=True, help="Run directory B")
    p.add_argument("--output", type=Path, required=True, help="Output JSON path")
    p.add_argument("--alpha",  type=float, default=0.05, help="Significance threshold")
    args = p.parse_args()

    logs_a = load_section_logs(args.dir_a)
    logs_b = load_section_logs(args.dir_b)

    if not logs_a or not logs_b:
        print("[ERR] Could not load section logs from one or both directories.")
        sys.exit(1)

    print(f"Loaded {len(logs_a)} sections from A ({args.dir_a.name})")
    print(f"Loaded {len(logs_b)} sections from B ({args.dir_b.name})")

    results = run_all_additional(
        logs_a, logs_b, name_a=args.dir_a.name, name_b=args.dir_b.name, alpha=args.alpha
    )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    print(f"\nResults written: {args.output}")
    print(f"  Wilcoxon p={results['wilcoxon_alignment_scores']['p_value']:.4f}")
    print(f"  Mann-Whitney p={results['mann_whitney_cegar_iters']['p_value']:.4f}")
    print(f"  Paired-t p={results['paired_t_wall_time']['p_value']:.4f}")
    print(f"  Chi2 p={results['chi2_error_distribution']['p_value']:.4f}")
    for dt, r in results["mcnemar_per_deontic"]["per_deontic"].items():
        print(f"  McNemar [{dt}] p={r.get('p_value', 'N/A')}")


if __name__ == "__main__":
    main()
