#!/usr/bin/env bash
# run_benchmark_threshold_08.sh — Shell driver for REFINE-SMT LLM benchmarking
# at oracle_threshold=0.8 (config_threshold_08.yaml), kept fully separate
# from the primary oracle_threshold=0.7 runs.
#
# Usage:
#   ./run_benchmark_threshold_08.sh [--acts DPDP,GDPR] [--sections N] [--dry-run]
#   ./run_benchmark_threshold_08.sh --dry-run --sections 1   # smoke test
#
# Output: LLM_Output/normal_threshold_08/{run_id}/...
# Logs are tee'd to LLM_Output/normal_threshold_08/logs/<timestamp>.log

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# ICLR supplementary: repointed to this bundle's own root (3 levels up from here), self-contained --
# matches llm_config.py/slm_config.py's own ROOT resolution.
ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
OUTPUT_DIR_NAME="normal_threshold_08"
LOG_DIR="$ROOT/LLM_Output/$OUTPUT_DIR_NAME/logs"
mkdir -p "$LOG_DIR"

TIMESTAMP=$(date -u +"%Y%m%dT%H%M%SZ")
LOG_FILE="$LOG_DIR/${TIMESTAMP}_benchmark.log"

# ── Check / install psutil ────────────────────────────────────────────────────
if ! python3 -c "import psutil" 2>/dev/null; then
    echo -e "  ${YELLOW}psutil not found — installing...${NC}"
    pip install -q psutil
fi

# ── Check / install bitsandbytes (required for 70B 4-bit quantization) ───────
if ! python3 -c "import bitsandbytes" 2>/dev/null; then
    echo -e "  ${YELLOW}bitsandbytes not found — installing...${NC}"
    pip install -q bitsandbytes
fi

# ── Environment: use local HF cache, no network calls ────────────────────────
# Models must already be downloaded via install_models_LLM.sh
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_HUB_ENABLE_HF_TRANSFER=1

export PYTHONPATH="$ROOT/Src/SMT_Generation:$SCRIPT_DIR/..:${PYTHONPATH:-}"

# ── Forward all arguments to Python ──────────────────────────────────────────
EXTRA_ARGS=("$@")

echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║  REFINE-SMT LLM Benchmark Runner — oracle_threshold=0.8   ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Timestamp  : ${YELLOW}${TIMESTAMP}${NC}"
echo -e "  Config     : ${YELLOW}config_threshold_08.yaml${NC}"
echo -e "  Output dir : ${YELLOW}LLM_Output/${OUTPUT_DIR_NAME}/${NC}"
echo -e "  Log file   : ${YELLOW}${LOG_FILE}${NC}"
echo -e "  HF offline : ${YELLOW}${HF_HUB_OFFLINE}${NC}  (models must be pre-downloaded)"
echo ""

python3 "$SCRIPT_DIR/run_benchmark.py" \
    --config "$SCRIPT_DIR/config_threshold_08.yaml" \
    --output-dir-name "$OUTPUT_DIR_NAME" \
    "${EXTRA_ARGS[@]}" 2>&1 | tee "$LOG_FILE"

EXIT_CODE=${PIPESTATUS[0]}
if [ "$EXIT_CODE" -eq 0 ]; then
    echo -e "\n  ${GREEN}✓ Benchmark complete.${NC}"
else
    echo -e "\n  ${RED}✗ Benchmark exited with code $EXIT_CODE. Check log: $LOG_FILE${NC}"
fi
exit "$EXIT_CODE"
