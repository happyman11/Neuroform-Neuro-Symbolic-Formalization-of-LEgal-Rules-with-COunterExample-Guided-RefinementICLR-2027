#!/usr/bin/env python3
"""
run_benchmark.py — REFINE-SMT LLM primary benchmarking runner.

Runs the full REFINE-SMT pipeline with LLM models (HuggingFace local inference)
across all 4 privacy acts and writes AAAI-ready structured logs.

Usage:
    python run_benchmark.py [--config config.yaml] [--acts DPDP,GDPR]
                            [--sections N] [--dry-run]

Output:
    LLM_Output/normal/{run_id}/{act}/   — per-section logs + Z3 code
    LLM_Output/normal/{run_id}/run_config.json
    LLM_Output/normal/{run_id}/{act}_aggregate_metrics.json
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from tqdm import tqdm

# ── path setup ───────────────────────────────────────────────────────────────
_HERE = Path(__file__).parent.parent
sys.path.insert(0, str(_HERE))

from llm_config import SRC, ACTS_INPUT, SLM_OUTPUT, IGNORE_FILES
from llm_pipeline import LLMRefineSMT, _make_run_id

sys.path.insert(0, str(SRC))
from utility import Utility
from legal_text import raw_legal_text


# ---------------------------------------------------------------------------
# Section loading
# ---------------------------------------------------------------------------

def _load_section(file_path: Path, utility: Any) -> dict:
    """
    Load a section JSON file.
    extract_json_robust returns only the parsed 'annotation' field;
    we augment the result with top-level metadata (label_metrics,
    structured_annotation, source) so llm_pipeline can extract ground-truth
    deontic type and clause complexity without re-reading the file.
    """
    try:
        with open(file_path, encoding="utf-8") as fh:
            full = json.load(fh)
    except Exception:
        full = {}

    section = utility.extract_json_robust(str(file_path))
    if section is None:
        section = {}

    # Inject top-level metadata the pipeline needs for LLM metrics
    for key in ("label_metrics", "structured_annotation", "source"):
        if key in full and key not in section:
            section[key] = full[key]

    return section


# ---------------------------------------------------------------------------
# Raw-text pre-flight: prove BEFORE any model loads that every section of every act has text to send
# ---------------------------------------------------------------------------

def _input_coverage(acts: list[str], section_limit: int | None, utility: Any) -> dict:
    """
    Per act: how many sections have raw legal text (legal_text.raw_legal_text on the exact dict the pipeline receives, i.e.
    _load_section's output), which `source` schema was used, text-length spread, and the sections that are EMPTY.
    """
    import statistics
    cov: dict = {}
    for act in acts:
        d = ACTS_INPUT.get(act)
        if d is None or not d.exists():
            cov[act] = {"input_dir": str(d), "input_dir_missing": True, "n_sections": 0, "n_with_text": 0,
                        "empty_sections": [], "schemas": {}, "chars": None}
            continue
        files = sorted(f for f in os.listdir(d) if f.endswith(".json") and f not in IGNORE_FILES)
        if section_limit:
            files = files[:section_limit]
        schemas: dict[str, int] = {}
        lens: list[int] = []
        empty: list[str] = []
        for f in files:
            text, schema = raw_legal_text(_load_section(d / f, utility))
            schemas[schema] = schemas.get(schema, 0) + 1
            if text.strip():
                lens.append(len(text))
            else:
                empty.append(f)
        cov[act] = {"input_dir": str(d), "input_dir_missing": False, "n_sections": len(files), "n_with_text": len(lens),
                    "empty_sections": empty, "schemas": schemas,
                    "chars": {"min": min(lens), "median": int(statistics.median(lens)), "max": max(lens)} if lens else None}
    return cov


def _log_input_coverage(cov: dict, run_dir: Path | None) -> bool:
    """Log the coverage table (and write run_dir/input_coverage.json). True iff every act exists and no section is empty."""
    ok = True
    logger.info("Raw-text input coverage (legal_text.raw_legal_text on each section's `source`):")
    for act, c in cov.items():
        if c["input_dir_missing"]:
            ok = False
            logger.error("  %-5s INPUT DIRECTORY MISSING: %s", act, c["input_dir"])
            continue
        if c["empty_sections"] or c["n_with_text"] != c["n_sections"]:
            ok = False
        ch = c["chars"] or {}
        logger.info("  %-5s %3d/%3d sections have text | schemas=%s | chars min/median/max=%s/%s/%s%s",
                    act, c["n_with_text"], c["n_sections"], c["schemas"], ch.get("min"), ch.get("median"), ch.get("max"),
                    f" | EMPTY: {c['empty_sections']}" if c["empty_sections"] else "")
    if run_dir is not None:
        with open(run_dir / "input_coverage.json", "w", encoding="utf-8") as fh:
            json.dump(cov, fh, indent=2)
    return ok


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def _setup_logging(run_dir: Path) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    logging.basicConfig(level=logging.INFO, format=fmt)
    fh = logging.FileHandler(run_dir / "run.log", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(fmt))
    logging.getLogger().addHandler(fh)


logger = logging.getLogger("benchmark")


# ---------------------------------------------------------------------------
# Core runner
# ---------------------------------------------------------------------------

def run_benchmark(
    cfg: dict,
    run_id: str,
    run_dir: Path,
    acts: list[str],
    section_limit: int | None = None,
    dry_run: bool = False,
    allow_empty_text: bool = False,
) -> dict:
    utility = Utility()

    hp   = cfg["hyperparameters"]
    mods = cfg["models"]
    # llm_b_skip: if set, LLM-B (semantic-alignment model) is never loaded/called -- _run_semantic_alignment-style check in
    # llm_pipeline.py/slm_pipeline.py returns (True, "", 1.0) unconditionally instead (same flag the M3/skip ablation variant uses).
    # Absent from the config (the normal case) -> False, byte-identical to behavior before this flag existed.
    llm_b_skip = bool(hp.get("llm_b_skip", False))
    llm_b_owner = "skip" if llm_b_skip else mods["llm_b"]["owner"]
    llm_b_model = "skip" if llm_b_skip else mods["llm_b"]["model"]
    # input_mode: "structured" (default, absent from config -> byte-identical to prior
    # behavior) sends the full annotated section dict to LLM-A/B/C. "text" sends only
    # the raw legal section text (source.full_text), bypassing the structured/deontic
    # annotation -- see RefineSMT._prompt_section() in SMT_Generation_AAAI_Final.py.
    input_mode = str(hp.get("input_mode", "structured"))
    # detailed_logging: opt-in per-section trace.jsonl (every prompt / raw response / score / LLM-B verdict) + input_text.txt --
    # see lib/step_trace.py. Absent -> False -> byte-identical to prior behavior.
    detailed_logging = bool(hp.get("detailed_logging", False))
    # strict_run (raw-text or detailed-logging runs): fail fast on missing/empty input, write act_status.json, and let the
    # caller exit non-zero if any act/section did not run. Other configs keep the previous lenient behavior.
    strict_run = (input_mode == "text") or detailed_logging

    _write_run_config(cfg, run_id, run_dir, acts, llm_b_owner=llm_b_owner, llm_b_model=llm_b_model)

    status: dict = {"input_mode": input_mode, "detailed_logging": detailed_logging, "dry_run": dry_run, "acts": {}}
    if strict_run:
        cov = _input_coverage(acts, section_limit, utility)
        cov_ok = _log_input_coverage(cov, run_dir)
        if not cov_ok and not (allow_empty_text and not any(c["input_dir_missing"] for c in cov.values())):
            logger.error("ABORT before loading any model: at least one act directory is missing or has a section with no raw "
                         "legal text (see table above / %s). Use --allow-empty-text to override for empty sections only.",
                         run_dir / "input_coverage.json")
            raise SystemExit(2)

    for act in acts:
        act_input = ACTS_INPUT.get(act)
        if act_input is None or not act_input.exists():
            logger.error("Act input directory not found: %s → %s", act, act_input)
            status["acts"][act] = {"input_dir_missing": True, "n_sections": 0, "completed": 0, "failed": []}
            continue

        act_output = run_dir / act
        act_output.mkdir(parents=True, exist_ok=True)

        files = sorted(
            f for f in os.listdir(act_input)
            if f.endswith(".json") and f not in IGNORE_FILES
        )
        if section_limit:
            files = files[:section_limit]

        logger.info(
            "=== %s | %d sections | LLM-A=%s | LLM-B=%s%s | LLM-C=%s",
            act, len(files),
            mods["llm_a"]["model"], llm_b_model, " (skipped)" if llm_b_skip else "", mods["llm_c"]["model"],
        )

        pipeline = LLMRefineSMT(
            output_path=str(act_output),
            model_owner=mods["llm_a"]["owner"],
            model=mods["llm_a"]["model"],
            agnostic_model_owner=llm_b_owner,
            agnostic_model=llm_b_model,
            corrector_owner=mods["llm_c"]["owner"],
            corrector_model=mods["llm_c"]["model"],
            max_outer_attempts=hp["max_outer"],
            max_cegar_iterations=hp["max_cegar"],
            beam_width=hp["beam_width"],
            oracle_pass_threshold=hp.get("oracle_threshold", 0.7),
            experiment="benchmarking",
            variant="primary",
            act_name=act,
            run_id=run_id,
            # Per-role generation params (Theorem 2.2)
            llm_a_temperature=mods["llm_a"].get("temperature", 0.7),
            llm_b_temperature=mods["llm_b"].get("temperature", 0.0),
            llm_c_temperature=mods["llm_c"].get("temperature", 0.0),
            # scripts/additional_runs/ knobs -- both default to prior behavior
            # (e4v detection on, seed unset/non-deterministic) unless the config
            # file explicitly sets them.
            e4v_detection_enabled=hp.get("e4v_detection_enabled", True),
            seed=hp.get("seed"),
            llm_b_skip=llm_b_skip,
            input_mode=input_mode,
            detailed_logging=detailed_logging,
            # ICLR supplementary: "paper_exact" is the pipeline's only algorithm -- see SMT_Generation_AAAI_Final.py.
            algorithm_mode=hp.get("algorithm_mode", "paper_exact"),
        )

        completed: list[str] = []
        failed: list[str] = []
        with tqdm(total=len(files), desc=act) as pbar:
            for filename in files:
                pbar.set_postfix_str(filename)
                if dry_run:
                    logger.info("[DRY-RUN] %s/%s", act, filename)
                    pbar.update(1)
                    continue
                try:
                    section = _load_section(act_input / filename, utility)
                    pipeline.process_act(section, filename.replace(".json", ""))
                    completed.append(filename)
                except Exception:
                    logger.exception("Failed: %s/%s", act, filename)
                    failed.append(filename)
                pbar.update(1)

        if not dry_run:
            pipeline.save_aggregate_metrics(log=True)
            agg_src = act_output / "aggregate_metrics.json"
            agg_dst = run_dir / f"{act}_aggregate_metrics.json"
            if agg_src.exists():
                shutil.copy(agg_src, agg_dst)
            logger.info("Act complete: %s → %s", act, act_output)

        n_ok = sum(1 for m in getattr(pipeline, "all_metrics", []) if m.final_success)
        status["acts"][act] = {"input_dir_missing": False, "n_sections": len(files), "completed": len(completed),
                               "synthesis_success": n_ok if not dry_run else None, "failed": failed}
        if strict_run and not dry_run:
            logger.info("Act %s: %d/%d sections completed without an exception (%d reached final_success); failed=%s",
                        act, len(completed), len(files), n_ok, failed or "none")
            with open(run_dir / "act_status.json", "w", encoding="utf-8") as fh:
                json.dump(status, fh, indent=2)

    status["all_ran"] = all(not a["input_dir_missing"] and not a["failed"] for a in status["acts"].values()) \
        and set(status["acts"]) == set(acts)
    if strict_run and not dry_run:
        with open(run_dir / "act_status.json", "w", encoding="utf-8") as fh:
            json.dump(status, fh, indent=2)
        logger.info("Run status: all %d act(s) ran with no failed section = %s  (%s)", len(acts), status["all_ran"],
                    run_dir / "act_status.json")
    logger.info("Benchmark run complete. Output: %s", run_dir)
    return status


# ---------------------------------------------------------------------------
# run_config.json
# ---------------------------------------------------------------------------

def _write_run_config(cfg: dict, run_id: str, run_dir: Path, acts: list[str], llm_b_owner: str, llm_b_model: str) -> None:
    try:
        import transformers
        tf_ver = transformers.__version__
    except ImportError:
        tf_ver = "N/A"

    mods = cfg["models"]
    # record what was ACTUALLY used for LLM-B, not the config file's models.llm_b verbatim: llm_b_skip=true (config_*_no_llm_b.yaml)
    # forces "skip"/"skip" here regardless of what the YAML lists, so run_config.json can never misreport a skipped model as loaded.
    recorded_models = dict(cfg["models"])
    recorded_models["llm_b"] = {**cfg["models"]["llm_b"], "owner": llm_b_owner, "model": llm_b_model}
    config = {
        "run_id":          run_id,
        "experiment":      "benchmarking",
        "variant":         "primary",
        "timestamp":       datetime.now(timezone.utc).isoformat(),
        "acts":            acts,
        "models":          recorded_models,
        "hyperparameters": cfg["hyperparameters"],
        "generation_params": {
            "llm_a_temperature": mods["llm_a"].get("temperature", 0.7),
            "llm_b_temperature": mods["llm_b"].get("temperature", 0.0),
            "llm_c_temperature": mods["llm_c"].get("temperature", 0.0),
        },
        "hardware":        platform.node(),
        "python_version":  platform.python_version(),
        "transformers_version": tf_ver,
    }
    run_dir.mkdir(parents=True, exist_ok=True)
    with open(run_dir / "run_config.json", "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)
    logger.info("run_config.json written: %s", run_dir / "run_config.json")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="REFINE-SMT LLM Benchmarking Runner")
    parser.add_argument(
        "--config", default=str(Path(__file__).parent / "config.yaml"),
        help="Path to benchmarking config YAML",
    )
    parser.add_argument(
        "--acts", default=None,
        help="Comma-separated act list override, e.g. DPDP,GDPR",
    )
    parser.add_argument(
        "--sections", type=int, default=None,
        help="Limit sections per act (useful for smoke tests)",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print what would run without calling any LLMs",
    )
    parser.add_argument(
        "--output-dir-name", default="normal",
        help="Subfolder under LLM_Output/ to write this run to (default: normal). "
             "Use to keep variant runs (e.g. a different oracle_threshold) fully "
             "separate from the primary normal/ runs.",
    )
    parser.add_argument(
        "--seed", type=int, default=None,
        help="Override hyperparameters.seed from the config file. Wired to "
             "generation (llm_pipeline.LLMRefineSMT -> llm_models.HuggingFaceModel.call's "
             "torch.manual_seed). Omit to leave the config's own value (or its "
             "absence -> unseeded/non-deterministic) unchanged.",
    )
    parser.add_argument(
        "--preflight", action="store_true",
        help="Only report raw-text coverage per act (does every section of every act have text to send?) and exit; "
             "loads no model and creates no run directory. Exit 2 if any act/section is empty.",
    )
    parser.add_argument(
        "--allow-empty-text", action="store_true",
        help="Raw-text runs abort before loading models if any section has no source text; this overrides that "
             "(empty sections only -- a missing act directory always aborts).",
    )
    args = parser.parse_args()

    with open(args.config, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    if args.seed is not None:
        cfg["hyperparameters"]["seed"] = args.seed

    acts = args.acts.split(",") if args.acts else cfg.get("acts", list(ACTS_INPUT.keys()))
    ts   = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id  = f"LLM-Primary-{ts}"
    run_dir = SLM_OUTPUT / args.output_dir_name / run_id  # SLM_OUTPUT here is llm_config's (quirky-named) LLM_Output constant

    if args.preflight:
        logging.basicConfig(level=logging.INFO, format="%(message)s")
        logger.info("Preflight for config %s (input_mode=%s), acts=%s", args.config,
                    cfg["hyperparameters"].get("input_mode", "structured"), acts)
        sys.exit(0 if _log_input_coverage(_input_coverage(acts, args.sections, Utility()), None) else 2)

    _setup_logging(run_dir)
    logger.info("Run ID: %s", run_id)
    logger.info("Acts: %s", acts)

    status = run_benchmark(
        cfg=cfg,
        run_id=run_id,
        run_dir=run_dir,
        acts=acts,
        section_limit=args.sections,
        dry_run=args.dry_run,
        allow_empty_text=args.allow_empty_text,
    )
    # Raw-text / detailed-logging runs report failure through the exit code (wrapper prints ✗ instead of ✓);
    # every other config exits 0 as before.
    strict = str(cfg["hyperparameters"].get("input_mode", "structured")) == "text" or bool(cfg["hyperparameters"].get("detailed_logging", False))
    if strict and not args.dry_run and not status.get("all_ran", True):
        sys.exit(1)


if __name__ == "__main__":
    main()
