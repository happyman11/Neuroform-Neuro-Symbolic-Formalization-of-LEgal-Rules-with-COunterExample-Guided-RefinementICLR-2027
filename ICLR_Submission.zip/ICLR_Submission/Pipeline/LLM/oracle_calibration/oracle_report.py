#!/usr/bin/env python3
"""
oracle_report.py — Visualize oracle calibration results and write a Markdown summary.

Reads oracle_calibration_results.json and produces:
  - oracle_threshold_curve.png  (matplotlib F1/FPR/FNR vs threshold)
  - oracle_calibration_report.md

Usage:
    python oracle_report.py \\
        --input  SLM_Output/aggregate/oracle_calibration_results.json \\
        --output SLM_Output/aggregate/
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Plotting (optional — skip gracefully if matplotlib unavailable)
# ---------------------------------------------------------------------------

def _plot_curves(data: dict, output_dir: Path) -> str | None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("[INFO] matplotlib not available — skipping plot generation")
        return None

    per_t = data.get("per_threshold", {})
    thresholds = sorted(float(k) for k in per_t)
    f1s  = [per_t[f"{t:.1f}"]["f1"]                 for t in thresholds]
    fprs = [per_t[f"{t:.1f}"]["false_positive_rate"] for t in thresholds]
    fnrs = [per_t[f"{t:.1f}"]["false_negative_rate"] for t in thresholds]

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(thresholds, f1s,  "o-",  color="steelblue",  linewidth=2, label="F1")
    ax.plot(thresholds, fprs, "s--", color="firebrick",  linewidth=1.5, label="FPR (↓ better)")
    ax.plot(thresholds, fnrs, "^--", color="darkorange", linewidth=1.5, label="FNR (↓ better)")

    opt_t = data.get("optimal_threshold", 0.7)
    ax.axvline(opt_t, color="steelblue", linestyle=":", linewidth=1.5,
               label=f"Optimal t={opt_t:.1f}")
    ax.axvline(0.7, color="gray", linestyle=":", linewidth=1.0, label="Default t=0.7")

    ax.set_xlabel("Oracle Threshold", fontsize=12)
    ax.set_ylabel("Rate", fontsize=12)
    ax.set_title("REFINE-SMT Oracle Threshold Calibration Curve", fontsize=13)
    ax.set_xticks(thresholds)
    ax.set_ylim(-0.05, 1.05)
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)

    out_path = output_dir / "oracle_threshold_curve.png"
    fig.tight_layout()
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Plot saved: {out_path}")
    return str(out_path)


# ---------------------------------------------------------------------------
# Markdown report
# ---------------------------------------------------------------------------

def _render_markdown(data: dict, plot_path: str | None) -> str:
    per_t = data.get("per_threshold", {})
    opt_t = data.get("optimal_threshold", 0.7)
    n     = data.get("n_sections", 0)

    lines = [
        "# Oracle Threshold Calibration Report",
        f"\n**Sections analysed:** {n}",
        f"**Current default threshold:** 0.7",
        f"**Recommended optimal threshold:** {opt_t}",
        f"\n> {data.get('recommendation', '')}",
        "\n---\n",
        "## Threshold Sweep Results\n",
        "| Threshold | Passed | FPR | FNR | Precision | Recall | F1 |",
        "|-----------|--------|-----|-----|-----------|--------|-----|",
    ]
    for t_str in sorted(per_t, key=float):
        v = per_t[t_str]
        marker = " **←**" if float(t_str) == opt_t else ""
        lines.append(
            f"| {t_str}{marker} | {v['n_passed']} | {v['false_positive_rate']:.3f} "
            f"| {v['false_negative_rate']:.3f} | {v['precision']:.3f} "
            f"| {v['recall']:.3f} | {v['f1']:.3f} |"
        )

    if plot_path:
        lines += [
            "\n---\n",
            "## Calibration Curve\n",
            f"![Oracle Calibration Curve]({Path(plot_path).name})\n",
        ]

    lines += [
        "\n---\n",
        "## Interpretation\n",
        "- **FPR (False Positive Rate):** Sections that passed the oracle but failed the full pipeline.",
        "  Lower is better — high FPR wastes LLM-B/C compute on doomed candidates.",
        "- **FNR (False Negative Rate):** Sections rejected by oracle that could have succeeded.",
        "  Lower is better — high FNR artificially depresses end-to-end success rate.",
        "- **F1:** Harmonic mean of precision and recall for the 'pass → success' event.",
        "  Maximising F1 balances FPR and FNR.",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="Oracle calibration report for REFINE-SMT SLM")
    p.add_argument("--input",  type=Path, required=True, help="oracle_calibration_results.json")
    p.add_argument("--output", type=Path, required=True, help="Output directory")
    args = p.parse_args()

    with open(args.input, encoding="utf-8") as f:
        data = json.load(f)

    args.output.mkdir(parents=True, exist_ok=True)

    plot_path = _plot_curves(data, args.output)
    md        = _render_markdown(data, plot_path)

    md_path = args.output / "oracle_calibration_report.md"
    md_path.write_text(md, encoding="utf-8")
    print(f"Report written: {md_path}")

    print(f"\nOptimal threshold : {data['optimal_threshold']}")
    print(f"Optimal F1        : {data['optimal_f1']:.4f}")


if __name__ == "__main__":
    main()
