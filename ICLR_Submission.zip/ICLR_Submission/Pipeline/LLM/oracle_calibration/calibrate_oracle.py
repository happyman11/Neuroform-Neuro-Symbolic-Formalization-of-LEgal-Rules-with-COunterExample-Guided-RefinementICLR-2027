#!/usr/bin/env python3
"""
calibrate_oracle.py — Sweep oracle threshold and analyze impact on REFINE-SMT behavior.

Reuses existing section_metrics.json logs — no LLM re-runs needed.

For each threshold t ∈ {0.5, 0.6, 0.7, 0.8, 0.9} (paper §6.3):
  - Determines which sections would have been PASSED to LLM-B (beam max ≥ t)
  - Computes: sections_passed, false_positive_rate, false_negative_rate
  - Identifies optimal threshold (highest F1 between pass → ultimate success)

Usage:
    python calibrate_oracle.py \\
        --run-dir SLM_Output/normal/SLM-Primary-.../ \\
        --output  SLM_Output/aggregate/oracle_calibration_results.json \\
        [--thresholds 0.5,0.6,0.7,0.8,0.9]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def _load_oracle_data(run_dir: Path) -> list[dict]:
    """
    Load per-section beam scores and outcomes from section_metrics.json.
    Returns list of dicts with keys: act, section, beam_scores, final_success.
    """
    rows = []
    for p in sorted(run_dir.rglob("section_metrics.json")):
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            print(f"[WARN] {p}: {e}")
            continue

        # Extract beam scores from augmented SLM log
        beam_log  = data.get("beam_log", [])
        all_scores = [s for entry in beam_log for s in entry.get("scores", [])]

        # Fallback: estimate max score from alignment_confirmed
        if not all_scores:
            r = data.get("results", {})
            aligned = r.get("semantic_alignment_confirmed", 0.0)
            # If section succeeded, max beam score was >= 0.7 (oracle threshold)
            all_scores = [aligned if aligned > 0 else (0.5 if r.get("final_success") else 0.3)]

        rows.append({
            "act":           data.get("slm_metadata", {}).get("act", "unknown"),
            "section":       data.get("act_file", p.parent.name),
            "beam_scores":   all_scores,
            "max_score":     max(all_scores),
            "final_success": data.get("results", {}).get("final_success", False),
            "aligned":       data.get("results", {}).get("semantic_alignment_confirmed", 0.0) >= 0.5,
        })
    return rows


# ---------------------------------------------------------------------------
# Calibration sweep
# ---------------------------------------------------------------------------

def calibrate(rows: list[dict], thresholds: list[float]) -> dict:
    n = len(rows)
    if n == 0:
        return {}

    results: dict[str, dict] = {}

    for t in thresholds:
        key = f"{t:.1f}"
        passed   = [r for r in rows if r["max_score"] >= t]
        rejected = [r for r in rows if r["max_score"] < t]

        # Of passed sections: how many ultimately succeeded?
        tp = sum(1 for r in passed if r["final_success"])      # True positive
        fp = sum(1 for r in passed if not r["final_success"])   # False positive (passed oracle, failed pipeline)

        # Of rejected sections: how many would have succeeded if allowed through?
        fn = sum(1 for r in rejected if r["final_success"])     # False negative (rejected but capable)
        tn = sum(1 for r in rejected if not r["final_success"]) # True negative (correctly rejected)

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1        = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
        fpr       = fp / (fp + tn) if (fp + tn) > 0 else 0.0    # False positive rate
        fnr       = fn / (fn + tp) if (fn + tp) > 0 else 0.0    # False negative rate

        results[key] = {
            "threshold":       t,
            "n_passed":        len(passed),
            "n_rejected":      len(rejected),
            "pass_rate":       round(len(passed) / n, 4),
            "true_positives":  tp,
            "false_positives": fp,
            "false_negatives": fn,
            "true_negatives":  tn,
            "precision":       round(precision, 4),
            "recall":          round(recall, 4),
            "f1":              round(f1, 4),
            "false_positive_rate": round(fpr, 4),
            "false_negative_rate": round(fnr, 4),
        }

    # Find optimal threshold (highest F1)
    best_t = max(results, key=lambda k: results[k]["f1"])
    return {
        "n_sections":         n,
        "thresholds_tested":  thresholds,
        "per_threshold":      results,
        "optimal_threshold":  float(best_t),
        "optimal_f1":         results[best_t]["f1"],
        "current_threshold":  0.7,
        "recommendation": (
            f"Optimal threshold: {best_t} (F1={results[best_t]['f1']:.4f}). "
            f"Current default 0.7 has F1={results.get('0.7', {}).get('f1', 'N/A')}."
        ),
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="Oracle threshold calibration for REFINE-SMT SLM")
    p.add_argument("--run-dir",    type=Path, required=True)
    p.add_argument("--output",     type=Path, required=True)
    p.add_argument(
        "--thresholds", default="0.5,0.6,0.7,0.8,0.9",
        help="Comma-separated threshold list (paper §6.3: 0.5–0.9)",
    )
    args = p.parse_args()

    thresholds = [float(t) for t in args.thresholds.split(",")]
    rows       = _load_oracle_data(args.run_dir)

    if not rows:
        print(f"[ERR] No section data found under {args.run_dir}")
        sys.exit(1)

    print(f"Loaded {len(rows)} sections. Sweeping thresholds: {thresholds}")
    result = calibrate(rows, thresholds)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    print(f"\nCalibration results written: {args.output}")
    print(f"Optimal threshold: {result['optimal_threshold']} "
          f"(F1={result['optimal_f1']:.4f})")
    print(f"Recommendation: {result['recommendation']}")

    print(f"\n{'Threshold':>10} {'Passed':>8} {'FPR':>8} {'FNR':>8} {'F1':>8}")
    print("-" * 50)
    for t_str, vals in sorted(result["per_threshold"].items()):
        marker = " ←" if float(t_str) == result["optimal_threshold"] else ""
        print(f"  {t_str:>8} {vals['n_passed']:>8} {vals['false_positive_rate']:>8.4f} "
              f"{vals['false_negative_rate']:>8.4f} {vals['f1']:>8.4f}{marker}")


if __name__ == "__main__":
    main()
