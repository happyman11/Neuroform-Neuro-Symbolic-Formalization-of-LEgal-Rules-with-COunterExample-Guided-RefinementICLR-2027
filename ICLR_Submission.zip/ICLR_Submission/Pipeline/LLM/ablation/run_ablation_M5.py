#!/usr/bin/env python3
"""
Ablation M5 — CEGAR Budget Study (paper §5.2.5)
Vary max_cegar ∈ {0, 1, 3, 5, 7}; fix all three LLMs = primary.

Goal: Determine marginal gain per CEGAR iteration and optimal budget
      for cost-performance trade-off.

Usage:
    python run_ablation_M5.py [--acts DPDP,GDPR] [--sections N] [--dry-run]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from ablation._ablation_runner import run_module_ablation

STUDY = "M5_cegar_budget"


def main():
    p = argparse.ArgumentParser(description="Ablation M5: CEGAR Budget")
    p.add_argument("--acts",     default=None, help="Comma-separated acts, e.g. DPDP,GDPR")
    p.add_argument("--sections", type=int, default=None, help="Limit sections per act")
    p.add_argument("--dry-run",  action="store_true")
    args = p.parse_args()

    acts = args.acts.split(",") if args.acts else None
    run_module_ablation(
        study=STUDY,
        acts=acts,
        section_limit=args.sections,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
