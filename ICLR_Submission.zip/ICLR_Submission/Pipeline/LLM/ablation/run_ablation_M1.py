#!/usr/bin/env python3
"""
Ablation M1 — Beam Width Study (paper §5.2.1)
Vary beam_width ∈ {1, 2, 3, 5}; fix all three LLMs = primary.

Goal: Assess how beam width affects oracle pass rate, beam diversity,
      and end-to-end success.

Usage:
    python run_ablation_M1.py [--acts DPDP,GDPR] [--sections N] [--dry-run]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from ablation._ablation_runner import run_module_ablation

STUDY = "M1_beam_width"


def main():
    p = argparse.ArgumentParser(description="Ablation M1: Beam Width")
    p.add_argument("--acts",     default=None, help="Comma-separated acts, e.g. DPDP,GDPR")
    p.add_argument("--sections", type=int, default=None, help="Limit sections per act")
    p.add_argument("--dry-run",  action="store_true")
    args = p.parse_args()

    acts = args.acts.split(",") if args.acts else None
    run_module_ablation(
        study=STUDY,
        acts=acts,
        section_limit=args.sections,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
