#!/usr/bin/env bash
# run_all_ablations.sh — Orchestrates all ablation studies for REFINE-SMT LLM
#
# Studies run in order:
#   Model-tier  : A1 → A2 → A3
#   Module-level: M1 → M2 → M3 → M4 → M5
#   Model-family: V6
#
# Usage:
#   ./run_all_ablations.sh [--only A2] [--acts DPDP,GDPR] [--sections N] [--dry-run]
#
# Options:
#   --only <study>    Run only one study (e.g. --only M3_llm_b_variant or --only M3)
#   --acts            Comma-separated act override (e.g. DPDP,GDPR)
#   --sections N      Limit sections per act per variant (smoke test)
#   --dry-run         Print what would run without calling LLMs

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# ICLR supplementary: repointed to this bundle's own root (3 levels up from here), self-contained --
# matches llm_config.py/slm_config.py's own ROOT resolution.
ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
LOG_DIR="$ROOT/LLM_Output/ablation/logs"
mkdir -p "$LOG_DIR"

TIMESTAMP=$(date -u +"%Y%m%dT%H%M%SZ")

# ── Parse args ────────────────────────────────────────────────────────────────
ONLY=""
PASS_THROUGH=()
while [[ $# -gt 0 ]]; do
    case "$1" in
        --only) ONLY="$2"; shift 2;;
        *)      PASS_THROUGH+=("$1"); shift;;
    esac
done

# ── Check / install psutil ────────────────────────────────────────────────────
if ! python3 -c "import psutil" 2>/dev/null; then
    echo -e "  ${YELLOW}psutil not found — installing...${NC}"
    pip install -q psutil
fi

# ── Check / install bitsandbytes (required for 70B 4-bit quantization) ───────
if ! python3 -c "import bitsandbytes" 2>/dev/null; then
    echo -e "  ${YELLOW}bitsandbytes not found — installing...${NC}"
    pip install -q bitsandbytes
fi

# ── Environment: use local HF cache, no network calls ────────────────────────
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_HUB_ENABLE_HF_TRANSFER=1
export PYTHONPATH="$ROOT/Src/SMT_Generation:$SCRIPT_DIR/..:${PYTHONPATH:-}"

# ── Runner helper ─────────────────────────────────────────────────────────────
run_ablation() {
    local study="$1"; local script="$2"
    # Support --only with short prefix (e.g. "A1" matches "A1_generation_scaling")
    if [[ -n "$ONLY" ]]; then
        if [[ "$ONLY" != "$study" && "$study" != "${ONLY}_"* && "${study%%_*}" != "$ONLY" ]]; then
            echo -e "  ${YELLOW}Skipping ${study} (--only ${ONLY})${NC}"
            return
        fi
    fi
    local log="$LOG_DIR/${TIMESTAMP}_${study}.log"
    echo -e "\n${CYAN}▶ Running ${study}${NC}  →  ${log}"
    python3 "$script" "${PASS_THROUGH[@]}" 2>&1 | tee "$log"
    local ec=${PIPESTATUS[0]}
    if [ "$ec" -eq 0 ]; then
        echo -e "  ${GREEN}✓ ${study} complete${NC}"
    else
        echo -e "  ${RED}✗ ${study} failed (exit $ec)${NC}"
        exit "$ec"
    fi
}

# ── Header ────────────────────────────────────────────────────────────────────
echo -e "${CYAN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║    REFINE-SMT LLM Ablation Studies                   ║${NC}"
echo -e "${CYAN}║    A1/A2/A3  |  M1-M5  |  V6                        ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════╝${NC}"
echo -e "  Timestamp : ${YELLOW}${TIMESTAMP}${NC}"
echo -e "  Log dir   : ${YELLOW}${LOG_DIR}${NC}"
if [[ -n "$ONLY" ]]; then
    echo -e "  Mode      : ${YELLOW}--only ${ONLY}${NC}"
fi

# ── Model-tier ablations ──────────────────────────────────────────────────────
run_ablation "A1_generation_scaling" "$SCRIPT_DIR/run_ablation_A1.py"
run_ablation "A2_semantic_verifier"  "$SCRIPT_DIR/run_ablation_A2.py"
run_ablation "A3_repair_capability"  "$SCRIPT_DIR/run_ablation_A3.py"

# ── Module-level ablations ────────────────────────────────────────────────────
run_ablation "M1_beam_width"         "$SCRIPT_DIR/run_ablation_M1.py"
run_ablation "M2_oracle_variant"     "$SCRIPT_DIR/run_ablation_M2.py"
run_ablation "M3_llm_b_variant"      "$SCRIPT_DIR/run_ablation_M3.py"
run_ablation "M4_feedback_mode"      "$SCRIPT_DIR/run_ablation_M4.py"
run_ablation "M5_cegar_budget"       "$SCRIPT_DIR/run_ablation_M5.py"

# ── Model-family ablation ─────────────────────────────────────────────────────
run_ablation "V6_model_family"       "$SCRIPT_DIR/run_ablation_V6.py"

echo -e "\n${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║    All ablation studies complete.                    ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
echo -e "  Output : ${YELLOW}$ROOT/LLM_Output/ablation/${NC}"
echo -e "  Logs   : ${YELLOW}${LOG_DIR}/${NC}"
echo ""
echo -e "  Next step: run evaluation and generate tables"
echo -e "  ${CYAN}cd $SCRIPT_DIR/../evaluation${NC}"
echo -e "  ${CYAN}python evaluator.py --ablation-dir $ROOT/LLM_Output/ablation/${NC}"
echo -e "  ${CYAN}python generate_tables.py --benchmark ... --ablation ... --output $ROOT/LLM_Output/aggregate/${NC}"
