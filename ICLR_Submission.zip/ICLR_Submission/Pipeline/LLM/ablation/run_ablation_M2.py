#!/usr/bin/env python3
"""
Ablation M2 — Oracle Variant Study (paper §5.2.2)
Vary oracle scoring mode across 7 configurations including σD.

Goal: Determine contribution of each oracle component and whether the
      deontic-augmented oracle (σD) improves selection quality.

Usage:
    python run_ablation_M2.py [--acts DPDP,GDPR] [--sections N] [--dry-run]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from ablation._ablation_runner import run_module_ablation

STUDY = "M2_oracle_variant"


def main():
    p = argparse.ArgumentParser(description="Ablation M2: Oracle Variant")
    p.add_argument("--acts",     default=None, help="Comma-separated acts, e.g. DPDP,GDPR")
    p.add_argument("--sections", type=int, default=None, help="Limit sections per act")
    p.add_argument("--dry-run",  action="store_true")
    args = p.parse_args()

    acts = args.acts.split(",") if args.acts else None
    run_module_ablation(
        study=STUDY,
        acts=acts,
        section_limit=args.sections,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
