#!/usr/bin/env python3
"""
run_ablation_M2_targeted.py — Run a single variant/act of the M2 oracle variant study.

Use this when you need to run one oracle variant against one act without touching
the others. The full runner (run_ablation_M2.py) runs all 7 variants × 4 acts in
sequence; this script isolates a single combination so runs can be parallelised or
restarted after a crash.

Usage:
    python run_ablation_M2_targeted.py --variant exec_only --act GDPR
    python run_ablation_M2_targeted.py --variant sigma_d   --act CCPA
    python run_ablation_M2_targeted.py --variant full      --act DPDP --dry-run
    python run_ablation_M2_targeted.py --variant pass_all  --act GDPR --sections 3
    python run_ablation_M2_targeted.py --variant theta_0_5 --act PIPD --resume

Variants: pass_all  exec_only  no_proof_bonus  theta_0_5  theta_0_9  full  sigma_d
Acts:     GDPR  CCPA  DPDP  PIPD

Output:
    LLM_Output/ablation/M2_oracle_variant/{variant}/{act}/
        section_metrics.json (per section, inside *_Z3_Outputs/)
        aggregate_metrics.json
    LLM_Output/ablation/M2_oracle_variant/{variant}/{act}_aggregate_metrics.json
    LLM_Output/ablation/M2_oracle_variant/M2_oracle_variant_comparison_{ts}.json
"""
from __future__ import annotations

import argparse
import glob
import json
import logging
import os
import platform
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml
from tqdm import tqdm

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
_HERE = Path(__file__).parent.parent   # scripts/LLM/
sys.path.insert(0, str(_HERE))

from llm_config import SRC, ACTS_INPUT, ABLATION_OUT, IGNORE_FILES
from llm_pipeline import LLMRefineSMT

sys.path.insert(0, str(SRC))
from utility import Utility

logger = logging.getLogger("m2_targeted")

ABLATION_CFG = Path(__file__).parent / "ablation_configs.yaml"

STUDY     = "M2_oracle_variant"
STUDY_DIR = "M2_oracle_variant"   # LLM uses full study name as directory

M2_VARIANTS = {
    "pass_all", "exec_only", "no_proof_bonus",
    "theta_0_5", "theta_0_9", "full", "sigma_d",
}

M2_HP_KEYS = {"oracle_mode", "oracle_threshold"}


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def _load_cfg() -> tuple[dict, dict]:
    with open(ABLATION_CFG, encoding="utf-8") as f:
        all_cfg = yaml.safe_load(f)
    return all_cfg[STUDY], all_cfg


def _build_configs(variant: str, study_cfg: dict, all_cfg: dict) -> tuple[dict, dict, dict, dict]:
    """Return (llm_a, llm_b, llm_c, effective_hp) for an M2 variant."""
    hp      = dict(all_cfg["hyperparameters"])
    primary = all_cfg["primary"]

    variant_cfg = study_cfg["variants"][variant]
    hp.update({k: v for k, v in variant_cfg.items() if k in M2_HP_KEYS})

    llm_a = dict(primary["llm_a"])
    llm_b = dict(primary["llm_b"])
    llm_c = dict(primary["llm_c"])
    return llm_a, llm_b, llm_c, hp


# ---------------------------------------------------------------------------
# Resume helper
# ---------------------------------------------------------------------------

def _sanitize(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", name)[:200]


def _section_is_done(act_output: Path, stem: str) -> bool:
    """True if section_metrics.json already exists for this section."""
    safe    = _sanitize(stem)
    pattern = str(act_output / f"*_{safe}_Z3_Outputs" / "section_metrics.json")
    return bool(glob.glob(pattern))


# ---------------------------------------------------------------------------
# Section loader (mirrors _ablation_runner._load_section)
# ---------------------------------------------------------------------------

def _load_section(file_path: Path, utility: Utility) -> dict:
    try:
        with open(file_path, encoding="utf-8") as fh:
            full = json.load(fh)
    except Exception:
        full = {}
    section = utility.extract_json_robust(str(file_path))
    if section is None:
        section = {}
    for key in ("label_metrics", "structured_annotation", "source"):
        if key in full and key not in section:
            section[key] = full[key]
    return section


# ---------------------------------------------------------------------------
# Comparison JSON writer
# ---------------------------------------------------------------------------

def _write_ablation_comparison(ts: str) -> None:
    """Regenerate M2_oracle_variant_comparison_{ts}.json from all on-disk aggregate files."""
    study_dir = ABLATION_OUT / STUDY_DIR
    if not study_dir.exists():
        return
    comparison: dict[str, list] = {}
    for variant_dir in sorted(study_dir.iterdir()):
        if not variant_dir.is_dir():
            continue
        variant = variant_dir.name
        comparison[variant] = []
        for agg_file in sorted(variant_dir.glob("*_aggregate_metrics.json")):
            act = agg_file.stem.replace("_aggregate_metrics", "")
            try:
                with open(agg_file) as f:
                    data = json.load(f)
                comparison[variant].append({
                    "act":                     act,
                    "success_rate":            data.get("success_rate"),
                    "semantic_alignment_rate": data.get("semantic_alignment_rate"),
                    "mean_llm_c_iterations":   data.get("mean_llm_c_iterations"),
                    "mean_wall_time_sec":       data.get("mean_wall_time_sec"),
                })
            except Exception:
                pass
    if comparison:
        out = study_dir / f"{STUDY}_comparison_{ts}.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(comparison, f, indent=2)
        logger.info("Comparison JSON written: %s", out)


# ---------------------------------------------------------------------------
# Core runner
# ---------------------------------------------------------------------------

def run_targeted(
    variant: str,
    act: str,
    resume: bool = False,
    dry_run: bool = False,
    section_limit: int | None = None,
) -> None:
    if variant not in M2_VARIANTS:
        raise ValueError(
            f"Unknown variant '{variant}'. Valid: {sorted(M2_VARIANTS)}"
        )

    act_input = ACTS_INPUT.get(act)
    if not act_input or not act_input.exists():
        raise ValueError(
            f"Act '{act}' not found or directory missing: {act_input}"
        )

    study_cfg, all_cfg = _load_cfg()
    llm_a, llm_b, llm_c, hp = _build_configs(variant, study_cfg, all_cfg)

    run_dir    = ABLATION_OUT / STUDY_DIR / variant
    act_output = run_dir / act
    act_output.mkdir(parents=True, exist_ok=True)

    fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    logging.basicConfig(level=logging.INFO, format=fmt)
    fh = logging.FileHandler(run_dir / "run.log", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(fmt))
    logging.getLogger().addHandler(fh)

    ts     = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = f"LLM-{STUDY}-{variant}-{ts}"

    logger.info("=== M2 targeted | variant=%s | act=%s | oracle_mode=%s | threshold=%.2f",
                variant, act,
                hp.get("oracle_mode", "full"),
                hp.get("oracle_threshold", 0.7))
    logger.info("    LLM-A=%s  LLM-B=%s  LLM-C=%s",
                llm_a["model"], llm_b["model"], llm_c["model"])

    all_files = sorted(
        f for f in os.listdir(act_input)
        if f.endswith(".json") and f not in IGNORE_FILES
    )
    if section_limit:
        all_files = all_files[:section_limit]

    if resume:
        files = [f for f in all_files
                 if not _section_is_done(act_output, f.replace(".json", ""))]
        logger.info("  Resume mode: %d/%d sections remaining",
                    len(files), len(all_files))
    else:
        files = all_files
        logger.info("  Fresh run: %d sections", len(files))

    if not files:
        print(f"  All sections already done for {STUDY_DIR}/{variant}/{act}. Nothing to run.")
        return

    if dry_run:
        print(f"  [DRY-RUN] {STUDY_DIR}/{variant}/{act} — would process {len(files)} sections:")
        for fn in files:
            done = _section_is_done(act_output, fn.replace(".json", ""))
            print(f"    {'[SKIP]' if done else '[RUN ]'} {fn}")
        return

    oracle_mode = hp.get("oracle_mode", "full")
    oracle_thr  = hp.get("oracle_threshold", 0.7)

    pipeline = LLMRefineSMT(
        output_path=str(act_output),
        model_owner=llm_a["owner"],
        model=llm_a["model"],
        agnostic_model_owner=llm_b["owner"],
        agnostic_model=llm_b["model"],
        corrector_owner=llm_c["owner"],
        corrector_model=llm_c["model"],
        max_outer_attempts=hp.get("max_outer", 5),
        max_cegar_iterations=hp.get("max_cegar", 5),
        beam_width=hp.get("beam_width", 3),
        oracle_pass_threshold=oracle_thr,
        experiment=STUDY,
        variant=variant,
        act_name=act,
        run_id=run_id,
        llm_a_temperature=llm_a.get("temperature", 0.7),
        llm_b_temperature=llm_b.get("temperature", 0.0),
        llm_c_temperature=llm_c.get("temperature", 0.0),
        oracle_mode=oracle_mode,
        llm_b_skip=False,
        llm_b_format="structured",
        feedback_mode="full_ce",
    )

    utility = Utility()

    with tqdm(total=len(files), desc=f"{variant}/{act}") as pbar:
        for filename in files:
            pbar.set_postfix_str(filename)
            try:
                section = _load_section(act_input / filename, utility)
                pipeline.process_act(section, filename.replace(".json", ""))
            except Exception:
                logger.exception("Failed: %s/%s/%s", variant, act, filename)
            pbar.update(1)

    pipeline.save_aggregate_metrics(log=True)

    agg_src = act_output / "aggregate_metrics.json"
    agg_dst = run_dir / f"{act}_aggregate_metrics.json"
    if agg_src.exists():
        shutil.copy(agg_src, agg_dst)
        with open(agg_src) as f:
            agg = json.load(f)
        logger.info("  Aggregate %s/%s/%s: SR=%.4f  SA=%.4f  n=%d",
                    STUDY_DIR, variant, act,
                    agg.get("success_rate", 0),
                    agg.get("semantic_alignment_rate", 0),
                    agg.get("acts_processed", 0))

    _write_ablation_comparison(ts)
    logger.info("Done: %s/%s/%s", STUDY_DIR, variant, act)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(
        description="Run a single M2 oracle variant against a single act.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Variants:  pass_all  exec_only  no_proof_bonus  theta_0_5  theta_0_9  full  sigma_d
Acts:      GDPR  CCPA  DPDP  PIPD

Examples:
  python run_ablation_M2_targeted.py --variant exec_only --act GDPR
  python run_ablation_M2_targeted.py --variant sigma_d   --act CCPA
  python run_ablation_M2_targeted.py --variant full      --act DPDP --dry-run
  python run_ablation_M2_targeted.py --variant pass_all  --act GDPR --sections 3
  python run_ablation_M2_targeted.py --variant theta_0_5 --act PIPD --resume
""",
    )
    p.add_argument("--variant",  required=True,
                   help="Oracle variant name (one of the 7 M2 variants)")
    p.add_argument("--act",      required=True,
                   help="Act to run: GDPR | CCPA | DPDP | PIPD")
    p.add_argument("--resume",   action="store_true",
                   help="Skip sections that already have section_metrics.json output")
    p.add_argument("--dry-run",  action="store_true",
                   help="Print what would be processed without actually running")
    p.add_argument("--sections", type=int, default=None,
                   help="Limit to the first N sections (useful for smoke tests)")
    args = p.parse_args()

    run_targeted(
        variant=args.variant,
        act=args.act,
        resume=args.resume,
        dry_run=args.dry_run,
        section_limit=args.sections,
    )


if __name__ == "__main__":
    main()
