#!/usr/bin/env python3
"""
Ablation A3 — Repair Capability
Vary LLM-C (Weak/Medium/Strong); fix LLM-A=Qwen2.5-Coder-32B, LLM-B=Phi-4.

Goal: Determine minimum symbolic debugging capability for effective CEGAR convergence.

Usage:
    python run_ablation_A3.py [--acts DPDP,GDPR] [--sections N] [--dry-run]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from ablation._ablation_runner import run_ablation

STUDY = "A3_repair_capability"


def build_model_config(variant_name, variant_model_cfg, study_cfg, all_cfg):
    llm_a = study_cfg["fixed_a"]
    llm_b = study_cfg["fixed_b"]
    llm_c = {"owner": variant_model_cfg["owner"], "model": variant_model_cfg["model"]}
    return llm_a, llm_b, llm_c


def main():
    p = argparse.ArgumentParser(description="Ablation A3: Repair Capability")
    p.add_argument("--acts",     default=None, help="Comma-separated acts, e.g. DPDP,GDPR")
    p.add_argument("--sections", type=int, default=None, help="Limit sections per act")
    p.add_argument("--dry-run",  action="store_true")
    args = p.parse_args()

    acts = args.acts.split(",") if args.acts else None
    run_ablation(
        study=STUDY,
        build_model_config=build_model_config,
        acts=acts,
        section_limit=args.sections,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
