"""
Shared runner logic for all ablation studies (A1-A3, M1-M5, V6).

Public API
----------
run_ablation(study, build_model_config, ...)
    Used by A1/A2/A3 and V6 — caller provides a function that builds
    (llm_a, llm_b, llm_c) config dicts for each variant.

run_module_ablation(study, ...)
    Used by M1-M5 — the runner reads module-level knobs from the config
    (beam_width, oracle_mode, llm_b_skip, feedback_mode, max_cegar) and
    applies them to LLMRefineSMT without changing the primary LLMs.
"""
from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from tqdm import tqdm

_HERE = Path(__file__).parent.parent
sys.path.insert(0, str(_HERE))

from llm_config import SRC, ACTS_INPUT, ABLATION_OUT, IGNORE_FILES
from llm_pipeline import LLMRefineSMT

sys.path.insert(0, str(SRC))
from utility import Utility

logger = logging.getLogger("ablation")

ABLATION_CFG = Path(__file__).parent / "ablation_configs.yaml"


# ---------------------------------------------------------------------------
# Config loading
# ---------------------------------------------------------------------------

def _load_section(file_path: Path, utility: Any) -> dict:
    try:
        with open(file_path, encoding="utf-8") as fh:
            full = json.load(fh)
    except Exception:
        full = {}
    section = utility.extract_json_robust(str(file_path))
    if section is None:
        section = {}
    for key in ("label_metrics", "structured_annotation", "source"):
        if key in full and key not in section:
            section[key] = full[key]
    return section


def _setup_logging(run_dir: Path) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    logging.basicConfig(level=logging.INFO, format=fmt)
    fh = logging.FileHandler(run_dir / "run.log", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(fmt))
    logging.getLogger().addHandler(fh)


def load_ablation_cfg(study: str) -> tuple[dict, dict]:
    with open(ABLATION_CFG, encoding="utf-8") as f:
        all_cfg = yaml.safe_load(f)
    return all_cfg[study], all_cfg


# ---------------------------------------------------------------------------
# Model-tier ablation runner  (A1 / A2 / A3 / V6)
# ---------------------------------------------------------------------------

def run_ablation(
    study: str,
    build_model_config,
    acts: list[str] | None = None,
    section_limit: int | None = None,
    dry_run: bool = False,
) -> None:
    """
    Run a model-tier or model-family ablation study.

    build_model_config(variant_name, variant_model_cfg, study_cfg, all_cfg)
        must return (llm_a_dict, llm_b_dict, llm_c_dict).
    """
    study_cfg, all_cfg = load_ablation_cfg(study)
    hp      = all_cfg["hyperparameters"]
    acts    = acts or all_cfg.get("acts", list(ACTS_INPUT.keys()))
    variants = study_cfg["variants"]
    utility  = Utility()

    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    for variant_name, variant_model_cfg in variants.items():
        llm_a, llm_b, llm_c = build_model_config(
            variant_name, variant_model_cfg, study_cfg, all_cfg
        )
        run_id  = f"LLM-{study}-{variant_name}-{ts}"
        run_dir = ABLATION_OUT / study / variant_name

        _setup_logging(run_dir)
        logger.info("=== Ablation %s | variant=%s | run_id=%s", study, variant_name, run_id)

        _write_run_config(
            run_id=run_id, run_dir=run_dir, study=study, variant=variant_name,
            acts=acts, llm_a=llm_a, llm_b=llm_b, llm_c=llm_c, hp=hp,
        )

        per_variant_results: list[dict] = []

        for act in acts:
            results = _run_act(
                act=act,
                run_dir=run_dir,
                run_id=run_id,
                study=study,
                variant_name=variant_name,
                utility=utility,
                llm_a=llm_a,
                llm_b=llm_b,
                llm_c=llm_c,
                hp=hp,
                section_limit=section_limit,
                dry_run=dry_run,
            )
            if results is not None:
                per_variant_results.append(results)

        if per_variant_results and not dry_run:
            summary_path = run_dir / f"{study}_{variant_name}_summary.json"
            with open(summary_path, "w", encoding="utf-8") as f:
                json.dump(per_variant_results, f, indent=2)
            logger.info("Variant summary: %s", summary_path)

    logger.info("Ablation %s complete.", study)
    _write_ablation_comparison(study, ts)


# ---------------------------------------------------------------------------
# Module ablation runner  (M1 / M2 / M3 / M4 / M5)
# ---------------------------------------------------------------------------

def run_module_ablation(
    study: str,
    acts: list[str] | None = None,
    section_limit: int | None = None,
    dry_run: bool = False,
) -> None:
    """
    Run a module-level ablation study where the primary LLMs are fixed
    and pipeline hyperparameters / modes change per variant.
    """
    study_cfg, all_cfg = load_ablation_cfg(study)
    hp      = all_cfg["hyperparameters"]
    primary = all_cfg["primary"]
    acts    = acts or all_cfg.get("acts", list(ACTS_INPUT.keys()))
    variants = study_cfg["variants"]
    utility  = Utility()

    # Primary model dicts (shared across all module variants)
    llm_a_base = primary["llm_a"]
    llm_b_base = primary["llm_b"]
    llm_c_base = primary["llm_c"]

    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    for variant_name, variant_cfg in variants.items():
        # Merge module overrides on top of primary hyperparameters
        effective_hp = dict(hp)
        effective_hp.update({k: v for k, v in variant_cfg.items() if k in (
            "beam_width", "max_cegar", "oracle_threshold",
            "oracle_mode", "llm_b_skip", "llm_b_format",
            "llm_b_same_as_a", "feedback_mode",
        )})

        # For M3 same_as_a: substitute LLM-B with LLM-A model
        llm_b = dict(llm_b_base)
        if effective_hp.get("llm_b_same_as_a"):
            llm_b = dict(llm_a_base)
            llm_b["temperature"] = 0.0  # LLM-B always deterministic

        llm_a = dict(llm_a_base)
        llm_c = dict(llm_c_base)

        run_id  = f"LLM-{study}-{variant_name}-{ts}"
        run_dir = ABLATION_OUT / study / variant_name

        _setup_logging(run_dir)
        logger.info("=== Module ablation %s | variant=%s | run_id=%s",
                    study, variant_name, run_id)

        _write_run_config(
            run_id=run_id, run_dir=run_dir, study=study, variant=variant_name,
            acts=acts, llm_a=llm_a, llm_b=llm_b, llm_c=llm_c, hp=effective_hp,
            extra={"module_variant": variant_cfg},
        )

        per_variant_results: list[dict] = []

        for act in acts:
            results = _run_act(
                act=act,
                run_dir=run_dir,
                run_id=run_id,
                study=study,
                variant_name=variant_name,
                utility=utility,
                llm_a=llm_a,
                llm_b=llm_b,
                llm_c=llm_c,
                hp=effective_hp,
                section_limit=section_limit,
                dry_run=dry_run,
                module_cfg=variant_cfg,
            )
            if results is not None:
                per_variant_results.append(results)

        if per_variant_results and not dry_run:
            summary_path = run_dir / f"{study}_{variant_name}_summary.json"
            with open(summary_path, "w", encoding="utf-8") as f:
                json.dump(per_variant_results, f, indent=2)
            logger.info("Variant summary: %s", summary_path)

    logger.info("Module ablation %s complete.", study)
    _write_ablation_comparison(study, ts)


# ---------------------------------------------------------------------------
# Shared per-act runner
# ---------------------------------------------------------------------------

def _run_act(
    act: str,
    run_dir: Path,
    run_id: str,
    study: str,
    variant_name: str,
    utility: Any,
    llm_a: dict,
    llm_b: dict,
    llm_c: dict,
    hp: dict,
    section_limit: int | None,
    dry_run: bool,
    module_cfg: dict | None = None,
) -> dict | None:
    act_input = ACTS_INPUT.get(act)
    if not act_input or not act_input.exists():
        logger.error("Act input not found: %s", act_input)
        return None

    act_output = run_dir / act
    act_output.mkdir(parents=True, exist_ok=True)

    files = sorted(
        f for f in os.listdir(act_input)
        if f.endswith(".json") and f not in IGNORE_FILES
    )
    if section_limit:
        files = files[:section_limit]

    logger.info(
        "  [%s] %s sections | LLM-A=%s LLM-B=%s LLM-C=%s",
        act, len(files), llm_a["model"], llm_b["model"], llm_c["model"],
    )

    llm_a_temp   = llm_a.get("temperature", 0.7)
    llm_b_temp   = llm_b.get("temperature", 0.0)
    llm_c_temp   = llm_c.get("temperature", 0.0)

    # Module-level overrides
    oracle_mode  = (module_cfg or {}).get("oracle_mode", "full")
    llm_b_skip   = (module_cfg or {}).get("llm_b_skip", False)
    llm_b_format = (module_cfg or {}).get("llm_b_format", "structured")
    feedback_mode = (module_cfg or {}).get("feedback_mode", "full_ce")

    pipeline = LLMRefineSMT(
        output_path=str(act_output),
        model_owner=llm_a["owner"],
        model=llm_a["model"],
        agnostic_model_owner=(llm_b["owner"] if not llm_b_skip else "skip"),
        agnostic_model=(llm_b["model"] if not llm_b_skip else "skip"),
        corrector_owner=llm_c["owner"],
        corrector_model=llm_c["model"],
        max_outer_attempts=hp.get("max_outer", 5),
        max_cegar_iterations=hp.get("max_cegar", 5),
        beam_width=hp.get("beam_width", 3),
        oracle_pass_threshold=hp.get("oracle_threshold", 0.7),
        experiment=study,
        variant=variant_name,
        act_name=act,
        run_id=run_id,
        # Per-role generation params
        llm_a_temperature=llm_a_temp,
        llm_b_temperature=llm_b_temp,
        llm_c_temperature=llm_c_temp,
        # Module-level flags
        oracle_mode=oracle_mode,
        llm_b_skip=llm_b_skip,
        llm_b_format=llm_b_format,
        feedback_mode=feedback_mode,
    )

    with tqdm(total=len(files), desc=f"{variant_name}/{act}") as pbar:
        for filename in files:
            pbar.set_postfix_str(filename)
            if dry_run:
                logger.info("[DRY-RUN] %s/%s/%s", variant_name, act, filename)
                pbar.update(1)
                continue
            try:
                section = _load_section(act_input / filename, utility)
                pipeline.process_act(section, filename.replace(".json", ""))
            except Exception:
                logger.exception("Failed: %s/%s", act, filename)
            pbar.update(1)

    if dry_run:
        return None

    pipeline.save_aggregate_metrics(log=True)
    agg_src = act_output / "aggregate_metrics.json"
    agg_dst = run_dir / f"{act}_aggregate_metrics.json"
    if agg_src.exists():
        shutil.copy(agg_src, agg_dst)
        with open(agg_src) as f:
            return {"act": act, "variant": variant_name, "metrics": json.load(f)}
    return None


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def _write_run_config(
    run_id, run_dir, study, variant, acts, llm_a, llm_b, llm_c, hp, extra=None
) -> None:
    try:
        import transformers
        tf_ver = transformers.__version__
    except ImportError:
        tf_ver = "N/A"

    run_dir.mkdir(parents=True, exist_ok=True)
    config: dict = {
        "run_id":        run_id,
        "experiment":    study,
        "variant":       variant,
        "timestamp":     datetime.now(timezone.utc).isoformat(),
        "acts":          acts,
        "models":        {"llm_a": llm_a, "llm_b": llm_b, "llm_c": llm_c},
        "hyperparameters": hp,
        "generation_params": {
            "llm_a_temperature": llm_a.get("temperature", 0.7),
            "llm_b_temperature": llm_b.get("temperature", 0.0),
            "llm_c_temperature": llm_c.get("temperature", 0.0),
        },
        "hardware":      platform.node(),
        "python_version": platform.python_version(),
        "transformers_version": tf_ver,
    }
    if extra:
        config.update(extra)
    with open(run_dir / "run_config.json", "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


def _write_ablation_comparison(study: str, ts: str) -> None:
    """Collect all variant summaries and write a single cross-variant comparison JSON."""
    study_dir = ABLATION_OUT / study
    if not study_dir.exists():
        return
    comparison: dict[str, list] = {}
    for variant_dir in sorted(study_dir.iterdir()):
        if not variant_dir.is_dir():
            continue
        variant = variant_dir.name
        comparison[variant] = []
        for agg_file in sorted(variant_dir.glob("*_aggregate_metrics.json")):
            act = agg_file.stem.replace("_aggregate_metrics", "")
            try:
                with open(agg_file) as f:
                    data = json.load(f)
                comparison[variant].append({
                    "act":                     act,
                    "success_rate":            data.get("success_rate"),
                    "semantic_alignment_rate": data.get("semantic_alignment_rate"),
                    "mean_llm_c_iterations":   data.get("mean_llm_c_iterations"),
                    "mean_wall_time_sec":       data.get("mean_wall_time_sec"),
                })
            except Exception:
                pass

    if comparison:
        out = ABLATION_OUT / study / f"{study}_comparison_{ts}.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(comparison, f, indent=2)
        logger.info("Ablation comparison written: %s", out)
