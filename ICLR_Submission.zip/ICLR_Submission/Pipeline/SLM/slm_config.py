from pathlib import Path

# ICLR supplementary: repointed from the original tree's UML_Annotations/ (external, absolute-parents-based --
# only portable at the exact original nesting depth) to this bundle's own Benchmark/dataset/ (relative to this
# file, self-contained -- no dependency on anything outside ICLR_Submission/). Verified byte-identical content
# to UML_Annotations/{ACT}_Act/ at the time this bundle was assembled (diff -q found zero differences across
# all 4 acts) -- see PAPER_CODE_CORRESPONDENCE.md. Layout: ICLR_Submission/Pipeline/SLM/slm_config.py
#   → parent   = SLM/
#   → parent×2 = Pipeline/
#   → parent×3 = <BUNDLE_ROOT>   (ICLR_Submission/)
ROOT = Path(__file__).resolve().parents[2]
SRC  = Path(__file__).parent / "lib"

# Per-section JSON input dirs (UML-annotated, one file per section)
ACTS_INPUT: dict[str, Path] = {
    "DPDP": ROOT / "Benchmark/dataset/DPDP_Act",
    "GDPR": ROOT / "Benchmark/dataset/GDPR_Act",
    "CCPA": ROOT / "Benchmark/dataset/CCPA_Act",
    "PIPD": ROOT / "Benchmark/dataset/PIPD_Act",
}

SLM_OUTPUT   = ROOT / "SLM_Output"
NORMAL_OUT   = SLM_OUTPUT / "normal"
ABLATION_OUT = SLM_OUTPUT / "ablation"
AGGREGATE_OUT = SLM_OUTPUT / "aggregate"

SCRIPTS_SLM = Path(__file__).parent

IGNORE_FILES = {".DS_Store", "sections", "aggregate_metric.json",
                "aggregate_metrics.json", "metrics_extract.log", "run.log"}
