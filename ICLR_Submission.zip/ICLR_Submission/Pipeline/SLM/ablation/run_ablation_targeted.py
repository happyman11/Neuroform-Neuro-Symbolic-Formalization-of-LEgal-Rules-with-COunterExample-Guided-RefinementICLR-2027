#!/usr/bin/env python3
"""
run_ablation_targeted.py — Run a single variant/act of any ablation study.

Supports both module-type studies (M1-M5) and model-type studies (A1-A3).
Use --resume to skip sections that already have section_metrics.json output.

Usage:
    python run_ablation_targeted.py --study M4 --variant class_hint_no_z3 --act GDPR
    python run_ablation_targeted.py --study A3 --variant strong --act PIPD --resume
    python run_ablation_targeted.py --study M3 --variant same_as_a --act DPDP --resume
    python run_ablation_targeted.py --study M4 --variant full_ce --act GDPR --resume
    python run_ablation_targeted.py --study M4 --variant class_hint_no_z3 --act GDPR --dry-run
"""
from __future__ import annotations

import argparse
import glob
import json
import logging
import os
import platform
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml
from tqdm import tqdm

# ---------------------------------------------------------------------------
# Paths — same as _ablation_runner.py
# ---------------------------------------------------------------------------
_HERE = Path(__file__).parent.parent  # scripts/SLM/
sys.path.insert(0, str(_HERE))

from slm_config import SRC, ACTS_INPUT, ABLATION_OUT, IGNORE_FILES
from slm_pipeline import SLMRefineSMT

sys.path.insert(0, str(SRC))
from utility import Utility

logger = logging.getLogger("targeted_runner")

ABLATION_CFG = Path(__file__).parent / "ablation_configs.yaml"

# Short name → full YAML key (for loading ablation_configs.yaml)
STUDY_MAP: dict[str, str] = {
    "M1": "M1_beam_width",      "M1_beam_width":      "M1_beam_width",
    "M2": "M2_oracle_variant",  "M2_oracle_variant":  "M2_oracle_variant",
    "M3": "M3_llm_b_variant",   "M3_llm_b_variant":   "M3_llm_b_variant",
    "M4": "M4_feedback_mode",   "M4_feedback_mode":   "M4_feedback_mode",
    "M5": "M5_cegar_budget",    "M5_cegar_budget":    "M5_cegar_budget",
    "A1": "A1_generation_scaling", "A1_generation_scaling": "A1_generation_scaling",
    "A2": "A2_semantic_verifier",  "A2_semantic_verifier":  "A2_semantic_verifier",
    "A3": "A3_repair_capability",  "A3_repair_capability":  "A3_repair_capability",
}

# Short name → actual output directory name under ABLATION_OUT
# M-type studies use the short name (M3, M4…); A-type use the full name.
STUDY_DIR_MAP: dict[str, str] = {
    "M1": "M1", "M1_beam_width":      "M1",
    "M2": "M2", "M2_oracle_variant":  "M2",
    "M3": "M3", "M3_llm_b_variant":   "M3",
    "M4": "M4", "M4_feedback_mode":   "M4",
    "M5": "M5", "M5_cegar_budget":    "M5",
    "A1": "A1_generation_scaling", "A1_generation_scaling": "A1_generation_scaling",
    "A2": "A2_semantic_verifier",  "A2_semantic_verifier":  "A2_semantic_verifier",
    "A3": "A3_repair_capability",  "A3_repair_capability":  "A3_repair_capability",
}

MODULE_STUDIES = {"M1_beam_width", "M2_oracle_variant", "M3_llm_b_variant",
                  "M4_feedback_mode", "M5_cegar_budget"}

# Hyperparameter keys that module variant configs can override
MODULE_HP_KEYS = {"beam_width", "max_cegar", "oracle_threshold", "oracle_mode",
                  "llm_b_skip", "llm_b_format", "llm_b_same_as_a", "feedback_mode"}


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def _sanitize(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", name)[:200]


def _load_cfg(study_key: str) -> tuple[dict, dict]:
    with open(ABLATION_CFG, encoding="utf-8") as f:
        all_cfg = yaml.safe_load(f)
    return all_cfg[study_key], all_cfg


def _build_model_configs(study_key: str, variant_name: str,
                         study_cfg: dict, all_cfg: dict) -> tuple[dict, dict, dict, dict]:
    """Return (llm_a, llm_b, llm_c, effective_hp)."""
    hp = dict(all_cfg["hyperparameters"])
    primary = all_cfg.get("primary", {})

    if study_key in MODULE_STUDIES:
        variant_cfg = study_cfg["variants"][variant_name]
        hp.update({k: v for k, v in variant_cfg.items() if k in MODULE_HP_KEYS})

        llm_a = dict(primary["llm_a"])
        llm_b = dict(primary["llm_b"])
        llm_c = dict(primary["llm_c"])

        # M3 same_as_a: replace LLM-B with LLM-A (but keep temp=0.0 for B)
        if hp.get("llm_b_same_as_a"):
            llm_b = dict(llm_a)
            llm_b["temperature"] = 0.0

        return llm_a, llm_b, llm_c, hp

    # Model-tier studies (A1/A2/A3)
    variant_model_cfg = study_cfg["variants"][variant_name]

    if study_key == "A1_generation_scaling":
        llm_a = {"owner": variant_model_cfg["owner"], "model": variant_model_cfg["model"],
                 "temperature": variant_model_cfg.get("temperature", 0.7)}
        llm_b = dict(study_cfg["fixed_b"])
        llm_c = dict(study_cfg["fixed_c"])
    elif study_key == "A2_semantic_verifier":
        llm_a = dict(study_cfg["fixed_a"])
        llm_b = {"owner": variant_model_cfg["owner"], "model": variant_model_cfg["model"],
                 "temperature": variant_model_cfg.get("temperature", 0.0)}
        llm_c = dict(study_cfg["fixed_c"])
    elif study_key == "A3_repair_capability":
        llm_a = dict(study_cfg["fixed_a"])
        llm_b = dict(study_cfg["fixed_b"])
        llm_c = {"owner": variant_model_cfg["owner"], "model": variant_model_cfg["model"],
                 "temperature": variant_model_cfg.get("temperature", 0.0)}
    else:
        raise ValueError(f"Unknown model-tier study: {study_key}")

    return llm_a, llm_b, llm_c, hp


# ---------------------------------------------------------------------------
# Skip/resume logic
# ---------------------------------------------------------------------------

def _section_is_done(act_output: Path, filename_stem: str) -> bool:
    """True if section_metrics.json already exists for this section."""
    safe = _sanitize(filename_stem)
    pattern = str(act_output / f"*_{safe}_Z3_Outputs" / "section_metrics.json")
    return bool(glob.glob(pattern))


# ---------------------------------------------------------------------------
# Core runner
# ---------------------------------------------------------------------------

def run_targeted(
    study: str,
    variant: str,
    act: str,
    resume: bool = False,
    dry_run: bool = False,
) -> None:
    study_key = STUDY_MAP.get(study)
    if not study_key:
        raise ValueError(f"Unknown study '{study}'. Valid: {sorted(STUDY_MAP)}")

    study_dir_name = STUDY_DIR_MAP[study_key]  # actual directory under ABLATION_OUT

    study_cfg, all_cfg = _load_cfg(study_key)

    if variant not in study_cfg["variants"]:
        available = sorted(study_cfg["variants"].keys())
        raise ValueError(f"Unknown variant '{variant}' for {study_key}. Available: {available}")

    act_input = ACTS_INPUT.get(act)
    if not act_input or not act_input.exists():
        raise ValueError(f"Act '{act}' not found in ACTS_INPUT or directory missing: {act_input}")

    llm_a, llm_b, llm_c, hp = _build_model_configs(study_key, variant, study_cfg, all_cfg)

    run_dir = ABLATION_OUT / study_dir_name / variant
    act_output = run_dir / act
    act_output.mkdir(parents=True, exist_ok=True)

    # Logging
    fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    logging.basicConfig(level=logging.INFO, format=fmt)
    fh = logging.FileHandler(run_dir / "run.log", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(fmt))
    logging.getLogger().addHandler(fh)

    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = f"SLM-{study_key}-{variant}-{ts}"
    logger.info("=== Targeted run | study=%s | variant=%s | act=%s | resume=%s",
                study_key, variant, act, resume)
    logger.info("    LLM-A=%s  LLM-B=%s  LLM-C=%s",
                llm_a["model"], llm_b["model"], llm_c["model"])

    # Collect section files
    all_files = sorted(
        f for f in os.listdir(act_input)
        if f.endswith(".json") and f not in IGNORE_FILES
    )

    if resume:
        files = [f for f in all_files
                 if not _section_is_done(act_output, f.replace(".json", ""))]
        logger.info("  Resume mode: %d/%d sections remaining",
                    len(files), len(all_files))
    else:
        files = all_files
        logger.info("  Full run: %d sections", len(files))

    if not files:
        print(f"  All sections already done for {study_key}/{variant}/{act}. Nothing to run.")
        return

    if dry_run:
        print(f"  [DRY-RUN] Would process {len(files)} sections:")
        for f in files:
            done = _section_is_done(act_output, f.replace(".json", ""))
            print(f"    {'[SKIP]' if done else '[RUN ]'} {f}")
        return

    # Module-level flags from hp
    oracle_mode   = hp.get("oracle_mode", "full")
    llm_b_skip    = hp.get("llm_b_skip", False)
    llm_b_format  = hp.get("llm_b_format", "structured")
    feedback_mode = hp.get("feedback_mode", "full_ce")

    pipeline = SLMRefineSMT(
        output_path=str(act_output),
        model_owner=llm_a["owner"],
        model=llm_a["model"],
        agnostic_model_owner=(llm_b["owner"] if not llm_b_skip else "skip"),
        agnostic_model=(llm_b["model"] if not llm_b_skip else "skip"),
        corrector_owner=llm_c["owner"],
        corrector_model=llm_c["model"],
        max_outer_attempts=hp.get("max_outer", 5),
        max_cegar_iterations=hp.get("max_cegar", 5),
        beam_width=hp.get("beam_width", 3),
        oracle_pass_threshold=hp.get("oracle_threshold", 0.7),
        experiment=study_key,
        variant=variant,
        act_name=act,
        run_id=run_id,
        llm_a_temperature=llm_a.get("temperature", 0.7),
        llm_b_temperature=llm_b.get("temperature", 0.0),
        llm_c_temperature=llm_c.get("temperature", 0.0),
        oracle_mode=oracle_mode,
        llm_b_skip=llm_b_skip,
        llm_b_format=llm_b_format,
        feedback_mode=feedback_mode,
    )

    utility = Utility()

    with tqdm(total=len(files), desc=f"{variant}/{act}") as pbar:
        for filename in files:
            pbar.set_postfix_str(filename)
            try:
                section = _load_section(act_input / filename, utility)
                pipeline.process_act(section, filename.replace(".json", ""))
            except Exception:
                logger.exception("Failed: %s/%s/%s", variant, act, filename)
            pbar.update(1)

    # Save aggregate metrics for this act
    pipeline.save_aggregate_metrics(log=True)
    agg_src = act_output / "aggregate_metrics.json"
    agg_dst = run_dir / f"{act}_aggregate_metrics.json"
    if agg_src.exists():
        shutil.copy(agg_src, agg_dst)
        with open(agg_src) as f:
            agg = json.load(f)
        logger.info("  Aggregate %s/%s/%s: SR=%.4f  SA=%.4f  n=%d",
                    study_key, variant, act,
                    agg.get("success_rate", 0),
                    agg.get("semantic_alignment_rate", 0),
                    agg.get("acts_processed", 0))

    # Regenerate the cross-variant comparison JSON for this study
    _write_ablation_comparison(study_key, study_dir_name, ts)
    logger.info("Done: %s/%s/%s", study_dir_name, variant, act)


def _load_section(file_path: Path, utility: Utility) -> dict:
    try:
        with open(file_path, encoding="utf-8") as fh:
            full = json.load(fh)
    except Exception:
        full = {}
    section = utility.extract_json_robust(str(file_path))
    if section is None:
        section = {}
    for key in ("label_metrics", "structured_annotation", "source"):
        if key in full and key not in section:
            section[key] = full[key]
    return section


def _write_ablation_comparison(study_key: str, study_dir_name: str, ts: str) -> None:
    study_dir = ABLATION_OUT / study_dir_name
    if not study_dir.exists():
        return
    comparison: dict[str, list] = {}
    for variant_dir in sorted(study_dir.iterdir()):
        if not variant_dir.is_dir():
            continue
        variant = variant_dir.name
        comparison[variant] = []
        for agg_file in sorted(variant_dir.glob("*_aggregate_metrics.json")):
            act = agg_file.stem.replace("_aggregate_metrics", "")
            try:
                with open(agg_file) as f:
                    data = json.load(f)
                comparison[variant].append({
                    "act":                     act,
                    "success_rate":            data.get("success_rate"),
                    "semantic_alignment_rate": data.get("semantic_alignment_rate"),
                    "mean_llm_c_iterations":   data.get("mean_llm_c_iterations"),
                    "mean_wall_time_sec":       data.get("mean_wall_time_sec"),
                })
            except Exception:
                pass
    if comparison:
        out = ABLATION_OUT / study_dir_name / f"{study_key}_comparison_{ts}.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(comparison, f, indent=2)
        logger.info("Comparison JSON written: %s", out)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(
        description="Run a single variant/act of an ablation study.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # M4 class_hint_no_z3 — fresh full GDPR run (never ran before)
  python run_ablation_targeted.py --study M4 --variant class_hint_no_z3 --act GDPR

  # M4 full_ce — resume GDPR from where it crashed (32/99 done)
  python run_ablation_targeted.py --study M4 --variant full_ce --act GDPR --resume

  # A3 strong — resume PIPD from section 29 (28/50 done)
  python run_ablation_targeted.py --study A3 --variant strong --act PIPD --resume

  # M3 same_as_a — resume DPDP (41/44 done, 3 sections missing)
  python run_ablation_targeted.py --study M3 --variant same_as_a --act DPDP --resume

  # Dry-run: see what would be processed without running
  python run_ablation_targeted.py --study M4 --variant class_hint_no_z3 --act GDPR --dry-run
""",
    )
    p.add_argument("--study",   required=True, help="Study ID: M3, M4, A3, M3_llm_b_variant, etc.")
    p.add_argument("--variant", required=True, help="Variant name from ablation_configs.yaml")
    p.add_argument("--act",     required=True, help="Act: GDPR, CCPA, DPDP, PIPD")
    p.add_argument("--resume",  action="store_true",
                   help="Skip sections that already have section_metrics.json output")
    p.add_argument("--dry-run", action="store_true",
                   help="Print what would run without actually running")
    args = p.parse_args()

    run_targeted(
        study=args.study,
        variant=args.variant,
        act=args.act,
        resume=args.resume,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
