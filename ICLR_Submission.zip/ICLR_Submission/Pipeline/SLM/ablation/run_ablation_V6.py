#!/usr/bin/env python3
"""
Ablation V6 — Model Family Study (paper §5.3, Table 7)
14 configurations (V6-A through V6-N) spanning commercial, open-source,
code-specialist, SLM, and legal-domain model families.

Goal: Identify how model family affects end-to-end success, semantic
      alignment, and repair capability across all 4 privacy acts.

Usage:
    python run_ablation_V6.py [--acts DPDP,GDPR] [--sections N] [--dry-run]
    python run_ablation_V6.py --variant V6_B_gpt4o    # single variant
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from ablation._ablation_runner import run_ablation

STUDY = "V6_model_family"


def build_model_config(variant_name, variant_model_cfg, study_cfg, all_cfg):
    """V6 variants define all three models explicitly in ablation_configs.yaml."""
    llm_a = variant_model_cfg["llm_a"]
    llm_b = variant_model_cfg["llm_b"]
    llm_c = variant_model_cfg["llm_c"]
    return llm_a, llm_b, llm_c


def main():
    p = argparse.ArgumentParser(description="Ablation V6: Model Family")
    p.add_argument("--acts",     default=None, help="Comma-separated acts, e.g. DPDP,GDPR")
    p.add_argument("--sections", type=int, default=None, help="Limit sections per act")
    p.add_argument("--dry-run",  action="store_true")
    p.add_argument(
        "--variant", default=None,
        help="Run a single variant only (e.g. V6_B_gpt4o)"
    )
    args = p.parse_args()

    acts = args.acts.split(",") if args.acts else None

    if args.variant:
        # Inject a single-variant override so the shared runner only runs that one
        import yaml
        from pathlib import Path as _P
        cfg_path = _P(__file__).parent / "ablation_configs.yaml"
        with open(cfg_path, encoding="utf-8") as f:
            all_cfg = yaml.safe_load(f)
        study_cfg = all_cfg[STUDY]
        if args.variant not in study_cfg["variants"]:
            print(f"Unknown variant: {args.variant}")
            print("Available:", list(study_cfg["variants"].keys()))
            sys.exit(1)
        study_cfg["variants"] = {args.variant: study_cfg["variants"][args.variant]}

    run_ablation(
        study=STUDY,
        build_model_config=build_model_config,
        acts=acts,
        section_limit=args.sections,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
