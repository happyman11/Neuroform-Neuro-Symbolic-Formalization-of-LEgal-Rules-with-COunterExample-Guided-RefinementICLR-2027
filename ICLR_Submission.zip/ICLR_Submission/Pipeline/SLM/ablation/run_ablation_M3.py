#!/usr/bin/env python3
"""
Ablation M3 — LLM-B Presence / Format Study (paper §5.2.3)
Vary semantic alignment step: skip | unstructured | structured (primary) | same-as-A.

Goal: Measure the contribution of the structured LLM-B JSON schema to
      deontic detection accuracy and end-to-end success.

Usage:
    python run_ablation_M3.py [--acts DPDP,GDPR] [--sections N] [--dry-run]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from ablation._ablation_runner import run_module_ablation

STUDY = "M3_llm_b_variant"


def main():
    p = argparse.ArgumentParser(description="Ablation M3: LLM-B Variant")
    p.add_argument("--acts",     default=None, help="Comma-separated acts, e.g. DPDP,GDPR")
    p.add_argument("--sections", type=int, default=None, help="Limit sections per act")
    p.add_argument("--dry-run",  action="store_true")
    args = p.parse_args()

    acts = args.acts.split(",") if args.acts else None
    run_module_ablation(
        study=STUDY,
        acts=acts,
        section_limit=args.sections,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
