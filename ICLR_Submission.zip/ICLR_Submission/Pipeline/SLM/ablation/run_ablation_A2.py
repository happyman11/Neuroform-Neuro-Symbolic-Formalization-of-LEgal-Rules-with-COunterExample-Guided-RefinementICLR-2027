#!/usr/bin/env python3
"""
Ablation A2 — Semantic Verifier Strength
Vary LLM-B (Weak/Medium/Strong); fix LLM-A=Qwen2.5-Coder-7B, LLM-C=DeepSeek-Coder.

Goal: Determine minimum semantic reasoning capability for reliable legal-symbolic alignment.

Usage:
    python run_ablation_A2.py [--acts DPDP,GDPR] [--sections N] [--dry-run]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from ablation._ablation_runner import run_ablation

STUDY = "A2_semantic_verifier"


def build_model_config(variant_name, variant_model_cfg, study_cfg, all_cfg):
    llm_a = study_cfg["fixed_a"]
    llm_b = {"owner": variant_model_cfg["owner"], "model": variant_model_cfg["model"]}
    llm_c = study_cfg["fixed_c"]
    return llm_a, llm_b, llm_c


def main():
    p = argparse.ArgumentParser(description="Ablation A2: Semantic Verifier Strength")
    p.add_argument("--acts",     default=None, help="Comma-separated acts, e.g. DPDP,GDPR")
    p.add_argument("--sections", type=int, default=None, help="Limit sections per act")
    p.add_argument("--dry-run",  action="store_true")
    args = p.parse_args()

    acts = args.acts.split(",") if args.acts else None
    run_ablation(
        study=STUDY,
        build_model_config=build_model_config,
        acts=acts,
        section_limit=args.sections,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
