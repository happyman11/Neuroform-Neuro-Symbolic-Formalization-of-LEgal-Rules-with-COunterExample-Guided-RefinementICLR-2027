#!/usr/bin/env python3
"""
test_paper_exact.py -- offline (no GPU, no model) verification of the algorithm_mode="paper_exact" Algorithm 1/3
implementation added to lib/SMT_Generation_AAAI_Final.py, and a regression check that algorithm_mode="legacy"
(the default, unchanged) still runs exactly as before. This is a WORKING COPY of the test intended for
ICLR_Submission/test_paper_exact.py -- see PAPER_CODE_CORRESPONDENCE.md. SLM-tier mirror of scripts/LLM/test_
paper_exact.py -- same fixtures/assertions, imports slm_pipeline.SLMRefineSMT instead of LLMRefineSMT.

    python3 test_paper_exact.py
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "lib"))

from slm_pipeline import SLMRefineSMT  # noqa: E402
import paper_diagnostics as PD  # noqa: E402

fails: list[str] = []


def check(cond, msg):
    if not cond:
        fails.append(msg)
    return cond


# A deliberately simple, non-vacuous encoding: the single annotation is an unconditional obligation
# ("controller must notify"), so the rule is the bare Bool var rather than an Implies -- this keeps the
# all-False probe UNSAT (not vacuously sat), so neither the legacy nor the paper-exact E4v detector fires,
# and it cleanly matches all 6 S1-S6 scenarios (verified by hand against paper_harness.py's construction).
GOOD_CODE = (
    "```python\nimport z3\n\nclass Sec:\n    def __init__(self):\n"
    "        self.controller_must_notify = z3.Bool('controller_must_notify')\n"
    "        self.data_breach_occurred = z3.Bool('data_breach_occurred')\n"
    "    def get_rule(self):\n"
    "        return self.controller_must_notify\n"
    "    def verify_data(self, data):\n"
    "        s = z3.Solver()\n        s.add(self.get_rule())\n"
    "        for k, v in data.items():\n            if hasattr(self, k):\n"
    "                zv = getattr(self, k)\n                if isinstance(zv, z3.BoolRef):\n"
    "                    s.add(zv == v)\n        return s.check()\n"
    "\nif __name__ == '__main__':\n"
    "    _sec = Sec()\n"
    "    print(_sec.verify_data({'controller_must_notify': True, 'data_breach_occurred': True}))\n```"
)
BAD_CODE = "```python\nimport z3\nclass Sec(:\n    pass\n```"          # syntax error -> E1
ALIGNED_JSON = '{"aligned": true, "gaps": [], "revised_code": ""}'
GAP_JSON = '{"aligned": false, "gaps": ["missing exception"], "revised_code": ""}'

SECTION = {
    "section_number": "TestSec1",
    "structured_annotation": {"paragraphs": [{"annotations": [
        {"label": "#obligation", "text": "controller must notify"},
    ]}]},
}


def make_pipeline(**kw):
    tmp = tempfile.mkdtemp()
    pipe = SLMRefineSMT(
        output_path=tmp, model_owner="HuggingFace", model="test-a",
        agnostic_model_owner="HuggingFace", agnostic_model="test-b",
        corrector_owner="HuggingFace", corrector_model="test-c",
        max_outer_attempts=2, max_cegar_iterations=3, beam_width=2,
        oracle_pass_threshold=0.80, experiment="test", variant="test", act_name="TEST",
        **kw,
    )
    pipe.output_dir = tmp  # normally set by process_act(); tests call generate_and_execute() directly
    return pipe, tmp


# =====================================================================================================================
# T1: algorithm_mode defaults to (and can only be) "paper_exact" -- "legacy" is no longer a selectable option
# =====================================================================================================================
pipe, tmp = make_pipeline()  # no algorithm_mode passed
check(pipe.algorithm_mode == "paper_exact", "T1: algorithm_mode did not default to 'paper_exact'")
try:
    make_pipeline(algorithm_mode="legacy")
    check(False, "T1: algorithm_mode='legacy' should raise ValueError -- it is no longer a supported option")
except ValueError:
    pass
try:
    make_pipeline(algorithm_mode="bogus")
    check(False, "T1: an unrecognized algorithm_mode should raise ValueError")
except ValueError:
    pass
print("[T1] algorithm_mode is paper_exact-only: OK ('legacy' and unknown values are rejected)")


# =====================================================================================================================
# T2: paper_exact mode, end-to-end, a clean aligned candidate -> SUCCESS
# =====================================================================================================================
def scripted_call_paper_exact(prompt, owner, model, role=None):
    if role == "llm_a":
        return GOOD_CODE
    if role == "llm_b":
        return ALIGNED_JSON
    return GOOD_CODE


pipe2, tmp2 = make_pipeline(algorithm_mode="paper_exact")
check(pipe2.algorithm_mode == "paper_exact", "T2: algorithm_mode not set to paper_exact")
with mock.patch.object(pipe2, "_call_llm", side_effect=scripted_call_paper_exact):
    metric2 = pipe2.generate_and_execute(SECTION)
check(metric2.final_success is True, f"T2: paper_exact run did not succeed on a clean aligned candidate: {metric2}")
out_files2 = list(Path(pipe2.output_dir).glob("*"))
success_txt2 = next((f for f in out_files2 if f.name.endswith("SUCCESS.txt")), None)
check(success_txt2 is not None, f"T2: no SUCCESS.txt written, files={out_files2}")
if success_txt2:
    txt2 = success_txt2.read_text()
    check("algorithm_mode=paper_exact" in txt2, "T2: paper_exact transcript header missing")
    check("sigma_impl" in txt2, "T2: paper_exact transcript missing sigma_impl logging")
print("[T2] paper_exact mode end-to-end: OK")


# =====================================================================================================================
# T3: paper_exact mode, LLM-A always returns a syntax error -> every candidate is E1 -> FAIL, never crashes
# =====================================================================================================================
def scripted_call_all_e1(prompt, owner, model, role=None):
    if role == "llm_a":
        return BAD_CODE
    return ALIGNED_JSON


pipe3, tmp3 = make_pipeline(algorithm_mode="paper_exact")
with mock.patch.object(pipe3, "_call_llm", side_effect=scripted_call_all_e1):
    metric3 = pipe3.generate_and_execute(SECTION)
check(metric3.final_success is False, "T3: an all-E1 run should not report success")
print("[T3] paper_exact all-E1 candidates: OK (fails cleanly, no crash)")


# =====================================================================================================================
# T4: g_sem rejection is a semantic reject, not a counterexample -- with a clean-but-misaligned candidate, the
# pipeline must exhaust its outer budget and FAIL (never silently "succeed" on a rejected candidate), and must
# never crash treating the rejection as a scenario mismatch.
# =====================================================================================================================
def scripted_call_gsem_reject(prompt, owner, model, role=None):
    if role == "llm_a":
        return GOOD_CODE
    if role == "llm_b":
        return GAP_JSON            # always rejects, regardless of repair
    return GOOD_CODE


pipe4, tmp4 = make_pipeline(algorithm_mode="paper_exact")
with mock.patch.object(pipe4, "_call_llm", side_effect=scripted_call_gsem_reject):
    metric4 = pipe4.generate_and_execute(SECTION)
check(metric4.final_success is False, "T4: a persistently g_sem-rejected candidate must not be reported success")
print("[T4] g_sem rejection handling: OK")


# =====================================================================================================================
# T5: _diagnostic_repair_paper_exact control-flow -- phi_best tracking, strict-inequality ties, E1-abort -- using
# a SCRIPTED queue of PaperExactEvaluation objects so the algorithm's control flow is verified precisely,
# independent of real Z3/LLM behavior (already verified separately by T1-T4 and paper_harness/paper_diagnostics'
# own tests).
# =====================================================================================================================
from SMT_Generation_AAAI_Final import Candidate, SectionMetric  # noqa: E402


def fake_eval(sigma, diag, mismatch_index=0):
    return PD.PaperExactEvaluation(True, 1.0, 1.0, 1.0 if diag == "E0" else 0.5, 1.0, sigma, diag,
                                    f"scripted:{diag}", mismatch_index, None, None, None)


pipe5, tmp5 = make_pipeline(algorithm_mode="paper_exact")
metric5 = SectionMetric(section_id="x", timestamp="t", beam_width=1, candidates_generated=0)

# Scripted trajectory: entry E3(sigma=0.60) -> repair1 E4(sigma=0.40, WORSE, must NOT overwrite phi_best)
#                    -> repair2 E4(sigma=0.60, TIE, must NOT overwrite -- strict inequality)
#                    -> repair3 E3(sigma=0.30, still worse) -> budget exhausted -> the function re-evaluates
#                       phi_best fresh before returning (4th eval call, scripted to match phi_best's own
#                       unchanged score) -> must return the ENTRY candidate (sigma=0.60), not the last-tried
#                       one (sigma=0.30), unlike the legacy loop's "return the last attempt" bug this fixes.
entry_cand = Candidate(code_blocks=["# entry"], raw_response="")
entry_ev = fake_eval(0.60, "E3")

call_log = []


def scripted_llm_c(prompt, owner, model, role=None):
    call_log.append(1)
    return f"```python\nimport z3\nclass Sec:\n    def __init__(self):\n        self.v = z3.Bool('v')\n"\
           f"    def get_rule(self):\n        return self.v\n    def verify_data(self, d):\n"\
           f"        s = z3.Solver(); s.add(self.get_rule()); return s.check()\n# call {len(call_log)}\n```"


eval_queue = [fake_eval(0.40, "E4"), fake_eval(0.60, "E3"), fake_eval(0.30, "E3"), fake_eval(0.60, "E3")]
with mock.patch.object(pipe5, "_call_llm", side_effect=scripted_llm_c), \
     mock.patch("paper_diagnostics.evaluate_candidate_paper_exact", side_effect=lambda s, c: eval_queue.pop(0)):
    best, best_ev, log_text = pipe5._diagnostic_repair_paper_exact(SECTION, entry_cand, entry_ev, metric5)

check(best is entry_cand, f"T5: phi_best should remain the entry candidate (sigma 0.60 was never beaten by a "
      f"strictly-higher score); got a different candidate instead")
check(best_ev.sigma_impl == 0.60, f"T5: phi_best's sigma_impl should be 0.60 (the entry's), got {best_ev.sigma_impl}")
print("[T5a] phi_best/strict-tie tracking: OK (worse and tied repairs never overwrite the incumbent)")

# T5b: a repaired candidate that STRICTLY beats the incumbent AND clears theta_impl/A=1/D=E0 returns immediately
# (no further eval calls needed -- the immediate-return path returns ev_prime directly, doesn't re-evaluate).
entry_cand_b = Candidate(code_blocks=["# entry"], raw_response="")
entry_ev_b = fake_eval(0.50, "E4")
eval_queue_b = [fake_eval(0.85, "E0")]
metric5b = SectionMetric(section_id="x", timestamp="t", beam_width=1, candidates_generated=0)
with mock.patch.object(pipe5, "_call_llm", side_effect=scripted_llm_c), \
     mock.patch("paper_diagnostics.evaluate_candidate_paper_exact", side_effect=lambda s, c: eval_queue_b.pop(0)):
    best_b, best_ev_b, _ = pipe5._diagnostic_repair_paper_exact(SECTION, entry_cand_b, entry_ev_b, metric5b)
check(best_b is not entry_cand_b, "T5b: a strictly-better, threshold-clearing repaired candidate should replace phi_best")
check(best_ev_b.sigma_impl == 0.85, f"T5b: phi_best should now be the 0.85 candidate, got {best_ev_b.sigma_impl}")
check(best_ev_b.diagnostic == "E0", "T5b: the immediate-return path should preserve D'=E0 on the returned eval")
print("[T5b] strict improvement + threshold clear -> immediate return: OK")

# T5c: E1 on the FIRST repair attempt must return the untouched entry candidate immediately, never overwritten.
entry_cand_c = Candidate(code_blocks=["# entry"], raw_response="")
entry_ev_c = fake_eval(0.55, "E4")
eval_queue_c = [fake_eval(0.0, "E1")]
metric5c = SectionMetric(section_id="x", timestamp="t", beam_width=1, candidates_generated=0)
with mock.patch.object(pipe5, "_call_llm", side_effect=scripted_llm_c), \
     mock.patch("paper_diagnostics.evaluate_candidate_paper_exact",
                 side_effect=lambda s, c: eval_queue_c.pop(0) if eval_queue_c else entry_ev_c):
    best_c, best_ev_c, _ = pipe5._diagnostic_repair_paper_exact(SECTION, entry_cand_c, entry_ev_c, metric5c)
check(best_c is entry_cand_c, "T5c: an E1 repair attempt must return the untouched entry candidate, never a new one")
check(best_ev_c.diagnostic == "E4", f"T5c: incumbent's own diagnostic should be preserved (E4), got {best_ev_c.diagnostic}")
print("[T5c] E1-on-repair abort-and-preserve-incumbent: OK")

# T5d: D=E0 on the entry itself returns immediately with zero LLM-C calls.
call_log.clear()
entry_cand_d = Candidate(code_blocks=["# entry"], raw_response="")
entry_ev_d = fake_eval(1.0, "E0")
metric5d = SectionMetric(section_id="x", timestamp="t", beam_width=1, candidates_generated=0)
with mock.patch.object(pipe5, "_call_llm", side_effect=scripted_llm_c):
    best_d, best_ev_d, _ = pipe5._diagnostic_repair_paper_exact(SECTION, entry_cand_d, entry_ev_d, metric5d)
check(best_d is entry_cand_d and len(call_log) == 0, "T5d: D=E0 must return immediately with zero LLM-C calls")
print("[T5d] E0-immediate-return: OK")


print()
for m in fails:
    print("FAIL:", m)
print(f"{'ALL CHECKS PASSED' if not fails else str(len(fails)) + ' CHECK(S) FAILED'}")
raise SystemExit(0 if not fails else 1)
