#!/usr/bin/env python3
"""
Standalone runner: M5 CEGAR-budget ablation — variant k1 (max_cegar=1), GDPR only.

Usage:
    cd ICLR_Submission/Pipeline/SLM
    python3 run_M5_k1_GDPR.py
    python3 run_M5_k1_GDPR.py --sections 5   # smoke-test on 5 sections
    python3 run_M5_k1_GDPR.py --dry-run      # verify paths without calling LLMs
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from tqdm import tqdm

# ── path setup ────────────────────────────────────────────────────────────────
_HERE = Path(__file__).parent
sys.path.insert(0, str(_HERE))

from slm_config import SRC, ACTS_INPUT, ABLATION_OUT, IGNORE_FILES
from slm_pipeline import SLMRefineSMT

sys.path.insert(0, str(SRC))
from utility import Utility

# ── fixed config ──────────────────────────────────────────────────────────────
STUDY       = "M5_cegar_budget"
VARIANT     = "k1"
ACT         = "GDPR"

LLM_A_OWNER = "HuggingFace"
LLM_A_MODEL = "Qwen/Qwen2.5-Coder-7B-Instruct"
LLM_A_TEMP  = 0.7

LLM_B_OWNER = "HuggingFace"
LLM_B_MODEL = "microsoft/phi-4"
LLM_B_TEMP  = 0.0

LLM_C_OWNER = "HuggingFace"
LLM_C_MODEL = "Qwen/Qwen2.5-Coder-7B-Instruct"
LLM_C_TEMP  = 0.0

BEAM_WIDTH      = 3
MAX_OUTER       = 7
MAX_CEGAR       = 1          # k1 — only 1 CEGAR repair iteration
ORACLE_THRESH   = 0.7
# ─────────────────────────────────────────────────────────────────────────────


def _setup_logging(run_dir: Path) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    logging.basicConfig(level=logging.INFO, format=fmt)
    fh = logging.FileHandler(run_dir / "run.log", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(fmt))
    logging.getLogger().addHandler(fh)


def _load_section(file_path: Path, utility) -> dict:
    try:
        with open(file_path, encoding="utf-8") as fh:
            full = json.load(fh)
    except Exception:
        full = {}
    section = utility.extract_json_robust(str(file_path)) or {}
    for key in ("label_metrics", "structured_annotation", "source"):
        if key in full and key not in section:
            section[key] = full[key]
    return section


def main() -> None:
    p = argparse.ArgumentParser(description="M5 k1 GDPR standalone runner")
    p.add_argument("--sections", type=int, default=None,
                   help="Limit number of sections (e.g. 5 for a smoke test)")
    p.add_argument("--dry-run", action="store_true",
                   help="List files that would run without calling any LLMs")
    args = p.parse_args()

    ts      = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id  = f"SLM-{STUDY}-{VARIANT}-{ACT}-{ts}"
    run_dir = ABLATION_OUT / STUDY / VARIANT

    _setup_logging(run_dir)
    logger = logging.getLogger("run_M5_k1_GDPR")

    act_input = ACTS_INPUT.get(ACT)
    if not act_input or not act_input.exists():
        logger.error("GDPR input directory not found: %s", act_input)
        sys.exit(1)

    act_output = run_dir / ACT
    act_output.mkdir(parents=True, exist_ok=True)

    files = sorted(
        f for f in os.listdir(act_input)
        if f.endswith(".json") and f not in IGNORE_FILES
    )
    if args.sections:
        files = files[:args.sections]

    logger.info("Run ID    : %s", run_id)
    logger.info("Study     : %s  variant=%s  act=%s", STUDY, VARIANT, ACT)
    logger.info("Sections  : %d", len(files))
    logger.info("LLM-A     : %s  T=%.1f", LLM_A_MODEL, LLM_A_TEMP)
    logger.info("LLM-B     : %s  T=%.1f", LLM_B_MODEL, LLM_B_TEMP)
    logger.info("LLM-C     : %s  T=%.1f", LLM_C_MODEL, LLM_C_TEMP)
    logger.info("max_cegar : %d  beam_width=%d  max_outer=%d", MAX_CEGAR, BEAM_WIDTH, MAX_OUTER)
    logger.info("Output    : %s", act_output)

    # Write run_config.json
    try:
        import transformers
        tf_ver = transformers.__version__
    except ImportError:
        tf_ver = "N/A"

    run_config = {
        "run_id": run_id, "study": STUDY, "variant": VARIANT, "act": ACT,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "models": {
            "llm_a": {"owner": LLM_A_OWNER, "model": LLM_A_MODEL, "temperature": LLM_A_TEMP},
            "llm_b": {"owner": LLM_B_OWNER, "model": LLM_B_MODEL, "temperature": LLM_B_TEMP},
            "llm_c": {"owner": LLM_C_OWNER, "model": LLM_C_MODEL, "temperature": LLM_C_TEMP},
        },
        "hyperparameters": {
            "beam_width": BEAM_WIDTH, "max_outer": MAX_OUTER,
            "max_cegar": MAX_CEGAR, "oracle_threshold": ORACLE_THRESH,
        },
        "hardware": platform.node(),
        "python_version": platform.python_version(),
        "transformers_version": tf_ver,
    }
    with open(run_dir / "run_config.json", "w", encoding="utf-8") as f:
        json.dump(run_config, f, indent=2)

    if args.dry_run:
        for fn in files:
            logger.info("[DRY-RUN] %s", fn)
        logger.info("Dry-run complete — no LLMs called.")
        return

    utility  = Utility()
    pipeline = SLMRefineSMT(
        output_path=str(act_output),
        model_owner=LLM_A_OWNER,
        model=LLM_A_MODEL,
        agnostic_model_owner=LLM_B_OWNER,
        agnostic_model=LLM_B_MODEL,
        corrector_owner=LLM_C_OWNER,
        corrector_model=LLM_C_MODEL,
        max_outer_attempts=MAX_OUTER,
        max_cegar_iterations=MAX_CEGAR,
        beam_width=BEAM_WIDTH,
        oracle_pass_threshold=ORACLE_THRESH,
        experiment=STUDY,
        variant=VARIANT,
        act_name=ACT,
        run_id=run_id,
        llm_a_temperature=LLM_A_TEMP,
        llm_b_temperature=LLM_B_TEMP,
        llm_c_temperature=LLM_C_TEMP,
    )

    with tqdm(total=len(files), desc=f"{VARIANT}/{ACT}") as pbar:
        for filename in files:
            pbar.set_postfix_str(filename)
            try:
                section = _load_section(act_input / filename, utility)
                pipeline.process_act(section, filename.replace(".json", ""))
            except Exception:
                logger.exception("Failed: %s", filename)
            pbar.update(1)

    pipeline.save_aggregate_metrics(log=True)

    # Copy aggregate metrics up one level for easy access
    agg_src = act_output / "aggregate_metrics.json"
    if agg_src.exists():
        shutil.copy(agg_src, run_dir / f"{ACT}_aggregate_metrics.json")

    logger.info("Done. Output: %s", act_output)


if __name__ == "__main__":
    main()
