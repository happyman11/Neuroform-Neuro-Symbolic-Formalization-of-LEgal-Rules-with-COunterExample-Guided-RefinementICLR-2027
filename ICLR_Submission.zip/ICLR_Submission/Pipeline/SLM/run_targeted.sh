#!/usr/bin/env bash
# =============================================================================
# run_targeted.sh — Launch a single-variant / single-act ablation run
#
# Usage:
#   ./run_targeted.sh --study STUDY --variant VARIANT --act ACT [--resume] [--dry-run]
#
# Options:
#   --study     Study ID (short or full name)
#               Short:  M1 M2 M3 M4 M5  A1 A2 A3
#               Full:   M4_feedback_mode  A3_repair_capability  etc.
#   --variant   Variant name from ablation_configs.yaml
#   --act       Regulation act: GDPR  CCPA  DPDP  PIPD
#   --resume    Skip sections that already have section_metrics.json output
#   --dry-run   Print what would run, don't actually run
#
# ─── Quick-start: 4 pending re-runs ──────────────────────────────────────────
#
#   1. M4/class_hint_no_z3/GDPR  — never ran (0/99 sections)
#      ./run_targeted.sh --study M4 --variant class_hint_no_z3 --act GDPR
#
#   2. M4/full_ce/GDPR            — crashed at Art25 (32/99 done)
#      ./run_targeted.sh --study M4 --variant full_ce --act GDPR --resume
#
#   3. A3/strong/PIPD             — killed at section 29 (28/50 done)
#      ./run_targeted.sh --study A3 --variant strong --act PIPD --resume
#
#   4. M3/same_as_a/DPDP         — 3 sections missing (41/44 done)
#      ./run_targeted.sh --study M3 --variant same_as_a --act DPDP --resume
#
# ─── Run all 4 in parallel (if you have compute) ─────────────────────────────
#
#   ./run_targeted.sh --study M4  --variant class_hint_no_z3 --act GDPR &
#   ./run_targeted.sh --study M4  --variant full_ce           --act GDPR --resume &
#   ./run_targeted.sh --study A3  --variant strong             --act PIPD --resume &
#   ./run_targeted.sh --study M3  --variant same_as_a          --act DPDP --resume &
#   wait && echo "All 4 done"
#
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUNNER="$SCRIPT_DIR/ablation/run_ablation_targeted.py"

# ─── Argument parsing ────────────────────────────────────────────────────────

STUDY=""
VARIANT=""
ACT=""
EXTRA_ARGS=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --study)   STUDY="$2";   shift 2 ;;
        --variant) VARIANT="$2"; shift 2 ;;
        --act)     ACT="$2";     shift 2 ;;
        --resume|--dry-run) EXTRA_ARGS+=("$1"); shift ;;
        -h|--help)
            sed -n '/^# ====/,/^# ====/p' "$0" | sed 's/^# \{0,1\}//'
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            exit 1
            ;;
    esac
done

if [[ -z "$STUDY" || -z "$VARIANT" || -z "$ACT" ]]; then
    echo "Error: --study, --variant, and --act are all required." >&2
    echo ""
    echo "Example:" >&2
    echo "  $0 --study M4 --variant class_hint_no_z3 --act GDPR" >&2
    echo "  $0 --study A3 --variant strong --act PIPD --resume" >&2
    exit 1
fi

# ─── Run ─────────────────────────────────────────────────────────────────────

echo "============================================================"
echo "  Study:   $STUDY"
echo "  Variant: $VARIANT"
echo "  Act:     $ACT"
[[ " ${EXTRA_ARGS[*]:-} " == *"--resume"* ]]  && echo "  Mode:    RESUME (skip already-done sections)"
[[ " ${EXTRA_ARGS[*]:-} " == *"--dry-run"* ]] && echo "  Mode:    DRY-RUN"
echo "============================================================"

python3 "$RUNNER" \
    --study   "$STUDY"   \
    --variant "$VARIANT" \
    --act     "$ACT"     \
    "${EXTRA_ARGS[@]}"
