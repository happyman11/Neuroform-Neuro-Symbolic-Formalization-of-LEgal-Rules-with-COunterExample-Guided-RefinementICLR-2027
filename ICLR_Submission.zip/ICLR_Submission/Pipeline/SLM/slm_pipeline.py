"""
SLMRefineSMT — subclass of RefineSMT that adds:
  - HuggingFace local inference  (owner == "HuggingFace")
  - Per-role temperature (Theorem 2.2: LLM-A T=0.7, LLM-B/C T=0.0)
  - Beam score / diversity capture
  - Deontic type tracking (ground truth + LLM-B predicted)
  - CEGAR per-iteration oracle score tracking
  - Module-level ablation flags: oracle_mode, llm_b_skip, llm_b_format, feedback_mode
  - σD deontic-augmented oracle scoring (M2 ablation)
  - SLM metadata augmentation in every section_metrics.json

Import this module before importing RefineSMT in any benchmarking/ablation script.
"""
from __future__ import annotations

import json
import logging
import os
import re
import sys
import time
from datetime import datetime, timezone
from math import sqrt

from slm_config import SRC
sys.path.insert(0, str(SRC))

from SMT_Generation_AAAI_Final import (  # noqa: E402
    RefineSMT, Candidate, SectionMetric, classify_error, ErrorType,
    detect_e4_vacuous, build_e4v_gap,
)
from slm_models import (
    HuggingFaceModel,
    TEMPERATURE_LLM_A, TEMPERATURE_LLM_B, TEMPERATURE_LLM_C,
)

logger = logging.getLogger(__name__)

# Oracle mode constants (M2 ablation)
ORACLE_MODE_FULL         = "full"         # σ = 0.5·exec + 0.2·solver + 0.2·verdict + 0.1·proof
ORACLE_MODE_PASS_ALL     = "pass_all"     # σ = 1.0 always (baseline)
ORACLE_MODE_EXEC_ONLY    = "exec_only"    # σ = 0.5·exec
ORACLE_MODE_NO_PROOF     = "no_proof_bonus"  # σ without the 0.1·proof term
ORACLE_MODE_SIGMA_D      = "sigma_d"      # σD = σ + 0.2·1[deont match], capped 1.0

# Feedback mode constants (M4 ablation)
FEEDBACK_NONE      = "none"
FEEDBACK_RAW       = "raw_error"
FEEDBACK_CLASS     = "class_only"
FEEDBACK_FULL_CE   = "full_ce"       # primary: class label + counterexample
FEEDBACK_CLASS_HINT = "class_hint"   # class + NL hint, no Z3 trace

# Keywords that appear in LLM-B gap descriptions for E4 (incomplete encoding).
# LLM-B reports gaps as "missing obligation X" / "clause not captured" / etc.
# — none of which contain the literal word "incomplete" — so we match the
# vocabulary that LLM-B actually uses.
_E4_GAP_KEYWORDS: frozenset[str] = frozenset({
    "missing", "not encoded", "not captured", "omitted",
    "absent", "incomplete", "not cover", "not include", "gap",
    "unencoded", "not represented", "not modeled",
})


class SLMRefineSMT(RefineSMT):
    """
    Drop-in replacement for RefineSMT with SLM-specific extensions.

    Extra constructor kwargs
    -----------------------
    experiment        : label for every section_metrics.json
    variant           : ablation tier
    act_name          : "DPDP" | "GDPR" | "CCPA" | "PIPD"
    run_id            : unique run identifier (auto-generated if empty)
    oracle_pass_threshold : override ORACLE_PASS_THRESHOLD class constant
    llm_a_temperature : sampling temperature for LLM-A (default 0.7, Theorem 2.2)
    llm_b_temperature : sampling temperature for LLM-B (default 0.0)
    llm_c_temperature : sampling temperature for LLM-C (default 0.0)
    oracle_mode       : one of ORACLE_MODE_* constants (default "full")
    llm_b_skip        : if True, skip semantic alignment step entirely (M3)
    llm_b_format      : "structured" | "unstructured" (M3)
    feedback_mode     : one of FEEDBACK_* constants (default "full_ce")
    """

    def __init__(
        self,
        *args,
        experiment: str = "benchmarking",
        variant: str = "primary",
        act_name: str = "unknown",
        run_id: str = "",
        oracle_pass_threshold: float | None = None,
        # Per-role temperatures (Theorem 2.2)
        llm_a_temperature: float = TEMPERATURE_LLM_A,
        llm_b_temperature: float = TEMPERATURE_LLM_B,
        llm_c_temperature: float = TEMPERATURE_LLM_C,
        # Per-role max tokens: A/C generate full Z3 programs; B outputs JSON only
        llm_a_max_tokens: int = 4096,
        llm_b_max_tokens: int = 2048,
        llm_c_max_tokens: int = 4096,
        # Module ablation flags
        oracle_mode: str = ORACLE_MODE_FULL,
        llm_b_skip: bool = False,
        llm_b_format: str = "structured",
        feedback_mode: str = FEEDBACK_FULL_CE,
        # E4 relaxation knobs
        alignment_gap_tolerance: int = 1,
        alignment_gap_min_score: float = 0.85,
        e4_cegar_skip: bool = True,
        # scripts/additional_runs/ knobs -- both default to prior behavior
        e4v_detection_enabled: bool = True,
        seed: int | None = None,
        # Opt-in per-section step log (trace.jsonl + input_text.txt, see lib/step_trace.py). False (default) -> no
        # method is wrapped and no extra file/key is written: byte-identical to prior behavior.
        detailed_logging: bool = False,
        **kwargs,
    ):
        super().__init__(*args, e4v_detection_enabled=e4v_detection_enabled, **kwargs)
        # torch.manual_seed() call-site (slm_models.HuggingFaceModel.call) needs a
        # DIFFERENT seed per LLM call, not one seed reused for every call in the run
        # (that would make every role/section's sampling draw from the identical
        # RNG state) -- self._call_counter increments once per _call_llm()
        # invocation, so seed is None -> unseeded (unchanged default behavior),
        # while an int seed reproduces the exact same sequence of per-call seeds
        # across repeated runs with the same base seed.
        self._seed = seed
        self._call_counter = 0
        self.experiment = experiment
        self.variant = variant
        self.act_name = act_name
        self.run_id = run_id or _make_run_id(experiment, variant, act_name)
        self._beam_log: list[dict] = []
        self._ranked_candidates: list[Candidate] = []
        self._slm_extra_data: dict = {}
        self._cegar_iter_scores: list[float] = []
        self._oracle_component_log: dict = {}

        # Per-role generation settings
        self._llm_a_temperature = llm_a_temperature
        self._llm_b_temperature = llm_b_temperature
        self._llm_c_temperature = llm_c_temperature
        self._llm_a_max_tokens  = llm_a_max_tokens
        self._llm_b_max_tokens  = llm_b_max_tokens
        self._llm_c_max_tokens  = llm_c_max_tokens

        # Module ablation flags
        self._oracle_mode = oracle_mode
        self._llm_b_skip = llm_b_skip
        self._llm_b_format = llm_b_format
        self._feedback_mode = feedback_mode

        # E4 relaxation:
        #   alignment_gap_tolerance — accept alignment if gap count ≤ this AND
        #                             oracle score ≥ alignment_gap_min_score
        #   e4_cegar_skip           — when E4 is the gap type, skip CEGAR entirely
        #                             and regenerate the beam with E4 context
        self._alignment_gap_tolerance = alignment_gap_tolerance
        self._alignment_gap_min_score = alignment_gap_min_score
        self._e4_cegar_skip           = e4_cegar_skip

        if oracle_pass_threshold is not None:
            self.ORACLE_PASS_THRESHOLD = oracle_pass_threshold

        self._detailed_logging = bool(detailed_logging)
        self._input_provenance: dict = {}
        if self._detailed_logging:
            from step_trace import install_step_trace
            install_step_trace(self)

    # ------------------------------------------------------------------
    # HuggingFace dispatch with per-role temperature
    # ------------------------------------------------------------------

    # System messages injected per role for base models that lack a chat template.
    # Instruction-tuned models use their built-in chat template and ignore these.
    # For base models, slm_models.HuggingFaceModel.call() embeds the message as
    # plain text and appends a ```python fence primer so extract_code() can parse
    # the output reliably.
    _LLM_A_SYSTEM_MSG = (
        "You are an expert Python and Z3 formal-verification engineer. "
        "Your task is to generate a complete Z3 Python program that formally encodes "
        "the given legal constraint. "
        "Output the complete, syntactically valid Python script inside "
        "a single ```python\\n...\\n``` fenced code block. "
        "The script must import z3, declare all variables, add all constraints, "
        "and print the solver result."
    )
    _LLM_B_SYSTEM_MSG = (
        "You are a formal-logic validator. "
        "Evaluate whether the given Z3 encoding is semantically faithful to the "
        "legal clause. Respond with a JSON object: "
        "{\"aligned\": true/false, \"gaps\": [\"...\"], \"deontic_type\": \"O|F|P\", "
        "\"deontic_confirmed\": true/false, \"revised_code\": \"...\"}."
    )
    _LLM_C_SYSTEM_MSG = (
        "You are an expert Python and Z3 formal-verification engineer. "
        "Your sole task is to produce corrected or completed Z3 Python code. "
        "Always output the complete, syntactically valid Python script inside "
        "a single ```python\\n...\\n``` fenced code block — nothing after it. "
        "The code must import z3, declare all variables, add all constraints, "
        "and print the solver result."
    )

    def _call_llm(self, prompt: str, owner: str, model: str, role: str | None = None) -> str:
        if owner == "HuggingFace":
            call_seed = self._next_seed()
            return HuggingFaceModel.call(
                model, prompt,
                temperature=self._resolve_temperature(model),
                max_new_tokens=self._resolve_max_tokens(model),
                system_message=self._resolve_system_message(model),
                seed=call_seed,
            )
        if owner == "Ollama":
            # ICLR supplementary: Ollama as a first-class, symmetric alternative to HuggingFace -- same per-
            # role temperature/max_tokens/system_message/seed resolution, just a different serving backend.
            call_seed = self._next_seed()
            return self.model_call.ollama_call_model(
                prompt=prompt, model=model,
                temperature=self._resolve_temperature(model),
                max_new_tokens=self._resolve_max_tokens(model),
                system_message=self._resolve_system_message(model),
                seed=call_seed,
            )
        return super()._call_llm(prompt, owner, model, role=role)

    def _next_seed(self) -> int | None:
        if self._seed is None:
            return None
        call_seed = self._seed + self._call_counter
        self._call_counter += 1
        return call_seed

    def _resolve_system_message(self, model: str) -> str:
        if model == self.corrector_model:
            return self._LLM_C_SYSTEM_MSG
        if model == self.model:
            return self._LLM_A_SYSTEM_MSG
        if model == self.agnostic_model:
            return self._LLM_B_SYSTEM_MSG
        return ""

    def _resolve_temperature(self, model: str) -> float:
        if model == self.model:
            return self._llm_a_temperature
        if model == self.agnostic_model:
            return self._llm_b_temperature
        if model == self.corrector_model:
            return self._llm_c_temperature
        return self._llm_a_temperature

    def _resolve_max_tokens(self, model: str) -> int:
        if model == self.model:
            return self._llm_a_max_tokens
        if model == self.agnostic_model:
            return self._llm_b_max_tokens
        if model == self.corrector_model:
            return self._llm_c_max_tokens
        return self._llm_a_max_tokens

    # ------------------------------------------------------------------
    # M2: Oracle mode variants — override execute_and_score
    # ------------------------------------------------------------------

    def _compute_oracle_score(self, candidate: Candidate) -> float:
        """
        Compute σ(φ, c) according to the active oracle_mode.

        Full formula (paper §4.1):
            σ = 0.5·1[exec] + 0.2·1[solver reached] + 0.2·1[V≠?] + 0.1·1[proof]

        σD adds deontic bonus:
            σD = min(1.0, σ + 0.2·1[deont(φ)=deont(yc)])
        """
        mode = self._oracle_mode

        if mode == ORACLE_MODE_PASS_ALL:
            return 1.0

        # Component flags from candidate (set by parent oracle)
        exec_ok    = getattr(candidate, "execution_success", False)
        solver_ok  = getattr(candidate, "solver_reached",    False)
        verdict_ok = getattr(candidate, "verdict_definite",  False)
        proof_ok   = getattr(candidate, "proof_extractable", False)

        if mode == ORACLE_MODE_EXEC_ONLY:
            score = 0.5 * float(exec_ok)
        elif mode == ORACLE_MODE_NO_PROOF:
            score = 0.5 * float(exec_ok) + 0.2 * float(solver_ok) + 0.3 * float(verdict_ok)
        else:  # full or sigma_d
            score = (0.5 * float(exec_ok) + 0.2 * float(solver_ok)
                     + 0.2 * float(verdict_ok) + 0.1 * float(proof_ok))

        if mode == ORACLE_MODE_SIGMA_D:
            gt  = self._slm_extra_data.get("_current_gt_deontic", "unknown")
            pred = self._slm_extra_data.get("deontic_type_predicted")
            if gt != "unknown" and pred is not None:
                pred_mapped = {"obligation": "O", "prohibition": "F",
                               "permission": "P"}.get(str(pred).lower(), pred)
                if gt == pred_mapped:
                    score = min(1.0, score + 0.2)

        # Store components for oracle_component_analysis metric
        self._oracle_component_log = {
            "exec": float(exec_ok),
            "solver": float(solver_ok),
            "verdict": float(verdict_ok),
            "proof": float(proof_ok),
            "final_score": round(score, 4),
            "mode": mode,
        }
        return score

    # ------------------------------------------------------------------
    # Beam score capture
    # ------------------------------------------------------------------

    def _select_best_candidate(
        self,
        candidates: list[Candidate],
        section_id: str,
        outer: int,
        log: list[str],
    ) -> Candidate:
        best = super()._select_best_candidate(candidates, section_id, outer, log)
        # Keep full sorted list so generate_and_execute can cascade through candidates.
        self._ranked_candidates = sorted(
            candidates, key=lambda c: c.semantic_score, reverse=True
        )
        self._beam_log.append({
            "outer": outer,
            "scores":      [round(c.semantic_score, 4) for c in candidates],
            "verdicts":    [c.z3_verdict for c in candidates],
            "error_types": [
                c.error_type.value if hasattr(c.error_type, "value") else str(c.error_type)
                for c in candidates
            ],
        })
        return best

    # ------------------------------------------------------------------
    # M3: LLM-B semantic alignment — skip or format variants
    # ------------------------------------------------------------------

    def _semantic_alignment_check(
        self, section: dict, candidate: Candidate
    ) -> tuple[bool, str, float]:
        """
        Overrides parent.  Handles M3 ablation modes:
          - llm_b_skip=True       → return (True, "", 1.0) unconditionally
          - llm_b_format="unstructured" → parse free-text instead of JSON
          - llm_b_format="structured"   → JSON schema (5 fields, primary)

        Also captures deontic_type_predicted, deontic_confirmed, n_gaps.
        """
        if self._llm_b_skip:
            self._slm_extra_data["deontic_type_predicted"] = None
            self._slm_extra_data["deontic_confirmed"] = True
            return True, "", 1.0

        prompt = self.prompter.get_Logic_Validation(self._prompt_section(section), candidate.code_blocks)
        raw_b = self._call_llm(prompt, self.agnostic_model_owner, self.agnostic_model, role="llm_b")

        if self._llm_b_format == "unstructured":
            return self._parse_unstructured_alignment(raw_b, candidate)

        # Structured JSON (primary)
        json_match = re.search(r"\{.*\}", raw_b, flags=re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())
                aligned = bool(parsed.get("aligned", False))
                gaps = parsed.get("gaps", [])
                revised_blocks = self.extract_code(parsed.get("revised_code", ""))
                gap_desc = "; ".join(gaps) if gaps else ""
                if revised_blocks:
                    candidate.code_blocks = revised_blocks
                align_score = (
                    round(max(0.5, 1.0 - 0.15 * len(gaps)), 2) if aligned
                    else round(max(0.0, 0.4 - 0.1 * len(gaps)), 2)
                )
                self._slm_extra_data["deontic_type_predicted"] = parsed.get("deontic_type")
                self._slm_extra_data["deontic_confirmed"] = bool(
                    parsed.get("deontic_confirmed", aligned)
                )
                self._slm_extra_data["n_gaps"] = (
                    self._slm_extra_data.get("n_gaps", 0) + len(gaps)
                )
                # E4 gap-tolerance relaxation: if not aligned but gap count is
                # small and oracle score is high, accept as aligned to avoid
                # burning CEGAR iterations on minor incompleteness.
                if (not aligned
                        and len(gaps) <= self._alignment_gap_tolerance
                        and candidate.semantic_score >= self._alignment_gap_min_score):
                    logger.info(
                        "E4 relaxation applied: %d gap(s) ≤ tolerance %d and "
                        "score %.2f ≥ %.2f — accepting as aligned.",
                        len(gaps), self._alignment_gap_tolerance,
                        candidate.semantic_score, self._alignment_gap_min_score,
                    )
                    aligned = True
                    align_score = round(0.5 + 0.1 * (1 - len(gaps)), 2)
                return aligned, gap_desc, align_score
            except json.JSONDecodeError:
                pass

        # Fallback to keyword detection
        return self._parse_unstructured_alignment(raw_b, candidate)

    def _parse_unstructured_alignment(
        self, raw_b: str, candidate: Candidate
    ) -> tuple[bool, str, float]:
        lower = raw_b.lower()
        aligned = any(k in lower for k in ["correct", "aligned", "faithful", "accurate"])
        not_aligned = any(k in lower for k in
                          ["missing", "incorrect", "wrong", "gap", "incomplete"])
        if not_aligned:
            aligned = False
        revised_blocks = self.extract_code(raw_b)
        if revised_blocks:
            candidate.code_blocks = revised_blocks
        gap_desc = raw_b[:400] if not aligned else ""
        align_score = 0.6 if aligned else 0.2
        self._slm_extra_data["deontic_type_predicted"] = None
        self._slm_extra_data["deontic_confirmed"] = aligned
        return aligned, gap_desc, align_score

    # ------------------------------------------------------------------
    # M4: Feedback mode — override CEGAR prompt construction
    # ------------------------------------------------------------------

    def _build_repair_prompt(
        self,
        section: dict,
        candidate: Candidate,
        semantic_gap: str,
        iteration: int,
    ) -> str:
        """
        Build the LLM-C repair prompt, implementing M4 feedback modes.

        Dispatch logic:
          - E4 (semantic_gap non-empty): use get_completion_repair — asks LLM-C
            to ADD missing legal constraints (not fix syntax, which contradicts E4).
          - E1-E3/E5: use get_execution_validation with counterexample built
            according to the active M4 feedback mode.
        """
        from SMT_Generation_AAAI_Final import classify_error, ErrorType

        # E4: non-empty semantic_gap means LLM-B flagged incomplete encoding.
        # Use the completion prompt so LLM-C knows to ADD constraints, not debug.
        if semantic_gap and hasattr(self.prompter, "get_completion_repair"):
            return self.prompter.get_completion_repair(
                self._prompt_section(section), candidate.code_blocks, semantic_gap
            )

        # Non-E4: build counterexample according to the M4 feedback mode.
        error_type = classify_error(
            candidate.error_message or "", candidate.execution_output or ""
        )
        error_class = error_type.value
        ce_text = candidate.error_message or candidate.execution_output or ""
        counterexample = self._build_counterexample(candidate, error_type, "")

        mode = self._feedback_mode
        if mode == FEEDBACK_NONE:
            # No error context — only section + current code.
            error_info = ""
        elif mode == FEEDBACK_RAW:
            error_info = ce_text
        elif mode == FEEDBACK_CLASS:
            error_info = error_class
        elif mode == FEEDBACK_CLASS_HINT:
            hint = _ERROR_CLASS_HINTS.get(error_class[:2], "")
            error_info = f"{error_class}: {hint}" if hint else error_class
        else:  # full_ce (primary)
            error_info = counterexample

        return self.prompter.get_execution_validation(
            self._prompt_section(section), candidate.code_blocks, error_info
        )

    # ------------------------------------------------------------------
    # CEGAR convergence profile
    # ------------------------------------------------------------------

    def _cegar_loop(
        self,
        section: dict,
        candidate: Candidate,
        semantic_gap: str,
        metric,
    ) -> tuple[bool, Candidate]:
        self._cegar_iter_scores = []
        orig_score_fn = self.oracle.execute_and_score

        def _intercepted_score(c: Candidate) -> None:
            orig_score_fn(c)
            # Apply M2 oracle mode override to stored semantic_score
            if self._oracle_mode != ORACLE_MODE_FULL:
                c.semantic_score = self._compute_oracle_score(c)
            self._cegar_iter_scores.append(round(c.semantic_score, 4))

        self.oracle.execute_and_score = _intercepted_score
        try:
            result = super()._cegar_loop(section, candidate, semantic_gap, metric)
        finally:
            self.oracle.execute_and_score = orig_score_fn

        return result

    # ------------------------------------------------------------------
    # Cascade candidate fallback
    # ------------------------------------------------------------------

    def generate_and_execute(self, section: dict) -> SectionMetric:
        """Algorithm 1 (paper_exact) is this pipeline's only algorithm -- delegates directly to
        SMT_Generation_AAAI_Final.py's _generate_and_execute_paper_exact. The prior cascade-fallback override
        this method used to run under algorithm_mode="legacy" has been removed as a selectable option; see
        _unused_legacy_generate_and_execute below (kept only for reference, no longer reachable)."""
        return self._generate_and_execute_paper_exact(section)

    def _unused_legacy_generate_and_execute(self, section: dict) -> SectionMetric:
        section_id = section.get("section_number", "Section")
        safe_id    = self.sanitize(section_id)
        start_time = time.time()

        metric = SectionMetric(
            section_id=section_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            beam_width=self.beam_width,
            candidates_generated=0,
        )
        log: list[str] = [
            f"REFINE-SMT Run\n"
            f"Section : {section_id}\n"
            f"Time    : {metric.timestamp}\n"
            f"Models  : A={self.model} | B={self.agnostic_model} | C={self.corrector_model}\n"
            f"{'='*70}\n\n"
        ]

        context_error = ""
        context_code  = ""
        best_candidate: Candidate | None = None

        for outer in range(self.max_outer_attempts):
            metric.llm_a_attempts += 1
            logger.info(
                "[%s] ════════ Outer attempt %d/%d ════════",
                section_id, outer + 1, self.max_outer_attempts,
            )
            log.append(
                f"\n{'═'*70}\n"
                f"OUTER ATTEMPT {outer+1}/{self.max_outer_attempts}  |  Section: {section_id}\n"
                f"{'═'*70}\n"
            )

            # Phase 1: Beam generation
            candidates = self._generate_beam(section, context_error, context_code)
            metric.candidates_generated += len(candidates)

            # Score all candidates; _select_best_candidate also fills self._ranked_candidates
            self._select_best_candidate(candidates, section_id, outer + 1, log)

            # Cascade: iterate ranked candidates before re-generating the beam
            cascade_tried  = 0
            repaired: Candidate | None = self._ranked_candidates[0] if self._ranked_candidates else None
            gap            = ""
            aligned        = False

            for candidate in self._ranked_candidates:

                # Only cascade through candidates that pass the oracle threshold.
                # Sub-threshold candidates are skipped entirely — they are not
                # worth sending to LLM-B or LLM-C.
                if candidate.semantic_score < self.ORACLE_PASS_THRESHOLD:
                    err = (classify_error(candidate.error_message).value
                           if candidate.error_message else "E1_syntax")
                    logger.warning(
                        "[%s] Candidate score %.2f below threshold %.2f — "
                        "stopping cascade, regenerating beam. error=%s",
                        section_id, candidate.semantic_score,
                        self.ORACLE_PASS_THRESHOLD, err,
                    )
                    log.append(
                        f"[Outer {outer+1}] ⚠ No more above-threshold candidates "
                        f"(score={candidate.semantic_score:.2f} < {self.ORACLE_PASS_THRESHOLD}). "
                        f"Regenerating: {err}\n"
                    )
                    context_error = err
                    context_code  = ""
                    break

                cascade_tried += 1

                # Phase 2: LLM-B semantic alignment
                logger.info(
                    "[%s] Oracle threshold passed (%.2f). LLM-B check (cascade %d)...",
                    section_id, candidate.semantic_score, cascade_tried,
                )
                aligned, gap, align_score = self._semantic_alignment_check(
                    section, candidate
                )
                log.append(
                    f"[Outer {outer+1}] LLM B (cascade {cascade_tried}): "
                    f"{'✔ ALIGNED' if aligned else '✘ GAP'} (score={align_score:.2f})\n"
                    f"Gap: {gap or 'none'}\n\n"
                )

                if aligned:
                    _code = "\n".join(candidate.code_blocks) if candidate.code_blocks else ""
                    if self.e4v_detection_enabled and _code and detect_e4_vacuous(_code):
                        logger.info(
                            "[%s] E4v detected after LLM-B alignment (cascade=%d) "
                            "— routing to CEGAR for vacuous-antecedent repair.",
                            section_id, cascade_tried,
                        )
                        log.append(
                            f"[Outer {outer+1}] E4v detected after LLM-B alignment "
                            f"(cascade {cascade_tried}) — routing to CEGAR.\n"
                        )
                        aligned = False
                        gap = build_e4v_gap(_code)
                    else:
                        logger.info(
                            "[%s] Aligned. Done. (cascade=%d, align_score=%.2f)",
                            section_id, cascade_tried, align_score,
                        )
                        metric.final_success = True
                        metric.semantic_alignment_confirmed = align_score
                        best_candidate = candidate
                        break

                metric.llm_b_semantic_flags += 1

                # E4 skip: incomplete-encoding gaps are hard for LLM-C to fix;
                # regenerating the beam with the gap as context is more effective.
                if self._e4_cegar_skip and gap and any(kw in gap.lower() for kw in _E4_GAP_KEYWORDS):
                    logger.info(
                        "[%s] E4 gap — skipping CEGAR, re-generating beam "
                        "with completeness context (cascade %d).",
                        section_id, cascade_tried,
                    )
                    log.append(
                        f"[Outer {outer+1}] E4 skip (cascade {cascade_tried}): "
                        f"re-generating beam with gap context.\n"
                    )
                    context_error = "E4_incomplete_encoding"
                    context_code  = "\n".join(candidate.code_blocks)
                    repaired = candidate
                    break

                # Phase 3: LLM-C CEGAR repair
                cegar_success, repaired = self._cegar_loop(
                    section, candidate, gap, metric
                )
                log.append(
                    f"[Outer {outer+1}] CEGAR (cascade {cascade_tried}): "
                    f"{'✔ SUCCESS' if cegar_success else '✘ FAILED — trying next candidate'}\n"
                    f"Error sequence: {metric.error_type_sequence}\n\n"
                )

                if cegar_success:
                    metric.final_success = True
                    # CEGAR repaired the candidate: use its oracle score as the
                    # alignment score. The base class _cegar_loop only succeeds
                    # when repaired.semantic_score >= oracle_threshold, so this
                    # value is always >= 0.7, correctly registering as aligned
                    # in save_aggregate_metrics (which uses a 0.5 threshold).
                    metric.semantic_alignment_confirmed = repaired.semantic_score
                    best_candidate = repaired
                    break

                # Both LLM-B and CEGAR failed — try next above-threshold candidate
                logger.info(
                    "[%s] CEGAR failed on cascade candidate %d — next.",
                    section_id, cascade_tried,
                )
                continue

            # Persist cascade count into slm_extra for metrics
            self._slm_extra_data["cascade_candidates_tried"] = (
                self._slm_extra_data.get("cascade_candidates_tried", 0) + cascade_tried
            )

            if metric.final_success:
                break

            # All ranked candidates exhausted — update context for next beam
            if repaired and repaired.code_blocks:
                context_error = repaired.error_message or gap
                context_code  = "\n".join(repaired.code_blocks)

        # ── Final recording (mirrors base class exactly) ──────────────────
        metric.wall_time_sec = round(time.time() - start_time, 2)
        metric.final_error_type = (
            ErrorType.NONE.value if metric.final_success
            else (metric.error_type_sequence[-1]
                  if metric.error_type_sequence else "E1_syntax")
        )
        status = "SUCCESS" if metric.final_success else "FAIL"
        log.append(
            f"\n{'='*70}\n"
            f"FINAL STATUS     : {status}\n"
            f"Wall Time        : {metric.wall_time_sec}s\n"
            f"LLM A Attempts   : {metric.llm_a_attempts}\n"
            f"LLM B Flags      : {metric.llm_b_semantic_flags}\n"
            f"LLM C Iterations : {metric.llm_c_attempts}\n"
            f"Error Sequence   : {metric.error_type_sequence}\n"
            f"Semantic Aligned : {metric.semantic_alignment_confirmed}\n"
        )
        if best_candidate:
            log.append(
                f"\n=== Final Z3 Program ===\n"
                + "\n".join(best_candidate.code_blocks) + "\n\n"
                + f"=== Final Execution Output ===\n"
                + (best_candidate.execution_output or "") + "\n"
            )

        final_path = os.path.join(self.output_dir, f"Section_{safe_id}_{status}.txt")
        self.save_file(final_path, "\n".join(log))
        logger.info("[%s] Log saved → %s", section_id, final_path)

        if best_candidate and best_candidate.code_blocks:
            code_header = (
                f"# REFINE-SMT — Final Generated Z3 Code\n"
                f"# Section   : {section_id}\n"
                f"# Status    : {status}\n"
                f"# Timestamp : {metric.timestamp}\n"
                f"# LLM A     : {self.model}\n"
                f"# LLM B     : {self.agnostic_model}\n"
                f"# LLM C     : {self.corrector_model}\n"
                f"# Oracle Score (final) : {best_candidate.semantic_score:.2f}\n"
                f"# Z3 Verdict (final)   : {best_candidate.z3_verdict}\n"
                f"# Semantic Aligned     : {metric.semantic_alignment_confirmed}\n"
                f"# {'='*60}\n\n"
            )
            code_path = os.path.join(self.output_dir, f"Section_{safe_id}_{status}.py")
            self.save_file(code_path, code_header + "\n\n".join(best_candidate.code_blocks))
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)
        else:
            logger.warning("[%s] No valid code to save — all attempts exhausted.", section_id)

        return metric

    # ------------------------------------------------------------------
    # Augment section_metrics.json
    # ------------------------------------------------------------------

    def process_act(self, section: dict, filename: str) -> None:
        self._beam_log = []
        self._ranked_candidates = []
        self._slm_extra_data = {"n_gaps": 0, "cascade_candidates_tried": 0}
        self._cegar_iter_scores = []
        self._oracle_component_log = {}

        # Pre-compute ground truth deontic for σD oracle
        gt_deontic = _extract_gt_deontic(section)
        self._slm_extra_data["_current_gt_deontic"] = gt_deontic

        super().process_act(section, filename)

        metrics_file = os.path.join(self.output_dir, "section_metrics.json")
        try:
            with open(metrics_file, encoding="utf-8") as f:
                data = json.load(f)
        except FileNotFoundError:
            data = {}

        all_scores = [s for entry in self._beam_log for s in entry["scores"]]
        subsection_count = len(
            (section.get("structured_annotation") or {}).get("subsections", [])
            or (section.get("source") or {}).get("sub_sections", [])
        )

        data["slm_metadata"] = {
            "run_id":     self.run_id,
            "experiment": self.experiment,
            "variant":    self.variant,
            "act":        self.act_name,
        }
        data["beam_log"]       = self._beam_log
        data["beam_diversity"] = round(_score_diversity(all_scores), 4)
        data["slm_extra"] = {
            "ground_truth_deontic":    gt_deontic,
            "deontic_type_predicted":  self._slm_extra_data.get("deontic_type_predicted"),
            "deontic_confirmed":       self._slm_extra_data.get("deontic_confirmed", False),
            "n_gaps":                  self._slm_extra_data.get("n_gaps", 0),
            "cegar_iter_scores":       self._cegar_iter_scores,
            "clause_complexity":       subsection_count,
            "cascade_candidates_tried": self._slm_extra_data.get("cascade_candidates_tried", 0),
        }
        data["oracle_components"] = self._oracle_component_log
        data["module_flags"] = {
            "oracle_mode":   self._oracle_mode,
            "llm_b_skip":    self._llm_b_skip,
            "llm_b_format":  self._llm_b_format,
            "feedback_mode": self._feedback_mode,
        }
        if self._detailed_logging:
            data["input_provenance"] = dict(self._input_provenance)
        data["generation_params"] = {
            "llm_a_temperature": self._llm_a_temperature,
            "llm_b_temperature": self._llm_b_temperature,
            "llm_c_temperature": self._llm_c_temperature,
            "llm_a_max_tokens":  self._llm_a_max_tokens,
            "llm_b_max_tokens":  self._llm_b_max_tokens,
            "llm_c_max_tokens":  self._llm_c_max_tokens,
        }

        with open(metrics_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        logger.debug(
            "[%s] slm_metadata written — beam_diversity=%.4f  gt_deontic=%s  oracle_mode=%s",
            filename, data["beam_diversity"], gt_deontic, self._oracle_mode,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_DEONTIC_LABEL_MAP = {
    "#obligation":  "O",
    "#prohibition": "F",
    "#permission":  "P",
}

# Natural-language hints per error class for M4 class_hint feedback
_ERROR_CLASS_HINTS = {
    "E1": "Fix syntax: check parentheses, indentation, and Python keyword usage.",
    "E2": "Fix Z3 encoding: ensure correct Sort declarations and constraint types.",
    "E3": "Fix semantic inversion: check that obligation/prohibition polarity is correct.",
    "E4": "Fix incomplete encoding: all clauses and exceptions must be represented.",
    "E5": "Fix over-constraining: remove redundant constraints that block satisfiability.",
}


def _extract_gt_deontic(section: dict) -> str:
    counts = section.get("label_metrics", {}).get("counts", {})
    deontic_counts = {
        label: counts.get(raw, 0)
        for raw, label in _DEONTIC_LABEL_MAP.items()
    }
    best_label = max(deontic_counts, key=deontic_counts.get)
    return best_label if deontic_counts[best_label] > 0 else "unknown"


def _score_diversity(scores: list[float]) -> float:
    n = len(scores)
    if n < 2:
        return 0.0
    mean = sum(scores) / n
    return sqrt(sum((s - mean) ** 2 for s in scores) / n)


def _make_run_id(experiment: str, variant: str, act: str) -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    parts = [p for p in (experiment, variant, act, ts) if p]
    return "SLM-" + "-".join(parts)
