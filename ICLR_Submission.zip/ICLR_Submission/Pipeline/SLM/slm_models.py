"""
HuggingFace local inference backend for REFINE-SMT SLM experiments.

Uses a class-level cache so large models (7B+) are loaded once per process
and reused across all sections and ablation variants.

Temperature protocol (from Theorem 2.2):
  LLM-A: T=0.7  (do_sample=True)  — beam diversity requires stochastic sampling
  LLM-B: T=0.0  (do_sample=False) — deterministic semantic alignment
  LLM-C: T=0.0  (do_sample=False) — deterministic CEGAR repair
"""
from __future__ import annotations

import logging
import warnings

logger = logging.getLogger(__name__)

# Suppress known-cosmetic transformers warnings that bury diagnostic log output
# during long benchmark runs (180 sections × multiple LLM calls each).
# Root cause: the transformers pipeline API changed in 4.40+ to prefer
# GenerationConfig objects over raw kwargs; we're on a pinned HPC version.
# These warnings are non-actionable and do not affect correctness.
warnings.filterwarnings(
    "ignore",
    message=r"Both `max_new_tokens`.*and `max_length`.*seem to have been set",
)
warnings.filterwarnings(
    "ignore",
    message=r"Passing `generation_config` together with generation-related arguments",
)
warnings.filterwarnings(
    "ignore",
    message=r"Ignoring clean_up_tokenization_spaces=True for BPE tokenizer",
)

try:
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from transformers import pipeline as hf_pipeline
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False
    logger.warning(
        "transformers / torch not installed — HuggingFace inference unavailable. "
        "Run: pip install transformers torch accelerate psutil"
    )

# psutil is required by accelerate's get_balanced_memory (device_map='auto').
# If missing, fall back to explicit single-GPU placement to avoid the crash.
try:
    import psutil  # noqa: F401
    _PSUTIL_OK = True
except ImportError:
    _PSUTIL_OK = False
    logger.warning(
        "psutil not installed — device_map='auto' may fail. "
        "Falling back to device_map='cuda:0'. "
        "Install with: pip install psutil"
    )

# Temperature per role (Theorem 2.2)
TEMPERATURE_LLM_A = 0.7
TEMPERATURE_LLM_B = 0.0
TEMPERATURE_LLM_C = 0.0


class HuggingFaceModel:
    """
    Shared, process-level cache of HuggingFace text-generation pipelines.

    Usage:
        text = HuggingFaceModel.call(model, prompt, temperature=0.7)   # LLM-A
        text = HuggingFaceModel.call(model, prompt, temperature=0.0)   # LLM-B/C
    """

    _cache: dict[str, object] = {}

    @classmethod
    def get(cls, model_name: str) -> object:
        if not HF_AVAILABLE:
            raise RuntimeError(
                "transformers and torch are required for HuggingFace inference.\n"
                "Install with: pip install transformers torch accelerate psutil"
            )
        if model_name not in cls._cache:
            logger.info("Loading HuggingFace model: %s  (first use — may take minutes)", model_name)

            import os
            offline = os.environ.get("HF_HUB_OFFLINE", "0") == "1" or \
                      os.environ.get("TRANSFORMERS_OFFLINE", "0") == "1"

            _on_gpu = HF_AVAILABLE and torch.cuda.is_available()
            # float16 is not supported on CPU and produces garbage outputs;
            # use float32 on CPU, float16 on GPU to save VRAM.
            _dtype = torch.float16 if _on_gpu else torch.float32

            load_kwargs = dict(
                dtype=_dtype,
                trust_remote_code=True,
                local_files_only=offline,
            )

            # device_map="auto" requires psutil; fall back to explicit GPU if missing.
            if _PSUTIL_OK:
                load_kwargs["device_map"] = "auto"
            else:
                load_kwargs["device_map"] = "cuda:0" if _on_gpu else "cpu"
                logger.warning("psutil missing — placing model on %s", load_kwargs["device_map"])

            if not _on_gpu:
                logger.info("No CUDA device — loading model in float32 on CPU")

            tokenizer = AutoTokenizer.from_pretrained(
                model_name, trust_remote_code=True, local_files_only=offline
            )
            # Set pad_token on the tokenizer directly to avoid the pipeline-level
            # pad_token_id kwarg deprecation introduced in transformers 4.40+.
            if tokenizer.pad_token_id is None:
                tokenizer.pad_token_id = tokenizer.eos_token_id

            model = AutoModelForCausalLM.from_pretrained(model_name, **load_kwargs)

            # Clear stale max_length so it does not conflict with max_new_tokens.
            if hasattr(model, "generation_config"):
                model.generation_config.max_length = None
            if hasattr(model, "config") and hasattr(model.config, "max_length"):
                model.config.max_length = None

            cls._cache[model_name] = hf_pipeline(
                "text-generation",
                model=model,
                tokenizer=tokenizer,
                return_full_text=False,
            )
            logger.info("Model ready: %s  (device_map=%s)", model_name, load_kwargs["device_map"])
        return cls._cache[model_name]

    @classmethod
    def call(
        cls,
        model_name: str,
        prompt: str,
        temperature: float = TEMPERATURE_LLM_A,
        max_new_tokens: int = 4096,
        system_message: str = "",
        seed: int | None = None,
    ) -> str:
        """
        Generate text from a HuggingFace model.

        Args:
            model_name:     HuggingFace model ID
            prompt:         Full prompt string
            temperature:    0.0 → greedy (do_sample=False), >0 → sampling
            max_new_tokens: Maximum tokens to generate (per-role values set in SLMRefineSMT)
            system_message: Optional system-role message prepended for instruction-tuned models.
                            Used to constrain output format (e.g. force code-fence output for LLM-C).
            seed:           Optional -- if given, seeds torch's RNG immediately before sampling
                            (scripts/additional_runs/'s seed-robustness study). None (default)
                            preserves EXACT prior behavior -- no seeding, matching every other
                            existing caller/ablation that doesn't pass this argument.

        Returns:
            Generated text string (no prompt echo).
        """
        pipe = cls.get(model_name)
        greedy = temperature == 0.0
        if seed is not None:
            torch.manual_seed(seed)
        generation_kwargs: dict = {"do_sample": not greedy, "max_new_tokens": max_new_tokens}
        if not greedy:
            generation_kwargs["temperature"] = temperature
        # Instruction-tuned models (Qwen-Instruct, Phi-4, DeepSeek-Instruct, etc.)
        # require the chat template to produce structured output with code fences.
        # Pass a message list so the pipeline applies the template automatically.
        tokenizer = pipe.tokenizer
        _has_template = bool(getattr(tokenizer, "chat_template", None))
        _primed_fence = False

        if _has_template:
            messages = []
            if system_message:
                messages.append({"role": "system", "content": system_message})
            messages.append({"role": "user", "content": prompt})
            inp = messages
        else:
            # Base model (no chat template): embed system message as plain text
            # and prime the model with an opening code fence so it generates code
            # directly rather than prose. With return_full_text=False the fence
            # prefix is NOT echoed back, so we prepend it to the output below.
            if system_message:
                inp = f"{system_message}\n\n{prompt}\n\n```python\n"
                _primed_fence = True
            else:
                inp = prompt

        result = pipe(inp, **generation_kwargs)
        text = result[0]["generated_text"]
        if _primed_fence:
            text = "```python\n" + text
        return text

    @classmethod
    def evict(cls, model_name: str) -> None:
        """Remove a model from cache to free GPU memory before loading the next."""
        if model_name in cls._cache:
            del cls._cache[model_name]
            if HF_AVAILABLE and torch.cuda.is_available():
                torch.cuda.empty_cache()
            logger.info("Evicted model from cache: %s", model_name)

    @classmethod
    def clear_all(cls) -> None:
        cls._cache.clear()
        if HF_AVAILABLE and torch.cuda.is_available():
            torch.cuda.empty_cache()
        logger.info("Model cache cleared")
