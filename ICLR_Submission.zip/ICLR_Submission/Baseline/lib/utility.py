import re
import json
import logging
from pydantic import BaseModel, Field, ValidationError
from typing import List, Optional, Dict, Any

_CODE_FENCE_RE = re.compile(r"```(?:json)?\s*(\{.*?\})\s*```", re.DOTALL | re.IGNORECASE)

logger = logging.getLogger(__name__)


def parse_annotation(raw: Any, src: str) -> Optional[Any]:
    """Parse an annotation field that may be a dict, list, or JSON string."""
    if isinstance(raw, (dict, list)):
        return raw                                          # already parsed

    if not isinstance(raw, str):
        logger.warning("Unexpected annotation type %s in %s", type(raw), src)
        return None

    # Normalize literal escaped newlines (e.g. "\\n" -> "\n")
    if "\\n" in raw:
        logger.debug("Detected literal escaped newlines in %s. Normalizing...", src)
        try:
            raw = bytes(raw, "utf-8").decode("unicode_escape")
        except Exception as exc:
            logger.warning("Normalization warning in %s: %s. Proceeding with original.", src, exc)

    match = _CODE_FENCE_RE.search(raw)                     # ```json ... ``` fence
    if match:
        try:
            return json.loads(match.group(1).strip())
        except json.JSONDecodeError as exc:
            logger.warning("Fence JSON parse error in %s: %s", src, exc)

    try:                                                    # bare JSON string
        return json.loads(raw.strip())
    except json.JSONDecodeError:
        pass

    logger.warning("Could not parse annotation in %s", src)
    return None


class Utility:
    def extract_json_robust(self, file_path: str) -> Optional[Any]:
        """Load a JSON file and robustly parse its 'annotation' field."""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = json.load(f)
        except FileNotFoundError:
            logger.error("File '%s' not found.", file_path)
            return None
        except Exception as exc:
            logger.error("Unexpected error reading '%s': %s", file_path, exc)
            return None

        raw_annotation = content.get("annotation")
        if raw_annotation is None:
            logger.warning("No 'annotation' key found in %s", file_path)
            return None

        return parse_annotation(raw_annotation, src=file_path)