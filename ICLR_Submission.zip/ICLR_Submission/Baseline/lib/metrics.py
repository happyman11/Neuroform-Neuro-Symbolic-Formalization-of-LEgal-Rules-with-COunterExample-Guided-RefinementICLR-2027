"""
metrics.py — Pure metric functions for REFINE-SMT SLM evaluation.

All functions take a list of section log dicts (loaded from section_metrics.json)
and return a flat metrics dict. No I/O — import and call directly.

Metric groups (per strategy document + AAAI-2026 paper):
  Generation (A1) : syntax_validity_rate, oracle_pass_rate, beam_diversity,
                    symbolic_consistency_rate
  Semantic   (A2) : e3_detection_rate, deontic_consistency_rate,
                    false_alignment_rate, mean_semantic_alignment,
                    deontic_type_accuracy, deontic_type_distribution,
                    deontic_confirmed_rate, mean_gaps_per_section,
                    gap_to_fix_rate, success_rate_by_deontic_type
  Repair     (A3) : repair_success_rate, mean_convergence_iters,
                    repair_stability_score, per_error_class_repair_rate,
                    per_error_class_mean_iters, cumulative_fix_rate_by_iter,
                    marginal_gain_by_iter
  System-level    : end_to_end_success_rate, mean_wall_time, mean_llm_calls,
                    mean_llm_a_calls, mean_llm_b_calls, mean_llm_c_calls,
                    success_rate_by_clause_complexity, oracle_component_analysis
  M2 oracle       : deontic_oracle_score (σD = σ + 0.2·1[deontic match], capped 1.0)
"""
from __future__ import annotations

import math
from typing import Any


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _rate(flags: list[bool]) -> float:
    return sum(flags) / len(flags) if flags else 0.0


def _error_seq(log: dict) -> list[str]:
    return log.get("error_analysis", {}).get("error_type_sequence", [])


def _attempts(log: dict) -> dict:
    return log.get("attempt_counts", {})


def _results(log: dict) -> dict:
    return log.get("results", {})


# ---------------------------------------------------------------------------
# Generation metrics (A1)
# ---------------------------------------------------------------------------

def syntax_validity_rate(logs: list[dict]) -> float:
    """Fraction of sections with no E1_syntax errors."""
    flags = ["E1_syntax" not in _error_seq(lg) for lg in logs]
    return round(_rate(flags), 4)


def oracle_pass_rate(logs: list[dict], threshold: float = 0.7) -> float:
    """
    Fraction of sections where the pipeline advanced past the oracle gate.
    Proxy: final_success OR semantic_alignment_confirmed >= threshold
    (the oracle gate was passed at least once if either holds).
    """
    flags = []
    for lg in logs:
        r = _results(lg)
        passed = r.get("final_success", False) or r.get("semantic_alignment_confirmed", 0.0) >= threshold
        flags.append(passed)
    return round(_rate(flags), 4)


def beam_diversity(logs: list[dict]) -> float:
    """
    Mean beam diversity score (std-dev of oracle scores) across all sections.
    Higher values indicate more diverse candidate exploration.
    """
    divs = [lg.get("beam_diversity", 0.0) for lg in logs if "beam_diversity" in lg]
    return round(_safe_mean(divs), 4)


def symbolic_consistency_rate(logs: list[dict]) -> float:
    """Fraction of sections with no E2_z3_encoding errors."""
    flags = ["E2_z3_encoding" not in _error_seq(lg) for lg in logs]
    return round(_rate(flags), 4)


# ---------------------------------------------------------------------------
# Semantic metrics (A2)
# ---------------------------------------------------------------------------

def e3_detection_rate(logs: list[dict]) -> float:
    """Fraction of sections where LLM-B detected E3 (semantic inversion)."""
    flags = ["E3_semantic_inversion" in _error_seq(lg) for lg in logs]
    return round(_rate(flags), 4)


def deontic_consistency_rate(logs: list[dict], threshold: float = 0.5) -> float:
    """Fraction of sections with semantic_alignment_confirmed >= threshold."""
    flags = [_results(lg).get("semantic_alignment_confirmed", 0.0) >= threshold for lg in logs]
    return round(_rate(flags), 4)


def false_alignment_rate(logs: list[dict]) -> float:
    """
    Fraction of sections where LLM-B reported alignment (score >= 0.5)
    but the section ultimately failed.
    """
    flags = []
    for lg in logs:
        r = _results(lg)
        aligned  = r.get("semantic_alignment_confirmed", 0.0) >= 0.5
        failed   = not r.get("final_success", True)
        flags.append(aligned and failed)
    return round(_rate(flags), 4)


def mean_semantic_alignment(logs: list[dict]) -> float:
    vals = [_results(lg).get("semantic_alignment_confirmed", 0.0) for lg in logs]
    return round(_safe_mean(vals), 4)


# ---------------------------------------------------------------------------
# Repair metrics (A3)
# ---------------------------------------------------------------------------

def repair_success_rate(logs: list[dict]) -> float:
    """
    Fraction of sections where CEGAR was invoked and converged.
    Sections with zero CEGAR attempts are excluded (repair not needed).
    """
    repaired = [lg for lg in logs if _attempts(lg).get("llm_c_cegar_iterations", 0) > 0]
    if not repaired:
        return 1.0  # no repairs needed = all passed before CEGAR
    flags = [_results(lg).get("final_success", False) for lg in repaired]
    return round(_rate(flags), 4)


def mean_convergence_iters(logs: list[dict]) -> float:
    """Mean number of CEGAR iterations per section (including zero for no-repair sections)."""
    vals = [_attempts(lg).get("llm_c_cegar_iterations", 0) for lg in logs]
    return round(_safe_mean(vals), 4)


def repair_stability_score(logs: list[dict]) -> float:
    """
    Fraction of sections where all CEGAR iterations shared the same error type
    (stable, targeted repair vs. oscillating error types).
    Sections with ≤1 CEGAR iteration are counted as stable.
    """
    flags = []
    for lg in logs:
        seq = _error_seq(lg)
        cegar_types = [e for e in seq if e != "E0_none"]
        if len(cegar_types) <= 1:
            flags.append(True)
        else:
            flags.append(len(set(cegar_types)) == 1)
    return round(_rate(flags), 4)


# ---------------------------------------------------------------------------
# System-level metrics
# ---------------------------------------------------------------------------

def end_to_end_success_rate(logs: list[dict]) -> float:
    """Fraction of sections with final_success == True."""
    flags = [_results(lg).get("final_success", False) for lg in logs]
    return round(_rate(flags), 4)


def mean_wall_time(logs: list[dict]) -> float:
    """Mean wall-clock time per section in seconds."""
    vals = [_results(lg).get("wall_time_sec", 0.0) for lg in logs]
    return round(_safe_mean(vals), 2)


def mean_llm_calls(logs: list[dict]) -> float:
    """
    Mean total LLM calls per section.
    Estimate: (outer_attempts × beam_width) + llm_b_flags + llm_c_iters.
    """
    totals = []
    for lg in logs:
        at = _attempts(lg)
        bw = lg.get("beam_width", 3)
        calls = (
            at.get("llm_a_outer_attempts", 1) * bw
            + at.get("llm_b_semantic_flags", 0)
            + at.get("llm_c_cegar_iterations", 0)
        )
        totals.append(calls)
    return round(_safe_mean(totals), 2)


def error_type_distribution(logs: list[dict]) -> dict[str, int]:
    """Count occurrences of each error type across all sections."""
    dist: dict[str, int] = {}
    for lg in logs:
        for e in _error_seq(lg):
            dist[e] = dist.get(e, 0) + 1
    return dict(sorted(dist.items()))


# ---------------------------------------------------------------------------
# Per-role LLM call breakdown  (AAAI §5.4)
# ---------------------------------------------------------------------------

def mean_llm_a_calls(logs: list[dict]) -> float:
    """Mean number of LLM-A (generation) calls per section (outer × beam_width)."""
    vals = []
    for lg in logs:
        at = _attempts(lg)
        bw = lg.get("beam_width", 3)
        vals.append(at.get("llm_a_outer_attempts", 1) * bw)
    return round(_safe_mean(vals), 2)


def mean_llm_b_calls(logs: list[dict]) -> float:
    """Mean number of LLM-B (semantic verifier) calls per section."""
    vals = [_attempts(lg).get("llm_b_semantic_flags", 0) for lg in logs]
    return round(_safe_mean(vals), 2)


def mean_llm_c_calls(logs: list[dict]) -> float:
    """Mean number of LLM-C (CEGAR repair) calls per section."""
    vals = [_attempts(lg).get("llm_c_cegar_iterations", 0) for lg in logs]
    return round(_safe_mean(vals), 2)


# ---------------------------------------------------------------------------
# Deontic type metrics  (AAAI §6.1)
# ---------------------------------------------------------------------------

def _slm_extra(log: dict) -> dict:
    return log.get("slm_extra", {})


def deontic_type_accuracy(logs: list[dict]) -> float:
    """
    Fraction of sections where LLM-B's predicted deontic type matches
    the ground-truth annotation label (O/F/P).
    Only sections where both values are known are included.
    """
    correct = total = 0
    for lg in logs:
        ex = _slm_extra(lg)
        gt  = ex.get("ground_truth_deontic")
        pred = ex.get("deontic_type_predicted")
        if gt and gt != "unknown" and pred:
            total += 1
            if gt == pred:
                correct += 1
    return round(correct / total, 4) if total else 0.0


def deontic_type_distribution(logs: list[dict]) -> dict[str, int]:
    """Count of ground-truth deontic types across all sections (O/F/P/unknown)."""
    dist: dict[str, int] = {"O": 0, "F": 0, "P": 0, "unknown": 0}
    for lg in logs:
        gt = _slm_extra(lg).get("ground_truth_deontic", "unknown")
        dist[gt] = dist.get(gt, 0) + 1
    return dist


def deontic_confirmed_rate(logs: list[dict]) -> float:
    """Fraction of sections where LLM-B confirmed deontic alignment."""
    flags = [bool(_slm_extra(lg).get("deontic_confirmed", False)) for lg in logs]
    return round(_rate(flags), 4)


def mean_gaps_per_section(logs: list[dict]) -> float:
    """Mean number of semantic gaps detected by LLM-B per section."""
    vals = [_slm_extra(lg).get("n_gaps", 0) for lg in logs]
    return round(_safe_mean(vals), 4)


def gap_to_fix_rate(logs: list[dict]) -> float:
    """
    Of sections where LLM-B found gaps (n_gaps > 0), fraction that
    ultimately succeeded (gap was fixed by CEGAR).
    """
    gapped = [lg for lg in logs if _slm_extra(lg).get("n_gaps", 0) > 0]
    if not gapped:
        return 0.0
    flags = [_results(lg).get("final_success", False) for lg in gapped]
    return round(_rate(flags), 4)


def success_rate_by_deontic_type(logs: list[dict]) -> dict[str, float]:
    """
    End-to-end success rate broken down by ground-truth deontic type (O/F/P).
    Only sections with a known deontic type are counted per bucket.
    """
    buckets: dict[str, list[bool]] = {"O": [], "F": [], "P": []}
    for lg in logs:
        dt = _slm_extra(lg).get("ground_truth_deontic", "unknown")
        if dt in buckets:
            buckets[dt].append(_results(lg).get("final_success", False))
    return {dt: round(_rate(flags), 4) for dt, flags in buckets.items()}


# ---------------------------------------------------------------------------
# Repair / CEGAR convergence metrics  (AAAI §6.2)
# ---------------------------------------------------------------------------

_ERROR_CLASSES = ["E1_syntax", "E2_z3_encoding", "E3_semantic_inversion",
                  "E4_incomplete_encoding", "E5_over_constrained"]


def per_error_class_repair_rate(logs: list[dict]) -> dict[str, float]:
    """
    For each error class, fraction of sections (where that class appeared)
    that ultimately succeeded.
    """
    success_by_class: dict[str, list[bool]] = {e: [] for e in _ERROR_CLASSES}
    for lg in logs:
        seq = set(_error_seq(lg))
        succeeded = _results(lg).get("final_success", False)
        for ec in _ERROR_CLASSES:
            if ec in seq:
                success_by_class[ec].append(succeeded)
    return {ec: round(_rate(flags), 4) for ec, flags in success_by_class.items()}


def per_error_class_mean_iters(logs: list[dict]) -> dict[str, float]:
    """
    Mean CEGAR iterations for sections where a given error class appeared.
    """
    iters_by_class: dict[str, list[int]] = {e: [] for e in _ERROR_CLASSES}
    for lg in logs:
        seq = set(_error_seq(lg))
        n_iters = _attempts(lg).get("llm_c_cegar_iterations", 0)
        for ec in _ERROR_CLASSES:
            if ec in seq:
                iters_by_class[ec].append(n_iters)
    return {ec: round(_safe_mean(vals), 4) for ec, vals in iters_by_class.items()}


def cumulative_fix_rate_by_iter(
    logs: list[dict], max_iter: int = 5, oracle_threshold: float = 0.7
) -> dict[str, float]:
    """
    Cumulative fraction of sections that first succeeded at or before iteration k.
    Only sections that entered CEGAR (llm_c_cegar_iterations > 0) are considered.
    cegar_iter_scores[i] is the oracle score after repair i (index 0 = iter 1).
    """
    cegar_logs = [lg for lg in logs if _attempts(lg).get("llm_c_cegar_iterations", 0) > 0]
    n = len(cegar_logs)
    if n == 0:
        return {}

    # We use the stored per-iteration scores when available
    # (written by SLMRefineSMT._cegar_loop); fall back to final_success at max_iter.
    cumulative: dict[str, float] = {}
    threshold = oracle_threshold
    for k in range(1, max_iter + 1):
        fixed = 0
        for lg in cegar_logs:
            iter_scores = _slm_extra(lg).get("cegar_iter_scores", [])
            if iter_scores:
                # succeeded if any of the first k scores crossed threshold
                fixed += any(s >= threshold for s in iter_scores[:k])
            else:
                # fallback: only know overall success
                if k == max_iter:
                    fixed += _results(lg).get("final_success", False)
        cumulative[f"iter_{k}"] = round(fixed / n, 4)
    return cumulative


def marginal_gain_by_iter(logs: list[dict], max_iter: int = 5) -> dict[str, float]:
    """
    Marginal improvement (percentage points) from each successive CEGAR iteration.
    Derived from cumulative_fix_rate_by_iter.
    """
    cum = cumulative_fix_rate_by_iter(logs, max_iter)
    if not cum:
        return {}
    keys = [f"iter_{k}" for k in range(1, max_iter + 1)]
    gains: dict[str, float] = {}
    prev = 0.0
    for k in keys:
        rate = cum.get(k, 0.0)
        gains[k] = round(rate - prev, 4)
        prev = rate
    return gains


# ---------------------------------------------------------------------------
# Clause complexity stratification  (AAAI §6.3)
# ---------------------------------------------------------------------------

def success_rate_by_clause_complexity(logs: list[dict]) -> dict[str, float]:
    """
    End-to-end success rate by section complexity bucket:
      simple   = 1 subsection
      moderate = 2–3 subsections
      complex  = 4+ subsections
    """
    buckets: dict[str, list[bool]] = {"simple": [], "moderate": [], "complex": []}
    for lg in logs:
        n_sub = _slm_extra(lg).get("clause_complexity", 0)
        succeeded = _results(lg).get("final_success", False)
        if n_sub <= 1:
            buckets["simple"].append(succeeded)
        elif n_sub <= 3:
            buckets["moderate"].append(succeeded)
        else:
            buckets["complex"].append(succeeded)
    return {k: round(_rate(v), 4) for k, v in buckets.items()}


# ---------------------------------------------------------------------------
# Oracle component analysis  (AAAI §6.3)
# ---------------------------------------------------------------------------

def oracle_component_analysis(logs: list[dict]) -> dict[str, float]:
    """
    Analyses how often each oracle score component contributes to a passing score.
    The oracle scoring rubric (SemanticOracle):
      +0.5  executability
      +0.2  solver reached
      +0.2  verdict != unknown
      +0.1  proof extractable
    We infer component contributions from beam_log scores via thresholds.
    """
    n = len(logs)
    if n == 0:
        return {}

    exec_ok   = 0   # score >= 0.5 → executed without crash
    solver_ok = 0   # score >= 0.7 → solver reached
    verdict_ok = 0  # score >= 0.9 → verdict known
    proof_ok  = 0   # score == 1.0 → proof extractable

    total_candidates = 0
    for lg in logs:
        beam_log = lg.get("beam_log", [])
        for entry in beam_log:
            for score in entry.get("scores", []):
                total_candidates += 1
                if score >= 0.5:  exec_ok   += 1
                if score >= 0.7:  solver_ok += 1
                if score >= 0.9:  verdict_ok += 1
                if score >= 1.0:  proof_ok  += 1

    if total_candidates == 0:
        return {}
    return {
        "executability_rate":  round(exec_ok    / total_candidates, 4),
        "solver_reached_rate": round(solver_ok  / total_candidates, 4),
        "verdict_known_rate":  round(verdict_ok / total_candidates, 4),
        "proof_extract_rate":  round(proof_ok   / total_candidates, 4),
    }


# ---------------------------------------------------------------------------
# σD Deontic-augmented oracle metric  (M2 ablation, paper §5.2.2)
# ---------------------------------------------------------------------------

def deontic_oracle_score(logs: list[dict]) -> dict[str, float]:
    """
    Compute σD scores from stored oracle_components data.

    σD(φ, c) = min(1.0, σ(φ, c) + 0.2 · 1[deont(φ) = deont(yc)])

    For logs produced with oracle_mode="sigma_d", the final_score in
    oracle_components already includes the deontic bonus.  For other runs,
    we post-hoc compute how much the bonus would have changed scores.

    Returns:
        mean_sigma_d          : mean σD across all sections
        deontic_bonus_rate    : fraction of sections where the bonus applied
        mean_bonus_applied    : mean bonus value added (0.0 or 0.2)
        sigma_d_vs_sigma_delta: mean(σD - σ) across sections (uplift)
    """
    if not logs:
        return {}

    sigma_d_scores: list[float] = []
    sigma_scores:   list[float] = []
    bonus_applied:  list[float] = []

    for lg in logs:
        components = lg.get("oracle_components", {})
        slm_extra  = _slm_extra(lg)

        # Base σ
        if components:
            base_sigma = components.get("final_score",
                          # Reconstruct from components if available
                          0.5 * components.get("exec",    0.0)
                        + 0.2 * components.get("solver",  0.0)
                        + 0.2 * components.get("verdict", 0.0)
                        + 0.1 * components.get("proof",   0.0))
        else:
            # Fall back to best beam score as proxy
            beam_log = lg.get("beam_log", [])
            all_scores = [s for e in beam_log for s in e.get("scores", [])]
            base_sigma = max(all_scores) if all_scores else 0.0

        # Deontic bonus
        gt    = slm_extra.get("ground_truth_deontic", "unknown")
        pred  = slm_extra.get("deontic_type_predicted")
        if pred is not None:
            pred_mapped = {"obligation": "O", "prohibition": "F",
                           "permission": "P"}.get(str(pred).lower(), str(pred))
        else:
            pred_mapped = None

        bonus = 0.2 if (gt != "unknown" and pred_mapped is not None
                        and gt == pred_mapped) else 0.0
        sigma_d = min(1.0, base_sigma + bonus)

        sigma_scores.append(base_sigma)
        sigma_d_scores.append(sigma_d)
        bonus_applied.append(bonus)

    return {
        "mean_sigma":             round(_safe_mean(sigma_scores),   4),
        "mean_sigma_d":           round(_safe_mean(sigma_d_scores), 4),
        "deontic_bonus_rate":     round(_rate([b > 0 for b in bonus_applied]), 4),
        "mean_bonus_applied":     round(_safe_mean(bonus_applied),  4),
        "sigma_d_vs_sigma_delta": round(
            _safe_mean([sd - s for sd, s in zip(sigma_d_scores, sigma_scores)]), 4
        ),
    }


# ---------------------------------------------------------------------------
# Aggregate — compute all metrics at once
# ---------------------------------------------------------------------------

def compute_all(logs: list[dict], oracle_threshold: float = 0.7) -> dict[str, Any]:
    """Compute every metric and return a flat dict."""
    return {
        # Generation (A1)
        "syntax_validity_rate":            syntax_validity_rate(logs),
        "oracle_pass_rate":                oracle_pass_rate(logs, oracle_threshold),
        "beam_diversity":                  beam_diversity(logs),
        "symbolic_consistency_rate":       symbolic_consistency_rate(logs),
        # Semantic (A2)
        "e3_detection_rate":               e3_detection_rate(logs),
        "deontic_consistency_rate":        deontic_consistency_rate(logs),
        "false_alignment_rate":            false_alignment_rate(logs),
        "mean_semantic_alignment":         mean_semantic_alignment(logs),
        "deontic_type_accuracy":           deontic_type_accuracy(logs),
        "deontic_type_distribution":       deontic_type_distribution(logs),
        "deontic_confirmed_rate":          deontic_confirmed_rate(logs),
        "mean_gaps_per_section":           mean_gaps_per_section(logs),
        "gap_to_fix_rate":                 gap_to_fix_rate(logs),
        "success_rate_by_deontic_type":    success_rate_by_deontic_type(logs),
        # Repair (A3)
        "repair_success_rate":             repair_success_rate(logs),
        "mean_convergence_iters":          mean_convergence_iters(logs),
        "repair_stability_score":          repair_stability_score(logs),
        "per_error_class_repair_rate":     per_error_class_repair_rate(logs),
        "per_error_class_mean_iters":      per_error_class_mean_iters(logs),
        "cumulative_fix_rate_by_iter":     cumulative_fix_rate_by_iter(logs),
        "marginal_gain_by_iter":           marginal_gain_by_iter(logs),
        # System-level
        "end_to_end_success_rate":         end_to_end_success_rate(logs),
        "mean_wall_time_sec":              mean_wall_time(logs),
        "mean_llm_calls":                  mean_llm_calls(logs),
        "mean_llm_a_calls":                mean_llm_a_calls(logs),
        "mean_llm_b_calls":                mean_llm_b_calls(logs),
        "mean_llm_c_calls":                mean_llm_c_calls(logs),
        "success_rate_by_clause_complexity": success_rate_by_clause_complexity(logs),
        "oracle_component_analysis":       oracle_component_analysis(logs),
        "deontic_oracle_score":            deontic_oracle_score(logs),
        "error_type_distribution":         error_type_distribution(logs),
        "n_sections":                      len(logs),
    }


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json

    mock_logs = [
        {
            "results": {"final_success": True, "semantic_alignment_confirmed": 0.85, "wall_time_sec": 40.0},
            "attempt_counts": {"llm_a_outer_attempts": 1, "llm_b_semantic_flags": 1, "llm_c_cegar_iterations": 0, "beam_candidates_generated": 3},
            "error_analysis": {"error_type_sequence": ["E0_none"]},
            "beam_log": [{"outer": 1, "scores": [0.9, 0.7, 0.5], "verdicts": ["SAT", "SAT", "UNSAT"], "error_types": ["E0_none", "E0_none", "E1_syntax"]}],
            "beam_diversity": 0.15, "beam_width": 3,
            "slm_extra": {
                "ground_truth_deontic": "O", "deontic_type_predicted": "O",
                "deontic_confirmed": True, "n_gaps": 1,
                "cegar_iter_scores": [], "clause_complexity": 2,
            },
        },
        {
            "results": {"final_success": True, "semantic_alignment_confirmed": 0.70, "wall_time_sec": 92.0},
            "attempt_counts": {"llm_a_outer_attempts": 2, "llm_b_semantic_flags": 1, "llm_c_cegar_iterations": 2, "beam_candidates_generated": 6},
            "error_analysis": {"error_type_sequence": ["E2_z3_encoding", "E2_z3_encoding"]},
            "beam_log": [{"outer": 1, "scores": [0.6, 0.5, 0.4], "verdicts": ["UNSAT", "UNSAT", "UNSAT"], "error_types": ["E2_z3_encoding", "E2_z3_encoding", "E2_z3_encoding"]}],
            "beam_diversity": 0.22, "beam_width": 3,
            "slm_extra": {
                "ground_truth_deontic": "F", "deontic_type_predicted": "F",
                "deontic_confirmed": True, "n_gaps": 2,
                "cegar_iter_scores": [0.5, 0.8], "clause_complexity": 3,
            },
        },
        {
            "results": {"final_success": False, "semantic_alignment_confirmed": 0.30, "wall_time_sec": 210.0},
            "attempt_counts": {"llm_a_outer_attempts": 5, "llm_b_semantic_flags": 0, "llm_c_cegar_iterations": 5, "beam_candidates_generated": 15},
            "error_analysis": {"error_type_sequence": ["E1_syntax", "E1_syntax", "E2_z3_encoding", "E3_semantic_inversion", "E2_z3_encoding"]},
            "beam_log": [{"outer": 1, "scores": [0.3, 0.2, 0.1], "verdicts": [None, None, None], "error_types": ["E1_syntax", "E1_syntax", "E1_syntax"]}],
            "beam_diversity": 0.08, "beam_width": 3,
            "slm_extra": {
                "ground_truth_deontic": "P", "deontic_type_predicted": None,
                "deontic_confirmed": False, "n_gaps": 0,
                "cegar_iter_scores": [0.3, 0.35, 0.4, 0.45, 0.5], "clause_complexity": 5,
            },
        },
    ]

    result = compute_all(mock_logs)
    print("Self-test metrics:")
    print(json.dumps(result, indent=2))

    assert result["end_to_end_success_rate"] == round(2 / 3, 4)
    assert result["syntax_validity_rate"] == round(2 / 3, 4)
    assert result["deontic_type_distribution"] == {"O": 1, "F": 1, "P": 1, "unknown": 0}
    assert result["mean_gaps_per_section"] == round((1 + 2 + 0) / 3, 4)
    assert result["deontic_confirmed_rate"] == round(2 / 3, 4)
    assert result["mean_llm_a_calls"] == round((3 + 6 + 15) / 3, 2)
    assert result["success_rate_by_deontic_type"] == {"O": 1.0, "F": 1.0, "P": 0.0}
    print("\nAll assertions passed.")
