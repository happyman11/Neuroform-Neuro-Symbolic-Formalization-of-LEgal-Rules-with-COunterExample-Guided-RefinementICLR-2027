"""
baseline_prompts.py — Prompt strings for baselines B2, B3, B4.

All prompts use Python str.format() placeholders.
FOL_Structure (B1/B3 initial generation) is reused from scripts/SLM/lib/promting.py
via Prompt().get_FOL_acts(section, error, prior_code).
"""

# ─────────────────────────────────────────────────────────────────────────────
# B2 — CoT Generation + Self-Refine
# ─────────────────────────────────────────────────────────────────────────────

COT_GENERATION_PROMPT = """\
You are an expert in legal reasoning, formal methods, and SMT solving using Z3.
Your task is to convert the given legal section into a Python Z3 program.

### Step-by-step reasoning (Chain of Thought):

**Step 1 — Identify legal entities and actors:**
Read the section and list: Who are the actors (e.g., data fiduciary, data principal,
controller, processor)? What data or objects are involved?

**Step 2 — Enumerate deontic obligations:**
Classify each obligation as:
  - Obligation (O): something that MUST happen ("shall", "must", "is required to")
  - Prohibition (F): something that MUST NOT happen ("shall not", "may not")
  - Permission (P): something that MAY happen ("may", "is permitted to")

**Step 3 — Define Z3 Bool variables:**
For each entity and condition identified above, declare a z3.Bool variable
(e.g., `self.consent_obtained = z3.Bool('consent_obtained')`).

**Step 4 — Write Z3 constraints:**
Translate each deontic obligation into a Z3 expression using z3.Implies,
z3.And, z3.Or, z3.Not. Pay close attention to conditional clauses ("if",
"unless", "subject to").

**Step 5 — Assemble the class:**
Write the complete Python class following the required structure.

### Requirements:
1. Define a Python class named according to the section (e.g., `class DPDPSection3:`).
2. The class must include:
   - `__init__`: declare all z3.Bool variables.
   - `get_rule(self)`: return the Z3 logical expression.
   - `verify_data(self, data)`: create a Solver, add the rule, iterate data dict, return solver.check().
3. Always include `import z3` at the top.
4. Instantiate the class and call verify_data at the end.

### Legal Section:
"{Section}"

### Output Format (single fenced code block):
```python
import z3

class <SectionClassName>:
    \"\"\"<section title>\"\"\"
    def __init__(self):
        # z3.Bool variable declarations
        ...

    def get_rule(self):
        # Z3 logical expression
        ...

    def verify_data(self, data):
        solver = z3.Solver()
        solver.add(self.get_rule())
        for var_name, var_value in data.items():
            if hasattr(self, var_name):
                z3_var = getattr(self, var_name)
                if isinstance(z3_var, z3.BoolRef):
                    solver.add(z3_var == var_value)
        return solver.check()

if __name__ == "__main__":
    obj = <SectionClassName>()
    print(obj.verify_data({{}}))
```
"""

# ─────────────────────────────────────────────────────────────────────────────

SELF_CRITIQUE_PROMPT = """\
You are a formal logic reviewer. You are given a legal section and a Z3 Python
program that was generated to encode it. Your task is to identify specific
logical deficiencies in the generated code.

### Legal Section:
"{Section}"

### Generated Z3 Code:
```python
{Code}
```

### Your Task:
List ONLY the logical deficiencies as a bulleted list. For each issue, state:
- What legal obligation/prohibition/permission is missing or wrong
- What the correct encoding should be (conceptually, not as code)

Do NOT rewrite the code. Do NOT provide corrected code.
Output ONLY the bulleted critique list, nothing else.

Example format:
- Missing: The condition "unless prior consent was obtained" is not encoded.
- Wrong polarity: The prohibition on data sharing is encoded as a permission.
- Incomplete: The actor restriction (only Data Fiduciaries) is not captured.
"""

# ─────────────────────────────────────────────────────────────────────────────

SELF_REFINE_PROMPT = """\
You are an expert Python and Z3 formal-verification engineer.
You are given a legal section, a previously generated Z3 program, and a
critique identifying its logical deficiencies.

### Legal Section:
"{Section}"

### Previous Z3 Code:
```python
{Code}
```

### Critique (issues to fix):
{Critique}

### Your Task:
Rewrite the Z3 Python program to address EVERY critique point listed above.
Requirements:
1. Preserve the same class structure (__init__, get_rule, verify_data).
2. Address each bulleted critique point explicitly.
3. Do not remove any correct constraints that were already in the code.
4. Output the COMPLETE revised program — not a diff, not a partial update.

Output the complete program inside a single ```python\\n...\\n``` fenced code block.
"""

# ─────────────────────────────────────────────────────────────────────────────
# B3 — Naive Retry (raw error, no structured repair hint)
# ─────────────────────────────────────────────────────────────────────────────

NAIVE_RETRY_PROMPT = """\
You are an expert Python and Z3 formal-verification engineer.
The following Z3 Python program for encoding a legal section has a runtime error.
Fix the code so it runs without errors.

### Legal Section:
"{Section}"

### Code with Error:
```python
{Code}
```

### Error:
{RawError}

Fix the code and output the complete corrected program inside a single
```python\\n...\\n``` fenced code block.
Do not change the logical structure unless absolutely necessary to fix the error.
"""

# ─────────────────────────────────────────────────────────────────────────────
# B4 — Grammar-Constrained (template-fill fallback)
# ─────────────────────────────────────────────────────────────────────────────

GRAMMAR_FILL_PROMPT = """\
You are an expert in Z3 formal verification of legal text.
Your task is to analyse the legal section below and extract ONLY:
1. The z3.Bool variable declarations (as Python assignment statements).
2. The Z3 constraint expressions to be added to the solver.

### Legal Section:
"{Section}"

### Class name to use: `{Z3ClassName}`

### Output Format:
Return ONLY a JSON object with exactly two keys. No prose, no markdown, no fences.

{{
  "variables": [
    "self.consent_obtained = z3.Bool('consent_obtained')",
    "self.data_shared = z3.Bool('data_shared')"
  ],
  "constraints": [
    "z3.Implies(self.data_shared, self.consent_obtained)",
    "z3.Not(z3.And(self.data_shared, z3.Not(self.consent_obtained)))"
  ]
}}

### One-shot example (DPDP Section 3):
Section text: "This Act shall not apply to the processing of personal data by an
individual for any personal or domestic purpose, or to personal data that is made
publicly available by the Data Principal or is required to be published under any
law for the time being in force."

Expected JSON output:
{{
  "variables": [
    "self.processed_by_individual = z3.Bool('processed_by_individual')",
    "self.personal_domestic_purpose = z3.Bool('personal_domestic_purpose')",
    "self.made_publicly_available = z3.Bool('made_publicly_available')",
    "self.required_by_law = z3.Bool('required_by_law')",
    "self.apply_act = z3.Bool('apply_act')"
  ],
  "constraints": [
    "z3.Implies(z3.And(self.processed_by_individual, self.personal_domestic_purpose), z3.Not(self.apply_act))",
    "z3.Implies(z3.Or(self.made_publicly_available, self.required_by_law), z3.Not(self.apply_act))"
  ]
}}

Now output the JSON for the section above. Nothing else.
"""

# ─────────────────────────────────────────────────────────────────────────────
# B5 — CEGIS-Sketch (Orvalho et al., AAAI 2025 — arXiv:2502.07786)
# Adapted from MaxSAT-FL + CEGIS student-program repair to Z3/legal domain.
# ─────────────────────────────────────────────────────────────────────────────

CEGIS_HOLE_FILL_PROMPT = """\
You are an expert Python and Z3 formal-verification engineer.

A Z3 program was generated to formally encode the legal section below, but it
failed the semantic oracle. Lines that were identified as faulty have been
replaced with "# @HOLE N @" markers — the rest of the program is correct and
must NOT be changed.

Your task: replace every "@HOLE N @" marker with syntactically valid Z3 Python
that correctly encodes the corresponding legal constraint.

### Legal Section:
"{Section}"

### Incomplete Z3 Program (fill ALL @HOLE@ lines):
```python
{Sketch}
```

### Oracle Feedback (why the previous attempt failed):
{OracleFeedback}

### Instructions:
1. Replace EVERY "# @HOLE N @" comment with correct Z3 Python code.
   Each hole should become one or more valid Python statements.
2. Preserve every line that is NOT marked as a hole — do not move, rename,
   or reorder them.
3. The completed program must:
   - import z3 at the top
   - declare z3.Bool variables in __init__
   - return a Z3 expression from get_rule
   - create a Solver, add the rule, and call solver.check() in verify_data
4. Output the COMPLETE filled program inside a single ```python\\n...\\n``` block.
   No partial snippets, no explanations — only the complete program.
"""

# ─────────────────────────────────────────────────────────────────────────────

CEGIS_FIXME_PROMPT = """\
You are an expert Python and Z3 formal-verification engineer.

A Z3 program was generated to formally encode the legal section below, but it
failed the semantic oracle. Lines identified as faulty are annotated with
"# FIXME: <reason>" comments. Fix ONLY those lines.

### Legal Section:
"{Section}"

### Z3 Program with FIXME annotations:
```python
{Code}
```

### Oracle Feedback (why the previous attempt failed):
{OracleFeedback}

### Instructions:
1. For every line containing "# FIXME: <reason>":
   - Fix the line to address the stated reason.
   - Remove the "# FIXME" comment from the fixed line.
2. Do NOT change any line that does NOT have a FIXME annotation.
3. The corrected program must remain syntactically valid Z3 Python.
4. Output the COMPLETE corrected program inside a single ```python\\n...\\n``` block.
   No partial snippets, no explanations — only the complete program.
"""
