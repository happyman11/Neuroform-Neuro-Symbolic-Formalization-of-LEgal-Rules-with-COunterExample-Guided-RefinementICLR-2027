from pydantic import  ValidationError
try:
    from azure.ai.inference import ChatCompletionsClient
    from azure.ai.inference.models import SystemMessage, UserMessage
    AZUREAI_AVAILABLE=True
except Exception:
    AZUREAI_AVAILABLE=False

try:
    from azure.core.credentials import AzureKeyCredential
    AZURECREDENTIAL_AVAILABLE=True
except Exception:
    AZURECREDENTIAL_AVAILABLE=False

try:
    import ollama
    OLLAMA_AVAILABLE = True
except Exception:
    OLLAMA_AVAILABLE = False

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except Exception:
    OPENAI_AVAILABLE = False

class ModelCall:
    _ollama_pulled: set = set()

    def __init__(self):
       pass

    def ollama_call_model(
        self, prompt: str, model: str = "llama3",
        temperature: float = 0.7, max_new_tokens: int = 4096,
        system_message: str = "", seed: int | None = None,
    ) -> str:
        """
        ICLR supplementary: Ollama as a first-class, symmetric alternative to HuggingFace (owner="Ollama").
        Parameter shape matches HuggingFaceModel.call() exactly (temperature/max_new_tokens/system_message/
        seed) so callers can switch backend without changing anything else -- adapted from the proven
        SLM-Optimisation/ollama_backend/ollama_model.py pattern (options={"temperature","num_predict","seed"},
        ollama.pull()-based lazy install). The old 2-arg call shape (prompt, model) still works unchanged --
        every new parameter has a default, so this is purely additive.
        """
        if not OLLAMA_AVAILABLE:
            raise RuntimeError("ollama package not installed. pip install ollama")

        if model not in self._ollama_pulled:
            local_models = {m.get("model", m.get("name", "")) for m in ollama.list().get("models", [])}
            if model not in local_models:
                ollama.pull(model)
            self._ollama_pulled.add(model)

        messages = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        messages.append({"role": "user", "content": prompt})

        options = {"temperature": temperature, "num_predict": max_new_tokens}
        if seed is not None:
            options["seed"] = seed

        response = ollama.chat(model=model, messages=messages, options=options)
        return response['message']['content']
    
    def github_model_call(self, prompt: str, model: str, github_endpoint: str, key: str) -> str:
        """
        Call a model hosted on GitHub's Azure AI inference endpoint.

        Parameters
        ----------
        prompt          : user prompt string
        model           : model name as registered on the GitHub endpoint
        github_endpoint : Azure AI inference endpoint URL
        key             : GitHub/Azure API key
        """
        if not AZUREAI_AVAILABLE:
            raise RuntimeError("azure-ai-inference package not installed. "
                               "Run: pip install azure-ai-inference")
        if not AZURECREDENTIAL_AVAILABLE:
            raise RuntimeError("azure-core package not installed. "
                               "Run: pip install azure-core")

        client = ChatCompletionsClient(
            endpoint=github_endpoint,
            credential=AzureKeyCredential(key),
        )
        response = client.complete(
            messages=[
                SystemMessage("You are the Legal Assistant. "
                              "Think like a Legal Researcher and Mapping Expert."),
                UserMessage(prompt),
            ],
            temperature=0.0,
            top_p=1.0,
            max_tokens=4000,
            model=model,
        )
        return response.choices[0].message.content.strip()

    def openai_model_call(self,prompt:str,model:str,key:str):
        if not OPENAI_AVAILABLE:
            raise RuntimeError("openai package not installed. pip install ollama")
        self.openai_key=key
        self.openai_client = OpenAI(api_key=self.openai_key)
        
        try:
            completion = self.openai_client.chat.completions.create(
                model=model, 
                messages=[
                            {
                            "role": "user",
                            "content": prompt
                             }
                        ], 
                    )

            raw_json_output = completion.choices[0].message.content
            return raw_json_output

        except ValidationError as e:
            print(f"Error: Model output did not conform to the Pydantic schema.")
            print(e)
            return None
        except Exception as e:
            print(f"An error occurred during the API call: {e}")
            return None
