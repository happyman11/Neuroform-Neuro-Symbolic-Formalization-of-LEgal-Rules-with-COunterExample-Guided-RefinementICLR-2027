"""
B6 — AquaForte-Adapted Baseline

Adaptation of Lv et al. "AquaForte" (arXiv:2601.04675) to the Z3/legal domain.

Core idea: LLM-guided adaptive retry with *learned clause exclusion*.
Each failed encoding triggers an LLM analysis call that identifies the specific
wrong constraint pattern; this pattern is then excluded from subsequent prompts.

Paper contribution → domain adaptation:
    QUFNIRA formula synthesis     →  Z3 Python class generation
    Clause exclusion (AquaForte)  →  "Do NOT generate <pattern>" injected into prompt
    Adaptive re-synthesis         →  iterative LLM regeneration with growing exclusion set
    UNSAT detection               →  SemanticOracle (exec + solver + verdict + proof)
"""
from __future__ import annotations

import json
import logging
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Make scripts/Baseline/ importable from this subdirectory
_BASELINE_PARENT = Path(__file__).resolve().parents[1]
if str(_BASELINE_PARENT) not in sys.path:
    sys.path.insert(0, str(_BASELINE_PARENT))

from baseline_config import (
    ORACLE_PASS_THRESHOLD,
    BASELINE_SYSTEM_MSG,
    MAX_NEW_TOKENS_GEN,
    MAX_NEW_TOKENS_DET,
    baseline_run_dir,
    get_hf_model,
)
from new_baseline_config import (
    MAX_AQUAFORTE_ITERS,
    TEMP_AQUAFORTE_GEN,
    TEMP_AQUAFORTE_ANALYSIS,
)

from SMT_Generation_AAAI_Final import (
    RefineSMT, Candidate, SemanticOracle, classify_error, ErrorType,
)
from promting import Prompt

logger = logging.getLogger(__name__)

BASELINE_NAME = "b6_aquaforte"

# ─────────────────────────────────────────────────────────────────────────────
# Exclusion analysis prompt
# ─────────────────────────────────────────────────────────────────────────────

_EXCLUSION_ANALYSIS_PROMPT = """\
You are analyzing a failed Z3 Python encoding of a legal rule.

Legal section:
{SectionText}

Failed Z3 code:
```python
{FailedCode}
```

Oracle failure:
  Error type   : {ErrorType}
  Error message: {ErrorMessage}
  Execution out: {ExecOutput}

Identify the SINGLE most problematic Z3 constraint pattern in the failed code.
Describe it in ONE concise sentence starting with "Do NOT generate ...".
Focus on the specific logical structure that is wrong (e.g., direction of Implies,
wrong variable pairing, tautological Or, missing exception negation, etc.).

Respond with exactly ONE sentence starting with "Do NOT generate".
"""

_EXCLUSION_GENERATION_PROMPT = """\
You must generate a Z3 Python encoding for the following legal section.

Legal section:
{SectionText}

EXCLUSION CONSTRAINTS — do not repeat these known-wrong patterns:
{ExclusionList}

Generate a complete, syntactically valid Z3 Python class with:
- An __init__ method declaring all z3.Bool / z3.Int variables
- A get_rule() method returning the complete Z3 formula
- A verify_data(data) method with a z3.Solver()

Output ONLY a single ```python\\n...\\n``` code block.
"""


def _extract_exclusion(analysis_text: str) -> str:
    """Extract the 'Do NOT generate ...' sentence from LLM analysis."""
    for line in analysis_text.splitlines():
        line = line.strip()
        if line.lower().startswith("do not generate"):
            return line
    # Fallback: take the first non-empty sentence
    for line in analysis_text.splitlines():
        line = line.strip()
        if line:
            return line[:200]
    return "Do NOT generate the same constraint structure as the failed attempt."


def _section_to_text(section: dict) -> str:
    if isinstance(section, str):
        return section
    parts = []
    for key in ("section_number", "title", "text", "content", "section_text"):
        if key in section and section[key]:
            parts.append(str(section[key]))
    return "\n".join(parts) if parts else str(section)


# ─────────────────────────────────────────────────────────────────────────────
# Main class
# ─────────────────────────────────────────────────────────────────────────────

class AquaForteBaseline:
    """
    B6: Adaptive LLM retry with learned clause exclusion.

    Mirrors the AquaForte (Lv et al. 2601.04675) strategy of excluding known-wrong
    constraint forms from subsequent synthesis attempts.
    """

    def __init__(
        self,
        model_id: str,
        tier: str,
        output_root: Path,
        act_name: str,
        run_id: str,
        max_aquaforte_iters: int = MAX_AQUAFORTE_ITERS,
    ) -> None:
        self.model_id             = model_id
        self.tier                 = tier
        self.output_root          = Path(output_root)
        self.act_name             = act_name
        self.run_id               = run_id
        self.max_aquaforte_iters  = max_aquaforte_iters

        self.HFModel  = get_hf_model(tier)
        self.oracle   = SemanticOracle()
        self.prompter = Prompt()

        self._section_logs: list[dict] = []
        self.output_root.mkdir(parents=True, exist_ok=True)
        logger.info(
            "B6 AquaForte ready | tier=%s model=%s act=%s max_iters=%d",
            tier, model_id, act_name, max_aquaforte_iters,
        )

    # ── Per-section ───────────────────────────────────────────────────────────

    def process_section(self, section: dict, filename_stem: str) -> None:
        section_id = section.get("section_number", filename_stem)
        t0 = time.time()

        section_dir = self.output_root / filename_stem
        section_dir.mkdir(parents=True, exist_ok=True)

        logger.info("[%s] ════ B6 AquaForte ════", section_id)

        section_text   = _section_to_text(section)
        exclusion_list: list[str] = []
        error_type_seq: list[str] = []
        llm_gen_calls   = 0
        llm_analysis_calls = 0

        # ── Step 1: Initial generation (T=0.7) ────────────────────────────────
        prompt0 = self.prompter.get_FOL_acts(section, error="", prior_code="")
        raw = self.HFModel.call(
            self.model_id, prompt0,
            temperature=TEMP_AQUAFORTE_GEN,
            max_new_tokens=MAX_NEW_TOKENS_GEN,
            system_message=BASELINE_SYSTEM_MSG,
        )
        llm_gen_calls += 1

        blocks = RefineSMT.extract_code(raw)
        if not blocks:
            logger.warning("[%s] No code extracted at initial generation", section_id)

        candidate = Candidate(code_blocks=blocks, raw_response=raw)
        self.oracle.execute_and_score(candidate)
        error_type_seq.append(candidate.error_type.value)

        logger.info(
            "[%s] Initial oracle: %.2f | exec=%s | verdict=%s | error=%s",
            section_id, candidate.semantic_score,
            candidate.execution_success, candidate.z3_verdict,
            candidate.error_type.value,
        )

        best_candidate = candidate
        iters_done     = 0

        # ── Step 2: Adaptive exclusion loop ───────────────────────────────────
        if candidate.semantic_score < ORACLE_PASS_THRESHOLD:
            for iteration in range(self.max_aquaforte_iters):
                logger.info(
                    "[%s] ════ AquaForte iter %d/%d ════",
                    section_id, iteration + 1, self.max_aquaforte_iters,
                )

                # a. LLM analyzes the failed code → extract exclusion pattern
                failed_code = candidate.code_blocks[0] if candidate.code_blocks else (
                    candidate.raw_response[:2000]
                )
                analysis_prompt = _EXCLUSION_ANALYSIS_PROMPT.format(
                    SectionText  = section_text[:1500],
                    FailedCode   = failed_code[:2000],
                    ErrorType    = candidate.error_type.value,
                    ErrorMessage = (candidate.error_message or "none")[:200],
                    ExecOutput   = (candidate.execution_output or "none")[:200],
                )
                analysis_raw = self.HFModel.call(
                    self.model_id, analysis_prompt,
                    temperature=TEMP_AQUAFORTE_ANALYSIS,
                    max_new_tokens=MAX_NEW_TOKENS_DET,
                    system_message="You are a formal verification expert analyzing failed Z3 code.",
                )
                llm_analysis_calls += 1

                exclusion = _extract_exclusion(analysis_raw)
                exclusion_list.append(exclusion)
                logger.info("[%s]   Exclusion added: %s", section_id, exclusion[:100])

                # b. Regenerate with exclusion constraints in prompt
                excl_block = "\n".join(f"  - {e}" for e in exclusion_list)
                gen_prompt = _EXCLUSION_GENERATION_PROMPT.format(
                    SectionText   = section_text[:1500],
                    ExclusionList = excl_block,
                )
                raw = self.HFModel.call(
                    self.model_id, gen_prompt,
                    temperature=TEMP_AQUAFORTE_GEN,
                    max_new_tokens=MAX_NEW_TOKENS_GEN,
                    system_message=BASELINE_SYSTEM_MSG,
                )
                llm_gen_calls += 1

                new_blocks = RefineSMT.extract_code(raw)
                if not new_blocks:
                    logger.warning(
                        "[%s]   No code extracted at AquaForte iter %d",
                        section_id, iteration + 1,
                    )

                new_candidate = Candidate(code_blocks=new_blocks, raw_response=raw)
                self.oracle.execute_and_score(new_candidate)
                error_type_seq.append(new_candidate.error_type.value)
                iters_done += 1

                logger.info(
                    "[%s]   iter %d oracle: %.2f | exec=%s | verdict=%s | error=%s",
                    section_id, iteration + 1, new_candidate.semantic_score,
                    new_candidate.execution_success, new_candidate.z3_verdict,
                    new_candidate.error_type.value,
                )

                if new_candidate.semantic_score > best_candidate.semantic_score:
                    best_candidate = new_candidate

                candidate = new_candidate

                if candidate.semantic_score >= ORACLE_PASS_THRESHOLD:
                    logger.info(
                        "[%s] SUCCESS at AquaForte iter %d — oracle=%.2f",
                        section_id, iteration + 1, candidate.semantic_score,
                    )
                    break
            else:
                logger.warning(
                    "[%s] FAILED — all %d AquaForte iters exhausted (best=%.2f)",
                    section_id, self.max_aquaforte_iters, best_candidate.semantic_score,
                )

        wall_time = time.time() - t0
        metrics = self._build_metrics(
            section, filename_stem, best_candidate, wall_time,
            llm_gen_calls, llm_analysis_calls, iters_done,
            exclusion_list, error_type_seq,
        )
        self._section_logs.append(metrics)

        metrics_path = section_dir / "section_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        logger.info("[%s] Log saved → %s", section_id, metrics_path)

        if best_candidate.code_blocks:
            code_path = section_dir / "final_code.py"
            code_path.write_text(best_candidate.code_blocks[0], encoding="utf-8")
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)

    # ── Aggregate ─────────────────────────────────────────────────────────────

    def save_aggregate_metrics(self) -> None:
        if not self._section_logs:
            return
        total     = len(self._section_logs)
        successes = sum(1 for m in self._section_logs if m["results"]["final_success"])
        agg = {
            "algorithm":   BASELINE_NAME,
            "tier":        self.tier,
            "act":         self.act_name,
            "run_id":      self.run_id,
            "model":       self.model_id,
            "max_aquaforte_iters": self.max_aquaforte_iters,
            "acts_processed":  total,
            "successful":      successes,
            "failed":          total - successes,
            "success_rate":    round(successes / total, 4) if total else 0.0,
            "mean_wall_time_sec": round(
                sum(m["results"]["wall_time_sec"] for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "mean_exclusion_clauses": round(
                sum(m["baseline_metadata"]["exclusion_clauses_added"]
                    for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "per_section": self._section_logs,
        }
        out = self.output_root / "aggregate_metrics.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(agg, f, indent=2)
        logger.info(
            "B6 aggregate metrics → %s  (success=%d/%d mean_excl=%.1f)",
            out, successes, total, agg["mean_exclusion_clauses"],
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_metrics(
        self,
        section: dict,
        filename_stem: str,
        candidate: Candidate,
        wall_time: float,
        llm_gen_calls: int,
        llm_analysis_calls: int,
        iters_done: int,
        exclusion_list: list[str],
        error_type_seq: list[str],
    ) -> dict:
        err_val    = candidate.error_type.value
        err_cnt    = Counter(error_type_seq)
        exec_ok    = float(candidate.execution_success)
        solver_ok  = float(candidate.semantic_score >= 0.7)
        verdict_ok = float(candidate.z3_verdict in ("sat", "unsat"))
        proof_ok   = float(candidate.semantic_score >= 1.0)

        return {
            "algorithm":  BASELINE_NAME,
            "act_file":   filename_stem,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "models":     {"primary": self.model_id},
            "hyperparameters": {
                "temperature_gen":       TEMP_AQUAFORTE_GEN,
                "temperature_analysis":  TEMP_AQUAFORTE_ANALYSIS,
                "max_new_tokens":        MAX_NEW_TOKENS_GEN,
                "max_aquaforte_iters":   self.max_aquaforte_iters,
                "oracle_pass_threshold": ORACLE_PASS_THRESHOLD,
            },
            "results": {
                "final_success":               candidate.semantic_score >= ORACLE_PASS_THRESHOLD,
                "semantic_alignment_confirmed": round(candidate.semantic_score, 4),
                "final_error_type":            err_val,
                "wall_time_sec":               round(wall_time, 3),
            },
            "attempt_counts": {
                "llm_a_outer_attempts":      llm_gen_calls,
                "llm_b_semantic_flags":      0,
                "llm_c_cegar_iterations":    llm_analysis_calls,
                "beam_candidates_generated": llm_gen_calls,
            },
            "error_analysis": {
                "error_type_sequence": error_type_seq,
                "error_type_counts":   dict(err_cnt),
            },
            "oracle_components": {
                "exec":        exec_ok,
                "solver":      solver_ok,
                "verdict":     verdict_ok,
                "proof":       proof_ok,
                "final_score": round(candidate.semantic_score, 4),
                "mode":        "full",
            },
            "baseline_metadata": {
                "baseline":               BASELINE_NAME,
                "tier":                   self.tier,
                "exclusion_clauses_added": len(exclusion_list),
                "instantiation_attempts":  llm_gen_calls,
                "exclusion_log":          exclusion_list,
                "aquaforte_iters_done":   iters_done,
                "paper_ref":              "Lv et al. AquaForte (arXiv:2601.04675)",
            },
        }
