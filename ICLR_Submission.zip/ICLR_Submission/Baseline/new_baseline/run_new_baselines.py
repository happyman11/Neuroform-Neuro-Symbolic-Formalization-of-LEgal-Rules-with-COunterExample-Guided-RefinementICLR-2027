#!/usr/bin/env python3
"""
run_new_baselines.py — Unified CLI runner for new baselines B6–B9.

Usage:
    cd ICLR_Submission/Baseline/new_baseline

    # Run single new baseline
    python run_new_baselines.py --baseline b6 --tier slm
    python run_new_baselines.py --baseline b7 --tier llm
    python run_new_baselines.py --baseline b8 --tier slm --max-masa-iters 3
    python run_new_baselines.py --baseline b9 --tier slm --rag-top-k 3

    # Run all four new baselines
    python run_new_baselines.py --baseline all --tier slm

    # Restrict acts / section count
    python run_new_baselines.py --baseline b9 --tier slm --acts GDPR,DPDP
    python run_new_baselines.py --baseline all --tier slm --sections 3

    # Dry-run (no LLM calls)
    python run_new_baselines.py --baseline all --tier slm --dry-run

Output structure (mirrors B1–B5 exactly):
    Baseline_Output/{tier}/{baseline_name}/{run_id}/{act}/
        section_metrics.json   (per section)
        final_code.py          (best Z3 code)
        aggregate_metrics.json (per act)
    Baseline_Output/{tier}/{baseline_name}/{run_id}/
        run_config.json
        run.log
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from tqdm import tqdm

# Make scripts/Baseline/ importable
_HERE        = Path(__file__).resolve().parent          # new_baseline/
_BASELINE    = _HERE.parent                             # scripts/Baseline/
for _p in [str(_BASELINE), str(_BASELINE / "lib"), str(_HERE)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

from baseline_config import (
    ACTS_INPUT, ACTS, IGNORE_FILES,
    TIER_MODELS, BASELINE_OUTPUT,
    ORACLE_PASS_THRESHOLD,
    baseline_run_dir, set_backend,
)
from new_baseline_config import (
    MAX_AQUAFORTE_ITERS, MAX_L4L_ITERS, MAX_MASA_ITERS, RAG_TOP_K,
)
from utility import Utility

from b6_aquaforte      import AquaForteBaseline
from b7_l4l_schema     import L4LSchemaBaseline
from b8_masa_multiagent import MASAMultiAgentBaseline
from b9_rag_smt        import RAGSMTBaseline

logger = logging.getLogger("run_new_baselines")

_BASELINES = {
    "b6": (AquaForteBaseline,      "b6_aquaforte"),
    "b7": (L4LSchemaBaseline,      "b7_l4l_schema"),
    "b8": (MASAMultiAgentBaseline, "b8_masa_multiagent"),
    "b9": (RAGSMTBaseline,         "b9_rag_smt"),
}


# ── Section loading (identical to run_baselines.py) ───────────────────────────

def _load_section(file_path: Path, utility: Utility) -> dict:
    try:
        with open(file_path, encoding="utf-8") as fh:
            full = json.load(fh)
    except Exception:
        full = {}
    section = utility.extract_json_robust(str(file_path)) or {}
    for key in ("label_metrics", "structured_annotation", "source"):
        if key in full and key not in section:
            section[key] = full[key]
    return section


# ── Logging setup ─────────────────────────────────────────────────────────────

def _setup_logging(run_dir: Path) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    logging.basicConfig(level=logging.INFO, format=fmt)
    fh = logging.FileHandler(run_dir / "run.log", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(fmt))
    logging.getLogger().addHandler(fh)


# ── run_config.json ───────────────────────────────────────────────────────────

def _write_run_config(
    run_id: str,
    run_dir: Path,
    tier: str,
    baseline_keys: list[str],
    acts: list[str],
    model_id: str,
    args: argparse.Namespace,
) -> None:
    try:
        import transformers
        tf_ver = transformers.__version__
    except ImportError:
        tf_ver = "N/A"

    cfg = {
        "run_id":         run_id,
        "baselines":      baseline_keys,
        "tier":           tier,
        "model_id":       model_id,
        "timestamp":      datetime.now(timezone.utc).isoformat(),
        "acts":           acts,
        "hyperparameters": {
            "max_aquaforte_iters":   args.max_aquaforte_iters,
            "max_l4l_iters":         args.max_l4l_iters,
            "max_masa_iters":        args.max_masa_iters,
            "rag_top_k":             args.rag_top_k,
            "oracle_pass_threshold": ORACLE_PASS_THRESHOLD,
        },
        "hardware":             platform.node(),
        "python_version":       platform.python_version(),
        "transformers_version": tf_ver,
    }
    run_dir.mkdir(parents=True, exist_ok=True)
    with open(run_dir / "run_config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    logger.info("run_config.json → %s", run_dir / "run_config.json")


# ── Per-baseline runner ────────────────────────────────────────────────────────

def _run_baseline(
    BaselineClass,
    baseline_name: str,
    tier: str,
    model_id: str,
    acts: list[str],
    run_id: str,
    utility: Utility,
    section_limit: int | None,
    dry_run: bool,
    extra_kwargs: dict,
) -> None:
    for act in acts:
        act_input = ACTS_INPUT.get(act)
        if not act_input or not act_input.exists():
            logger.error("Act input not found: %s → %s", act, act_input)
            continue

        act_output = baseline_run_dir(tier, baseline_name, run_id, act)
        act_output.mkdir(parents=True, exist_ok=True)

        files = sorted(
            f for f in os.listdir(act_input)
            if f.endswith(".json") and f not in IGNORE_FILES
        )
        if section_limit:
            files = files[:section_limit]

        logger.info(
            "=== %s | %s | %s | %d sections ===",
            baseline_name, tier, act, len(files),
        )

        runner = BaselineClass(
            model_id=model_id,
            tier=tier,
            output_root=act_output,
            act_name=act,
            run_id=run_id,
            **extra_kwargs,
        )

        with tqdm(total=len(files), desc=f"{baseline_name}/{act}") as pbar:
            for filename in files:
                pbar.set_postfix_str(filename)
                if dry_run:
                    logger.info("[DRY-RUN] %s/%s/%s", baseline_name, act, filename)
                    pbar.update(1)
                    continue
                try:
                    section = _load_section(act_input / filename, utility)
                    runner.process_section(section, filename.replace(".json", ""))
                except Exception:
                    logger.exception("Failed: %s/%s", act, filename)
                pbar.update(1)

        if not dry_run:
            runner.save_aggregate_metrics()

            agg_src = act_output / "aggregate_metrics.json"
            run_top = BASELINE_OUTPUT / tier / baseline_name / run_id
            if agg_src.exists():
                shutil.copy(agg_src, run_top / f"{act}_aggregate_metrics.json")


# ── CLI ────────────────────────────────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(description="REFINE-SMT New Baselines Runner (B6–B9)")
    p.add_argument(
        "--baseline", default="b6",
        choices=["b6", "b7", "b8", "b9", "all"],
        help="Which new baseline(s) to run",
    )
    p.add_argument(
        "--tier", default="slm", choices=["slm", "llm"],
        help="Model tier — slm (7B) or llm (32B)",
    )
    p.add_argument(
        "--backend", default="huggingface", choices=["huggingface", "ollama"],
        help="ICLR supplementary: model-serving backend, equally supported either way (default: "
             "huggingface, byte-identical to prior behavior). 'ollama' routes every new baseline's model "
             "calls through a local Ollama daemon instead -- see install/model_registry.yaml for model ids.",
    )
    p.add_argument(
        "--acts", default=None,
        help="Comma-separated acts, e.g. DPDP,GDPR  (default: all)",
    )
    p.add_argument("--sections", type=int, default=None,
                   help="Limit sections per act (smoke test)")
    p.add_argument("--dry-run", action="store_true",
                   help="List what would run without calling LLMs")
    # B6-specific
    p.add_argument("--max-aquaforte-iters", type=int, default=MAX_AQUAFORTE_ITERS,
                   help="B6: max AquaForte exclusion iterations (default %(default)s)")
    # B7-specific
    p.add_argument("--max-l4l-iters", type=int, default=MAX_L4L_ITERS,
                   help="B7: max L4L schema-extract+instantiate cycles (default %(default)s)")
    # B8-specific
    p.add_argument("--max-masa-iters", type=int, default=MAX_MASA_ITERS,
                   help="B8: max MASA hard+soft critique iterations (default %(default)s)")
    # B9-specific
    p.add_argument("--rag-top-k", type=int, default=RAG_TOP_K,
                   help="B9: number of BM25-retrieved context sections (default %(default)s)")
    p.add_argument("--no-maxsmt", action="store_true",
                   help="B9: disable MaxSMT repair step")
    args = p.parse_args()

    set_backend(args.backend)
    acts      = args.acts.split(",") if args.acts else ACTS
    model_id  = (TIER_MODELS[args.tier]["ollama_id"] if args.backend == "ollama"
                 else TIER_MODELS[args.tier]["model_id"])
    baseline_keys = list(_BASELINES.keys()) if args.baseline == "all" else [args.baseline]

    ts     = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = f"NewBaseline-{args.tier.upper()}-{args.baseline.upper()}-{ts}"

    run_top = BASELINE_OUTPUT / args.tier / "run_logs" / run_id
    _setup_logging(run_top)

    logger.info("Run ID    : %s", run_id)
    logger.info("Tier      : %s  backend=%s  model=%s", args.tier, args.backend, model_id)
    logger.info("Baselines : %s", baseline_keys)
    logger.info("Acts      : %s", acts)
    logger.info("Sections  : %s", args.sections or "all")

    _write_run_config(run_id, run_top, args.tier, baseline_keys, acts, model_id, args)

    utility = Utility()

    for key in baseline_keys:
        BaselineClass, baseline_name = _BASELINES[key]

        extra: dict = {}
        if key == "b6":
            extra["max_aquaforte_iters"] = args.max_aquaforte_iters
        elif key == "b7":
            extra["max_l4l_iters"] = args.max_l4l_iters
        elif key == "b8":
            extra["max_masa_iters"] = args.max_masa_iters
        elif key == "b9":
            extra["rag_top_k"]       = args.rag_top_k
            extra["maxsmt_enabled"]  = not args.no_maxsmt

        logger.info("─── Starting baseline %s (%s) ───", key.upper(), baseline_name)
        _run_baseline(
            BaselineClass  = BaselineClass,
            baseline_name  = baseline_name,
            tier           = args.tier,
            model_id       = model_id,
            acts           = acts,
            run_id         = run_id,
            utility        = utility,
            section_limit  = args.sections,
            dry_run        = args.dry_run,
            extra_kwargs   = extra,
        )

    logger.info("All new baselines complete. Output: %s", BASELINE_OUTPUT / args.tier)


if __name__ == "__main__":
    main()
