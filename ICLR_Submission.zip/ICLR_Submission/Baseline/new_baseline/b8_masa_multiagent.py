"""
B8 — MASA Multi-Agent Baseline

Adaptation of Zhang et al. "MASA" (arXiv:2510.08988) to the Z3/legal domain.

MASA Algorithm 3 (Iterative Self-Refinement) uses two critique axes:
  - Hard Critique: formal/syntactic errors caught by execution
  - Soft Critique: semantic coverage gaps not caught by execution

We implement this as a single LLM with five role-differentiated prompts:
  1. AutoformalizationAgent:  initial Z3 generation  (T=0.7)
  2. HardCritiqueAgent:       formal error analysis   (T=0.0)
  3. FormalRefinementAgent:   fix formal errors only  (T=0.0)
  4. SoftCritiqueAgent:       semantic gap detection  (T=0.0)
  5. InformalRefinementAgent: semantic gap repair     (T=0.7)

GPU constraint note: MASA originally uses separate model instances.
We use a single LLM with role-differentiated system messages and prompts.

Paper contribution → domain adaptation:
    Chinese criminal-law AutoFormalization  →  Privacy-law Z3 formalization
    Hard critique (compiler/SMT errors)     →  SemanticOracle + classify_error
    Soft critique (legal interpretation)    →  YES/NO coverage probe
    Formal refinement agent                 →  targeted Z3 repair
    Informal refinement agent               →  legal interpretation revision
"""
from __future__ import annotations

import json
import logging
import re
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

_BASELINE_PARENT = Path(__file__).resolve().parents[1]
if str(_BASELINE_PARENT) not in sys.path:
    sys.path.insert(0, str(_BASELINE_PARENT))

from baseline_config import (
    ORACLE_PASS_THRESHOLD,
    BASELINE_SYSTEM_MSG,
    MAX_NEW_TOKENS_GEN,
    MAX_NEW_TOKENS_DET,
    get_hf_model,
)
from new_baseline_config import (
    MAX_MASA_ITERS,
    TEMP_MASA_AUTOFORMALIZE,
    TEMP_MASA_HARD_CRITIQUE,
    TEMP_MASA_SOFT_CRITIQUE,
    TEMP_MASA_FORMAL_REFINE,
    TEMP_MASA_INFORMAL_REFINE,
    MASA_ASPECT_DESCRIPTION,
)

from SMT_Generation_AAAI_Final import (
    RefineSMT, Candidate, SemanticOracle, ErrorType,
)
from promting import Prompt

logger = logging.getLogger(__name__)

BASELINE_NAME = "b8_masa_multiagent"

# ─────────────────────────────────────────────────────────────────────────────
# Role-differentiated prompts
# ─────────────────────────────────────────────────────────────────────────────

_AUTOFORMALIZE_SYSTEM = (
    "You are AutoformalizationAgent: an expert in converting privacy law text "
    "into Z3 Python formal logic. Output only a single ```python\\n...\\n``` block."
)

_HARD_CRITIQUE_SYSTEM = (
    "You are HardCritiqueAgent: a formal verification expert who analyzes "
    "failed Z3 code. Identify the root cause of the formal error precisely. "
    "Be concise — one paragraph maximum."
)

_HARD_CRITIQUE_PROMPT = """\
Analyze this failed Z3 Python encoding of a legal rule.

Legal section:
{SectionText}

Z3 code:
```python
{Code}
```

Oracle failure:
  Error type   : {ErrorType}
  Error message: {ErrorMessage}
  Execution out: {ExecOutput}
  Oracle score : {Score:.2f}

What is the specific root cause of the formal error?
How should the Z3 structure be changed to fix it?
"""

_FORMAL_REFINE_SYSTEM = (
    "You are FormalRefinementAgent: fix ONLY the identified formal error in the "
    "Z3 code. Do NOT change parts that are correct. "
    "Output only a single ```python\\n...\\n``` block."
)

_FORMAL_REFINE_PROMPT = """\
Fix the formal error identified below in this Z3 Python encoding.

Legal section:
{SectionText}

Current Z3 code:
```python
{Code}
```

Identified formal error:
{HardCritique}

Fix ONLY the identified error. Keep all correct parts unchanged.
Output ONLY a single ```python\\n...\\n``` code block.
"""

_SOFT_CRITIQUE_SYSTEM = (
    "You are SoftCritiqueAgent: evaluate whether a Z3 encoding semantically covers "
    "all legal obligations and exceptions. Respond with YES or NO followed by "
    "a brief explanation."
)

_SOFT_CRITIQUE_PROMPT = """\
Does the following Z3 Python encoding correctly and COMPLETELY cover
{AspectDescription}
from the legal section below?

Legal section:
{SectionText}

Z3 encoding:
```python
{Code}
```

Answer: YES (fully covers all aspects) or NO (missing something)?
If NO, specify exactly what aspect is missing in one sentence starting with "Missing:".
"""

_INFORMAL_REFINE_SYSTEM = (
    "You are InformalRefinementAgent: revise a Z3 encoding to include aspects "
    "identified as missing by the soft critique. "
    "Output only a single ```python\\n...\\n``` block."
)

_INFORMAL_REFINE_PROMPT = """\
Revise this Z3 Python encoding to include the missing aspect identified below.

Legal section:
{SectionText}

Current Z3 encoding:
```python
{Code}
```

Missing aspect (from soft critique):
{MissingAspect}

Revise the encoding to incorporate the missing aspect while keeping all correct parts.
Output ONLY a single ```python\\n...\\n``` code block.
"""


def _parse_soft_verdict(response: str) -> tuple[str, str]:
    """Return ('YES'|'NO', missing_aspect_description)."""
    resp = response.strip().upper()
    verdict = "NO"
    missing = ""

    if resp.startswith("YES"):
        verdict = "YES"
    else:
        verdict = "NO"
        # Extract "Missing: ..." from response
        m = re.search(r"[Mm]issing:\s*(.+?)(?:\n|$)", response, re.DOTALL)
        if m:
            missing = m.group(1).strip()[:300]
        else:
            # Fallback: use first sentence after NO
            lines = [ln.strip() for ln in response.splitlines() if ln.strip()]
            missing = lines[1][:300] if len(lines) > 1 else "unspecified missing aspect"

    return verdict, missing


def _section_to_text(section: dict) -> str:
    if isinstance(section, str):
        return section
    parts = []
    for key in ("section_number", "title", "text", "content", "section_text"):
        if key in section and section[key]:
            parts.append(str(section[key]))
    return "\n".join(parts) if parts else str(section)


# ─────────────────────────────────────────────────────────────────────────────
# Main class
# ─────────────────────────────────────────────────────────────────────────────

class MASAMultiAgentBaseline:
    """
    B8: Multi-agent hard+soft critique with formal+informal refinement.

    Implements MASA Algorithm 3 (Zhang et al. 2510.08988) with role-differentiated
    prompts over a single LLM.
    """

    def __init__(
        self,
        model_id: str,
        tier: str,
        output_root: Path,
        act_name: str,
        run_id: str,
        max_masa_iters: int = MAX_MASA_ITERS,
    ) -> None:
        self.model_id       = model_id
        self.tier           = tier
        self.output_root    = Path(output_root)
        self.act_name       = act_name
        self.run_id         = run_id
        self.max_masa_iters = max_masa_iters

        self.HFModel  = get_hf_model(tier)
        self.oracle   = SemanticOracle()
        self.prompter = Prompt()

        self._section_logs: list[dict] = []
        self.output_root.mkdir(parents=True, exist_ok=True)
        logger.info(
            "B8 MASA-MultiAgent ready | tier=%s model=%s act=%s max_iters=%d",
            tier, model_id, act_name, max_masa_iters,
        )

    # ── Per-section ───────────────────────────────────────────────────────────

    def process_section(self, section: dict, filename_stem: str) -> None:
        section_id  = section.get("section_number", filename_stem)
        t0          = time.time()
        section_dir = self.output_root / filename_stem
        section_dir.mkdir(parents=True, exist_ok=True)

        logger.info("[%s] ════ B8 MASA Multi-Agent ════", section_id)

        section_text = _section_to_text(section)
        error_type_seq: list[str] = []

        hard_critique_calls    = 0
        soft_critique_calls    = 0
        formal_refine_calls    = 0
        informal_refine_calls  = 0
        autoformalize_calls    = 0
        soft_no_verdicts       = 0
        soft_verdict_log: list[str] = []

        # ── Step 1: AutoformalizationAgent (T=0.7) ────────────────────────────
        autoformalize_prompt = self.prompter.get_FOL_acts(section, error="", prior_code="")
        raw = self.HFModel.call(
            self.model_id, autoformalize_prompt,
            temperature=TEMP_MASA_AUTOFORMALIZE,
            max_new_tokens=MAX_NEW_TOKENS_GEN,
            system_message=_AUTOFORMALIZE_SYSTEM,
        )
        autoformalize_calls += 1

        blocks = RefineSMT.extract_code(raw)
        if not blocks:
            logger.warning("[%s] No code extracted at initial autoformalization", section_id)

        candidate = Candidate(code_blocks=blocks, raw_response=raw)
        self.oracle.execute_and_score(candidate)
        error_type_seq.append(candidate.error_type.value)

        logger.info(
            "[%s] Initial oracle: %.2f | exec=%s | verdict=%s | error=%s",
            section_id, candidate.semantic_score,
            candidate.execution_success, candidate.z3_verdict,
            candidate.error_type.value,
        )

        best_candidate = candidate
        iters_done     = 0

        if candidate.semantic_score < ORACLE_PASS_THRESHOLD:
            for iteration in range(self.max_masa_iters):
                logger.info(
                    "[%s] ════ MASA iter %d/%d ════",
                    section_id, iteration + 1, self.max_masa_iters,
                )

                current_code = (
                    candidate.code_blocks[0] if candidate.code_blocks
                    else candidate.raw_response[:2000]
                )

                # ── Step 2a: Hard Critique (T=0.0) ────────────────────────────
                if not candidate.execution_success or candidate.error_type not in (
                    ErrorType.NONE,
                ):
                    hard_prompt = _HARD_CRITIQUE_PROMPT.format(
                        SectionText  = section_text[:1500],
                        Code         = current_code[:2000],
                        ErrorType    = candidate.error_type.value,
                        ErrorMessage = (candidate.error_message or "none")[:200],
                        ExecOutput   = (candidate.execution_output or "none")[:200],
                        Score        = candidate.semantic_score,
                    )
                    hard_critique_raw = self.HFModel.call(
                        self.model_id, hard_prompt,
                        temperature=TEMP_MASA_HARD_CRITIQUE,
                        max_new_tokens=MAX_NEW_TOKENS_DET,
                        system_message=_HARD_CRITIQUE_SYSTEM,
                    )
                    hard_critique_calls += 1
                    logger.info(
                        "[%s]   HardCritique: %s...",
                        section_id, hard_critique_raw[:80],
                    )

                    # ── Step 2b: FormalRefinementAgent (T=0.0) ─────────────────
                    formal_prompt = _FORMAL_REFINE_PROMPT.format(
                        SectionText  = section_text[:1500],
                        Code         = current_code[:2000],
                        HardCritique = hard_critique_raw[:500],
                    )
                    formal_raw = self.HFModel.call(
                        self.model_id, formal_prompt,
                        temperature=TEMP_MASA_FORMAL_REFINE,
                        max_new_tokens=MAX_NEW_TOKENS_GEN,
                        system_message=_FORMAL_REFINE_SYSTEM,
                    )
                    formal_refine_calls += 1
                    autoformalize_calls += 1

                    new_blocks = RefineSMT.extract_code(formal_raw)
                    if not new_blocks:
                        logger.warning(
                            "[%s]   FormalRefine produced no code at iter %d",
                            section_id, iteration + 1,
                        )
                    new_candidate = Candidate(code_blocks=new_blocks, raw_response=formal_raw)
                    self.oracle.execute_and_score(new_candidate)
                    error_type_seq.append(new_candidate.error_type.value)
                    iters_done += 1

                    logger.info(
                        "[%s]   Post-FormalRefine oracle: %.2f | error=%s",
                        section_id, new_candidate.semantic_score,
                        new_candidate.error_type.value,
                    )

                    if new_candidate.semantic_score > best_candidate.semantic_score:
                        best_candidate = new_candidate
                    candidate = new_candidate
                    current_code = (
                        candidate.code_blocks[0] if candidate.code_blocks
                        else current_code
                    )

                    if candidate.semantic_score >= ORACLE_PASS_THRESHOLD:
                        logger.info(
                            "[%s] SUCCESS after FormalRefine iter %d — oracle=%.2f",
                            section_id, iteration + 1, candidate.semantic_score,
                        )
                        break

                # ── Step 3a: SoftCritiqueAgent (T=0.0) ────────────────────────
                soft_prompt = _SOFT_CRITIQUE_PROMPT.format(
                    AspectDescription = MASA_ASPECT_DESCRIPTION,
                    SectionText       = section_text[:1500],
                    Code              = current_code[:2000],
                )
                soft_raw = self.HFModel.call(
                    self.model_id, soft_prompt,
                    temperature=TEMP_MASA_SOFT_CRITIQUE,
                    max_new_tokens=MAX_NEW_TOKENS_DET,
                    system_message=_SOFT_CRITIQUE_SYSTEM,
                )
                soft_critique_calls += 1

                verdict, missing_aspect = _parse_soft_verdict(soft_raw)
                soft_verdict_log.append(verdict)
                logger.info(
                    "[%s]   SoftCritique verdict=%s missing=%s",
                    section_id, verdict, missing_aspect[:60],
                )

                if verdict == "NO" and missing_aspect:
                    soft_no_verdicts += 1

                    # ── Step 3b: InformalRefinementAgent (T=0.7) ─────────────
                    informal_prompt = _INFORMAL_REFINE_PROMPT.format(
                        SectionText   = section_text[:1500],
                        Code          = current_code[:2000],
                        MissingAspect = missing_aspect,
                    )
                    informal_raw = self.HFModel.call(
                        self.model_id, informal_prompt,
                        temperature=TEMP_MASA_INFORMAL_REFINE,
                        max_new_tokens=MAX_NEW_TOKENS_GEN,
                        system_message=_INFORMAL_REFINE_SYSTEM,
                    )
                    informal_refine_calls += 1
                    autoformalize_calls   += 1

                    new_blocks = RefineSMT.extract_code(informal_raw)
                    if not new_blocks:
                        logger.warning(
                            "[%s]   InformalRefine produced no code at iter %d",
                            section_id, iteration + 1,
                        )
                    new_candidate = Candidate(code_blocks=new_blocks, raw_response=informal_raw)
                    self.oracle.execute_and_score(new_candidate)
                    error_type_seq.append(new_candidate.error_type.value)
                    iters_done += 1

                    logger.info(
                        "[%s]   Post-InformalRefine oracle: %.2f | error=%s",
                        section_id, new_candidate.semantic_score,
                        new_candidate.error_type.value,
                    )

                    if new_candidate.semantic_score > best_candidate.semantic_score:
                        best_candidate = new_candidate
                    candidate = new_candidate

                    if candidate.semantic_score >= ORACLE_PASS_THRESHOLD:
                        logger.info(
                            "[%s] SUCCESS after InformalRefine iter %d — oracle=%.2f",
                            section_id, iteration + 1, candidate.semantic_score,
                        )
                        break
                else:
                    # Soft critique says YES — but oracle still failing
                    # Try one more autoformalization with the existing feedback
                    logger.info(
                        "[%s]   Soft critique YES but oracle low — no soft refine needed",
                        section_id,
                    )
                    break
            else:
                logger.warning(
                    "[%s] FAILED — all %d MASA iters exhausted (best=%.2f)",
                    section_id, self.max_masa_iters, best_candidate.semantic_score,
                )

        wall_time = time.time() - t0
        metrics = self._build_metrics(
            section, filename_stem, best_candidate, wall_time,
            autoformalize_calls, hard_critique_calls, soft_critique_calls,
            formal_refine_calls, informal_refine_calls, soft_no_verdicts,
            soft_verdict_log, error_type_seq,
        )
        self._section_logs.append(metrics)

        metrics_path = section_dir / "section_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        logger.info("[%s] Log saved → %s", section_id, metrics_path)

        if best_candidate.code_blocks:
            code_path = section_dir / "final_code.py"
            code_path.write_text(best_candidate.code_blocks[0], encoding="utf-8")
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)

    # ── Aggregate ─────────────────────────────────────────────────────────────

    def save_aggregate_metrics(self) -> None:
        if not self._section_logs:
            return
        total     = len(self._section_logs)
        successes = sum(1 for m in self._section_logs if m["results"]["final_success"])
        agg = {
            "algorithm":      BASELINE_NAME,
            "tier":           self.tier,
            "act":            self.act_name,
            "run_id":         self.run_id,
            "model":          self.model_id,
            "max_masa_iters": self.max_masa_iters,
            "acts_processed":  total,
            "successful":      successes,
            "failed":          total - successes,
            "success_rate":    round(successes / total, 4) if total else 0.0,
            "mean_wall_time_sec": round(
                sum(m["results"]["wall_time_sec"] for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "mean_soft_no_verdicts": round(
                sum(
                    m["baseline_metadata"]["soft_critique_iters"]
                    for m in self._section_logs
                ) / total, 2
            ) if total else 0.0,
            "per_section": self._section_logs,
        }
        out = self.output_root / "aggregate_metrics.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(agg, f, indent=2)
        logger.info(
            "B8 aggregate metrics → %s  (success=%d/%d)",
            out, successes, total,
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_metrics(
        self,
        section: dict,
        filename_stem: str,
        candidate: Candidate,
        wall_time: float,
        autoformalize_calls: int,
        hard_critique_calls: int,
        soft_critique_calls: int,
        formal_refine_calls: int,
        informal_refine_calls: int,
        soft_no_verdicts: int,
        soft_verdict_log: list[str],
        error_type_seq: list[str],
    ) -> dict:
        err_val    = candidate.error_type.value
        err_cnt    = Counter(error_type_seq)
        exec_ok    = float(candidate.execution_success)
        solver_ok  = float(candidate.semantic_score >= 0.7)
        verdict_ok = float(candidate.z3_verdict in ("sat", "unsat"))
        proof_ok   = float(candidate.semantic_score >= 1.0)
        total_critique = hard_critique_calls + formal_refine_calls

        return {
            "algorithm":  BASELINE_NAME,
            "act_file":   filename_stem,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "models":     {"primary": self.model_id},
            "hyperparameters": {
                "temperature_autoformalize": TEMP_MASA_AUTOFORMALIZE,
                "temperature_hard_critique": TEMP_MASA_HARD_CRITIQUE,
                "temperature_soft_critique": TEMP_MASA_SOFT_CRITIQUE,
                "temperature_formal_refine": TEMP_MASA_FORMAL_REFINE,
                "temperature_informal_refine": TEMP_MASA_INFORMAL_REFINE,
                "max_new_tokens":            MAX_NEW_TOKENS_GEN,
                "max_masa_iters":            self.max_masa_iters,
                "oracle_pass_threshold":     ORACLE_PASS_THRESHOLD,
                "aspect_description":        MASA_ASPECT_DESCRIPTION,
            },
            "results": {
                "final_success":               candidate.semantic_score >= ORACLE_PASS_THRESHOLD,
                "semantic_alignment_confirmed": round(candidate.semantic_score, 4),
                "final_error_type":            err_val,
                "wall_time_sec":               round(wall_time, 3),
            },
            "attempt_counts": {
                "llm_a_outer_attempts":      autoformalize_calls,
                "llm_b_semantic_flags":      soft_no_verdicts,
                "llm_c_cegar_iterations":    total_critique,
                "beam_candidates_generated": autoformalize_calls,
            },
            "error_analysis": {
                "error_type_sequence": error_type_seq,
                "error_type_counts":   dict(err_cnt),
            },
            "oracle_components": {
                "exec":        exec_ok,
                "solver":      solver_ok,
                "verdict":     verdict_ok,
                "proof":       proof_ok,
                "final_score": round(candidate.semantic_score, 4),
                "mode":        "full",
            },
            "baseline_metadata": {
                "baseline":              BASELINE_NAME,
                "tier":                  self.tier,
                "hard_critique_iters":   hard_critique_calls,
                "soft_critique_iters":   soft_no_verdicts,
                "formal_refinements":    formal_refine_calls,
                "informal_refinements":  informal_refine_calls,
                "soft_critique_verdicts": soft_verdict_log,
                "paper_ref":             "Zhang et al. MASA (arXiv:2510.08988)",
            },
        }
