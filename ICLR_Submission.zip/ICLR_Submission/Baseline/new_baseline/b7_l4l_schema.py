"""
B7 — L4L Schema-Guided Baseline

Adaptation of Chen et al. "L4L" (arXiv:2511.21033) to the privacy-law/Z3 domain.

L4L uses a two-phase role-agent approach:
  Phase 1 (Extractor Agent, T=0.0): extract a structured schema tuple from legal text
  Phase 2 (Instantiator Agent, T=0.7): convert the schema into formal code

The original schema was for criminal law (Actor-Action-DrugQuantity-Penalty).
We adapt it to privacy law: Actor-Action-Norm-Condition-Exception-Penalty.

If oracle fails, the schema is refined (Phase 1 re-run) then re-instantiated (Phase 2),
for up to MAX_L4L_ITERS total cycles.

Paper contribution → domain adaptation:
    Criminal-law schema (CN-CAIL)  →  Privacy-law schema (GDPR/CCPA/DPDP/PIPD)
    Two-role LLM pipeline          →  Same two-role pipeline with privacy schema
    SMT-LIB output                 →  Z3 Python output (matches oracle API)
"""
from __future__ import annotations

import json
import logging
import re
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

_BASELINE_PARENT = Path(__file__).resolve().parents[1]
if str(_BASELINE_PARENT) not in sys.path:
    sys.path.insert(0, str(_BASELINE_PARENT))

from baseline_config import (
    ORACLE_PASS_THRESHOLD,
    BASELINE_SYSTEM_MSG,
    MAX_NEW_TOKENS_GEN,
    MAX_NEW_TOKENS_DET,
    get_hf_model,
)
from new_baseline_config import (
    MAX_L4L_ITERS,
    TEMP_L4L_EXTRACT,
    TEMP_L4L_INSTANTIATE,
    PRIVACY_LAW_SCHEMA,
)

from SMT_Generation_AAAI_Final import (
    RefineSMT, Candidate, SemanticOracle, ErrorType,
)
from promting import Prompt

logger = logging.getLogger(__name__)

BASELINE_NAME = "b7_l4l_schema"

# ─────────────────────────────────────────────────────────────────────────────
# Prompts
# ─────────────────────────────────────────────────────────────────────────────

_SCHEMA_EXTRACT_SYSTEM = (
    "You are a legal ontology specialist. Extract structured schema tuples from "
    "legal text. Always respond with a valid JSON object only — no extra text."
)

_SCHEMA_EXTRACT_PROMPT = """\
Extract the following privacy-law schema from the legal section below.
Return ONLY a valid JSON object with these exact keys:

{{
  "norm_type":  "<obligation|prohibition|permission>",
  "actors":     ["<roles from: data_principal, data_fiduciary, data_processor, supervisory_authority>"],
  "action":     "<verb from: collect, process, disclose, transfer, erase, notify, store, share>",
  "conditions": ["<trigger conditions e.g. consent_given, purpose_specified, request_received, breach_occurred>"],
  "exceptions": ["<exception types e.g. legal_obligation, vital_interest, public_interest, defense_of_claims>"],
  "penalty":    "<penalty type e.g. administrative_fine, civil_claim, criminal_sanction or null>"
}}

Legal section:
{SectionText}

{RefinementHint}

Respond ONLY with the JSON object. No explanation, no markdown fences.
"""

_INSTANTIATE_SYSTEM = (
    "You are an expert Python and Z3 formal-verification engineer specializing in "
    "privacy law formalization. Output only a single fenced ```python\\n...\\n``` code block."
)

_INSTANTIATE_PROMPT = """\
Using the structured privacy-law schema below, generate a complete Z3 Python class
that formally encodes the legal rule.

Schema:
{SchemaJSON}

Legal section (for reference):
{SectionText}

Requirements:
- Class name: Section{StemClass}
- __init__ declares all z3.Bool variables needed for actors, conditions, exceptions
- get_rule() returns the Z3 formula encoding Norm(Actor, Action | Condition, not Exception)
- verify_data(data) creates a z3.Solver, adds get_rule(), checks data dict values
- Encode the norm_type correctly:
    obligation  → z3.Implies(condition, action_required)
    prohibition → z3.Implies(condition, z3.Not(action_forbidden))
    permission  → z3.Or(condition_grounds)

{PriorFeedback}

Output ONLY a single ```python\\n...\\n``` code block.
"""


def _extract_schema_json(raw: str) -> Optional[dict]:
    """Parse JSON from LLM schema extraction response."""
    # Try to find JSON in the response
    raw = raw.strip()
    # Remove any markdown fences
    raw = re.sub(r"```json\s*", "", raw)
    raw = re.sub(r"```\s*", "", raw)
    # Find first { ... }
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        return None


def _schema_completeness(schema: Optional[dict]) -> float:
    """Return fraction of required schema fields that are non-empty."""
    if not schema:
        return 0.0
    required = ["norm_type", "actors", "action", "conditions", "exceptions"]
    filled = sum(
        1 for k in required
        if k in schema and schema[k] and schema[k] != [] and schema[k] != ""
    )
    return round(filled / len(required), 4)


def _section_to_text(section: dict) -> str:
    if isinstance(section, str):
        return section
    parts = []
    for key in ("section_number", "title", "text", "content", "section_text"):
        if key in section and section[key]:
            parts.append(str(section[key]))
    return "\n".join(parts) if parts else str(section)


def _stem_to_classname(stem: str) -> str:
    """Convert file stem (e.g. Ch2_Art5) to a valid Python class suffix."""
    return re.sub(r"[^A-Za-z0-9]", "_", stem)


# ─────────────────────────────────────────────────────────────────────────────
# Main class
# ─────────────────────────────────────────────────────────────────────────────

class L4LSchemaBaseline:
    """
    B7: Two-phase schema-guided Z3 generation.

    Phase 1 (Extractor): structured JSON schema from legal text (T=0.0)
    Phase 2 (Instantiator): Z3 Python code from schema (T=0.7)
    """

    def __init__(
        self,
        model_id: str,
        tier: str,
        output_root: Path,
        act_name: str,
        run_id: str,
        max_l4l_iters: int = MAX_L4L_ITERS,
    ) -> None:
        self.model_id      = model_id
        self.tier          = tier
        self.output_root   = Path(output_root)
        self.act_name      = act_name
        self.run_id        = run_id
        self.max_l4l_iters = max_l4l_iters

        self.HFModel  = get_hf_model(tier)
        self.oracle   = SemanticOracle()
        self.prompter = Prompt()

        self._section_logs: list[dict] = []
        self.output_root.mkdir(parents=True, exist_ok=True)
        logger.info(
            "B7 L4L-Schema ready | tier=%s model=%s act=%s max_iters=%d",
            tier, model_id, act_name, max_l4l_iters,
        )

    # ── Per-section ───────────────────────────────────────────────────────────

    def process_section(self, section: dict, filename_stem: str) -> None:
        section_id   = section.get("section_number", filename_stem)
        t0           = time.time()
        section_dir  = self.output_root / filename_stem
        section_dir.mkdir(parents=True, exist_ok=True)

        logger.info("[%s] ════ B7 L4L-Schema ════", section_id)

        section_text       = _section_to_text(section)
        stem_class         = _stem_to_classname(filename_stem)
        error_type_seq: list[str] = []
        schema_completeness_log: list[float] = []

        schema_refinement_iters = 0
        prior_feedback          = ""
        schema: Optional[dict]  = None
        best_candidate          = Candidate(code_blocks=[], raw_response="")
        iters_done              = 0
        extract_calls           = 0
        instantiate_calls       = 0
        completeness_flags      = 0

        for iteration in range(self.max_l4l_iters):
            logger.info(
                "[%s] ════ L4L iter %d/%d ════",
                section_id, iteration + 1, self.max_l4l_iters,
            )

            # ── Phase 1: Schema Extraction (T=0.0) ────────────────────────────
            refinement_hint = (
                f"Previous schema was incomplete or generated wrong code. "
                f"Reason: {prior_feedback}" if prior_feedback else ""
            )
            extract_prompt = _SCHEMA_EXTRACT_PROMPT.format(
                SectionText    = section_text[:2000],
                RefinementHint = refinement_hint,
            )
            extract_raw = self.HFModel.call(
                self.model_id, extract_prompt,
                temperature=TEMP_L4L_EXTRACT,
                max_new_tokens=MAX_NEW_TOKENS_DET,
                system_message=_SCHEMA_EXTRACT_SYSTEM,
            )
            extract_calls += 1

            schema = _extract_schema_json(extract_raw)
            completeness = _schema_completeness(schema)
            schema_completeness_log.append(completeness)

            if completeness < 0.6:
                completeness_flags += 1
                logger.warning(
                    "[%s]   Schema incomplete (%.0f%%) — iter %d",
                    section_id, completeness * 100, iteration + 1,
                )
                prior_feedback = (
                    f"The schema was only {completeness*100:.0f}% complete. "
                    "Ensure norm_type, actors, action, and conditions are all filled."
                )
                schema_refinement_iters += 1
                # Skip instantiation on very incomplete schema, try extract again
                if completeness < 0.2 and iteration < self.max_l4l_iters - 1:
                    error_type_seq.append(ErrorType.NONE.value)
                    continue
            else:
                logger.info(
                    "[%s]   Schema extracted (%.0f%% complete): norm=%s actors=%s",
                    section_id, completeness * 100,
                    (schema or {}).get("norm_type", "?"),
                    (schema or {}).get("actors", []),
                )

            # ── Phase 2: Z3 Instantiation (T=0.7) ────────────────────────────
            schema_str = json.dumps(schema or {}, indent=2)
            inst_prompt = _INSTANTIATE_PROMPT.format(
                SchemaJSON    = schema_str,
                SectionText   = section_text[:1500],
                StemClass     = stem_class,
                PriorFeedback = (
                    f"Previous attempt failed: {prior_feedback}" if prior_feedback else ""
                ),
            )
            inst_raw = self.HFModel.call(
                self.model_id, inst_prompt,
                temperature=TEMP_L4L_INSTANTIATE,
                max_new_tokens=MAX_NEW_TOKENS_GEN,
                system_message=_INSTANTIATE_SYSTEM,
            )
            instantiate_calls += 1

            blocks = RefineSMT.extract_code(inst_raw)
            if not blocks:
                logger.warning(
                    "[%s]   No code extracted at L4L iter %d", section_id, iteration + 1,
                )

            candidate = Candidate(code_blocks=blocks, raw_response=inst_raw)
            self.oracle.execute_and_score(candidate)
            error_type_seq.append(candidate.error_type.value)
            iters_done += 1

            logger.info(
                "[%s]   iter %d oracle: %.2f | exec=%s | verdict=%s | error=%s",
                section_id, iteration + 1, candidate.semantic_score,
                candidate.execution_success, candidate.z3_verdict,
                candidate.error_type.value,
            )

            if candidate.semantic_score > best_candidate.semantic_score:
                best_candidate = candidate

            if candidate.semantic_score >= ORACLE_PASS_THRESHOLD:
                logger.info(
                    "[%s] SUCCESS at L4L iter %d — oracle=%.2f",
                    section_id, iteration + 1, candidate.semantic_score,
                )
                break

            # Prepare feedback for schema refinement
            prior_feedback = (
                f"error_type={candidate.error_type.value}, "
                f"error={candidate.error_message or 'none'}"
            )
            schema_refinement_iters += 1
        else:
            logger.warning(
                "[%s] FAILED — all %d L4L iters exhausted (best=%.2f)",
                section_id, self.max_l4l_iters, best_candidate.semantic_score,
            )

        wall_time = time.time() - t0
        metrics = self._build_metrics(
            section, filename_stem, best_candidate, wall_time,
            extract_calls, instantiate_calls, completeness_flags,
            schema_refinement_iters, schema, schema_completeness_log, error_type_seq,
        )
        self._section_logs.append(metrics)

        metrics_path = section_dir / "section_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        logger.info("[%s] Log saved → %s", section_id, metrics_path)

        if best_candidate.code_blocks:
            code_path = section_dir / "final_code.py"
            code_path.write_text(best_candidate.code_blocks[0], encoding="utf-8")
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)

    # ── Aggregate ─────────────────────────────────────────────────────────────

    def save_aggregate_metrics(self) -> None:
        if not self._section_logs:
            return
        total     = len(self._section_logs)
        successes = sum(1 for m in self._section_logs if m["results"]["final_success"])
        agg = {
            "algorithm":     BASELINE_NAME,
            "tier":          self.tier,
            "act":           self.act_name,
            "run_id":        self.run_id,
            "model":         self.model_id,
            "max_l4l_iters": self.max_l4l_iters,
            "acts_processed":  total,
            "successful":      successes,
            "failed":          total - successes,
            "success_rate":    round(successes / total, 4) if total else 0.0,
            "mean_wall_time_sec": round(
                sum(m["results"]["wall_time_sec"] for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "mean_schema_completeness": round(
                sum(
                    m["baseline_metadata"].get("schema_completeness", 0.0)
                    for m in self._section_logs
                ) / total, 4
            ) if total else 0.0,
            "per_section": self._section_logs,
        }
        out = self.output_root / "aggregate_metrics.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(agg, f, indent=2)
        logger.info(
            "B7 aggregate metrics → %s  (success=%d/%d mean_schema_comp=%.2f)",
            out, successes, total, agg["mean_schema_completeness"],
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_metrics(
        self,
        section: dict,
        filename_stem: str,
        candidate: Candidate,
        wall_time: float,
        extract_calls: int,
        instantiate_calls: int,
        completeness_flags: int,
        schema_refinement_iters: int,
        schema: Optional[dict],
        schema_completeness_log: list[float],
        error_type_seq: list[str],
    ) -> dict:
        err_val    = candidate.error_type.value
        err_cnt    = Counter(error_type_seq)
        exec_ok    = float(candidate.execution_success)
        solver_ok  = float(candidate.semantic_score >= 0.7)
        verdict_ok = float(candidate.z3_verdict in ("sat", "unsat"))
        proof_ok   = float(candidate.semantic_score >= 1.0)
        final_comp = schema_completeness_log[-1] if schema_completeness_log else 0.0

        return {
            "algorithm":  BASELINE_NAME,
            "act_file":   filename_stem,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "models":     {"primary": self.model_id},
            "hyperparameters": {
                "temperature_extract":     TEMP_L4L_EXTRACT,
                "temperature_instantiate": TEMP_L4L_INSTANTIATE,
                "max_new_tokens":          MAX_NEW_TOKENS_GEN,
                "max_l4l_iters":           self.max_l4l_iters,
                "oracle_pass_threshold":   ORACLE_PASS_THRESHOLD,
            },
            "results": {
                "final_success":               candidate.semantic_score >= ORACLE_PASS_THRESHOLD,
                "semantic_alignment_confirmed": round(candidate.semantic_score, 4),
                "final_error_type":            err_val,
                "wall_time_sec":               round(wall_time, 3),
            },
            "attempt_counts": {
                "llm_a_outer_attempts":      instantiate_calls,
                "llm_b_semantic_flags":      completeness_flags,
                "llm_c_cegar_iterations":    schema_refinement_iters,
                "beam_candidates_generated": instantiate_calls,
            },
            "error_analysis": {
                "error_type_sequence": error_type_seq,
                "error_type_counts":   dict(err_cnt),
            },
            "oracle_components": {
                "exec":        exec_ok,
                "solver":      solver_ok,
                "verdict":     verdict_ok,
                "proof":       proof_ok,
                "final_score": round(candidate.semantic_score, 4),
                "mode":        "full",
            },
            "baseline_metadata": {
                "baseline":               BASELINE_NAME,
                "tier":                   self.tier,
                "schema_extracted":       schema or {},
                "schema_completeness":    final_comp,
                "schema_completeness_log": schema_completeness_log,
                "schema_refinement_iters": schema_refinement_iters,
                "paper_ref":              "Chen et al. L4L (arXiv:2511.21033)",
            },
        }
