"""
new_baseline_config.py — Hyperparameter constants for new baselines B6–B9.

All values are kept separate from baseline_config.py to avoid polluting the
existing baseline namespace. Import this module in addition to baseline_config.
"""

# ── B6: AquaForte-Adapted ─────────────────────────────────────────────────────
# Lv et al. (arXiv:2601.04675) — LLM-guided adaptive retry with clause exclusion
MAX_AQUAFORTE_ITERS    = 5
TEMP_AQUAFORTE_GEN     = 0.7   # stochastic generation
TEMP_AQUAFORTE_ANALYSIS = 0.0  # deterministic "what is wrong" step

# ── B7: L4L Schema-Guided ─────────────────────────────────────────────────────
# Chen et al. (arXiv:2511.21033) — role-agent autoformalizer with domain schema
MAX_L4L_ITERS        = 3
TEMP_L4L_EXTRACT     = 0.0   # deterministic schema extraction
TEMP_L4L_INSTANTIATE = 0.7   # stochastic Z3 instantiation

# Privacy-law adaptation of L4L's criminal-law schema (Actor-Action-DrugQty-Penalty)
PRIVACY_LAW_SCHEMA: dict = {
    "Norm":      ["obligation", "prohibition", "permission"],
    "Actor":     ["data_principal", "data_fiduciary", "data_processor",
                  "supervisory_authority"],
    "Action":    ["collect", "process", "disclose", "transfer", "erase",
                  "notify", "store", "share"],
    "Condition": ["consent_given", "purpose_specified", "request_received",
                  "breach_occurred", "legitimate_interest"],
    "Exception": ["legal_obligation", "vital_interest", "public_interest",
                  "defense_of_claims", "scientific_research"],
    "Penalty":   ["administrative_fine", "civil_claim", "criminal_sanction"],
}

# ── B8: MASA Multi-Agent ──────────────────────────────────────────────────────
# Zhang et al. (arXiv:2510.08988) — hard+soft critique with formal+informal refine
MAX_MASA_ITERS          = 3
TEMP_MASA_AUTOFORMALIZE = 0.7  # initial generation
TEMP_MASA_HARD_CRITIQUE = 0.0  # formal error analysis
TEMP_MASA_SOFT_CRITIQUE = 0.0  # semantic coverage check
TEMP_MASA_FORMAL_REFINE = 0.0  # fix formal errors only
TEMP_MASA_INFORMAL_REFINE = 0.7  # revise legal interpretation
MASA_ASPECT_DESCRIPTION = (
    "all legal obligations, prohibitions, exceptions, conditions, "
    "actor roles, and temporal constraints"
)

# ── B9: RAG+SMT ───────────────────────────────────────────────────────────────
# Hsia et al. (arXiv:2601.06181) — BM25 retrieval + LLM→SMT + MaxSMT repair
RAG_TOP_K      = 3
RAG_METHOD     = "bm25"
TEMP_RAG_GEN   = 0.7
MAXSMT_ENABLED = True
