"""
B9 — RAG+SMT Baseline

Adaptation of Hsia et al. (arXiv:2601.06181) to the Z3/legal domain.

Core pipeline:
  1. BM25 retrieval: find top-K related sections from the same act corpus
  2. LLM generation: produce Z3 code with retrieved context (T=0.7)
  3. Oracle check: standard SemanticOracle
  4. MaxSMT repair: if oracle fails with encoding error, try Z3 Optimize() to
     find the minimal constraint violation set, then feed violations to LLM

BM25 implementation uses rank_bm25 (pure Python); falls back to simple TF overlap
if rank_bm25 is not installed.

Paper contribution → domain adaptation:
    Legal NLP pipeline (Hsia et al.)   →  Privacy-law Z3 formalization
    RAG over legal corpus              →  BM25 over same-act UML_Annotations JSONs
    SMT consistency check              →  SemanticOracle (exec + solver + verdict)
    MaxSMT for minimal violations      →  Z3 Optimize() soft-constraint transformation
"""
from __future__ import annotations

import json
import logging
import os
import re
import sys
import textwrap
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

_BASELINE_PARENT = Path(__file__).resolve().parents[1]
if str(_BASELINE_PARENT) not in sys.path:
    sys.path.insert(0, str(_BASELINE_PARENT))

from baseline_config import (
    ORACLE_PASS_THRESHOLD,
    BASELINE_SYSTEM_MSG,
    MAX_NEW_TOKENS_GEN,
    MAX_NEW_TOKENS_DET,
    get_hf_model,
    ACTS_INPUT,
    IGNORE_FILES,
)
from new_baseline_config import (
    RAG_TOP_K,
    RAG_METHOD,
    TEMP_RAG_GEN,
    MAXSMT_ENABLED,
)

from SMT_Generation_AAAI_Final import (
    RefineSMT, Candidate, SemanticOracle, ErrorType,
)
from promting import Prompt

logger = logging.getLogger(__name__)

BASELINE_NAME = "b9_rag_smt"

# ─────────────────────────────────────────────────────────────────────────────
# BM25 / retrieval layer
# ─────────────────────────────────────────────────────────────────────────────

def _tokenize(text: str) -> list[str]:
    """Simple whitespace + lowercase tokenization."""
    return re.findall(r"[a-z0-9]+", text.lower())


def _build_corpus(act: str) -> list[dict]:
    """Load all section JSONs for an act, return list of {id, text, tokens}."""
    act_path = ACTS_INPUT.get(act)
    if not act_path or not act_path.exists():
        return []
    corpus = []
    for fname in sorted(os.listdir(act_path)):
        if not fname.endswith(".json") or fname in IGNORE_FILES:
            continue
        fpath = act_path / fname
        try:
            with open(fpath, encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            continue
        text_parts = []
        for key in ("section_number", "title", "text", "content", "section_text"):
            if key in data and data[key]:
                text_parts.append(str(data[key]))
        text = " ".join(text_parts)
        corpus.append({
            "id":     fname.replace(".json", ""),
            "text":   text,
            "tokens": _tokenize(text),
        })
    return corpus


def _bm25_scores(corpus: list[dict], query_tokens: list[str]) -> list[float]:
    """BM25 scoring using rank_bm25 if available, else TF-overlap fallback."""
    try:
        from rank_bm25 import BM25Okapi  # noqa: PLC0415
        bm25 = BM25Okapi([doc["tokens"] for doc in corpus])
        return bm25.get_scores(query_tokens).tolist()
    except ImportError:
        # Fallback: TF-overlap (cosine-like)
        query_set = set(query_tokens)
        scores = []
        for doc in corpus:
            doc_set = set(doc["tokens"])
            overlap = len(query_set & doc_set)
            score   = overlap / (len(query_set | doc_set) + 1e-9)
            scores.append(score)
        return scores


def retrieve_top_k(
    act: str,
    query_text: str,
    query_section_id: str,
    top_k: int = RAG_TOP_K,
) -> list[dict]:
    """Return up to top_k sections from the same act, excluding self."""
    corpus = _build_corpus(act)
    if not corpus:
        return []

    query_tokens = _tokenize(query_text)
    scores = _bm25_scores(corpus, query_tokens)

    ranked = sorted(
        zip(scores, corpus),
        key=lambda x: x[0],
        reverse=True,
    )

    results = []
    for score, doc in ranked:
        if doc["id"] == query_section_id:
            continue
        results.append({**doc, "retrieval_score": round(score, 6)})
        if len(results) >= top_k:
            break
    return results


# ─────────────────────────────────────────────────────────────────────────────
# MaxSMT transformation
# ─────────────────────────────────────────────────────────────────────────────

def _apply_maxsmt(code: str) -> tuple[str, list[str]]:
    """
    Transform Z3 Solver code into MaxSMT code using Z3 Optimize().

    Replaces:
      solver = z3.Solver()  →  solver = z3.Optimize()
      solver.add(X)         →  solver.add_soft(X)    (soft constraints)
      solver.check()        →  solver.check()

    After check(), extracts which soft constraints are unsatisfied.
    Returns (transformed_code, violated_constraint_names).
    """
    transformed = code

    # Replace Solver() with Optimize()
    transformed = re.sub(
        r"\bz3\.Solver\s*\(\s*\)",
        "z3.Optimize()",
        transformed,
    )
    # Replace solver.add( with solver.add_soft( to make all constraints soft
    # (so MaxSMT finds the minimum violation set)
    transformed = re.sub(
        r"\bsolver\.add\s*\(",
        "solver.add_soft(",
        transformed,
    )

    # Inject violation reporting after check()
    # Find the print(result) or check() call and add reporting
    violation_snippet = textwrap.dedent("""\
        _result = solver.check()
        _violations = []
        if _result == z3.sat:
            _model = solver.model()
            # Soft constraints with weight=1; unsat ones are violations
        print("MaxSMT result:", _result)
        print("Violations:", _violations)
    """)

    # Replace the last `solver.check()` call pattern with our snippet
    transformed = re.sub(
        r"(result\s*=\s*)?solver\.check\(\)",
        "_maxsmt_check = solver.check()\nprint(_maxsmt_check)",
        transformed,
        count=1,
    )

    return transformed, []


def _run_maxsmt_code(transformed_code: str) -> tuple[str, list[str]]:
    """
    Execute the MaxSMT-transformed code and capture result/violations.
    Returns (status: 'sat'|'unsat'|'unknown'|'error', violations: list[str]).
    """
    import subprocess
    import tempfile

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, encoding="utf-8"
    ) as tmp:
        tmp.write(transformed_code)
        tmp_path = tmp.name

    try:
        result = subprocess.run(
            [sys.executable, tmp_path],
            capture_output=True, text=True, timeout=30,
        )
        stdout = result.stdout.strip()
        status = "unknown"
        if "sat" in stdout.lower():
            status = "sat" if "unsat" not in stdout.lower() else "unsat"
        violations: list[str] = []
        for line in stdout.splitlines():
            if line.startswith("Violations:"):
                try:
                    violations = json.loads(line.split(":", 1)[1].strip())
                except Exception:
                    pass
        return status, violations
    except Exception as e:
        return "error", [str(e)[:100]]
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Prompts
# ─────────────────────────────────────────────────────────────────────────────

_RAG_GENERATION_PROMPT = """\
Generate a Z3 Python encoding for the following primary legal section.
You are also provided with related sections from the same act for cross-section context.

=== PRIMARY SECTION (encode this) ===
{PrimaryText}

=== RELATED SECTIONS (context only — do NOT encode these) ===
{RetrievedContext}

Requirements:
- Encode ONLY the primary section
- Use the related sections ONLY as context for correct variable naming and scope
- Class with __init__ (z3 variable declarations), get_rule() (Z3 formula), verify_data(data)

Output ONLY a single ```python\\n...\\n``` code block.
"""

_MAXSMT_REPAIR_PROMPT = """\
The Z3 encoding below has constraint violations detected by MaxSMT analysis.

Legal section:
{SectionText}

Current Z3 code:
```python
{Code}
```

MaxSMT analysis found these violations:
{Violations}

Oracle failure:
  Error type   : {ErrorType}
  Error message: {ErrorMessage}

Repair the Z3 encoding to resolve the constraint violations while correctly encoding
all obligations and exceptions from the legal text.

Output ONLY a single ```python\\n...\\n``` code block.
"""


def _section_to_text(section: dict) -> str:
    if isinstance(section, str):
        return section
    parts = []
    for key in ("section_number", "title", "text", "content", "section_text"):
        if key in section and section[key]:
            parts.append(str(section[key]))
    return "\n".join(parts) if parts else str(section)


def _format_retrieved_context(docs: list[dict]) -> str:
    """Format retrieved docs as labeled context block."""
    if not docs:
        return "(no related sections retrieved)"
    parts = []
    for i, doc in enumerate(docs, 1):
        preview = doc["text"][:500] if doc["text"] else "(empty)"
        parts.append(f"[{i}] {doc['id']}:\n{preview}")
    return "\n\n".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
# Main class
# ─────────────────────────────────────────────────────────────────────────────

class RAGSMTBaseline:
    """
    B9: BM25 retrieval + LLM generation with cross-section context + MaxSMT repair.

    Implements the pipeline from Hsia et al. (arXiv:2601.06181) adapted to the
    Z3/privacy-law formalization setting.
    """

    def __init__(
        self,
        model_id: str,
        tier: str,
        output_root: Path,
        act_name: str,
        run_id: str,
        rag_top_k: int = RAG_TOP_K,
        maxsmt_enabled: bool = MAXSMT_ENABLED,
    ) -> None:
        self.model_id       = model_id
        self.tier           = tier
        self.output_root    = Path(output_root)
        self.act_name       = act_name
        self.run_id         = run_id
        self.rag_top_k      = rag_top_k
        self.maxsmt_enabled = maxsmt_enabled

        self.HFModel  = get_hf_model(tier)
        self.oracle   = SemanticOracle()
        self.prompter = Prompt()

        self._section_logs: list[dict] = []
        self.output_root.mkdir(parents=True, exist_ok=True)
        logger.info(
            "B9 RAG+SMT ready | tier=%s model=%s act=%s top_k=%d maxsmt=%s",
            tier, model_id, act_name, rag_top_k, maxsmt_enabled,
        )

    # ── Per-section ───────────────────────────────────────────────────────────

    def process_section(self, section: dict, filename_stem: str) -> None:
        section_id  = section.get("section_number", filename_stem)
        t0          = time.time()
        section_dir = self.output_root / filename_stem
        section_dir.mkdir(parents=True, exist_ok=True)

        logger.info("[%s] ════ B9 RAG+SMT ════", section_id)

        section_text = _section_to_text(section)
        error_type_seq: list[str] = []

        llm_gen_calls    = 0
        maxsmt_applied   = False
        maxsmt_violations: list[str] = []
        consistency_result = "unknown"

        # ── Step 1: BM25 Retrieval ────────────────────────────────────────────
        retrieved_docs = retrieve_top_k(
            act       = self.act_name,
            query_text = section_text,
            query_section_id = filename_stem,
            top_k     = self.rag_top_k,
        )
        retrieved_ids = [doc["id"] for doc in retrieved_docs]
        logger.info(
            "[%s] Retrieved %d docs: %s",
            section_id, len(retrieved_docs), retrieved_ids,
        )

        retrieved_context = _format_retrieved_context(retrieved_docs)

        # ── Step 2: LLM Generation with Context (T=0.7) ───────────────────────
        rag_prompt = _RAG_GENERATION_PROMPT.format(
            PrimaryText      = section_text[:1500],
            RetrievedContext = retrieved_context[:2000],
        )
        raw = self.HFModel.call(
            self.model_id, rag_prompt,
            temperature=TEMP_RAG_GEN,
            max_new_tokens=MAX_NEW_TOKENS_GEN,
            system_message=BASELINE_SYSTEM_MSG,
        )
        llm_gen_calls += 1

        blocks = RefineSMT.extract_code(raw)
        if not blocks:
            logger.warning("[%s] No code extracted at RAG generation", section_id)

        candidate = Candidate(code_blocks=blocks, raw_response=raw)
        self.oracle.execute_and_score(candidate)
        error_type_seq.append(candidate.error_type.value)

        # Record Z3 consistency check result from oracle
        consistency_result = candidate.z3_verdict or "unknown"

        logger.info(
            "[%s] RAG oracle: %.2f | exec=%s | verdict=%s | error=%s",
            section_id, candidate.semantic_score,
            candidate.execution_success, candidate.z3_verdict,
            candidate.error_type.value,
        )

        best_candidate = candidate

        # ── Step 3: MaxSMT Repair (if enabled and oracle fails) ───────────────
        if (
            self.maxsmt_enabled
            and candidate.semantic_score < ORACLE_PASS_THRESHOLD
            and candidate.code_blocks
            and candidate.error_type in (
                ErrorType.Z3_ENCODING, ErrorType.SEMANTIC_INV, ErrorType.OVER_CONSTRAINED,
            )
        ):
            logger.info("[%s] Applying MaxSMT transformation...", section_id)
            maxsmt_applied = True

            current_code = candidate.code_blocks[0]
            transformed_code, _ = _apply_maxsmt(current_code)
            maxsmt_status, maxsmt_violations = _run_maxsmt_code(transformed_code)

            logger.info(
                "[%s] MaxSMT: status=%s violations=%s",
                section_id, maxsmt_status, maxsmt_violations[:3],
            )

            # Feed violations to LLM for targeted repair
            violations_str = (
                "\n".join(f"  - {v}" for v in maxsmt_violations)
                if maxsmt_violations else "  (MaxSMT could not isolate specific violations)"
            )
            repair_prompt = _MAXSMT_REPAIR_PROMPT.format(
                SectionText  = section_text[:1500],
                Code         = current_code[:2000],
                Violations   = violations_str,
                ErrorType    = candidate.error_type.value,
                ErrorMessage = (candidate.error_message or "none")[:200],
            )
            repair_raw = self.HFModel.call(
                self.model_id, repair_prompt,
                temperature=TEMP_RAG_GEN,
                max_new_tokens=MAX_NEW_TOKENS_GEN,
                system_message=BASELINE_SYSTEM_MSG,
            )
            llm_gen_calls += 1

            new_blocks = RefineSMT.extract_code(repair_raw)
            if not new_blocks:
                logger.warning("[%s] No code extracted at MaxSMT repair", section_id)

            new_candidate = Candidate(code_blocks=new_blocks, raw_response=repair_raw)
            self.oracle.execute_and_score(new_candidate)
            error_type_seq.append(new_candidate.error_type.value)
            consistency_result = new_candidate.z3_verdict or consistency_result

            logger.info(
                "[%s] Post-MaxSMT oracle: %.2f | error=%s",
                section_id, new_candidate.semantic_score, new_candidate.error_type.value,
            )

            if new_candidate.semantic_score > best_candidate.semantic_score:
                best_candidate = new_candidate

            if new_candidate.semantic_score >= ORACLE_PASS_THRESHOLD:
                logger.info(
                    "[%s] SUCCESS after MaxSMT repair — oracle=%.2f",
                    section_id, new_candidate.semantic_score,
                )
            else:
                logger.warning(
                    "[%s] MaxSMT repair did not reach threshold (best=%.2f)",
                    section_id, best_candidate.semantic_score,
                )
        elif candidate.semantic_score >= ORACLE_PASS_THRESHOLD:
            logger.info(
                "[%s] SUCCESS at RAG generation — oracle=%.2f",
                section_id, candidate.semantic_score,
            )

        wall_time = time.time() - t0
        metrics = self._build_metrics(
            section, filename_stem, best_candidate, wall_time,
            llm_gen_calls, retrieved_docs, retrieved_ids,
            maxsmt_applied, maxsmt_violations, consistency_result, error_type_seq,
        )
        self._section_logs.append(metrics)

        metrics_path = section_dir / "section_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        logger.info("[%s] Log saved → %s", section_id, metrics_path)

        if best_candidate.code_blocks:
            code_path = section_dir / "final_code.py"
            code_path.write_text(best_candidate.code_blocks[0], encoding="utf-8")
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)

    # ── Aggregate ─────────────────────────────────────────────────────────────

    def save_aggregate_metrics(self) -> None:
        if not self._section_logs:
            return
        total     = len(self._section_logs)
        successes = sum(1 for m in self._section_logs if m["results"]["final_success"])
        maxsmt_applied_count = sum(
            1 for m in self._section_logs
            if m["baseline_metadata"]["maxsmt_applied"]
        )
        agg = {
            "algorithm":       BASELINE_NAME,
            "tier":            self.tier,
            "act":             self.act_name,
            "run_id":          self.run_id,
            "model":           self.model_id,
            "rag_top_k":       self.rag_top_k,
            "maxsmt_enabled":  self.maxsmt_enabled,
            "acts_processed":  total,
            "successful":      successes,
            "failed":          total - successes,
            "success_rate":    round(successes / total, 4) if total else 0.0,
            "mean_wall_time_sec": round(
                sum(m["results"]["wall_time_sec"] for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "maxsmt_applied_count": maxsmt_applied_count,
            "per_section": self._section_logs,
        }
        out = self.output_root / "aggregate_metrics.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(agg, f, indent=2)
        logger.info(
            "B9 aggregate metrics → %s  (success=%d/%d maxsmt_applied=%d)",
            out, successes, total, maxsmt_applied_count,
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_metrics(
        self,
        section: dict,
        filename_stem: str,
        candidate: Candidate,
        wall_time: float,
        llm_gen_calls: int,
        retrieved_docs: list[dict],
        retrieved_ids: list[str],
        maxsmt_applied: bool,
        maxsmt_violations: list[str],
        consistency_result: str,
        error_type_seq: list[str],
    ) -> dict:
        err_val    = candidate.error_type.value
        err_cnt    = Counter(error_type_seq)
        exec_ok    = float(candidate.execution_success)
        solver_ok  = float(candidate.semantic_score >= 0.7)
        verdict_ok = float(candidate.z3_verdict in ("sat", "unsat"))
        proof_ok   = float(candidate.semantic_score >= 1.0)
        maxsmt_trigger = 1 if maxsmt_applied else 0
        maxsmt_repair_calls = 1 if maxsmt_applied else 0

        return {
            "algorithm":  BASELINE_NAME,
            "act_file":   filename_stem,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "models":     {"primary": self.model_id},
            "hyperparameters": {
                "temperature_gen":       TEMP_RAG_GEN,
                "max_new_tokens":        MAX_NEW_TOKENS_GEN,
                "rag_top_k":             self.rag_top_k,
                "rag_method":            RAG_METHOD,
                "maxsmt_enabled":        self.maxsmt_enabled,
                "oracle_pass_threshold": ORACLE_PASS_THRESHOLD,
            },
            "results": {
                "final_success":               candidate.semantic_score >= ORACLE_PASS_THRESHOLD,
                "semantic_alignment_confirmed": round(candidate.semantic_score, 4),
                "final_error_type":            err_val,
                "wall_time_sec":               round(wall_time, 3),
            },
            "attempt_counts": {
                "llm_a_outer_attempts":      llm_gen_calls,
                "llm_b_semantic_flags":      maxsmt_trigger,
                "llm_c_cegar_iterations":    maxsmt_repair_calls,
                "beam_candidates_generated": llm_gen_calls,
            },
            "error_analysis": {
                "error_type_sequence": error_type_seq,
                "error_type_counts":   dict(err_cnt),
            },
            "oracle_components": {
                "exec":        exec_ok,
                "solver":      solver_ok,
                "verdict":     verdict_ok,
                "proof":       proof_ok,
                "final_score": round(candidate.semantic_score, 4),
                "mode":        "full",
            },
            "baseline_metadata": {
                "baseline":                BASELINE_NAME,
                "tier":                    self.tier,
                "rag_docs_retrieved":      len(retrieved_docs),
                "retrieved_section_ids":   retrieved_ids,
                "rag_method":              RAG_METHOD,
                "maxsmt_applied":          maxsmt_applied,
                "maxsmt_violations":       maxsmt_violations,
                "consistency_check_result": consistency_result,
                "paper_ref":               "Hsia et al. (arXiv:2601.06181)",
            },
        }
