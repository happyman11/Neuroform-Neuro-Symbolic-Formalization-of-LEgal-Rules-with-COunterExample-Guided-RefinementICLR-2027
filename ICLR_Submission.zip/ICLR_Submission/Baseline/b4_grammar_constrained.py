"""
B4 — Grammar-Constrained Generation

Enforces structural validity of generated Z3 programs at generation time.

Two backends (selected automatically):

1. outlines (primary, if installed):
   Uses token-level constrained decoding via outlines.generate.regex() to force
   the model output to match r"```python\n[^`]+```", guaranteeing a Python code
   fence is always produced.  Install: pip install outlines

2. template_fallback (if outlines not available or --force-template-fallback):
   Prompts the model to return a JSON with "variables" and "constraints" lists,
   then composes them into a fixed Z3 class skeleton, guaranteeing structural
   validity (import z3, __init__, get_rule, verify_data).  If JSON parsing fails,
   falls back to plain FOL_Structure generation.

In both cases, a single generation pass is performed (no retry) — the grammar
constraint is intended to handle structural correctness so iterative repair
is unnecessary for this baseline.
"""
from __future__ import annotations

import json
import logging
import re
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from baseline_config import (
    ORACLE_PASS_THRESHOLD,
    BASELINE_SYSTEM_MSG,
    DEFAULT_TEMPERATURE_GEN,
    MAX_NEW_TOKENS_GEN,
    MAX_NEW_TOKENS_DET,
    baseline_run_dir,
    get_hf_model,
)
from baseline_prompts import GRAMMAR_FILL_PROMPT

from SMT_Generation_AAAI_Final import (
    RefineSMT, Candidate, SemanticOracle, classify_error, ErrorType,
)
from promting import Prompt

logger = logging.getLogger(__name__)

BASELINE_NAME = "b4_grammar_constrained"

# ── outlines availability ──────────────────────────────────────────────────────
try:
    import outlines                          # noqa: F401
    import outlines.models as _outlines_models
    import outlines.generate as _outlines_generate
    OUTLINES_AVAILABLE = True
    _OUTLINES_VERSION = getattr(outlines, "__version__", "unknown")
    logger.info("outlines %s available — B4 will use regex-constrained generation",
                _OUTLINES_VERSION)
except ImportError:
    OUTLINES_AVAILABLE = False
    _OUTLINES_VERSION = None
    logger.warning(
        "outlines not installed — B4 will use template_fallback mode. "
        "Install with: pip install outlines"
    )

# Regex that forces a Python code fence in the output
_FENCE_REGEX = r"```python\n[^`]+```"

_FILL_SYSTEM_MSG = (
    "You are an expert in Z3 formal verification. "
    "Output ONLY a valid JSON object with keys 'variables' and 'constraints'. "
    "No prose, no markdown, no code fences."
)


class GrammarConstrainedBaseline:
    """B4: grammar-constrained Z3 generation, outlines backend with template fallback."""

    def __init__(
        self,
        model_id: str,
        tier: str,
        output_root: Path,
        act_name: str,
        run_id: str,
        temperature: float = DEFAULT_TEMPERATURE_GEN,
        force_fallback: bool = False,
    ) -> None:
        self.model_id      = model_id
        self.tier          = tier
        self.output_root   = Path(output_root)
        self.act_name      = act_name
        self.run_id        = run_id
        self.temperature   = temperature
        self.force_fallback = force_fallback

        self._use_outlines = OUTLINES_AVAILABLE and not force_fallback

        self.HFModel   = get_hf_model(tier)
        self.oracle    = SemanticOracle()
        self.prompter  = Prompt()

        self._section_logs: list[dict] = []
        self._outlines_model = None  # lazy-loaded

        self.output_root.mkdir(parents=True, exist_ok=True)
        backend = "outlines" if self._use_outlines else "template_fallback"
        logger.info("B4 GrammarConstrained ready | tier=%s model=%s backend=%s act=%s",
                    tier, model_id, backend, act_name)

    # ── Per-section ───────────────────────────────────────────────────────────

    def process_section(self, section: dict, filename_stem: str) -> None:
        section_id = section.get("section_number", filename_stem)
        t0 = time.time()

        section_dir = self.output_root / filename_stem
        section_dir.mkdir(parents=True, exist_ok=True)

        logger.info("[%s] ════ B4 Grammar-Constrained ════", section_id)

        if self._use_outlines:
            raw, grammar_backend = self._generate_outlines(section, section_id)
        else:
            raw, grammar_backend = self._generate_template_fallback(section, section_id)

        blocks = RefineSMT.extract_code(raw)
        if not blocks:
            logger.warning("[%s] No code extracted at attempt 1", section_id)

        candidate = Candidate(code_blocks=blocks, raw_response=raw)
        if blocks:
            self.oracle.execute_and_score(candidate)

        wall_time = time.time() - t0
        success = candidate.semantic_score >= ORACLE_PASS_THRESHOLD

        logger.info(
            "[%s] Oracle score: %.2f | exec=%s | verdict=%s | error=%s",
            section_id, candidate.semantic_score,
            candidate.execution_success, candidate.z3_verdict,
            candidate.error_type.value,
        )
        if success:
            logger.info("[%s] SUCCESS — oracle=%.2f wall_time=%.1fs",
                        section_id, candidate.semantic_score, wall_time)
        else:
            logger.warning("[%s] FAILED — all 1 attempts exhausted", section_id)

        metrics = self._build_metrics(
            section, filename_stem, candidate, grammar_backend, wall_time
        )
        self._section_logs.append(metrics)

        metrics_path = section_dir / "section_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        logger.info("[%s] Log saved → %s", section_id, metrics_path)

        if blocks:
            code_path = section_dir / "final_code.py"
            code_path.write_text(blocks[0], encoding="utf-8")
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)

    # ── Aggregate ─────────────────────────────────────────────────────────────

    def save_aggregate_metrics(self) -> None:
        if not self._section_logs:
            return
        total = len(self._section_logs)
        successes = sum(1 for m in self._section_logs
                        if m["results"]["final_success"])
        agg = {
            "algorithm":      BASELINE_NAME,
            "tier":           self.tier,
            "act":            self.act_name,
            "run_id":         self.run_id,
            "model":          self.model_id,
            "acts_processed": total,
            "successful":     successes,
            "failed":         total - successes,
            "success_rate":   round(successes / total, 4) if total else 0.0,
            "mean_wall_time_sec": round(
                sum(m["results"]["wall_time_sec"] for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "per_section":    self._section_logs,
        }
        out = self.output_root / "aggregate_metrics.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(agg, f, indent=2)
        logger.info("B4 aggregate → %s  (success=%d/%d)", out, successes, total)

    # ── Backend: outlines ─────────────────────────────────────────────────────

    def _generate_outlines(self, section: dict, section_id: str) -> tuple[str, str]:
        """Token-level regex-constrained generation via outlines."""
        try:
            if self._outlines_model is None:
                logger.info("[%s] Loading outlines model: %s", section_id, self.model_id)
                self._outlines_model = _outlines_models.transformers(self.model_id)

            prompt = self.prompter.get_FOL_acts(section, error="", prior_code="")
            generator = _outlines_generate.regex(self._outlines_model, _FENCE_REGEX)
            raw = generator(prompt)
            logger.info("[%s] outlines generation complete", section_id)
            return raw, "outlines"
        except Exception as exc:
            logger.warning(
                "[%s] outlines generation failed (%s) — falling back to template_fallback",
                section_id, exc,
            )
            return self._generate_template_fallback(section, section_id)

    # ── Backend: template fallback ────────────────────────────────────────────

    def _generate_template_fallback(self, section: dict, section_id: str) -> tuple[str, str]:
        """
        Prompt the model to fill a JSON with variable/constraint lists, then compose
        them into a fixed Z3 class skeleton — guaranteeing structural validity.
        Falls through to plain FOL_Structure if JSON parsing fails.
        """
        # Derive a safe Python class name from the section identifier
        class_name = re.sub(r"[^A-Za-z0-9]", "", section_id.replace("_", " ").title().replace(" ", ""))
        if not class_name or not class_name[0].isalpha():
            class_name = f"Section{class_name}"
        act_prefix = re.sub(r"[^A-Za-z]", "", self.act_name)
        class_name = f"{act_prefix}{class_name}"

        fill_prompt = GRAMMAR_FILL_PROMPT.format(
            Section=section,
            Z3ClassName=class_name,
        )
        raw_json = self.HFModel.call(
            self.model_id, fill_prompt,
            temperature=self.temperature,
            max_new_tokens=MAX_NEW_TOKENS_DET,
            system_message=_FILL_SYSTEM_MSG,
        )

        parsed = self._parse_json_response(raw_json, section_id)
        if parsed and parsed.get("variables") and parsed.get("constraints"):
            code = self._compose_from_template(class_name, parsed)
            logger.info("[%s] template_fallback compose succeeded", section_id)
            return code, "template_fallback"

        # Ultimate fallback: plain FOL_Structure generation
        logger.warning(
            "[%s] template fill parse failed — falling back to FOL_Structure",
            section_id,
        )
        plain_prompt = self.prompter.get_FOL_acts(section, error="", prior_code="")
        raw = self.HFModel.call(
            self.model_id, plain_prompt,
            temperature=self.temperature,
            max_new_tokens=MAX_NEW_TOKENS_GEN,
            system_message=BASELINE_SYSTEM_MSG,
        )
        return raw, "template_fallback_plain"

    def _parse_json_response(self, raw: str, section_id: str) -> dict | None:
        """Robustly extract a JSON object from the model response."""
        # Strip fences if present
        fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw, re.DOTALL)
        if fenced:
            raw = fenced.group(1)

        m = re.search(r"\{.*\}", raw, re.DOTALL)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass
        logger.debug("[%s] JSON parse failed on fill response", section_id)
        return None

    def _compose_from_template(self, class_name: str, parsed: dict) -> str:
        """Inject parsed variable/constraint lists into a fixed Z3 class skeleton."""
        variables   = parsed.get("variables", [])
        constraints = parsed.get("constraints", [])

        indent = "        "
        var_block = f"\n{indent}".join(variables) if variables else "pass"
        con_block = f"\n{indent}".join(
            f"solver.add({c})" if not c.strip().startswith("solver.add") else c
            for c in constraints
        ) if constraints else "pass"

        return (
            f"```python\n"
            f"import z3\n\n"
            f"class {class_name}:\n"
            f"    \"\"\"Grammar-constrained Z3 encoding (B4).\"\"\"\n"
            f"    def __init__(self):\n"
            f"        {var_block}\n\n"
            f"    def get_rule(self):\n"
            f"        return z3.BoolVal(True)\n\n"
            f"    def verify_data(self, data):\n"
            f"        solver = z3.Solver()\n"
            f"        {con_block}\n"
            f"        for var_name, var_value in data.items():\n"
            f"            if hasattr(self, var_name):\n"
            f"                z3_var = getattr(self, var_name)\n"
            f"                if isinstance(z3_var, z3.BoolRef):\n"
            f"                    solver.add(z3_var == var_value)\n"
            f"        return solver.check()\n\n"
            f"if __name__ == '__main__':\n"
            f"    obj = {class_name}()\n"
            f"    print(obj.verify_data({{}}))\n"
            f"```"
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_metrics(
        self,
        section: dict,
        filename_stem: str,
        candidate: Candidate,
        grammar_backend: str,
        wall_time: float,
    ) -> dict:
        err_val   = candidate.error_type.value if hasattr(candidate.error_type, "value") else str(candidate.error_type)
        exec_ok   = float(candidate.execution_success)
        solver_ok  = float(candidate.semantic_score >= 0.7)
        verdict_ok = float(candidate.z3_verdict in ("sat", "unsat"))
        proof_ok   = float(candidate.semantic_score >= 1.0)

        return {
            "algorithm":  BASELINE_NAME,
            "act_file":   filename_stem,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "models":     {"primary": self.model_id},
            "hyperparameters": {
                "temperature":           self.temperature,
                "max_new_tokens":        MAX_NEW_TOKENS_GEN,
                "oracle_pass_threshold": ORACLE_PASS_THRESHOLD,
                "grammar_backend":       grammar_backend,
            },
            "results": {
                "final_success":               candidate.semantic_score >= ORACLE_PASS_THRESHOLD,
                "semantic_alignment_confirmed": round(candidate.semantic_score, 4),
                "final_error_type":            err_val,
                "wall_time_sec":               round(wall_time, 3),
            },
            "attempt_counts": {
                "llm_a_outer_attempts":    1,
                "llm_b_semantic_flags":    0,
                "llm_c_cegar_iterations":  0,
                "beam_candidates_generated": 1,
            },
            "error_analysis": {
                "error_type_sequence": [err_val],
                "error_type_counts":   {err_val: 1},
            },
            "oracle_components": {
                "exec":        exec_ok,
                "solver":      solver_ok,
                "verdict":     verdict_ok,
                "proof":       proof_ok,
                "final_score": round(candidate.semantic_score, 4),
                "mode":        "full",
            },
            "baseline_metadata": {
                "baseline":         BASELINE_NAME,
                "tier":             self.tier,
                "grammar_backend":  grammar_backend,
                "outlines_version": _OUTLINES_VERSION,
                "fence_regex":      _FENCE_REGEX,
                "temperature":      self.temperature,
            },
        }
