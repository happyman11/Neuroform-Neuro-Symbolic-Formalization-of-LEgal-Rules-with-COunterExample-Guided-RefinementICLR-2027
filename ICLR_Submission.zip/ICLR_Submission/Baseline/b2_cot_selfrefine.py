"""
B2 — CoT-Based Generation with Self-Refine Critique-Regenerate

Three-phase loop per section:
  1. CoT generation (T=0.7): step-by-step reasoning to produce initial Z3 code.
  2. Self-critique  (T=0.0): model critiques its own code against the source clause.
  3. Self-refinement (T=0.0): model rewrites code to address each critique point.
Steps 2–3 repeat up to max_refine_iters; loop exits early if oracle >= threshold.

LLM calls per section = 1 (CoT gen) + 2 × n_refine_iters (critique + refine each).
llm_c_cegar_iterations stores n_refine_iters so repair_success_rate in metrics.py
is comparable to REFINE-SMT's CEGAR iteration count.
"""
from __future__ import annotations

import json
import logging
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from baseline_config import (
    ORACLE_PASS_THRESHOLD,
    BASELINE_SYSTEM_MSG,
    DEFAULT_MAX_REFINE_ITERS,
    DEFAULT_TEMPERATURE_GEN,
    DEFAULT_TEMPERATURE_DET,
    MAX_NEW_TOKENS_GEN,
    MAX_NEW_TOKENS_DET,
    baseline_run_dir,
    get_hf_model,
)
from baseline_prompts import (
    COT_GENERATION_PROMPT,
    SELF_CRITIQUE_PROMPT,
    SELF_REFINE_PROMPT,
)

from SMT_Generation_AAAI_Final import (
    RefineSMT, Candidate, SemanticOracle, classify_error, ErrorType,
)

logger = logging.getLogger(__name__)

BASELINE_NAME = "b2_cot_selfrefine"

_CRITIQUE_SYSTEM_MSG = (
    "You are a formal logic reviewer. "
    "Output ONLY a bulleted list of specific logical deficiencies in the Z3 code. "
    "Do NOT rewrite the code."
)
_REFINE_SYSTEM_MSG = (
    "You are an expert Python and Z3 formal-verification engineer. "
    "Rewrite the Z3 program to address every critique point. "
    "Output the COMPLETE revised program in a single ```python\\n...\\n``` fenced block."
)


class CoTSelfRefineBaseline:
    """B2: Chain-of-Thought generation followed by self-critique and refinement loop."""

    def __init__(
        self,
        model_id: str,
        tier: str,
        output_root: Path,
        act_name: str,
        run_id: str,
        max_refine_iters: int = DEFAULT_MAX_REFINE_ITERS,
        temperature_gen: float = DEFAULT_TEMPERATURE_GEN,
        temperature_det: float = DEFAULT_TEMPERATURE_DET,
        seed: int | None = None,
    ) -> None:
        self.model_id         = model_id
        self.tier             = tier
        self.output_root      = Path(output_root)
        self.act_name         = act_name
        self.run_id           = run_id
        self.max_refine_iters = max_refine_iters
        self.temperature_gen  = temperature_gen
        self.temperature_det  = temperature_det
        # scripts/additional_runs/'s seed-robustness study. None (default)
        # preserves exact prior (unseeded) behavior. A distinct seed per call
        # (not one reused for every call) -- see _hf_call() below.
        self._seed = seed
        self._call_counter = 0

        self.HFModel = get_hf_model(tier)
        self.oracle  = SemanticOracle()

        self._section_logs: list[dict] = []

        self.output_root.mkdir(parents=True, exist_ok=True)
        logger.info("B2 CoT-SelfRefine ready | tier=%s model=%s max_refine=%d act=%s",
                    tier, model_id, max_refine_iters, act_name)

    # ── Per-section ───────────────────────────────────────────────────────────

    def _hf_call(self, *args, **kwargs) -> str:
        """Wraps self.HFModel.call() with a distinct derived seed per call
        (self._seed + running counter) when a base seed is set; None/unseeded
        otherwise, identical to calling self.HFModel.call() directly."""
        if self._seed is not None:
            kwargs["seed"] = self._seed + self._call_counter
            self._call_counter += 1
        return self.HFModel.call(*args, **kwargs)

    def process_section(self, section: dict, filename_stem: str) -> None:
        section_id = section.get("section_number", filename_stem)
        t0 = time.time()

        section_dir = self.output_root / filename_stem
        section_dir.mkdir(parents=True, exist_ok=True)

        # ── Step 1: CoT generation ────────────────────────────────────────────
        logger.info("[%s] ════ B2 Step 1 — CoT Generation ════", section_id)

        cot_prompt = COT_GENERATION_PROMPT.format(Section=section)
        raw = self._hf_call(
            self.model_id, cot_prompt,
            temperature=self.temperature_gen,
            max_new_tokens=MAX_NEW_TOKENS_GEN,
            system_message=BASELINE_SYSTEM_MSG,
        )

        blocks = RefineSMT.extract_code(raw)
        if not blocks:
            logger.warning("[%s] No code extracted at CoT generation step", section_id)
            blocks = []

        candidate = Candidate(code_blocks=blocks, raw_response=raw)
        if blocks:
            self.oracle.execute_and_score(candidate)

        iter_scores = [candidate.semantic_score]
        error_type_sequence = [candidate.error_type.value]

        logger.info(
            "[%s] Oracle score: %.2f | exec=%s | verdict=%s | error=%s",
            section_id, candidate.semantic_score,
            candidate.execution_success, candidate.z3_verdict,
            candidate.error_type.value,
        )

        n_refine_iters = 0

        if candidate.semantic_score >= ORACLE_PASS_THRESHOLD:
            logger.info("[%s] SUCCESS after CoT gen — oracle=%.2f wall_time=%.1fs",
                        section_id, candidate.semantic_score, time.time() - t0)
        else:
            # ── Steps 2–3: Self-critique and refine loop ──────────────────────
            code_str = "\n\n".join(candidate.code_blocks) if candidate.code_blocks else ""

            for i in range(self.max_refine_iters):
                logger.info("[%s] ════ B2 Refine %d/%d ════",
                            section_id, i + 1, self.max_refine_iters)
                n_refine_iters += 1

                # Step 2: Self-critique (T=0.0 deterministic)
                critique_prompt = SELF_CRITIQUE_PROMPT.format(
                    Section=section,
                    Code=code_str or "<no code generated>",
                )
                critique = self._hf_call(
                    self.model_id, critique_prompt,
                    temperature=self.temperature_det,
                    max_new_tokens=MAX_NEW_TOKENS_DET,
                    system_message=_CRITIQUE_SYSTEM_MSG,
                )

                # Step 3: Refinement (T=0.0 deterministic)
                refine_prompt = SELF_REFINE_PROMPT.format(
                    Section=section,
                    Code=code_str or "<no code generated>",
                    Critique=critique,
                )
                raw_refined = self._hf_call(
                    self.model_id, refine_prompt,
                    temperature=self.temperature_det,
                    max_new_tokens=MAX_NEW_TOKENS_GEN,
                    system_message=BASELINE_SYSTEM_MSG,
                )

                refined_blocks = RefineSMT.extract_code(raw_refined)
                if not refined_blocks:
                    logger.warning("[%s] No code extracted at refine iter %d",
                                   section_id, i + 1)
                    iter_scores.append(0.0)
                    error_type_sequence.append(ErrorType.SYNTAX.value)
                    continue

                refined_cand = Candidate(code_blocks=refined_blocks, raw_response=raw_refined)
                self.oracle.execute_and_score(refined_cand)
                iter_scores.append(refined_cand.semantic_score)

                classified = classify_error(
                    refined_cand.error_message, refined_cand.execution_output
                )
                error_type_sequence.append(classified.value)

                logger.info(
                    "[%s] Oracle score: %.2f | exec=%s | verdict=%s | error=%s",
                    section_id, refined_cand.semantic_score,
                    refined_cand.execution_success, refined_cand.z3_verdict,
                    classified.value,
                )

                # Keep best candidate
                if refined_cand.semantic_score > candidate.semantic_score:
                    candidate = refined_cand

                code_str = "\n\n".join(refined_cand.code_blocks)

                if refined_cand.semantic_score >= ORACLE_PASS_THRESHOLD:
                    logger.info("[%s] SUCCESS — oracle=%.2f wall_time=%.1fs",
                                section_id, refined_cand.semantic_score, time.time() - t0)
                    break
            else:
                logger.warning("[%s] FAILED — all %d refine iters exhausted",
                               section_id, self.max_refine_iters)

        wall_time = time.time() - t0
        metrics = self._build_metrics(
            section, filename_stem, candidate,
            n_refine_iters, iter_scores, error_type_sequence, wall_time,
        )
        self._section_logs.append(metrics)

        metrics_path = section_dir / "section_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        logger.info("[%s] Log saved → %s", section_id, metrics_path)

        if candidate.code_blocks:
            code_path = section_dir / "final_code.py"
            code_path.write_text(candidate.code_blocks[0], encoding="utf-8")
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)

    # ── Aggregate ─────────────────────────────────────────────────────────────

    def save_aggregate_metrics(self) -> None:
        if not self._section_logs:
            return
        total = len(self._section_logs)
        successes = sum(1 for m in self._section_logs
                        if m["results"]["final_success"])
        agg = {
            "algorithm":      BASELINE_NAME,
            "tier":           self.tier,
            "act":            self.act_name,
            "run_id":         self.run_id,
            "model":          self.model_id,
            "acts_processed": total,
            "successful":     successes,
            "failed":         total - successes,
            "success_rate":   round(successes / total, 4) if total else 0.0,
            "mean_wall_time_sec": round(
                sum(m["results"]["wall_time_sec"] for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "per_section":    self._section_logs,
        }
        out = self.output_root / "aggregate_metrics.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(agg, f, indent=2)
        logger.info("B2 aggregate → %s  (success=%d/%d)", out, successes, total)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_metrics(
        self,
        section: dict,
        filename_stem: str,
        candidate: Candidate,
        n_refine_iters: int,
        iter_scores: list[float],
        error_type_sequence: list[str],
        wall_time: float,
    ) -> dict:
        err_val   = candidate.error_type.value if hasattr(candidate.error_type, "value") else str(candidate.error_type)
        exec_ok   = float(candidate.execution_success)
        solver_ok  = float(candidate.semantic_score >= 0.7)
        verdict_ok = float(candidate.z3_verdict in ("sat", "unsat"))
        proof_ok   = float(candidate.semantic_score >= 1.0)
        err_cnt    = dict(Counter(error_type_sequence))

        return {
            "algorithm":  BASELINE_NAME,
            "act_file":   filename_stem,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "models":     {"primary": self.model_id},
            "hyperparameters": {
                "temperature_gen":      self.temperature_gen,
                "temperature_det":      self.temperature_det,
                "max_new_tokens":       MAX_NEW_TOKENS_GEN,
                "max_refine_iters":     self.max_refine_iters,
                "oracle_pass_threshold": ORACLE_PASS_THRESHOLD,
            },
            "results": {
                "final_success":               candidate.semantic_score >= ORACLE_PASS_THRESHOLD,
                "semantic_alignment_confirmed": round(candidate.semantic_score, 4),
                "final_error_type":            err_val,
                "wall_time_sec":               round(wall_time, 3),
            },
            "attempt_counts": {
                "llm_a_outer_attempts":    1,
                "llm_b_semantic_flags":    0,
                "llm_c_cegar_iterations":  n_refine_iters,
                "beam_candidates_generated": 1,
            },
            "error_analysis": {
                "error_type_sequence": error_type_sequence,
                "error_type_counts":   err_cnt,
            },
            "oracle_components": {
                "exec":        exec_ok,
                "solver":      solver_ok,
                "verdict":     verdict_ok,
                "proof":       proof_ok,
                "final_score": round(candidate.semantic_score, 4),
                "mode":        "full",
            },
            "baseline_metadata": {
                "baseline":           BASELINE_NAME,
                "tier":               self.tier,
                "temperature_gen":    self.temperature_gen,
                "temperature_det":    self.temperature_det,
                "n_refine_iters":     n_refine_iters,
                "iter_oracle_scores": [round(s, 4) for s in iter_scores],
            },
        }
