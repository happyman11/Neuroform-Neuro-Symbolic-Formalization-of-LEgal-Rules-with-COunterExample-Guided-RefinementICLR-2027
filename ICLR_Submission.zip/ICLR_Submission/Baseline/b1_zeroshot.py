"""
B1 — Zero-Shot Direct LLM Generation

Single deterministic call (T=0.0) using the FOL_Structure prompt.
No retries, no beam, no CEGAR, no LLM-B semantic check.

This is the simplest possible baseline: one shot, accept whatever comes out.
"""
from __future__ import annotations

import json
import logging
import os
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from baseline_config import (
    ORACLE_PASS_THRESHOLD,
    BASELINE_SYSTEM_MSG,
    MAX_NEW_TOKENS_GEN,
    baseline_run_dir,
    get_hf_model,
)

# Shared lib (sys.path set by baseline_config import)
from SMT_Generation_AAAI_Final import (
    RefineSMT, Candidate, SemanticOracle, classify_error, ErrorType,
)
from promting import Prompt

logger = logging.getLogger(__name__)

BASELINE_NAME = "b1_zeroshot"


class ZeroShotBaseline:
    """B1: single deterministic Z3 generation call, no retry."""

    def __init__(
        self,
        model_id: str,
        tier: str,
        output_root: Path,
        act_name: str,
        run_id: str,
    ) -> None:
        self.model_id    = model_id
        self.tier        = tier
        self.output_root = Path(output_root)
        self.act_name    = act_name
        self.run_id      = run_id

        self.HFModel  = get_hf_model(tier)
        self.oracle   = SemanticOracle()
        self.prompter = Prompt()

        self._section_logs: list[dict] = []

        self.output_root.mkdir(parents=True, exist_ok=True)
        logger.info("B1 ZeroShot ready | tier=%s model=%s act=%s",
                    tier, model_id, act_name)

    # ── Per-section ───────────────────────────────────────────────────────────

    def process_section(self, section: dict, filename_stem: str) -> None:
        section_id = section.get("section_number", filename_stem)
        t0 = time.time()

        section_dir = self.output_root / filename_stem
        section_dir.mkdir(parents=True, exist_ok=True)

        logger.info("[%s] ════ B1 Zero-Shot ════", section_id)

        prompt = self.prompter.get_FOL_acts(section, error="", prior_code="")
        raw = self.HFModel.call(
            self.model_id, prompt,
            temperature=0.0,
            max_new_tokens=MAX_NEW_TOKENS_GEN,
            system_message=BASELINE_SYSTEM_MSG,
        )

        blocks = RefineSMT.extract_code(raw)
        if not blocks:
            logger.warning("[%s] No code extracted at attempt 1", section_id)

        candidate = Candidate(code_blocks=blocks, raw_response=raw)
        self.oracle.execute_and_score(candidate)

        wall_time = time.time() - t0
        success = candidate.semantic_score >= ORACLE_PASS_THRESHOLD

        logger.info(
            "[%s] Oracle score: %.2f | exec=%s | verdict=%s | error=%s",
            section_id, candidate.semantic_score,
            candidate.execution_success, candidate.z3_verdict,
            candidate.error_type.value,
        )
        if success:
            logger.info("[%s] SUCCESS — oracle=%.2f wall_time=%.1fs",
                        section_id, candidate.semantic_score, wall_time)
        else:
            logger.warning("[%s] FAILED — all 1 attempts exhausted", section_id)

        metrics = self._build_metrics(section, filename_stem, candidate, wall_time)
        self._section_logs.append(metrics)

        # Save files
        metrics_path = section_dir / "section_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        logger.info("[%s] Log saved → %s", section_id, metrics_path)

        if blocks:
            code_path = section_dir / "final_code.py"
            code_path.write_text(blocks[0], encoding="utf-8")
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)

    # ── Aggregate ─────────────────────────────────────────────────────────────

    def save_aggregate_metrics(self) -> None:
        if not self._section_logs:
            return
        total = len(self._section_logs)
        successes = sum(1 for m in self._section_logs
                        if m["results"]["final_success"])
        agg = {
            "algorithm":        BASELINE_NAME,
            "tier":             self.tier,
            "act":              self.act_name,
            "run_id":           self.run_id,
            "model":            self.model_id,
            "acts_processed":   total,
            "successful":       successes,
            "failed":           total - successes,
            "success_rate":     round(successes / total, 4) if total else 0.0,
            "mean_wall_time_sec": round(
                sum(m["results"]["wall_time_sec"] for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "per_section":      self._section_logs,
        }
        out = self.output_root / "aggregate_metrics.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(agg, f, indent=2)
        logger.info("B1 aggregate metrics → %s  (success=%d/%d)", out, successes, total)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_metrics(
        self,
        section: dict,
        filename_stem: str,
        candidate: Candidate,
        wall_time: float,
    ) -> dict:
        err_val  = candidate.error_type.value
        err_seq  = [err_val]
        err_cnt  = Counter(err_seq)
        exec_ok  = float(candidate.execution_success)
        solver_ok = float(candidate.semantic_score >= 0.7)
        verdict_ok = float(candidate.z3_verdict in ("sat", "unsat"))
        proof_ok  = float(candidate.semantic_score >= 1.0)

        return {
            "algorithm":  BASELINE_NAME,
            "act_file":   filename_stem,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "models":     {"primary": self.model_id},
            "hyperparameters": {
                "temperature":          0.0,
                "max_new_tokens":       MAX_NEW_TOKENS_GEN,
                "oracle_pass_threshold": ORACLE_PASS_THRESHOLD,
            },
            "results": {
                "final_success":               candidate.semantic_score >= ORACLE_PASS_THRESHOLD,
                "semantic_alignment_confirmed": round(candidate.semantic_score, 4),
                "final_error_type":            err_val,
                "wall_time_sec":               round(wall_time, 3),
            },
            "attempt_counts": {
                "llm_a_outer_attempts":    1,
                "llm_b_semantic_flags":    0,
                "llm_c_cegar_iterations":  0,
                "beam_candidates_generated": 1,
            },
            "error_analysis": {
                "error_type_sequence": err_seq,
                "error_type_counts":   dict(err_cnt),
            },
            "oracle_components": {
                "exec":        exec_ok,
                "solver":      solver_ok,
                "verdict":     verdict_ok,
                "proof":       proof_ok,
                "final_score": round(candidate.semantic_score, 4),
                "mode":        "full",
            },
            "baseline_metadata": {
                "baseline":    BASELINE_NAME,
                "tier":        self.tier,
                "single_shot": True,
                "temperature": 0.0,
            },
        }
