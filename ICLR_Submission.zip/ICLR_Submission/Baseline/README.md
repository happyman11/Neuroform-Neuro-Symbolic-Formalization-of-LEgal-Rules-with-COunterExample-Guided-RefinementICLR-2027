# REFINE-SMT Baseline Comparison Systems — Run Instructions

> **Target:** AAAI-2026 submission
> **Purpose:** Nine baselines. B1–B5 isolate the contribution of each REFINE-SMT component (including an
> independent CEGIS-sketch system, B5, from the program repair literature). B6–B9 are independent
> autoformalization/repair systems from the wider literature, each adapted to this Z3/privacy-law domain, giving
> four additional external reference points beyond REFINE-SMT's own component ablations.
> **Working directory for all commands:** `ICLR_Submission/Baseline/` (this folder).

---

## What Are These Baselines?

REFINE-SMT is a three-LLM CEGAR pipeline (LLM-A beam generation → LLM-B semantic alignment → LLM-C structured
repair). B1–B5 each remove or replace one component to answer *what is each component actually contributing?*
B6–B9 are each a domain adaptation of a distinct published system, answering *how does REFINE-SMT compare against
an independently-designed autoformalization or repair approach?*

| ID | Name | What it does | What it tests |
|----|------|-------------|---------------|
| **B1** | Zero-Shot | Single T=0.0 call using the FOL_Structure prompt. No retry, no beam, no repair. | Lower bound — raw generation quality |
| **B2** | CoT + Self-Refine | Chain-of-thought generation (T=0.7) → self-critique (T=0.0) → self-refine (T=0.0), up to 3 iterations. | LLM-internal repair without oracle feedback |
| **B3** | Naive Retry | Generate → if SMT fails, retry with raw Python traceback. Up to 7 retries (same budget as REFINE-SMT). No error taxonomy, no structured counterexample. | Raw error feedback vs structured CEGAR |
| **B4** | Grammar-Constrained | Token-level constrained decoding via `outlines` (regex forces Python code fence). Template-fill fallback if `outlines` not installed. | Structural validity guarantee at generation time |
| **B5** | CEGIS-Sketch | Taxonomy-guided fault localization → @HOLE@ sketch → CEGIS loop with oracle counterexample feedback (up to 5 iterations). Implements Orvalho et al., AAAI 2025 (arXiv:2502.07786). | Independent CEGIS repair vs REFINE-SMT structured CEGAR |
| **B6** | AquaForte-Adapted | LLM-guided adaptive retry with *learned clause exclusion*: each failed encoding triggers an analysis call that identifies the wrong constraint pattern, which is then excluded from subsequent prompts. Up to 5 iterations. Adapts Lv et al. (arXiv:2601.04675). | Clause-exclusion adaptive retry vs REFINE-SMT structured CEGAR |
| **B7** | L4L Schema-Guided | Two-phase role-agent: Extractor Agent (T=0.0) pulls a structured schema (Actor-Action-Norm-Condition-Exception-Penalty, adapted from L4L's criminal-law schema) from the legal text; Instantiator Agent (T=0.7) converts it to Z3 code. Re-extracts and re-instantiates on failure, up to 3 cycles. Adapts Chen et al. (arXiv:2511.21033). | Schema-guided formalization vs REFINE-SMT's direct generation |
| **B8** | MASA Multi-Agent | Five role-differentiated prompts on a single LLM: AutoformalizationAgent (T=0.7) → HardCritiqueAgent (T=0.0, formal/syntactic errors) → FormalRefinementAgent (T=0.0) → SoftCritiqueAgent (T=0.0, semantic coverage gaps) → InformalRefinementAgent (T=0.7). Up to 3 iterations. Adapts Zhang et al. (arXiv:2510.08988). | Dual hard/soft critique-refine vs REFINE-SMT's single LLM-B gate |
| **B9** | RAG+SMT | BM25 retrieval of the top-K related sections from the same act → LLM generation with retrieved context (T=0.7) → oracle check → on encoding failure, Z3 `Optimize()` (MaxSMT) finds the minimal constraint-violation set and feeds it back to the LLM. Adapts Hsia et al. (arXiv:2601.06181). | Retrieval-augmented generation + MaxSMT repair vs REFINE-SMT's non-retrieval CEGAR |

### Model Selection

Same primary models as the benchmarking configs — apples-to-apples comparison. Both backends are equally
supported (see `--backend` below and `../install/README.md`); the table gives the HuggingFace model id, with the
Ollama equivalent in `../install/model_registry.yaml` under `baseline:`.

| Tier | Model (HuggingFace id) | Why |
|------|-------|-----|
| SLM | `Qwen/Qwen2.5-Coder-7B-Instruct` | Primary LLM-A in `Pipeline/SLM/benchmarking/config.yaml` (best SLM, 80.2% E2E) |
| LLM | `Qwen/Qwen2.5-Coder-32B-Instruct` | Primary LLM-A in `Pipeline/LLM/benchmarking/config.yaml` (best LLM, 87.4% E2E) |

---

## Directory Layout

```
ICLR_Submission/Baseline/
├── README.md                        ← this file
├── baseline_config.py               ← paths, model IDs, hyperparameters, backend switch (self-contained)
│
├── b1_zeroshot.py                   ← B1: single zero-shot generation
├── b2_cot_selfrefine.py             ← B2: CoT gen + self-critique + self-refine loop
├── b3_naive_retry.py                ← B3: generate → raw-error retry (no taxonomy)
├── b4_grammar_constrained.py        ← B4: outlines-constrained + template fallback
├── b5_cegis_sketch.py               ← B5: taxonomy-FL → @HOLE@ sketch → CEGIS loop
│
├── run_baselines.py                 ← unified Python CLI runner for B1–B5
├── evaluate_baselines.py            ← evaluation and comparison table (B1–B5)
│
├── run_baselines.sh                 ← shell driver (sets env, tees log) ← USE THIS
├── evaluate_baselines.sh            ← evaluation shell driver           ← USE THIS
│
├── new_baseline/                    ← B6–B9, same conventions as B1–B5, separate runner
│   ├── b6_aquaforte.py              ← B6: clause-exclusion adaptive retry
│   ├── b7_l4l_schema.py             ← B7: two-phase schema-extract + instantiate
│   ├── b8_masa_multiagent.py        ← B8: hard+soft critique multi-agent
│   ├── b9_rag_smt.py                ← B9: BM25 retrieval + LLM + MaxSMT repair
│   ├── new_baseline_config.py       ← B6–B9-specific hyperparameters (iters, RAG top-k, schema)
│   └── run_new_baselines.py         ← unified Python CLI runner for B6–B9
│
└── lib/                             ← fully local copies — NO cross-folder imports
    ├── SMT_Generation_AAAI_Final.py ← RefineSMT, SemanticOracle, Candidate, classify_error
    ├── promting.py                  ← Prompt.get_FOL_acts() (FOL_Structure prompt)
    ├── utility.py                   ← Utility.extract_json_robust()
    ├── models.py                    ← model config helpers + Ollama backend (ModelCall.ollama_call_model)
    ├── baseline_models.py           ← HuggingFaceModel class (7B float16, 32B bfloat16)
    ├── baseline_prompts.py          ← prompt strings for B2, B3, B4, B5
    ├── metrics.py                   ← compute_all() — same function as SLM/LLM evaluation
    └── __init__.py
```

**Input data:** `../Benchmark/dataset/{DPDP,GDPR,CCPA,PIPD}_Act/*.json` (this bundle's own copy of the 4-act
corpus — `baseline_config.py`'s `ACTS_INPUT` resolves this relative to its own file location, no dependency on
anything outside `ICLR_Submission/`)
**All outputs go to:** `ICLR_Submission/Baseline_Output/`

> **Design note:** `lib/` contains local copies of all shared pipeline code. None of the Baseline scripts import
> from `Pipeline/SLM/` or `Pipeline/LLM/`. This makes the folder fully portable.

---

## Prerequisites

### 1. Install Python dependencies

```bash
pip install transformers torch accelerate tqdm z3-solver
# Optional — improves device placement on multi-GPU machines
pip install psutil
# Optional — required for 32B bfloat16 and 4-bit quantization
pip install bitsandbytes
# Optional — required for B4 outlines backend (token-level constrained decoding)
pip install outlines
# Optional — required for B9's BM25 retrieval (falls back to simple TF overlap if absent)
pip install rank_bm25
# Optional — required for --backend ollama (any baseline)
pip install ollama
```

### 2. Models must already be downloaded

The shell scripts run with `HF_HUB_OFFLINE=1` — no network calls are made at run time. See
`../install/README.md` for both backends, side by side.

- **HuggingFace (Option A):** `../install/install_models_huggingface.sh --tier slm|llm`
- **Ollama (Option B):** `../install/install_models_ollama.sh --tier slm|llm`

### 3. Verify paths

```bash
cd ICLR_Submission/Baseline
python3 -c "
from baseline_config import ACTS_INPUT, BASELINE_OUTPUT, AAAI_ROOT
for act, p in ACTS_INPUT.items():
    print(act, '✓' if p.exists() else '✗ MISSING', p)
print('Output root:', BASELINE_OUTPUT)
"
```

All 4 act directories must show ✓.

---

## Two runners: B1–B5 vs B6–B9

B1–B5 and B6–B9 use separate CLI runners (same conventions, same output layout, same evaluator) so that
`baseline_config.py`'s namespace and `new_baseline_config.py`'s namespace stay independent:

| Baselines | Runner | Working directory |
|---|---|---|
| B1–B5 | `run_baselines.py` / `run_baselines.sh` | `ICLR_Submission/Baseline/` |
| B6–B9 | `new_baseline/run_new_baselines.py` | `ICLR_Submission/Baseline/new_baseline/` |

Both accept `--backend huggingface\|ollama` (default `huggingface`) — see `../install/README.md`.

---

## Step 0 — Smoke Test (run first, no GPU needed)

Verifies imports, path setup, and section loading without calling any LLMs:

```bash
cd ICLR_Submission/Baseline

# Dry-run B1-B5, DPDP only, 2 sections
python3 run_baselines.py --baseline all --tier slm --acts DPDP --sections 2 --dry-run

# Or via shell script
bash run_baselines.sh --baseline all --tier slm --acts DPDP --sections 2 --dry-run

# Dry-run B6-B9
cd new_baseline
python3 run_new_baselines.py --baseline all --tier slm --acts DPDP --sections 2 --dry-run
```

Expected: prints `[DRY-RUN] <baseline_name>/DPDP/...` for each section, no errors, exits 0.

---

## Step 1 — Run Baselines

### Option A — Shell script (B1–B5 only, recommended, tees to log file)

```bash
cd ICLR_Submission/Baseline

# Run all 5 baselines, SLM tier, all 4 acts
bash run_baselines.sh --baseline all --tier slm

# Run all 5 baselines, LLM tier
bash run_baselines.sh --baseline all --tier llm

# Single baseline
bash run_baselines.sh --baseline b1 --tier slm
bash run_baselines.sh --baseline b2 --tier slm
bash run_baselines.sh --baseline b3 --tier slm
bash run_baselines.sh --baseline b4 --tier slm
bash run_baselines.sh --baseline b5 --tier slm
bash run_baselines.sh --baseline b5 --tier slm --max-cegar 5 --sketch-mode fixme

# Specific acts only
bash run_baselines.sh --baseline all --tier slm --acts DPDP,GDPR

# Smoke test — 3 sections per act
bash run_baselines.sh --baseline all --tier slm --acts DPDP --sections 3

# B4 without outlines (saves VRAM, use on memory-limited machines)
bash run_baselines.sh --baseline b4 --tier slm --force-template-fallback

# Ollama backend instead of HuggingFace
bash run_baselines.sh --baseline all --tier slm --backend ollama
```

Logs are written to `Baseline_Output/logs/<timestamp>_baselines.log`.

### Option B — Python directly (B1–B5)

```bash
cd ICLR_Submission/Baseline
python3 run_baselines.py --baseline all --tier slm
python3 run_baselines.py --baseline b3 --tier llm --max-retries 7 --acts GDPR,CCPA
python3 run_baselines.py --baseline all --tier slm --backend ollama
```

### Option C — B6–B9

```bash
cd ICLR_Submission/Baseline/new_baseline

# All four
python3 run_new_baselines.py --baseline all --tier slm

# Single baseline, with its own knob
python3 run_new_baselines.py --baseline b6 --tier slm --max-aquaforte-iters 5
python3 run_new_baselines.py --baseline b7 --tier slm --max-l4l-iters 3
python3 run_new_baselines.py --baseline b8 --tier slm --max-masa-iters 3
python3 run_new_baselines.py --baseline b9 --tier slm --rag-top-k 3

# Ollama backend
python3 run_new_baselines.py --baseline all --tier slm --backend ollama

# Restrict acts / sections (same flags as B1-B5)
python3 run_new_baselines.py --baseline all --tier slm --acts GDPR,DPDP --sections 3
```

### CLI Options Reference — `run_baselines.py` (B1–B5)

| Option | Default | Description |
|--------|---------|-------------|
| `--baseline` | `b1` | Which baseline(s): `b1`, `b2`, `b3`, `b4`, `b5`, or `all` |
| `--tier` | `slm` | Model tier: `slm` (7B) or `llm` (32B) |
| `--backend` | `huggingface` | Model-serving backend: `huggingface` or `ollama` — equally supported |
| `--acts` | all 4 | Comma-separated: `DPDP`, `GDPR`, `CCPA`, `PIPD` |
| `--sections N` | all | Limit N sections per act (smoke test) |
| `--dry-run` | off | List files without calling LLMs |
| `--max-refine-iters N` | 3 | B2: number of critique-refine iterations |
| `--max-retries N` | 7 | B3: maximum retry attempts |
| `--force-template-fallback` | off | B4: skip outlines, use template-fill backend |
| `--max-cegar N` | 5 | B5: max CEGIS sketch-fill iterations |
| `--sketch-mode` | `hole` | B5: `hole` (replace line with @HOLE@) or `fixme` (annotate with FIXME) |

### CLI Options Reference — `new_baseline/run_new_baselines.py` (B6–B9)

| Option | Default | Description |
|--------|---------|-------------|
| `--baseline` | `b6` | Which baseline(s): `b6`, `b7`, `b8`, `b9`, or `all` |
| `--tier` | `slm` | Model tier: `slm` (7B) or `llm` (32B) |
| `--backend` | `huggingface` | Model-serving backend: `huggingface` or `ollama` — equally supported |
| `--acts` | all 4 | Comma-separated: `DPDP`, `GDPR`, `CCPA`, `PIPD` |
| `--sections N` | all | Limit N sections per act (smoke test) |
| `--dry-run` | off | List files without calling LLMs |
| `--max-aquaforte-iters N` | 5 | B6: max clause-exclusion retry iterations |
| `--max-l4l-iters N` | 3 | B7: max schema extract+instantiate cycles |
| `--max-masa-iters N` | 3 | B8: max hard+soft critique iterations |
| `--rag-top-k N` | 3 | B9: number of BM25-retrieved context sections |
| `--no-maxsmt` | off | B9: disable the MaxSMT repair step |

---

## Step 2 — Evaluate Results

`evaluate_baselines.py` covers **all 9** baselines (B1-B5 and B6-B9 share the same `section_metrics.json`
format and output layout, so one evaluator works for both) -- there is no separate B6-B9 evaluator.

### Option A — Shell script

```bash
cd ICLR_Submission/Baseline

# Auto-discover the latest run for each of the 9 baselines independently, SLM tier -- recommended, since
# B1-B5 and B6-B9 come from two different runners with two different run_ids (see "Two runners" above)
bash evaluate_baselines.sh --tier slm

# LLM tier
bash evaluate_baselines.sh --tier llm

# One shared run_id, e.g. B1-B5 run together via --baseline all
bash evaluate_baselines.sh --tier slm --run-id Baseline-SLM-ALL-20260609T120000Z

# Per-baseline run IDs, any subset of b1..b9 (if run separately)
bash evaluate_baselines.sh --tier slm \
    --run-ids b1=Baseline-SLM-B1-... b5=Baseline-SLM-B5-... \
              b6=NewBaseline-SLM-B6-... b9=NewBaseline-SLM-B9-...

# Save to custom file
bash evaluate_baselines.sh --tier slm --output my_comparison.json
```

### Option B — Python directly

```bash
python3 evaluate_baselines.py --tier slm
```

Evaluation logs are written to `Baseline_Output/logs/<timestamp>_eval.log`.

### What evaluate does

Loads all `section_metrics.json` files, calls `compute_all(logs)` from `lib/metrics.py`
(the exact same 28-metric function used for SLM/LLM evaluation), and prints a summary table:

```
── Baseline Comparison Summary ──────────────────────────────────
Baseline                       Act        E2E %   Align %      n
─────────────────────────────────────────────────────────────────
b1_zeroshot                    CCPA      42.3%    58.1%      52
b1_zeroshot                    DPDP      38.7%    54.2%      62
b2_cot_selfrefine              CCPA      61.5%    72.4%      52
b3_naive_retry                 CCPA      58.1%    68.9%      52
b4_grammar_constrained         CCPA      55.8%    66.3%      52
b5_cegis_sketch                CCPA      64.2%    73.8%      52
b6_aquaforte                   CCPA      59.6%    69.7%      52
b7_l4l_schema                  CCPA      57.3%    67.1%      52
b8_masa_multiagent             CCPA      62.8%    71.5%      52
b9_rag_smt                     CCPA      63.4%    72.9%      52
─────────────────────────────────────────────────────────────────
```

Full results written to `Baseline_Output/{tier}/comparison_{timestamp}.json`.

---

## Output Structure

```
AAAI-2026/Baseline_Output/
├── logs/
│   ├── <timestamp>_baselines.log      ← shell-level tee logs (run)
│   └── <timestamp>_eval.log           ← shell-level tee logs (evaluation)
│
└── slm/                               ← or llm/
    ├── run_logs/
    │   └── Baseline-SLM-ALL-<ts>/
    │       └── run_config.json        ← full reproducibility config
    │
    ├── b1_zeroshot/
    │   └── Baseline-SLM-B1-<ts>/
    │       ├── DPDP/
    │       │   ├── ChIII_Sec11/
    │       │   │   ├── section_metrics.json   ← per-section metrics
    │       │   │   └── final_code.py          ← best Z3 code generated
    │       │   ├── ChIII_Sec12/ ...
    │       │   └── aggregate_metrics.json     ← act-level aggregate
    │       ├── GDPR/ CCPA/ PIPD/
    │       └── DPDP_aggregate_metrics.json    ← copy at run level
    │
    ├── b2_cot_selfrefine/  (same structure)
    ├── b3_naive_retry/     (same structure)
    ├── b4_grammar_constrained/ (same structure)
    ├── b5_cegis_sketch/    (same structure)
    ├── b6_aquaforte/       (same structure -- written under a separate NewBaseline-* run_id)
    ├── b7_l4l_schema/      (same structure)
    ├── b8_masa_multiagent/ (same structure)
    ├── b9_rag_smt/         (same structure)
    │
    └── comparison_<timestamp>.json    ← evaluate_baselines.py output (covers all 9)
```

---

## Per-Baseline Design Details

### B1 — Zero-Shot (`b1_zeroshot.py`)

- **Prompt:** `Prompt.get_FOL_acts(section)` — the standard FOL_Structure prompt
- **Temperature:** T=0.0 (fully deterministic)
- **LLM calls:** 1 per section
- **Retry:** none
- **Key fields in section_metrics.json:**
  - `llm_c_cegar_iterations = 0`
  - `llm_a_outer_attempts = 1`
  - `baseline_metadata.single_shot = true`

### B2 — CoT + Self-Refine (`b2_cot_selfrefine.py`)

- **Step 1:** `COT_GENERATION_PROMPT` at T=0.7 — step-by-step entity/obligation/constraint reasoning
- **Step 2:** `SELF_CRITIQUE_PROMPT` at T=0.0 — model lists logical deficiencies, no code rewrite
- **Step 3:** `SELF_REFINE_PROMPT` at T=0.0 — full revised program addressing each critique point
- Steps 2–3 repeat up to `max_refine_iters=3`; exits early if oracle ≥ 0.7
- **LLM calls:** 1 + 2 × n_refine_iters per section (max 7)
- **Key fields:**
  - `llm_c_cegar_iterations = n_actual_refine_iters`
  - `baseline_metadata.iter_oracle_scores = [0.3, 0.6, 0.8]` (progression)

### B3 — Naive Retry (`b3_naive_retry.py`)

- **Initial:** `Prompt.get_FOL_acts(section)` at T=0.7
- **Retries:** `NAIVE_RETRY_PROMPT` with raw Python traceback — **no error classification fed to model**
- Error taxonomy `classify_error()` IS called for our own `error_type_sequence` logging
- Up to `max_retries=7` retries (same total budget as REFINE-SMT `max_outer=7`)
- **Key design difference from REFINE-SMT:** model receives only raw `error_message + execution_output[:300]`, no structured counterexample, no error class label
- **Key fields:**
  - `llm_c_cegar_iterations = n_retries_done`
  - `baseline_metadata.feedback_mode = "raw_error_only"`

### B4 — Grammar-Constrained (`b4_grammar_constrained.py`)

- **Backend 1 — outlines** (if installed): `outlines.generate.regex(model, r"```python\n[^`]+```")` — token-level constrained decoding guarantees a code fence is always produced
- **Backend 2 — template_fallback** (if outlines not installed or `--force-template-fallback`):
  1. Prompt model to output JSON `{"variables": [...], "constraints": [...]}`
  2. Inject into fixed Z3 class skeleton (`__init__`, `get_rule`, `verify_data`)
  3. If JSON parse fails → plain FOL_Structure generation
- **Single generation pass** — no retry loop; structural validity is enforced at generation time
- **Key fields:**
  - `llm_c_cegar_iterations = 0`
  - `baseline_metadata.grammar_backend = "outlines" | "template_fallback" | "template_fallback_plain"`

### B5 — CEGIS-Sketch (`b5_cegis_sketch.py`)

> **Paper:** Orvalho, Janota, Manquinho — "Counterexample Guided Program Repair Using Zero-Shot Learning and MaxSAT-based Fault Localization", AAAI 2025 (arXiv:2502.07786)

Implements the paper's best configuration without a reference implementation: **Sk-De-TS-CE** (Sketch + Description + Test-Suite feedback + Counterexample). Adapted to the Z3/legal domain by replacing the paper's MaxSAT FL tool with **taxonomy-guided fault localization** using the existing `classify_error()` error taxonomy (E0–E5).

**Algorithm:**

1. **Initial generation** (T=0.7): `Prompt.get_FOL_acts(section)` — same start as all baselines
2. If oracle ≥ 0.7 → done
3. **CEGIS loop** (up to `max_cegar=5` iterations):
   - **Fault localize** — identify faulty lines using the error taxonomy:

     | ErrorType | Lines flagged |
     |-----------|---------------|
     | E1_syntax | Traceback line number; fallback: all `self.X = z3.` assignments |
     | E2_z3_encoding | All `z3.Bool/Int/Real(` declaration lines in `__init__` |
     | E3_semantic_inversion | All `z3.Implies/Not/And/Or(` lines — wrong polarity |
     | E4_incomplete | Last line of `__init__` + synthetic hole after it |
     | E5_over_constrained | All `solver.add(` lines |
     | E0 / fallback | Entire `get_rule` body |

   - **Create sketch** from faulty lines:
     - `hole` mode: replace line with `# @HOLE N @  # was: <orig[:40]>`
     - `fixme` mode: append `  # FIXME: <reason>` to line
   - **CEGIS prompt** with section text + sketch + oracle feedback (counterexample)
   - **LLM fills holes** (T=0.7, stochastic for diversity)
   - Oracle check; if pass → done

- **Key design difference from REFINE-SMT:** a single LLM role fills all holes (no LLM-B semantic alignment); fault localization is structural/regex (no MaxSAT solver); no beam — one candidate per iteration
- **Key fields:**
  - `llm_c_cegar_iterations = n_actual_cegar_iters`
  - `baseline_metadata.sketch_mode = "hole" | "fixme"`
  - `baseline_metadata.fault_localization_mode = "taxonomy_guided"`
  - `baseline_metadata.cegar_iter_scores = [0.3, 0.5, 0.7]` (oracle score per iter)
  - `baseline_metadata.n_holes_per_iter = [0, 2, 1]` (holes created; 0 for initial gen)
  - `baseline_metadata.paper_ref = "Orvalho et al. AAAI 2025 (arXiv:2502.07786)"`

### B6 — AquaForte-Adapted (`new_baseline/b6_aquaforte.py`)

> **Paper:** Lv et al. — "AquaForte" (arXiv:2601.04675)

Core idea: LLM-guided adaptive retry with **learned clause exclusion**. Adapted from AquaForte's QUFNIRA formula
synthesis (Z3 Python class generation here) and its clause-exclusion mechanism ("do NOT generate `<pattern>`"
injected into the next prompt).

**Algorithm:**

1. **Initial generation** (T=0.7): `Prompt.get_FOL_acts(section)`
2. Oracle check via `SemanticOracle` (exec + solver + verdict + proof)
3. If not passed, up to `max_aquaforte_iters=5` iterations:
   - **Analysis call** (T=0.0): LLM identifies the specific wrong constraint pattern in the failed candidate
   - That pattern is appended to a growing **exclusion set**, injected into the next generation prompt as an
     explicit "do not generate" constraint
   - **Re-synthesize** (T=0.7) with the exclusion set in context; oracle check; if pass → done
- **Key design difference from REFINE-SMT:** no LLM-B semantic-alignment gate; repair works by narrowing the
  generation search space (excluding known-bad patterns) rather than targeted counterexample-guided repair of a
  specific candidate
- **Key fields:** `llm_c_cegar_iterations = n_actual_iters`, `baseline_metadata.excluded_patterns = [...]`,
  `baseline_metadata.paper_ref = "Lv et al. (arXiv:2601.04675)"`

### B7 — L4L Schema-Guided (`new_baseline/b7_l4l_schema.py`)

> **Paper:** Chen et al. — "L4L" (arXiv:2511.21033)

Two-phase role-agent autoformalizer. L4L's original schema (Actor-Action-DrugQuantity-Penalty, for criminal law)
is adapted to privacy law: **Actor-Action-Norm-Condition-Exception-Penalty** (see `new_baseline_config.py`'s
`PRIVACY_LAW_SCHEMA` for the full enumerated value sets per field).

**Algorithm:**

1. **Extractor Agent** (T=0.0): pulls a structured schema tuple from the legal text
2. **Instantiator Agent** (T=0.7): converts the schema into Z3 Python code (matches the oracle's `verify_data`
   API, unlike L4L's original SMT-LIB output)
3. Oracle check; on failure, re-run the Extractor (schema refinement) then re-instantiate, up to
   `max_l4l_iters=3` total cycles
- **Key design difference from REFINE-SMT:** repair operates on the intermediate *schema*, not the Z3 code
  directly -- a wrong schema extraction is fixed before re-instantiating, rather than patching the generated code
- **Key fields:** `llm_c_cegar_iterations = n_actual_cycles`, `baseline_metadata.schema = {...}`,
  `baseline_metadata.paper_ref = "Chen et al. (arXiv:2511.21033)"`

### B8 — MASA Multi-Agent (`new_baseline/b8_masa_multiagent.py`)

> **Paper:** Zhang et al. — "MASA" (arXiv:2510.08988)

MASA's Algorithm 3 (Iterative Self-Refinement) uses two critique axes -- **Hard Critique** (formal/syntactic
errors caught by execution) and **Soft Critique** (semantic coverage gaps not caught by execution). Implemented
here as five role-differentiated prompts on a single LLM (MASA originally uses separate model instances; this
adaptation uses one model with role-differentiated system messages, a disclosed GPU-constraint adaptation).

**Algorithm** (up to `max_masa_iters=3` full cycles):

1. **AutoformalizationAgent** (T=0.7): initial Z3 generation
2. **HardCritiqueAgent** (T=0.0): formal error analysis — maps to `SemanticOracle` + `classify_error()`
3. **FormalRefinementAgent** (T=0.0): fixes formal errors only
4. **SoftCritiqueAgent** (T=0.0): semantic coverage gap detection — a YES/NO probe over
   `MASA_ASPECT_DESCRIPTION` ("all legal obligations, prohibitions, exceptions, conditions, actor roles, and
   temporal constraints")
5. **InformalRefinementAgent** (T=0.7): revises the legal interpretation to close soft-critique gaps
- **Key design difference from REFINE-SMT:** two separate critique/refine axes (formal + semantic) rather than
  REFINE-SMT's single LLM-B alignment gate feeding into one LLM-C repair role
- **Key fields:** `llm_c_cegar_iterations = n_actual_cycles`, `baseline_metadata.hard_critique_findings = [...]`,
  `baseline_metadata.soft_critique_gaps = [...]`, `baseline_metadata.paper_ref = "Zhang et al. (arXiv:2510.08988)"`

### B9 — RAG+SMT (`new_baseline/b9_rag_smt.py`)

> **Paper:** Hsia et al. (arXiv:2601.06181)

**Algorithm:**

1. **BM25 retrieval** (`rank_bm25`, falling back to simple TF overlap if not installed): top-`rag_top_k=3`
   related sections from the same act's corpus
2. **Generation** (T=0.7): `Prompt.get_FOL_acts(section)` augmented with the retrieved context
3. **Oracle check** via `SemanticOracle`
4. On an *encoding* error (not any failure), **MaxSMT repair**: Z3 `Optimize()` with soft constraints finds the
   minimal set of violated constraints, and that minimal violation set is fed back to the LLM as targeted
   feedback (`--no-maxsmt` disables this step, falling back to a plain retry)
- **Key design difference from REFINE-SMT:** retrieval-augmented context (no other baseline or REFINE-SMT itself
  retrieves related sections) combined with a MaxSMT-based minimal-violation repair signal, instead of REFINE-
  SMT's structured E0-E5 counterexample
- **Key fields:** `llm_c_cegar_iterations = 0 | 1` (single MaxSMT repair attempt), `baseline_metadata.retrieved_sections = [...]`,
  `baseline_metadata.maxsmt_violations = [...]`, `baseline_metadata.paper_ref = "Hsia et al. (arXiv:2601.06181)"`

---

## Metrics Computed by `evaluate_baselines.py`

Uses `lib/metrics.py compute_all(logs)` — the same 28-metric function used for all SLM/LLM evaluations. Key metrics for the comparison table:

| Metric | What it measures |
|--------|-----------------|
| `end_to_end_success_rate` | Fraction of sections with oracle score ≥ 0.7 |
| `mean_semantic_alignment` | Mean oracle score across all sections (0–1) |
| `repair_success_rate` | Fraction that succeeded after at least one retry/refine |
| `mean_convergence_iters` | Mean CEGAR/refine iterations to success |
| `syntax_validity_rate` | Fraction with no E1_syntax errors |
| `error_type_distribution` | Breakdown across E0–E5 error classes |
| `oracle_component_analysis` | Mean exec / solver / verdict / proof sub-scores |
| `mean_wall_time_sec` | Average seconds per section |

> **Note:** `slm_extra` fields (deontic type, clause complexity) are absent in baseline output — `compute_all()` handles this gracefully; deontic metrics return 0.0 by default.

---

## Hyperparameter Reference

| Parameter | Value | Source |
|-----------|-------|--------|
| `oracle_pass_threshold` | 0.7 | Matches REFINE-SMT primary config |
| `temperature_gen` (LLM-A / generation role) | 0.7 | Theorem 2.2 — stochastic beam diversity |
| `temperature_det` (LLM-B/C / critique-repair role) | 0.0 | Theorem 2.2 — deterministic alignment/repair |
| `max_retries` (B3) | 7 | Same budget as REFINE-SMT `max_outer=7` |
| `max_refine_iters` (B2) | 3 | — |
| `max_cegar` (B5) | 5 | CEGIS iterations; budget comparable to REFINE-SMT `max_cegar=7` |
| `sketch_mode` (B5) | `hole` | `hole` = replace faulty lines; `fixme` = annotate |
| `max_aquaforte_iters` (B6) | 5 | Clause-exclusion retry budget |
| `max_l4l_iters` (B7) | 3 | Schema extract+instantiate cycles |
| `max_masa_iters` (B8) | 3 | Hard+soft critique cycles |
| `rag_top_k` (B9) | 3 | BM25-retrieved context sections |
| `maxsmt_enabled` (B9) | `True` | `--no-maxsmt` disables |
| `max_new_tokens` (generation) | 4096 | — |
| `max_new_tokens` (critique/fill) | 2048 | — |

---

## Full End-to-End Run

```bash
BASE="ICLR_Submission/Baseline"
cd "$BASE"

# SLM tier — B1-B5, all 4 acts
bash run_baselines.sh --baseline all --tier slm

# LLM tier
bash run_baselines.sh --baseline all --tier llm

# B5 only (hole mode — default)
bash run_baselines.sh --baseline b5 --tier slm

# B5 fixme mode
bash run_baselines.sh --baseline b5 --tier slm --sketch-mode fixme --max-cegar 5

# B6-B9, SLM and LLM tiers
cd new_baseline
python3 run_new_baselines.py --baseline all --tier slm
python3 run_new_baselines.py --baseline all --tier llm
cd ..

# Evaluate and compare all 9 at once (auto-discovers each baseline's own latest run)
bash evaluate_baselines.sh --tier slm
bash evaluate_baselines.sh --tier llm
```

---

## Troubleshooting

### `ModuleNotFoundError: No module named 'baseline_config'`

You are running from outside the Baseline directory. Always:
```bash
cd ICLR_Submission/Baseline
python3 run_baselines.py ...       # B1-B5
# or, from new_baseline/:
python3 run_new_baselines.py ...   # B6-B9
```
The shell scripts handle this automatically (B1-B5 only).

### `ModuleNotFoundError: No module named 'SMT_Generation_AAAI_Final'`

`lib/` is not in `sys.path`. This is set automatically when `baseline_config` is imported. If running a single file in isolation, add:
```bash
export PYTHONPATH="$(pwd):$(pwd)/lib:${PYTHONPATH:-}"
```

### `RuntimeError: transformers and torch are required`

```bash
pip install transformers torch accelerate
```
(Not needed if running with `--backend ollama` — see `../install/README.md`.)

### `Act input not found: DPDP → None`

`Benchmark/dataset/` (this bundle's own copy of the 4-act corpus) is missing or `ICLR_Submission/` was moved
without keeping that folder alongside `Baseline/`. Check:
```bash
python3 -c "from baseline_config import ACTS_INPUT; print(ACTS_INPUT)"
```

### B4: `outlines not installed — B4 will use template_fallback mode`

This is a warning, not an error — B4 will run using the template-fill fallback. To use the outlines backend:
```bash
pip install outlines
```

### `CUDA out of memory`

- SLM tier (7B, float16): ~14 GB VRAM — fits on any modern GPU.
- LLM tier (32B, bfloat16): ~64 GB VRAM — requires H200 or 2× A100 80GB.
- B4 with outlines loads a second model instance separately. Use `--force-template-fallback` on memory-limited machines.

### `No logs found for slm / b1_zeroshot / <run_id>`

The baseline has not been run yet, or the `run_id` is wrong. To auto-discover the latest run:
```bash
bash evaluate_baselines.sh --tier slm
# (omit --run-id to auto-discover)
```

### `No section data found`

Check that the baseline run completed:
```bash
find Baseline_Output/ -name "section_metrics.json" | wc -l
```

---

## Notes for AAAI Paper

- **B1 vs REFINE-SMT** tests the end-to-end value of the full pipeline (generation + alignment + repair).
- **B2 vs REFINE-SMT** tests whether oracle-guided CEGAR feedback outperforms LLM-internal self-critique.
- **B3 vs REFINE-SMT** isolates the contribution of the structured error taxonomy counterexample — B3 has the same budget but only raw tracebacks.
- **B4 vs REFINE-SMT** tests whether structural validity alone (guaranteed by grammar) substitutes for semantic correctness (achieved by oracle-guided repair).
- **B5 vs REFINE-SMT** tests an independent CEGIS repair system from the program-repair literature. Key differences: (1) no LLM-B semantic alignment step; (2) fault localization is regex/taxonomy (not MaxSAT); (3) a single LLM fills @HOLE@ markers rather than a structured 3-LLM pipeline. A B5 win suggests the sketch-based approach is competitive; a REFINE-SMT win validates the 3-LLM design.
- **B6 vs REFINE-SMT** tests whether adaptive-retry-with-clause-exclusion (narrowing the generation search space) is competitive with REFINE-SMT's targeted, counterexample-guided repair of a fixed candidate.
- **B7 vs REFINE-SMT** tests whether an intermediate structured schema (extract-then-instantiate) helps or hurts relative to REFINE-SMT's direct text-to-Z3 generation with structured repair.
- **B8 vs REFINE-SMT** tests whether splitting REFINE-SMT's single LLM-B alignment gate into two axes (hard/formal vs soft/semantic critique), each with its own refinement agent, outperforms REFINE-SMT's unified gate-then-repair design.
- **B9 vs REFINE-SMT** tests whether retrieval-augmented context (BM25 over same-act sections) plus a MaxSMT-based minimal-violation repair signal outperforms REFINE-SMT's non-retrieval, structured-counterexample CEGAR.
- All nine baselines use identical oracle scoring (`SemanticOracle.execute_and_score`) so `section_metrics.json` is directly comparable via `compute_all()`.
- The `llm_c_cegar_iterations` field maps to repair metrics consistently: B1/B4 = 0, B2 = refine iters, B3 = retry count, B5 = CEGIS iters, B6 = clause-exclusion iters, B7 = extract-instantiate cycles, B8 = critique-refine cycles, B9 = 0 or 1 (single MaxSMT repair attempt).
- B6–B9 are domain adaptations of published systems with no reference implementation in this codebase's
  domain (Z3/privacy-law) — each adaptation's paper→domain mapping is documented in its own module docstring
  (`new_baseline/b6_aquaforte.py` etc.) and summarized in the Per-Baseline Design Details above.
