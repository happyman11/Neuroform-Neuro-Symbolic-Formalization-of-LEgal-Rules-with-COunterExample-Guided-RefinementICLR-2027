#!/usr/bin/env bash
# evaluate_baselines.sh — Evaluate and compare all REFINE-SMT baseline results
#
# Loads section_metrics.json from Baseline_Output/{tier}/ and produces a
# side-by-side comparison table using the same compute_all() metrics as the
# main REFINE-SMT evaluation.
#
# Usage:
#   ./evaluate_baselines.sh [--tier slm|llm]
#   ./evaluate_baselines.sh --tier slm --run-id Baseline-SLM-ALL-20260609T120000Z
#   ./evaluate_baselines.sh --tier slm --run-ids b1=<id> b2=<id> b3=<id> b4=<id>
#   ./evaluate_baselines.sh --tier llm --output my_comparison.json
#
# If no --run-id / --run-ids given, auto-discovers the latest run for each baseline.
#
# Logs are tee'd to Baseline_Output/logs/<timestamp>_eval.log

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# ICLR supplementary: repointed to this bundle's own root (one level up from Baseline/), self-contained --
# matches baseline_config.py's own ROOT/BASELINE_OUTPUT resolution.
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
LOG_DIR="$ROOT/Baseline_Output/logs"
mkdir -p "$LOG_DIR"

TIMESTAMP=$(date -u +"%Y%m%dT%H%M%SZ")
LOG_FILE="$LOG_DIR/${TIMESTAMP}_eval.log"

export PYTHONPATH="$SCRIPT_DIR:$SCRIPT_DIR/lib:${PYTHONPATH:-}"

# ── Forward all arguments to Python ──────────────────────────────────────────
EXTRA_ARGS=("$@")

# Determine tier for display
TIER="slm"
for i in "${!EXTRA_ARGS[@]}"; do
    if [[ "${EXTRA_ARGS[$i]}" == "--tier" ]]; then TIER="${EXTRA_ARGS[$((i+1))]}"; fi
done

echo -e "${CYAN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║    REFINE-SMT Baseline Evaluation                    ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Timestamp : ${YELLOW}${TIMESTAMP}${NC}"
echo -e "  Tier      : ${YELLOW}${TIER}${NC}"
echo -e "  Log file  : ${YELLOW}${LOG_FILE}${NC}"
echo ""

python3 "$SCRIPT_DIR/evaluate_baselines.py" \
    "${EXTRA_ARGS[@]}" 2>&1 | tee "$LOG_FILE"

EXIT_CODE=${PIPESTATUS[0]}
if [ "$EXIT_CODE" -eq 0 ]; then
    echo -e "\n  ${GREEN}✓ Evaluation complete.${NC}"
    echo -e "  Results : ${YELLOW}$ROOT/Baseline_Output/${TIER}/comparison_*.json${NC}"
else
    echo -e "\n  ${RED}✗ Evaluation exited with code $EXIT_CODE. Check log: $LOG_FILE${NC}"
fi
exit "$EXIT_CODE"
