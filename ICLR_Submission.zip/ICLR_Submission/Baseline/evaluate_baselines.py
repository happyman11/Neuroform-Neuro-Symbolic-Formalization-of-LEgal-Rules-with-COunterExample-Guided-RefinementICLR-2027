#!/usr/bin/env python3
"""
evaluate_baselines.py — Compare all nine baselines (B1-B9) using the existing compute_all() metric.

Loads section_metrics.json from Baseline_Output/{tier}/{baseline}/{run_id}/
and runs the same metrics.py compute_all() function (local copy in lib/) used for
REFINE-SMT results, enabling apples-to-apples comparison tables.

Usage:
    cd ICLR_Submission/Baseline

    # No args -- auto-discovers the latest run for each of the 9 baseline names independently
    # (recommended: B1-B5 come from run_baselines.py's run_id, B6-B9 from
    # new_baseline/run_new_baselines.py's OWN, separate run_id -- this mode handles both correctly)
    python evaluate_baselines.py --tier slm

    # Evaluate B1-B5 from one shared run (all run together via --baseline all)
    python evaluate_baselines.py --tier slm --run-id Baseline-SLM-ALL-20260609T120000Z

    # Specify per-baseline run IDs explicitly (any subset of b1..b9, short or full name)
    python evaluate_baselines.py --tier slm \\
        --run-ids b1=Baseline-SLM-B1-20260609T...  b6=NewBaseline-SLM-B6-20260609T...

    # Output comparison to custom file
    python evaluate_baselines.py --tier slm --run-id <id> --output results.json

Output:
    Baseline_Output/{tier}/comparison_{ts}.json
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

# ── Path setup — all imports from local lib/, no cross-folder paths ───────────
_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_HERE / "lib"))

from baseline_config import BASELINE_OUTPUT, ACTS
from metrics import compute_all  # lib/metrics.py — local copy

logger = logging.getLogger("evaluate_baselines")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)

_BASELINE_NAMES = [
    "b1_zeroshot",
    "b2_cot_selfrefine",
    "b3_naive_retry",
    "b4_grammar_constrained",
    "b5_cegis_sketch",
    "b6_aquaforte",
    "b7_l4l_schema",
    "b8_masa_multiagent",
    "b9_rag_smt",
]

_SHORT_KEY_TO_NAME = {
    "b1": "b1_zeroshot",
    "b2": "b2_cot_selfrefine",
    "b3": "b3_naive_retry",
    "b4": "b4_grammar_constrained",
    "b5": "b5_cegis_sketch",
    "b6": "b6_aquaforte",
    "b7": "b7_l4l_schema",
    "b8": "b8_masa_multiagent",
    "b9": "b9_rag_smt",
}


# ── Loaders ───────────────────────────────────────────────────────────────────

def _load_section_logs(
    tier: str,
    baseline_name: str,
    run_id: str,
) -> dict[str, list[dict]]:
    """Return {act: [section_metrics_dict, ...]} for one baseline run."""
    base = BASELINE_OUTPUT / tier / baseline_name / run_id
    logs_by_act: dict[str, list[dict]] = {}
    for metrics_file in sorted(base.rglob("section_metrics.json")):
        # Parent directory name is the act
        act = metrics_file.parent.parent.name
        try:
            with open(metrics_file, encoding="utf-8") as f:
                data = json.load(f)
            logs_by_act.setdefault(act, []).append(data)
        except Exception as exc:
            logger.warning("Failed to load %s: %s", metrics_file, exc)
    return logs_by_act


def _find_latest_run_id(tier: str, baseline_name: str) -> str | None:
    """Return the most recent run_id for a baseline by directory mtime."""
    base = BASELINE_OUTPUT / tier / baseline_name
    if not base.exists():
        return None
    dirs = sorted(
        [d for d in base.iterdir() if d.is_dir()],
        key=lambda d: d.stat().st_mtime,
        reverse=True,
    )
    return dirs[0].name if dirs else None


# ── Compute ───────────────────────────────────────────────────────────────────

def compute_comparison(
    tier: str,
    run_id_map: dict[str, str],
) -> dict:
    """
    For each baseline in run_id_map, compute_all(logs) per act.
    Returns nested dict: {baseline_name: {act: metrics_dict}}.
    """
    results: dict[str, dict] = {}

    for baseline_key, run_id in run_id_map.items():
        # Accept both short keys ("b1".."b9") and full names ("b1_zeroshot", ...)
        baseline_name = _SHORT_KEY_TO_NAME.get(baseline_key, baseline_key)

        logs_by_act = _load_section_logs(tier, baseline_name, run_id)
        if not logs_by_act:
            logger.warning("No logs found for %s / %s / %s", tier, baseline_name, run_id)
            continue

        results[baseline_name] = {}
        for act, logs in sorted(logs_by_act.items()):
            try:
                metrics = compute_all(logs)
                results[baseline_name][act] = metrics
                sr = metrics.get("end_to_end_success_rate", 0.0)
                logger.info("  %-30s %-6s  E2E=%.1f%%  n=%d",
                            baseline_name, act, sr * 100, len(logs))
            except Exception as exc:
                logger.error("compute_all failed for %s/%s: %s", baseline_name, act, exc)
                results[baseline_name][act] = {"error": str(exc)}

    return results


# ── CLI ────────────────────────────────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(description="Evaluate REFINE-SMT baselines")
    p.add_argument("--tier", default="slm", choices=["slm", "llm"])
    p.add_argument(
        "--run-id", default=None,
        help="Single run_id for all baselines (if run with --baseline all)",
    )
    p.add_argument(
        "--run-ids", nargs="+", default=None,
        metavar="KEY=RUN_ID",
        help="Per-baseline run IDs, e.g. b1=Baseline-SLM-B1-... b6=NewBaseline-SLM-B6-... (any subset of b1..b9)",
    )
    p.add_argument("--output", default=None,
                   help="Output JSON path (default: Baseline_Output/{tier}/comparison_{ts}.json)")
    args = p.parse_args()

    # Build run_id_map
    run_id_map: dict[str, str] = {}

    if args.run_ids:
        for item in args.run_ids:
            key, _, rid = item.partition("=")
            run_id_map[key.strip()] = rid.strip()
    elif args.run_id:
        for name in _BASELINE_NAMES:
            run_id_map[name] = args.run_id
    else:
        logger.info("No run_id provided — discovering latest runs for each baseline")
        for name in _BASELINE_NAMES:
            rid = _find_latest_run_id(args.tier, name)
            if rid:
                run_id_map[name] = rid
                logger.info("  %s → %s", name, rid)
            else:
                logger.warning("  %s → no runs found", name)

    if not run_id_map:
        logger.error("No run IDs found. Run baselines first with run_baselines.py")
        sys.exit(1)

    logger.info("Evaluating %d baseline(s) for tier=%s", len(run_id_map), args.tier)
    comparison = compute_comparison(args.tier, run_id_map)

    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_path = Path(args.output) if args.output else (
        BASELINE_OUTPUT / args.tier / f"comparison_{ts}.json"
    )
    out_path.parent.mkdir(parents=True, exist_ok=True)

    output = {
        "tier":      args.tier,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "run_ids":   run_id_map,
        "results":   comparison,
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)

    logger.info("Comparison written → %s", out_path)

    # Print summary table
    print("\n── Baseline Comparison Summary ──────────────────────────────────")
    print(f"{'Baseline':<30} {'Act':<8}  {'E2E %':>7}  {'Align %':>8}  {'n':>5}")
    print("─" * 65)
    for bname, act_metrics in sorted(comparison.items()):
        for act, m in sorted(act_metrics.items()):
            if isinstance(m, dict) and "end_to_end_success_rate" in m:
                print(
                    f"{bname:<30} {act:<8}  "
                    f"{m['end_to_end_success_rate']*100:>6.1f}%  "
                    f"{m.get('mean_semantic_alignment', 0.0)*100:>7.1f}%  "
                    f"{m.get('n_sections', 0):>5}"
                )
    print("─" * 65)


if __name__ == "__main__":
    main()
