"""
B3 — Generate → SMT Fail → Retry (without structured repair)

Control condition for REFINE-SMT's structured CEGAR loop.

Key design difference from REFINE-SMT:
  - NO error taxonomy classification fed to the model (we still classify for
    our own analysis and populate error_type_sequence, but the model receives
    only the raw Python traceback — no class label, no targeted hint).
  - NO beam search: single candidate per attempt.
  - NO LLM-B semantic alignment check.
  - Max retry budget matches REFINE-SMT's max_outer (default 7).

This tests whether REFINE-SMT's structured counterexample is responsible for
its repair advantage, or whether any error feedback suffices.
"""
from __future__ import annotations

import json
import logging
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from baseline_config import (
    ORACLE_PASS_THRESHOLD,
    BASELINE_SYSTEM_MSG,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TEMPERATURE_GEN,
    MAX_NEW_TOKENS_GEN,
    baseline_run_dir,
    get_hf_model,
)
from baseline_prompts import NAIVE_RETRY_PROMPT

from SMT_Generation_AAAI_Final import (
    RefineSMT, Candidate, SemanticOracle, classify_error, ErrorType,
)
from promting import Prompt

logger = logging.getLogger(__name__)

BASELINE_NAME = "b3_naive_retry"


class NaiveRetryBaseline:
    """B3: naive retry with raw error feedback, no structured repair."""

    def __init__(
        self,
        model_id: str,
        tier: str,
        output_root: Path,
        act_name: str,
        run_id: str,
        max_retries: int = DEFAULT_MAX_RETRIES,
        temperature: float = DEFAULT_TEMPERATURE_GEN,
        seed: int | None = None,
    ) -> None:
        self.model_id    = model_id
        self.tier        = tier
        self.output_root = Path(output_root)
        self.act_name    = act_name
        self.run_id      = run_id
        self.max_retries = max_retries
        self.temperature = temperature
        self._seed = seed
        self._call_counter = 0

        self.HFModel  = get_hf_model(tier)
        self.oracle   = SemanticOracle()
        self.prompter = Prompt()

        self._section_logs: list[dict] = []

        self.output_root.mkdir(parents=True, exist_ok=True)
        logger.info("B3 NaiveRetry ready | tier=%s model=%s max_retries=%d act=%s",
                    tier, model_id, max_retries, act_name)

    def _hf_call(self, *args, **kwargs) -> str:
        """Wraps self.HFModel.call() with a distinct derived seed per call
        (self._seed + running counter) when a base seed is set; None/unseeded
        otherwise, identical to calling self.HFModel.call() directly."""
        if self._seed is not None:
            kwargs["seed"] = self._seed + self._call_counter
            self._call_counter += 1
        return self.HFModel.call(*args, **kwargs)

    # ── Per-section ───────────────────────────────────────────────────────────

    def process_section(self, section: dict, filename_stem: str) -> None:
        section_id = section.get("section_number", filename_stem)
        t0 = time.time()

        section_dir = self.output_root / filename_stem
        section_dir.mkdir(parents=True, exist_ok=True)

        total_attempts = 1 + self.max_retries
        error_type_sequence: list[str] = []
        best_candidate: Candidate | None = None
        best_score = 0.0
        n_retries = 0
        prev_candidate: Candidate | None = None

        for attempt in range(total_attempts):
            logger.info("[%s] ════ B3 Attempt %d/%d ════",
                        section_id, attempt + 1, total_attempts)

            if attempt == 0:
                prompt = self.prompter.get_FOL_acts(section, error="", prior_code="")
            else:
                # Raw error only — deliberately no classification or targeted hint
                raw_error = ""
                if prev_candidate:
                    parts = []
                    if prev_candidate.error_message:
                        parts.append(prev_candidate.error_message)
                    if prev_candidate.execution_output:
                        parts.append(prev_candidate.execution_output[:300])
                    raw_error = "\n".join(parts).strip()

                prev_code = (
                    "\n\n".join(prev_candidate.code_blocks)
                    if prev_candidate and prev_candidate.code_blocks
                    else ""
                )
                prompt = NAIVE_RETRY_PROMPT.format(
                    Section=section,
                    Code=prev_code,
                    RawError=raw_error or "Unknown error.",
                )

            raw = self._hf_call(
                self.model_id, prompt,
                temperature=self.temperature,
                max_new_tokens=MAX_NEW_TOKENS_GEN,
                system_message=BASELINE_SYSTEM_MSG,
            )

            blocks = RefineSMT.extract_code(raw)
            if not blocks:
                logger.warning("[%s] No code extracted at attempt %d",
                               section_id, attempt + 1)
                error_type_sequence.append(ErrorType.SYNTAX.value)
                if attempt > 0:
                    n_retries += 1
                # Keep prev_candidate so next iteration's error string is meaningful
                prev_raw_cand = Candidate(code_blocks=[], raw_response=raw)
                prev_raw_cand.error_type = ErrorType.SYNTAX
                prev_raw_cand.error_message = "No code block extracted from model output."
                prev_candidate = prev_raw_cand
                continue

            candidate = Candidate(code_blocks=blocks, raw_response=raw)
            self.oracle.execute_and_score(candidate)

            # Classify for OUR analysis — NOT passed to model (key B3 invariant)
            classified = classify_error(
                candidate.error_message, candidate.execution_output
            )
            error_type_sequence.append(classified.value)

            logger.info(
                "[%s] Oracle score: %.2f | exec=%s | verdict=%s | error=%s",
                section_id, candidate.semantic_score,
                candidate.execution_success, candidate.z3_verdict, classified.value,
            )

            if candidate.semantic_score > best_score:
                best_score = candidate.semantic_score
                best_candidate = candidate

            if attempt > 0:
                n_retries += 1

            prev_candidate = candidate

            if candidate.semantic_score >= ORACLE_PASS_THRESHOLD:
                logger.info("[%s] SUCCESS — oracle=%.2f wall_time=%.1fs",
                            section_id, candidate.semantic_score, time.time() - t0)
                break
        else:
            logger.warning("[%s] FAILED — all %d attempts exhausted",
                           section_id, total_attempts)

        if best_candidate is None:
            best_candidate = Candidate(code_blocks=[], raw_response="")
            best_candidate.error_type = ErrorType.SYNTAX
            if error_type_sequence:
                best_candidate.error_type = ErrorType(error_type_sequence[-1])

        wall_time = time.time() - t0
        metrics = self._build_metrics(
            section, filename_stem, best_candidate,
            n_retries, error_type_sequence, wall_time,
        )
        self._section_logs.append(metrics)

        metrics_path = section_dir / "section_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        logger.info("[%s] Log saved → %s", section_id, metrics_path)

        if best_candidate.code_blocks:
            code_path = section_dir / "final_code.py"
            code_path.write_text(best_candidate.code_blocks[0], encoding="utf-8")
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)

    # ── Aggregate ─────────────────────────────────────────────────────────────

    def save_aggregate_metrics(self) -> None:
        if not self._section_logs:
            return
        total = len(self._section_logs)
        successes = sum(1 for m in self._section_logs
                        if m["results"]["final_success"])
        agg = {
            "algorithm":      BASELINE_NAME,
            "tier":           self.tier,
            "act":            self.act_name,
            "run_id":         self.run_id,
            "model":          self.model_id,
            "acts_processed": total,
            "successful":     successes,
            "failed":         total - successes,
            "success_rate":   round(successes / total, 4) if total else 0.0,
            "mean_wall_time_sec": round(
                sum(m["results"]["wall_time_sec"] for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "per_section":    self._section_logs,
        }
        out = self.output_root / "aggregate_metrics.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(agg, f, indent=2)
        logger.info("B3 aggregate → %s  (success=%d/%d)", out, successes, total)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_metrics(
        self,
        section: dict,
        filename_stem: str,
        candidate: Candidate,
        n_retries: int,
        error_type_sequence: list[str],
        wall_time: float,
    ) -> dict:
        err_val  = candidate.error_type.value if hasattr(candidate.error_type, "value") else str(candidate.error_type)
        exec_ok  = float(candidate.execution_success)
        solver_ok = float(candidate.semantic_score >= 0.7)
        verdict_ok = float(candidate.z3_verdict in ("sat", "unsat"))
        proof_ok  = float(candidate.semantic_score >= 1.0)
        err_cnt  = dict(Counter(error_type_sequence))

        return {
            "algorithm":  BASELINE_NAME,
            "act_file":   filename_stem,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "models":     {"primary": self.model_id},
            "hyperparameters": {
                "temperature":          self.temperature,
                "max_new_tokens":       MAX_NEW_TOKENS_GEN,
                "max_retries":          self.max_retries,
                "oracle_pass_threshold": ORACLE_PASS_THRESHOLD,
            },
            "results": {
                "final_success":               candidate.semantic_score >= ORACLE_PASS_THRESHOLD,
                "semantic_alignment_confirmed": round(candidate.semantic_score, 4),
                "final_error_type":            err_val,
                "wall_time_sec":               round(wall_time, 3),
            },
            "attempt_counts": {
                "llm_a_outer_attempts":    1,
                "llm_b_semantic_flags":    0,
                "llm_c_cegar_iterations":  n_retries,
                "beam_candidates_generated": 1 + n_retries,
            },
            "error_analysis": {
                "error_type_sequence": error_type_sequence,
                "error_type_counts":   err_cnt,
            },
            "oracle_components": {
                "exec":        exec_ok,
                "solver":      solver_ok,
                "verdict":     verdict_ok,
                "proof":       proof_ok,
                "final_score": round(candidate.semantic_score, 4),
                "mode":        "full",
            },
            "baseline_metadata": {
                "baseline":      BASELINE_NAME,
                "tier":          self.tier,
                "feedback_mode": "raw_error_only",
                "retries_done":  n_retries,
                "temperature":   self.temperature,
            },
        }
