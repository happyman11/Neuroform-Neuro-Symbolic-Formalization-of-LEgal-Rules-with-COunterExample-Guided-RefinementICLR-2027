"""
baseline_config.py — Fully self-contained configuration for all REFINE-SMT baselines.

No imports from any other scripts/ subdirectory.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# ── Directory layout ──────────────────────────────────────────────────────────
# ICLR supplementary: ROOT now means "this bundle's own root" (ICLR_Submission/), not the original tree's
# Final_Implementation/ -- ACTS_INPUT below is repointed accordingly (see next comment block). Layout:
# ICLR_Submission/Baseline/baseline_config.py
#   parent   = Baseline/
#   parent×2 = ICLR_Submission/  (ROOT)

_BASELINE_DIR = Path(__file__).resolve().parent       # ICLR_Submission/Baseline/
_LIB_DIR      = _BASELINE_DIR / "lib"
ROOT          = _BASELINE_DIR.resolve().parents[0]    # ICLR_Submission/
AAAI_ROOT     = ROOT

# Make lib/ importable — everything the runners need lives there
for _p in [str(_BASELINE_DIR), str(_LIB_DIR)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ICLR supplementary: repointed from the original tree's UML_Annotations/ (external to this bundle) to this
# bundle's own Benchmark/dataset/ (self-contained). Verified byte-identical content to UML_Annotations/
# {ACT}_Act/ at the time this bundle was assembled -- see PAPER_CODE_CORRESPONDENCE.md.
ACTS_INPUT: dict[str, Path] = {
    "DPDP": AAAI_ROOT / "Benchmark/dataset/DPDP_Act",
    "GDPR": AAAI_ROOT / "Benchmark/dataset/GDPR_Act",
    "CCPA": AAAI_ROOT / "Benchmark/dataset/CCPA_Act",
    "PIPD": AAAI_ROOT / "Benchmark/dataset/PIPD_Act",
}

IGNORE_FILES: set[str] = {
    ".DS_Store", "sections", "aggregate_metric.json",
    "aggregate_metrics.json", "metrics_extract.log", "run.log",
}

ACTS = list(ACTS_INPUT.keys())   # ["DPDP", "GDPR", "CCPA", "PIPD"]

# ── Output paths ──────────────────────────────────────────────────────────────
BASELINE_OUTPUT = AAAI_ROOT / "Baseline_Output"


def baseline_run_dir(tier: str, baseline_name: str, run_id: str, act: str) -> Path:
    return BASELINE_OUTPUT / tier / baseline_name / run_id / act


# ── Model selection ───────────────────────────────────────────────────────────
# SLM tier → Qwen/Qwen2.5-Coder-7B-Instruct
#   Primary LLM-A in SLM benchmarking config (scripts/SLM/benchmarking/config.yaml)
#   Best-performing SLM in REFINE-SMT primary config (80.2 % E2E success).
#
# LLM tier → Qwen/Qwen2.5-Coder-32B-Instruct
#   Primary LLM-A in LLM benchmarking config (scripts/LLM/benchmarking/config.yaml)
#   Best-performing LLM in the paper (87.4 % E2E success).
#
# Both are instruction-tuned (chat_template present) → fence priming never needed.
TIER_MODELS: dict[str, dict] = {
    "slm": {
        "model_id":  "Qwen/Qwen2.5-Coder-7B-Instruct",
        "owner":     "HuggingFace",
        "size_hint": "7B",
        # ICLR supplementary: Ollama backend, same model -- see install/model_registry.yaml.
        "ollama_id": "qwen2.5-coder:7b",
    },
    "llm": {
        "model_id":  "Qwen/Qwen2.5-Coder-32B-Instruct",
        "owner":     "HuggingFace",
        "size_hint": "32B",
        "ollama_id": "qwen2.5-coder:32b",
    },
}

# ── Hyperparameter defaults ───────────────────────────────────────────────────
# scripts/additional_runs/ seed-robustness study: overridable via
# BASELINE_ORACLE_THRESHOLD env var (e.g. set to "0.8" by run_multi_seed.sh) so
# a baseline can be re-scored at the same threshold as config_threshold_08.yaml
# without touching this module's default. Unset -> unchanged prior behavior (0.7).
ORACLE_PASS_THRESHOLD   = float(os.environ.get("BASELINE_ORACLE_THRESHOLD", "0.7"))
DEFAULT_TEMPERATURE_GEN = 0.7   # LLM-A temperature (Theorem 2.2)
DEFAULT_TEMPERATURE_DET = 0.0   # LLM-B/C temperature (Theorem 2.2)
DEFAULT_MAX_RETRIES     = 7     # B3 — same budget as REFINE-SMT max_outer=7
DEFAULT_MAX_REFINE_ITERS = 3    # B2 CoT self-refine

MAX_NEW_TOKENS_GEN = 4096   # generation / repair calls
MAX_NEW_TOKENS_DET = 2048   # critique / fill calls

# System message injected for all baseline HF calls — forces code-fence output
BASELINE_SYSTEM_MSG = (
    "You are an expert Python and Z3 formal-verification engineer. "
    "Your task is to generate a complete Z3 Python program that formally encodes "
    "the given legal constraint. "
    "Output the complete, syntactically valid Python script inside "
    "a single ```python\\n...\\n``` fenced code block. "
    "The script must import z3, declare all variables, add all constraints, "
    "and print the solver result."
)

# ── Model backend accessor ────────────────────────────────────────────────────
# baseline_models.py (in lib/) is a copy of llm_models.py — handles 7B and 32B.
#
# ICLR supplementary: Ollama as a first-class, symmetric alternative to HuggingFace. All 9 baselines (b1-b9)
# call get_hf_model(tier) by name (imported once at module load, invoked at __init__ time) -- rather than
# editing all 9 call sites, get_hf_model() itself is made backend-aware via the module-level _BACKEND flag
# below, set once by run_baselines.py/run_new_baselines.py's --backend flag before any baseline is
# constructed. This keeps every baseline file, and its existing `self.HFModel = get_hf_model(tier)` line,
# completely unchanged; get_ollama_model() is also exposed directly for callers that want it explicitly.
_BACKEND = "huggingface"


def set_backend(name: str) -> None:
    global _BACKEND
    if name not in ("huggingface", "ollama"):
        raise ValueError(f"backend must be 'huggingface' or 'ollama', got {name!r}")
    _BACKEND = name


def get_hf_model(tier: str | None = None):
    """Return the model-calling class for the currently selected backend (see set_backend() above; default
    'huggingface' -- byte-identical to prior behavior when --backend is never passed).

    The tier parameter is accepted for call-site compatibility but ignored — baseline_models.py handles both
    7B (float16) and 32B (bfloat16) automatically based on the model_id passed to HuggingFaceModel.call().
    """
    if _BACKEND == "ollama":
        return get_ollama_model(tier)
    from baseline_models import HuggingFaceModel  # noqa: PLC0415
    return HuggingFaceModel


def get_ollama_model(tier: str | None = None):
    """Ollama backend counterpart to get_hf_model() -- an adapter exposing the exact same .call(model,
    prompt, temperature=, max_new_tokens=, system_message=, seed=) classmethod shape as HuggingFaceModel,
    routed through lib/models.py's ModelCall.ollama_call_model (already parameter-complete -- see
    PAPER_CODE_CORRESPONDENCE.md). tier is accepted for call-site/signature parity with get_hf_model but
    ignored (the model id is chosen by the caller via TIER_MODELS[tier]["ollama_id"], same as the HF path
    uses TIER_MODELS[tier]["model_id"])."""
    from models import ModelCall  # noqa: PLC0415

    class _OllamaModelAdapter:
        _mc = ModelCall()

        @classmethod
        def call(cls, model_name: str, prompt: str, temperature: float = 0.7, max_new_tokens: int = 4096,
                  system_message: str = "", seed: int | None = None) -> str:
            return cls._mc.ollama_call_model(
                prompt=prompt, model=model_name, temperature=temperature,
                max_new_tokens=max_new_tokens, system_message=system_message, seed=seed,
            )

    return _OllamaModelAdapter
