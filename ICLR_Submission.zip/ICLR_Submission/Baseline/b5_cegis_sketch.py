"""
B5 — CEGIS-Sketch (Orvalho et al., AAAI 2025 — arXiv:2502.07786)

Adaptation of "Counterexample Guided Program Repair Using Zero-Shot Learning
and MaxSAT-based Fault Localization" to the Z3/legal domain.

Paper contribution → domain adaptation:
  MaxSAT-based fault localization  →  taxonomy-guided FL (classify_error E0-E5)
  Student C programs + test suite  →  Z3 Python + SemanticOracle
  @HOLE@ program sketch            →  same (hole mode) or FIXME annotation (fixme mode)
  Counterexample (failing test)    →  oracle feedback: error_type + error_msg + exec_out

Best paper config without reference implementation (Table 2):
  "Sk-De-TS-CE" = Sketch + Description + Test-Suite feedback + Counterexample
This maps exactly to: sketch with oracle feedback each CEGIS iteration.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from baseline_config import (
    ORACLE_PASS_THRESHOLD,
    BASELINE_SYSTEM_MSG,
    MAX_NEW_TOKENS_GEN,
    DEFAULT_TEMPERATURE_GEN,
    baseline_run_dir,
    get_hf_model,
)

# Shared lib (sys.path set by baseline_config import)
from SMT_Generation_AAAI_Final import (
    RefineSMT, Candidate, SemanticOracle, classify_error, ErrorType,
)
from promting import Prompt
from baseline_prompts import CEGIS_HOLE_FILL_PROMPT, CEGIS_FIXME_PROMPT

logger = logging.getLogger(__name__)

BASELINE_NAME = "b5_cegis_sketch"


# ─────────────────────────────────────────────────────────────────────────────
# Fault Localization
# ─────────────────────────────────────────────────────────────────────────────

def _localize_faults(
    code: str,
    error_type: ErrorType,
    error_msg: str,
) -> list[tuple[int, str]]:
    """
    Returns list of (line_index_0based, reason) tuples identifying faulty lines.

    Strategy per ErrorType (taxonomy-guided, no MaxSAT needed):
      E1_syntax           — parse traceback for 'line N'; fall back to self.X=z3. lines
      E2_z3_encoding      — all z3.Bool/Int/Real declaration lines in __init__
      E3_semantic_inversion — z3.Implies/Not/And/Or lines (wrong polarity lives here)
      E4_incomplete       — last line of __init__ + synthetic hole after it
      E5_over_constrained — all solver.add() lines
      E0_none / fallback  — entire get_rule body
    """
    lines = code.splitlines()
    faulty: list[tuple[int, str]] = []

    if error_type == ErrorType.SYNTAX:
        # Try to parse traceback line number
        m = re.search(r"[Ll]ine[^\d]*(\d+)", error_msg)
        if m:
            idx = int(m.group(1)) - 1  # convert 1-based to 0-based
            if 0 <= idx < len(lines):
                faulty.append((idx, "syntax error on this line"))
        if not faulty:
            # Fall back: mark lines with self.X = z3. assignments
            for i, ln in enumerate(lines):
                if re.search(r"self\.\w+\s*=\s*z3\.", ln):
                    faulty.append((i, "possibly malformed z3 declaration"))

    elif error_type == ErrorType.Z3_ENCODING:
        # Mark all z3.Bool/Int/Real/Function declaration lines
        for i, ln in enumerate(lines):
            if re.search(r"z3\.(Bool|Int|Real|Function|BitVec)\s*\(", ln):
                faulty.append((i, "z3 variable declaration may be incorrect"))

    elif error_type == ErrorType.SEMANTIC_INV:
        # Wrong polarity: mark Implies/Not/And/Or usage
        for i, ln in enumerate(lines):
            if re.search(r"z3\.(Implies|Not|And|Or|ForAll|Exists)\s*\(", ln):
                faulty.append((i, "logical connective may have wrong polarity or arguments"))

    elif error_type == ErrorType.INCOMPLETE:
        # Find last line of __init__ and mark it + add hole after
        in_init = False
        last_init_line = -1
        for i, ln in enumerate(lines):
            if re.match(r"\s*def\s+__init__\s*\(", ln):
                in_init = True
            elif in_init and re.match(r"\s*def\s+\w+", ln):
                in_init = False
            if in_init and ln.strip():
                last_init_line = i
        if last_init_line >= 0:
            faulty.append((last_init_line, "incomplete — missing variable declarations for all constraints"))
        else:
            # Fallback: get_rule body
            faulty = _get_rule_body_lines(lines, "incomplete encoding")

    elif error_type == ErrorType.OVER_CONSTRAINED:
        # All solver.add() calls — remove over-restrictive constraints
        for i, ln in enumerate(lines):
            if re.search(r"solver\.add\s*\(", ln):
                faulty.append((i, "possibly redundant or over-restrictive constraint"))

    else:
        # NONE or unknown — mark entire get_rule body
        faulty = _get_rule_body_lines(lines, "body may not encode all legal obligations")

    # Fallback: if still nothing found, mark entire get_rule body
    if not faulty:
        faulty = _get_rule_body_lines(lines, "unable to localize specific fault")

    return faulty


def _get_rule_body_lines(lines: list[str], reason: str) -> list[tuple[int, str]]:
    """Return all non-empty lines inside the get_rule method body."""
    in_body = False
    result: list[tuple[int, str]] = []
    for i, ln in enumerate(lines):
        if re.match(r"\s*def\s+get_rule\s*\(", ln):
            in_body = True
            continue
        if in_body:
            if re.match(r"\s*def\s+\w+", ln):
                break
            if ln.strip() and not ln.strip().startswith("#"):
                result.append((i, reason))
    return result if result else [(max(0, len(lines) - 2), reason)]


# ─────────────────────────────────────────────────────────────────────────────
# Sketch Creation
# ─────────────────────────────────────────────────────────────────────────────

def _create_sketch(
    code: str,
    faulty: list[tuple[int, str]],
    mode: str,
) -> tuple[str, int]:
    """
    Returns (sketch_str, hole_count).

    mode="hole" : replace faulty line with # @HOLE N @  # was: <orig[:40]>
    mode="fixme": append # FIXME: <reason> to faulty line
    """
    lines = code.splitlines()
    faulty_idx = {idx: reason for idx, reason in faulty}
    hole_n = 0
    out: list[str] = []

    for i, ln in enumerate(lines):
        if i in faulty_idx:
            reason = faulty_idx[i]
            indent = len(ln) - len(ln.lstrip())
            spaces = " " * indent
            if mode == "hole":
                orig_preview = ln.strip()[:40].replace('"', "'")
                out.append(f'{spaces}# @HOLE {hole_n} @  # was: {orig_preview}')
                hole_n += 1
            else:  # fixme
                out.append(f'{ln}  # FIXME: {reason}')
        else:
            out.append(ln)

    return "\n".join(out), hole_n


# ─────────────────────────────────────────────────────────────────────────────
# Main Baseline Class
# ─────────────────────────────────────────────────────────────────────────────

class CEGISSketchBaseline:
    """
    B5: taxonomy-guided fault localization → program sketch → CEGIS loop.

    Implements the "Sk-De-TS-CE" configuration from Orvalho et al. AAAI 2025:
    - Sketch: replace faulty lines with @HOLE@ (or FIXME) markers
    - Description: include legal section text in every prompt
    - Test Suite: SemanticOracle is the oracle / test suite
    - Counterexample: oracle failure details fed back each iteration
    """

    def __init__(
        self,
        model_id: str,
        tier: str,
        output_root: Path,
        act_name: str,
        run_id: str,
        max_cegar: int = 5,
        sketch_mode: str = "hole",
    ) -> None:
        self.model_id    = model_id
        self.tier        = tier
        self.output_root = Path(output_root)
        self.act_name    = act_name
        self.run_id      = run_id
        self.max_cegar   = max_cegar
        self.sketch_mode = sketch_mode

        self.HFModel  = get_hf_model(tier)
        self.oracle   = SemanticOracle()
        self.prompter = Prompt()

        self._section_logs: list[dict] = []

        self.output_root.mkdir(parents=True, exist_ok=True)
        logger.info(
            "B5 CEGIS-Sketch ready | tier=%s model=%s act=%s max_cegar=%d mode=%s",
            tier, model_id, act_name, max_cegar, sketch_mode,
        )

    # ── Per-section ───────────────────────────────────────────────────────────

    def process_section(self, section: dict, filename_stem: str) -> None:
        section_id = section.get("section_number", filename_stem)
        t0 = time.time()

        section_dir = self.output_root / filename_stem
        section_dir.mkdir(parents=True, exist_ok=True)

        logger.info("[%s] ════ B5 CEGIS-Sketch (mode=%s) ════", section_id, self.sketch_mode)

        # ── Step 1: Initial generation (T=0.7 for stochasticity) ──────────────
        prompt0 = self.prompter.get_FOL_acts(section, error="", prior_code="")
        raw = self.HFModel.call(
            self.model_id, prompt0,
            temperature=DEFAULT_TEMPERATURE_GEN,
            max_new_tokens=MAX_NEW_TOKENS_GEN,
            system_message=BASELINE_SYSTEM_MSG,
        )

        blocks = RefineSMT.extract_code(raw)
        if not blocks:
            logger.warning("[%s] No code extracted at initial generation", section_id)

        candidate = Candidate(code_blocks=blocks, raw_response=raw)
        self.oracle.execute_and_score(candidate)

        cegar_iter_scores = [round(candidate.semantic_score, 4)]
        n_holes_per_iter  = [0]
        error_type_seq    = [candidate.error_type.value]
        cegar_iters_done  = 0
        best_candidate    = candidate

        logger.info(
            "[%s] Initial oracle: %.2f | exec=%s | verdict=%s | error=%s",
            section_id, candidate.semantic_score,
            candidate.execution_success, candidate.z3_verdict,
            candidate.error_type.value,
        )

        # ── Step 2: Check early pass ───────────────────────────────────────────
        if candidate.semantic_score >= ORACLE_PASS_THRESHOLD:
            logger.info("[%s] SUCCESS at initial generation — oracle=%.2f", section_id, candidate.semantic_score)
        else:
            # ── Step 3: CEGIS loop ─────────────────────────────────────────────
            for cegar_iter in range(self.max_cegar):
                logger.info("[%s] ════ CEGIS iter %d/%d ════", section_id, cegar_iter + 1, self.max_cegar)

                # a. Fault localize
                current_code = candidate.code_blocks[0] if candidate.code_blocks else ""
                if not current_code:
                    current_code = self._extract_fallback_code(candidate.raw_response)

                faulty_lines = _localize_faults(
                    current_code,
                    candidate.error_type,
                    candidate.error_message or "",
                )
                logger.info(
                    "[%s]   FL: %d faulty lines identified for %s",
                    section_id, len(faulty_lines), candidate.error_type.value,
                )

                # b. Create sketch
                sketch, n_holes = _create_sketch(current_code, faulty_lines, self.sketch_mode)

                # c. Build oracle feedback string (counterexample)
                oracle_feedback = (
                    f"Error type: {candidate.error_type.value}\n"
                    f"Error message: {(candidate.error_message or 'none')[:200]}\n"
                    f"Execution output: {(candidate.execution_output or 'none')[:200]}\n"
                    f"Oracle score: {candidate.semantic_score:.2f} (need >= {ORACLE_PASS_THRESHOLD})"
                )

                # d. Build CEGIS repair prompt
                section_text = self._section_to_text(section)
                if self.sketch_mode == "hole":
                    repair_prompt = CEGIS_HOLE_FILL_PROMPT.format(
                        Section=section_text,
                        Sketch=sketch,
                        OracleFeedback=oracle_feedback,
                    )
                else:
                    repair_prompt = CEGIS_FIXME_PROMPT.format(
                        Section=section_text,
                        Code=sketch,
                        OracleFeedback=oracle_feedback,
                    )

                # e. LLM fills holes (T=0.7 for diversity)
                raw = self.HFModel.call(
                    self.model_id, repair_prompt,
                    temperature=DEFAULT_TEMPERATURE_GEN,
                    max_new_tokens=MAX_NEW_TOKENS_GEN,
                    system_message=BASELINE_SYSTEM_MSG,
                )

                new_blocks = RefineSMT.extract_code(raw)
                if not new_blocks:
                    logger.warning("[%s]   No code extracted at CEGIS iter %d", section_id, cegar_iter + 1)

                new_candidate = Candidate(code_blocks=new_blocks, raw_response=raw)
                self.oracle.execute_and_score(new_candidate)

                cegar_iters_done += 1
                cegar_iter_scores.append(round(new_candidate.semantic_score, 4))
                n_holes_per_iter.append(n_holes)
                error_type_seq.append(new_candidate.error_type.value)

                logger.info(
                    "[%s]   iter %d oracle: %.2f | exec=%s | verdict=%s | error=%s | holes=%d",
                    section_id, cegar_iter + 1, new_candidate.semantic_score,
                    new_candidate.execution_success, new_candidate.z3_verdict,
                    new_candidate.error_type.value, n_holes,
                )

                # Track best
                if new_candidate.semantic_score > best_candidate.semantic_score:
                    best_candidate = new_candidate

                candidate = new_candidate

                if candidate.semantic_score >= ORACLE_PASS_THRESHOLD:
                    logger.info(
                        "[%s] SUCCESS at CEGIS iter %d — oracle=%.2f",
                        section_id, cegar_iter + 1, candidate.semantic_score,
                    )
                    break
            else:
                logger.warning(
                    "[%s] FAILED — all %d CEGIS iters exhausted (best=%.2f)",
                    section_id, self.max_cegar, best_candidate.semantic_score,
                )

        wall_time = time.time() - t0

        # Build and save metrics using best candidate
        metrics = self._build_metrics(
            section, filename_stem, best_candidate, wall_time,
            cegar_iters_done, cegar_iter_scores, n_holes_per_iter, error_type_seq,
        )
        self._section_logs.append(metrics)

        metrics_path = section_dir / "section_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as f:
            json.dump(metrics, f, indent=2)
        logger.info("[%s] Log saved → %s", section_id, metrics_path)

        if best_candidate.code_blocks:
            code_path = section_dir / "final_code.py"
            code_path.write_text(best_candidate.code_blocks[0], encoding="utf-8")
            logger.info("[%s] Final Z3 code saved → %s", section_id, code_path)

    # ── Aggregate ─────────────────────────────────────────────────────────────

    def save_aggregate_metrics(self) -> None:
        if not self._section_logs:
            return
        total     = len(self._section_logs)
        successes = sum(1 for m in self._section_logs if m["results"]["final_success"])
        agg = {
            "algorithm":  BASELINE_NAME,
            "tier":       self.tier,
            "act":        self.act_name,
            "run_id":     self.run_id,
            "model":      self.model_id,
            "sketch_mode": self.sketch_mode,
            "max_cegar":  self.max_cegar,
            "acts_processed": total,
            "successful":     successes,
            "failed":         total - successes,
            "success_rate":   round(successes / total, 4) if total else 0.0,
            "mean_wall_time_sec": round(
                sum(m["results"]["wall_time_sec"] for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "mean_cegar_iters": round(
                sum(m["attempt_counts"]["llm_c_cegar_iterations"] for m in self._section_logs) / total, 2
            ) if total else 0.0,
            "per_section": self._section_logs,
        }
        out = self.output_root / "aggregate_metrics.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(agg, f, indent=2)
        logger.info(
            "B5 aggregate metrics → %s  (success=%d/%d mean_cegar_iters=%.1f)",
            out, successes, total, agg["mean_cegar_iters"],
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _build_metrics(
        self,
        section: dict,
        filename_stem: str,
        candidate: Candidate,
        wall_time: float,
        cegar_iters_done: int,
        cegar_iter_scores: list[float],
        n_holes_per_iter: list[int],
        error_type_seq: list[str],
    ) -> dict:
        err_val   = candidate.error_type.value
        err_cnt   = Counter(error_type_seq)
        exec_ok   = float(candidate.execution_success)
        solver_ok = float(candidate.semantic_score >= 0.7)
        verdict_ok = float(candidate.z3_verdict in ("sat", "unsat"))
        proof_ok  = float(candidate.semantic_score >= 1.0)

        return {
            "algorithm":  BASELINE_NAME,
            "act_file":   filename_stem,
            "timestamp":  datetime.now(timezone.utc).isoformat(),
            "models":     {"primary": self.model_id},
            "hyperparameters": {
                "temperature":           DEFAULT_TEMPERATURE_GEN,
                "max_new_tokens":        MAX_NEW_TOKENS_GEN,
                "max_cegar":             self.max_cegar,
                "sketch_mode":           self.sketch_mode,
                "oracle_pass_threshold": ORACLE_PASS_THRESHOLD,
            },
            "results": {
                "final_success":               candidate.semantic_score >= ORACLE_PASS_THRESHOLD,
                "semantic_alignment_confirmed": round(candidate.semantic_score, 4),
                "final_error_type":            err_val,
                "wall_time_sec":               round(wall_time, 3),
            },
            "attempt_counts": {
                "llm_a_outer_attempts":      1,
                "llm_b_semantic_flags":      0,
                "llm_c_cegar_iterations":    cegar_iters_done,
                "beam_candidates_generated": 1 + cegar_iters_done,
            },
            "error_analysis": {
                "error_type_sequence": error_type_seq,
                "error_type_counts":   dict(err_cnt),
            },
            "oracle_components": {
                "exec":        exec_ok,
                "solver":      solver_ok,
                "verdict":     verdict_ok,
                "proof":       proof_ok,
                "final_score": round(candidate.semantic_score, 4),
                "mode":        "full",
            },
            "baseline_metadata": {
                "baseline":               BASELINE_NAME,
                "tier":                   self.tier,
                "sketch_mode":            self.sketch_mode,
                "fault_localization_mode": "taxonomy_guided",
                "cegar_iter_scores":      cegar_iter_scores,
                "n_holes_per_iter":       n_holes_per_iter,
                "paper_ref":              "Orvalho et al. AAAI 2025 (arXiv:2502.07786)",
            },
        }

    def _section_to_text(self, section: dict) -> str:
        """Extract plain text from a section dict."""
        if isinstance(section, str):
            return section
        parts = []
        for key in ("section_number", "title", "text", "content", "section_text"):
            if key in section and section[key]:
                parts.append(str(section[key]))
        return "\n".join(parts) if parts else str(section)

    def _extract_fallback_code(self, raw_response: str) -> str:
        """Last-resort code extraction from raw LLM response."""
        if not raw_response:
            return ""
        blocks = RefineSMT.extract_code(raw_response)
        return blocks[0] if blocks else raw_response[:2000]
