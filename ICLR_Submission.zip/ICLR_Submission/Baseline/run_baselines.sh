#!/usr/bin/env bash
# run_baselines.sh — Shell driver for REFINE-SMT Baseline comparison systems
#
# Usage:
#   ./run_baselines.sh [--baseline b1|b2|b3|b4|all] [--tier slm|llm]
#                      [--acts DPDP,GDPR] [--sections N] [--dry-run]
#   ./run_baselines.sh --dry-run --sections 1          # smoke test
#   ./run_baselines.sh --baseline b1 --tier slm        # single baseline
#   ./run_baselines.sh --baseline all --tier llm       # all four baselines, LLM tier
#   ./run_baselines.sh --baseline b4 --force-template-fallback  # B4 without outlines
#
# Logs are tee'd to Baseline_Output/logs/<timestamp>.log

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# ICLR supplementary: repointed to this bundle's own root (one level up from Baseline/), self-contained --
# matches baseline_config.py's own ROOT/BASELINE_OUTPUT resolution.
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
LOG_DIR="$ROOT/Baseline_Output/logs"
mkdir -p "$LOG_DIR"

TIMESTAMP=$(date -u +"%Y%m%dT%H%M%SZ")
LOG_FILE="$LOG_DIR/${TIMESTAMP}_baselines.log"

# ── Check / install psutil ────────────────────────────────────────────────────
if ! python3 -c "import psutil" 2>/dev/null; then
    echo -e "  ${YELLOW}psutil not found — installing...${NC}"
    python3 -m pip install -q psutil 2>/dev/null || true
fi

# ── Check / install bitsandbytes (required for 32B bfloat16) ─────────────────
if ! python3 -c "import bitsandbytes" 2>/dev/null; then
    echo -e "  ${YELLOW}bitsandbytes not found — installing...${NC}"
    python3 -m pip install -q bitsandbytes 2>/dev/null || true
fi

# ── Check / install tqdm ──────────────────────────────────────────────────────
if ! python3 -c "import tqdm" 2>/dev/null; then
    echo -e "  ${YELLOW}tqdm not found — installing...${NC}"
    python3 -m pip install -q tqdm 2>/dev/null || true
fi

# ── Environment: use local HF cache, no network calls ────────────────────────
# Models must already be downloaded via install_models_Hugging_face.sh or
# install_models_LLM.sh depending on tier
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_HUB_ENABLE_HF_TRANSFER=1

export PYTHONPATH="$SCRIPT_DIR:$SCRIPT_DIR/lib:${PYTHONPATH:-}"

# ── Forward all arguments to Python ──────────────────────────────────────────
EXTRA_ARGS=("$@")

# Determine tier and baseline for display (parse loosely — Python validates)
TIER="slm"
BASELINE="all"
for i in "${!EXTRA_ARGS[@]}"; do
    if [[ "${EXTRA_ARGS[$i]}" == "--tier"     ]]; then TIER="${EXTRA_ARGS[$((i+1))]}"; fi
    if [[ "${EXTRA_ARGS[$i]}" == "--baseline" ]]; then BASELINE="${EXTRA_ARGS[$((i+1))]}"; fi
done

echo -e "${CYAN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║    REFINE-SMT Baseline Comparison Runner             ║${NC}"
echo -e "${CYAN}║    B1: Zero-Shot  B2: CoT-SelfRefine                 ║${NC}"
echo -e "${CYAN}║    B3: NaiveRetry B4: Grammar-Constrained            ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Timestamp : ${YELLOW}${TIMESTAMP}${NC}"
echo -e "  Baseline  : ${YELLOW}${BASELINE}${NC}"
echo -e "  Tier      : ${YELLOW}${TIER}${NC}"
echo -e "  Log file  : ${YELLOW}${LOG_FILE}${NC}"
echo -e "  HF offline: ${YELLOW}${HF_HUB_OFFLINE}${NC}  (models must be pre-downloaded)"
echo ""

python3 "$SCRIPT_DIR/run_baselines.py" \
    "${EXTRA_ARGS[@]}" 2>&1 | tee "$LOG_FILE"

EXIT_CODE=${PIPESTATUS[0]}
if [ "$EXIT_CODE" -eq 0 ]; then
    echo -e "\n  ${GREEN}✓ Baselines complete.${NC}"
    echo -e "  Output : ${YELLOW}$ROOT/Baseline_Output/${TIER}/${NC}"
    echo ""
    echo -e "  Next step: evaluate results"
    echo -e "  ${CYAN}./evaluate_baselines.sh --tier ${TIER}${NC}"
else
    echo -e "\n  ${RED}✗ Baselines exited with code $EXIT_CODE. Check log: $LOG_FILE${NC}"
fi
exit "$EXIT_CODE"
