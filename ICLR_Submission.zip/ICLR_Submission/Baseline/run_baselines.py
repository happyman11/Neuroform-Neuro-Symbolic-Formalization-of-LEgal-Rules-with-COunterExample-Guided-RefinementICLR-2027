#!/usr/bin/env python3
"""
run_baselines.py — Unified CLI runner for all five REFINE-SMT baselines.

Usage:
    cd ICLR_Submission/Baseline

    # Run single baseline
    python run_baselines.py --baseline b1 --tier slm
    python run_baselines.py --baseline b2 --tier llm
    python run_baselines.py --baseline b3 --tier slm --max-retries 7
    python run_baselines.py --baseline b4 --tier slm --force-template-fallback
    python run_baselines.py --baseline b5 --tier slm --max-cegar 5 --sketch-mode hole
    python run_baselines.py --baseline b5 --tier slm --max-cegar 5 --sketch-mode fixme

    # Run all five baselines
    python run_baselines.py --baseline all --tier slm

    # Restrict acts / section count
    python run_baselines.py --baseline b1 --tier slm --acts GDPR,DPDP
    python run_baselines.py --baseline b1 --tier slm --sections 3  # smoke test

    # Dry-run (no LLM calls)
    python run_baselines.py --baseline all --tier slm --dry-run

Output structure:
    Baseline_Output/{tier}/{baseline_name}/{run_id}/{act}/
        section_metrics.json   (per section)
        final_code.py          (best Z3 code)
        aggregate_metrics.json (per act)
    Baseline_Output/{tier}/{baseline_name}/{run_id}/
        run_config.json
        run.log
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from tqdm import tqdm

# ── Path setup — baseline_config injects _BASELINE_DIR and lib/ into sys.path ─
_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))
sys.path.insert(0, str(_HERE / "lib"))

from baseline_config import (
    ACTS_INPUT, ACTS, IGNORE_FILES,
    TIER_MODELS, BASELINE_OUTPUT,
    ORACLE_PASS_THRESHOLD,
    DEFAULT_MAX_RETRIES, DEFAULT_MAX_REFINE_ITERS,
    baseline_run_dir, set_backend,
)

# Utility lives in lib/ — no cross-folder import needed
from utility import Utility

from b1_zeroshot            import ZeroShotBaseline
from b2_cot_selfrefine      import CoTSelfRefineBaseline
from b3_naive_retry         import NaiveRetryBaseline
from b4_grammar_constrained import GrammarConstrainedBaseline
from b5_cegis_sketch        import CEGISSketchBaseline

logger = logging.getLogger("run_baselines")

# Mapping baseline key → (class, name string)
_BASELINES = {
    "b1": (ZeroShotBaseline,          "b1_zeroshot"),
    "b2": (CoTSelfRefineBaseline,     "b2_cot_selfrefine"),
    "b3": (NaiveRetryBaseline,        "b3_naive_retry"),
    "b4": (GrammarConstrainedBaseline,"b4_grammar_constrained"),
    "b5": (CEGISSketchBaseline,       "b5_cegis_sketch"),
}


# ── Section loading (matches run_benchmark.py pattern exactly) ─────────────────

def _load_section(file_path: Path, utility: Utility) -> dict:
    try:
        with open(file_path, encoding="utf-8") as fh:
            full = json.load(fh)
    except Exception:
        full = {}
    section = utility.extract_json_robust(str(file_path)) or {}
    for key in ("label_metrics", "structured_annotation", "source"):
        if key in full and key not in section:
            section[key] = full[key]
    return section


# ── Logging setup ──────────────────────────────────────────────────────────────

def _setup_logging(run_dir: Path) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    logging.basicConfig(level=logging.INFO, format=fmt)
    fh = logging.FileHandler(run_dir / "run.log", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(fmt))
    logging.getLogger().addHandler(fh)


# ── run_config.json ───────────────────────────────────────────────────────────

def _write_run_config(
    run_id: str,
    run_dir: Path,
    tier: str,
    baseline_keys: list[str],
    acts: list[str],
    model_id: str,
    args: argparse.Namespace,
) -> None:
    try:
        import transformers
        tf_ver = transformers.__version__
    except ImportError:
        tf_ver = "N/A"

    cfg = {
        "run_id":         run_id,
        "baselines":      baseline_keys,
        "tier":           tier,
        "model_id":       model_id,
        "timestamp":      datetime.now(timezone.utc).isoformat(),
        "acts":           acts,
        "hyperparameters": {
            "max_retries":           args.max_retries,
            "max_refine_iters":      args.max_refine_iters,
            "oracle_pass_threshold": ORACLE_PASS_THRESHOLD,
            "seed":                  args.seed,
        },
        "hardware":             platform.node(),
        "python_version":       platform.python_version(),
        "transformers_version": tf_ver,
    }
    run_dir.mkdir(parents=True, exist_ok=True)
    with open(run_dir / "run_config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    logger.info("run_config.json → %s", run_dir / "run_config.json")


# ── Per-baseline runner ────────────────────────────────────────────────────────

def _run_baseline(
    BaselineClass,
    baseline_name: str,
    tier: str,
    model_id: str,
    acts: list[str],
    run_id: str,
    utility: Utility,
    section_limit: int | None,
    dry_run: bool,
    extra_kwargs: dict,
) -> None:
    for act in acts:
        act_input = ACTS_INPUT.get(act)
        if not act_input or not act_input.exists():
            logger.error("Act input not found: %s → %s", act, act_input)
            continue

        act_output = baseline_run_dir(tier, baseline_name, run_id, act)
        act_output.mkdir(parents=True, exist_ok=True)

        files = sorted(
            f for f in os.listdir(act_input)
            if f.endswith(".json") and f not in IGNORE_FILES
        )
        if section_limit:
            files = files[:section_limit]

        logger.info(
            "=== %s | %s | %s | %d sections ===",
            baseline_name, tier, act, len(files),
        )

        runner = BaselineClass(
            model_id=model_id,
            tier=tier,
            output_root=act_output,
            act_name=act,
            run_id=run_id,
            **extra_kwargs,
        )

        with tqdm(total=len(files), desc=f"{baseline_name}/{act}") as pbar:
            for filename in files:
                pbar.set_postfix_str(filename)
                if dry_run:
                    logger.info("[DRY-RUN] %s/%s/%s", baseline_name, act, filename)
                    pbar.update(1)
                    continue
                try:
                    section = _load_section(act_input / filename, utility)
                    runner.process_section(section, filename.replace(".json", ""))
                except Exception:
                    logger.exception("Failed: %s/%s", act, filename)
                pbar.update(1)

        if not dry_run:
            runner.save_aggregate_metrics()

            # Copy aggregate up to run_id level for easy access
            agg_src = act_output / "aggregate_metrics.json"
            run_top = BASELINE_OUTPUT / tier / baseline_name / run_id
            if agg_src.exists():
                shutil.copy(agg_src, run_top / f"{act}_aggregate_metrics.json")


# ── CLI ────────────────────────────────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(description="REFINE-SMT Baseline Runner")
    p.add_argument(
        "--baseline", default="b1",
        choices=["b1", "b2", "b3", "b4", "b5", "all"],
        help="Which baseline(s) to run",
    )
    p.add_argument(
        "--tier", default="slm", choices=["slm", "llm"],
        help="Model tier — slm (7B) or llm (32B)",
    )
    p.add_argument(
        "--backend", default="huggingface", choices=["huggingface", "ollama"],
        help="ICLR supplementary: model-serving backend, equally supported either way (default: "
             "huggingface, byte-identical to prior behavior). 'ollama' routes every baseline's model calls "
             "through a local Ollama daemon instead -- see install/model_registry.yaml for model ids.",
    )
    p.add_argument(
        "--acts", default=None,
        help="Comma-separated acts, e.g. DPDP,GDPR  (default: all)",
    )
    p.add_argument("--sections", type=int, default=None,
                   help="Limit sections per act (smoke test)")
    p.add_argument("--dry-run", action="store_true",
                   help="List what would run without calling LLMs")
    p.add_argument(
        "--seed", type=int, default=None,
        help="scripts/additional_runs/ seed-robustness study: base seed threaded "
             "to per-call torch.manual_seed() (derived_seed = seed + running call "
             "counter) for B2 (CoT-SelfRefine) and B3 (Naive-Retry) only -- the two "
             "baselines with seed support. Ignored by B1/B4/B5. Omit for prior "
             "unseeded/non-deterministic behavior.",
    )
    # B2-specific
    p.add_argument("--max-refine-iters", type=int, default=DEFAULT_MAX_REFINE_ITERS,
                   help="B2: max self-refine iterations (default %(default)s)")
    # B3-specific
    p.add_argument("--max-retries", type=int, default=DEFAULT_MAX_RETRIES,
                   help="B3: max retry attempts (default %(default)s)")
    # B4-specific
    p.add_argument("--force-template-fallback", action="store_true",
                   help="B4: skip outlines even if installed (saves VRAM on small machines)")
    # B5-specific
    p.add_argument("--max-cegar", type=int, default=5,
                   help="B5: max CEGIS iterations (default %(default)s)")
    p.add_argument("--sketch-mode", default="hole", choices=["hole", "fixme"],
                   help="B5: sketch style — hole replaces lines, fixme annotates them")
    args = p.parse_args()

    set_backend(args.backend)
    acts = args.acts.split(",") if args.acts else ACTS
    model_id = (TIER_MODELS[args.tier]["ollama_id"] if args.backend == "ollama"
                else TIER_MODELS[args.tier]["model_id"])

    baseline_keys = list(_BASELINES.keys()) if args.baseline == "all" else [args.baseline]

    ts     = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_id = f"Baseline-{args.tier.upper()}-{args.baseline.upper()}-{ts}"

    # Log at the top-level run directory (shared across baselines in this run)
    run_top = BASELINE_OUTPUT / args.tier / "run_logs" / run_id
    _setup_logging(run_top)

    logger.info("Run ID    : %s", run_id)
    logger.info("Tier      : %s  backend=%s  model=%s", args.tier, args.backend, model_id)
    logger.info("Baselines : %s", baseline_keys)
    logger.info("Acts      : %s", acts)
    logger.info("Sections  : %s", args.sections or "all")

    _write_run_config(run_id, run_top, args.tier, baseline_keys, acts, model_id, args)

    utility = Utility()

    for key in baseline_keys:
        BaselineClass, baseline_name = _BASELINES[key]

        extra: dict = {}
        if key == "b2":
            extra["max_refine_iters"] = args.max_refine_iters
            if args.seed is not None:
                extra["seed"] = args.seed
        elif key == "b3":
            extra["max_retries"] = args.max_retries
            if args.seed is not None:
                extra["seed"] = args.seed
        elif key == "b4":
            extra["force_fallback"] = args.force_template_fallback
        elif key == "b5":
            extra["max_cegar"]   = args.max_cegar
            extra["sketch_mode"] = args.sketch_mode

        logger.info("─── Starting baseline %s (%s) ───", key.upper(), baseline_name)
        _run_baseline(
            BaselineClass=BaselineClass,
            baseline_name=baseline_name,
            tier=args.tier,
            model_id=model_id,
            acts=acts,
            run_id=run_id,
            utility=utility,
            section_limit=args.sections,
            dry_run=args.dry_run,
            extra_kwargs=extra,
        )

    logger.info("All baselines complete. Output: %s", BASELINE_OUTPUT / args.tier)


if __name__ == "__main__":
    main()
