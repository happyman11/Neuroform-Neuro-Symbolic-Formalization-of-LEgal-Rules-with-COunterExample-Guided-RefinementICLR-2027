# Paper <-> code correspondence

This document maps the paper's formal algorithm (Section 3, 4.2, Algorithm 1, Algorithm 3, Appendix B) to the
code in `Pipeline/{SLM,LLM}/lib/`, states every divergence a code audit found between the paper's formalization
and the pipeline that had previously been used to produce results, and explains how `algorithm_mode="paper_exact"`
closes each one. Findings are stated plainly, including ones that are unflattering or unresolved, rather than
silently patched or omitted.

## 1. How to read this document

`algorithm_mode="paper_exact"` is this pipeline's **only** algorithm -- a faithful reimplementation of the
paper's own Algorithm 1 / Algorithm 3 / Eq 1-52 formalization (real per-candidate `h_rep`, `sigma_impl` per Eq
17, the corrected `Gap_i`/`Cov(F_phi)`/`Over_i` diagnostic classifier with the right precedence, `phi_best`-
tracking repair, `g_sem` re-checked fresh after every repair). `RefineSMT.__init__` (`lib/
SMT_Generation_AAAI_Final.py`, both tiers) rejects any other value, including the prior `"legacy"` mode, with a
`ValueError` -- there is no selectable alternative. Every `Pipeline/{SLM,LLM}/benchmarking/config*.yaml` in this
bundle sets `algorithm_mode: paper_exact` explicitly (redundant with the constructor default, kept for clarity).

**What "legacy" was, for context**: earlier in this bundle's development, the codebase supported an
`algorithm_mode="legacy"` alternative -- byte-for-byte the pipeline that had previously produced experimental
numbers under the paper's earlier (non-`paper_exact`) implementation, kept only for a transitional reproducibility
guarantee. That option has since been removed at the user's explicit request: `paper_exact` is now the pipeline's
one and only algorithm, in every config, every benchmarking run, and every ablation. The legacy method bodies this
superseded (`_cegar_loop`, `classify_error`, `detect_e4_vacuous`, `SemanticOracle.score`, the base
`_semantic_alignment_check`) are left in the codebase, renamed to `_unused_legacy_generate_and_execute` where they
were the `generate_and_execute` entry point itself, **only** because a handful of ablation-variant override
methods (M2/M3/M4, see §9 below) still reference them -- no entry point reaches them anymore, and they should be
treated as dead code, not as a supported alternative.

**Consequence for ablations, stated plainly (see §9):** because `generate_and_execute` now unconditionally runs
`paper_exact`, the M2 (oracle-scoring variant), M3 (LLM-B format variant), and M4 (repair-feedback-mode variant)
ablation knobs no longer have any effect -- `paper_exact`'s own scoring/alignment/repair machinery does not
consult `self._oracle_mode` / `self._llm_b_format` / `self._feedback_mode` at all. M1 (beam width), M5 (CEGAR
budget), A1-A3 (model swaps), and V6 (model family) are unaffected, since `paper_exact` already respects
`beam_width` and `max_cegar_iterations` and uses whatever models are configured.

**Important, stated plainly:** producing `algorithm_mode="paper_exact"` results for the four acts requires a
full re-run (this bundle implements and locally verifies the algorithm offline, with a stub LLM and real Z3 --
see `test_paper_exact.py` -- it does not fabricate new headline numbers). Any already-reported numbers from
before this bundle's algorithm work are not claimed to be what `paper_exact` produces.

## 2. Equation / algorithm correspondence

| Paper | Code (`algorithm_mode="paper_exact"`) |
|---|---|
| Eq 1, `Gamma(x)` total Boolean valuation | `paper_harness.ScenarioEntry.assignment` (a `var -> bool` dict passed whole to `verify_data`) |
| Eq 3, `h_rep(s)`, repair-time scenario battery | `paper_harness.build_hrep()` |
| Eq 10, `h_eval(s)`, held-out scenario battery | `paper_harness.build_heval()` |
| Eq 11, `X_rep ∩ X_eval = ∅` | `paper_harness.harness_disjoint_fraction()` -- see caveat in §4.2 below |
| Eq 4, `A_beh(phi, h)` | `paper_harness.HarnessResult.a_beh` |
| Eq 17, `sigma_impl = 0.5 e_init + 0.2 e_solver + 0.2 e_verdict + 0.1 e_diag` | `paper_diagnostics.evaluate_candidate_paper_exact()` -> `PaperExactEvaluation.sigma_impl` |
| Eq 8, `Accept(phi)` (`sigma_impl >= theta_impl and A_beh=1 and D=E0`) | the accept condition tested in `_generate_and_execute_paper_exact` and at the end of `_diagnostic_repair_paper_exact` |
| Eq 21, `g_sem` total binary semantic-alignment parser | `_semantic_alignment_check_paper_exact()` -- returns exactly 1.0 or 0.0, never mutates the candidate |
| Eq 49/50, `Gap_i`, `R_i(s, a_hat)`, `Cov(F_phi)` | `paper_diagnostics.has_gap()`, `required_predicates()`, `_coverage_hit()` |
| Eq 51 / Appendix B.6, `Over_i` | `paper_diagnostics.over_constrained()` (real constraint-removal re-solve over `Fphi`'s top-level AST conjuncts) |
| Eq 52, `I_E3 = M(phi) \ (I_E4 ∪ I_E5)` | the E3 branch of `paper_diagnostics.classify_paper_exact()` -- the definitive-mismatch leftover once `Gap_i`/`Over_i` are computed |
| Diagnostic classes `Dcls={E0,E1,E2,E3,E4,E4v,E5}`, precedence `E1≻E2≻E4≻E5≻E3≻E4v≻E0` | `classify_paper_exact()`'s fixed-order checks (E1/E4v handled by the caller, see §3.3) |
| Eq 54, self-contained counterexample `(x_i*, y_i*, y_hat_i*, d_phi)` | the counterexample text built in `_diagnostic_repair_paper_exact()` from `ev.hrep.entries[i_star]` / `ev.result.verdicts[i_star]` |
| Algorithm 1 (candidate ranking, single repair target, `g_sem` gate) | `_generate_and_execute_paper_exact()` |
| Algorithm 3 / Appendix B.6.1 (`DIAGNOSTICREPAIR`, `phi_best`/`S_best` tracking) | `_diagnostic_repair_paper_exact()` |

## 3. Divergences found in the legacy pipeline, and how `paper_exact` fixes them

All line numbers below are from the pre-bundle state of `scripts/LLM/lib/SMT_Generation_AAAI_Final.py` (the LLM
tier; the SLM tier's file was byte-identical except cosmetic differences, e.g. `Optional[Candidate]` vs
`Candidate | None`, `section_id =  section.get(...)` double-space).

### 3.1 `sigma_impl` (Eq 17) never actually computed `h_rep`

**Legacy** (`SemanticOracle.score`, was lines 300-358): a single execution of the whole candidate script,
substring-matching captured stdout for `"sat"`/`"unsat"`/`"model"`/`"proof"`. The 0.5/0.2/0.2/0.1 coefficients
match the paper's Eq 17 numerically, but every term's *meaning* diverges -- there is no `h_rep`, no
ground-truth comparison anywhere in this function; `e_verdict` is really "did the printed output contain the
word sat/unsat," not `A_beh(phi, h_rep)`.

**paper_exact**: `paper_diagnostics.evaluate_candidate_paper_exact()` builds a real `h_rep` via
`paper_harness.build_hrep()`, runs all 6 scenarios through the candidate's own `verify_data()`, and computes
`e_verdict = A_beh(phi, h_rep)` (Eq 4) exactly. `e_init`/`e_solver`/`e_diag` are similarly grounded in the real
harness run, not stdout string matching.

### 3.2 `classify_error`'s precedence, and E3/E5 being effectively dead

**Legacy** (`classify_error`, was lines 87-120): keyword/substring classifier with precedence
`E1≻E2≻E3≻E5≻E4≻(fallback E2)≻E0` -- the paper wants `E1≻E2≻E4≻E5≻E3≻E4v≻E0`. The `"expected sat"`/`"expected
unsat"` substrings that would trigger E3 are never produced anywhere in the codebase (E3 was dead code, 0
occurrences possible). E5 was a bare `"unsat" in msg` guess with no constraint-removal re-solve (`Unsupported`
/ `F_{phi\r}` grep-confirmed absent from the entire codebase). E4 triggered off LLM-B's free-text `"gaps"`
array, not a `Gap_i`/`Cov(F_phi)` computation. A genuine `z3.unknown` verdict was never classified at all and
silently fell through to E0.

**paper_exact**: `paper_diagnostics.classify_paper_exact()` implements the real precedence as an explicit
ordered check over index sets computed once (`Gap_i` via `has_gap()`, `Over_i` via `over_constrained()`,
`I_E3` as the definitive-mismatch leftover). Verified on 443 real `IO_Examples/*/*/*/05_final_code.py`
candidates paired with real annotations: diagnostic histogram `{E4: 214, E0: 152, E3: 59, E5: 13, E1: 5}` --
E3 and E5 are now genuinely reachable (previously E3 was literally unreachable code; E5 was reachable only by
coincidental substring match, never a real `Unsupported` computation). `unknown`/`error` verdicts now populate
`I_E2`.

### 3.3 `_cegar_loop` had no `phi_best` tracking, and no E0/E1 short-circuit

**Legacy** (`_cegar_loop`, was lines 704-823): tracked only `current` (the most recent attempt), not
`(phi_best, S_best)` -- on budget exhaustion it returned the *last* candidate tried, even if an earlier
iteration had scored strictly higher. No E0-immediate-return guard. No E1-abort-preserve-incumbent rule (an E1
on a *repaired* candidate just continued the loop instead of returning the untouched incumbent).

**paper_exact**: `_diagnostic_repair_paper_exact()` tracks `(phi_best, S_best)` explicitly, initialized from
the entry candidate; `D=E0` returns immediately; `D=E1` returns `phi_best` immediately, never overwritten;
after each repair, `S' > S_best` (**strict** inequality -- ties preserve the earlier incumbent) is the only
condition that updates the incumbent; on budget exhaustion, `phi_best` (not the last attempt) is returned.
Verified by scripted control-flow unit tests (`test_paper_exact.py` T5a-T5d) exercising exactly these four
rules independent of real Z3/LLM behavior: a worse-then-tied-then-worse-again repair trajectory correctly
preserves the original (higher-scoring) entry candidate rather than drifting to the last, lower-scoring attempt
-- the exact bug class this rewrite fixes.

### 3.4 The actual runtime cascade tried every above-threshold candidate, not one repair target

**Legacy**: the base class's `_cegar_loop` (§3.3) was not even what ran in practice -- `generate_and_execute` is
overridden per tier (`llm_pipeline.py:494-720` for the LLM tier, `slm_pipeline.py`'s analogous override) with a
cascade that tries *every* ranked candidate above the oracle threshold in turn, each independently, rather than
Algorithm 1's single repair target per outer iteration. It also reused `repaired.semantic_score` as the
post-repair alignment proxy (`llm_pipeline.py:639-648`) instead of re-invoking `g_sem`.

**paper_exact**: `_generate_and_execute_paper_exact()` scans candidates sorted by `sigma_impl` descending
(stable sort), skipping `E1`; the first `E0`-and-above-threshold candidate is checked against `g_sem` and
returned if aligned, otherwise the scan continues to the *next* candidate (a semantic rejection, not a
counterexample -- matches Section 4.2.4: "does not itself generate a diagnostic counterexample"); the first
*remaining* candidate with `A_beh<1 or D!=E0` becomes the **sole** repair target for that outer iteration. After
`DIAGNOSTICREPAIR` returns, `g_sem` is re-invoked **fresh** on the repaired candidate -- its own oracle score is
never substituted as an alignment proxy.

### 3.5 E4v had no source-interface scoping or `Imp(F_phi)≠∅` precondition

**Legacy** (`detect_e4_vacuous`, was lines 143-166): probed *every* non-underscore instance attribute (no `P_s`
scoping) and had no precondition gating the all-False probe on the formula actually containing an `Implies`
node.

**paper_exact**: `paper_diagnostics.detect_e4v_paper_exact()` adds the `Imp(F_phi)≠∅` precondition via a direct
Z3 AST walk (`.decl().kind() == z3.Z3_OP_IMPLIES`) before running the probe. `P_s` is operationalized as every
`z3.Bool` attribute the candidate declares -- disclosed, not silently assumed: this codebase has no formal
auxiliary-vs-interface distinction, and the paper's own auxiliary definition ("constrained by an acyclic
defining equivalence") has no detector built for it here, which would require new semantic-parsing machinery
out of scope for this bundle. This is behavior-identical to the legacy detector for the common case of no true
auxiliary variables, and correctly narrower in the rare case one exists.

### 3.6 `g_sem` silently mutated the candidate on rejection

**Legacy** (`_semantic_alignment_check` and tier overrides): on `aligned:false`, the code substituted
`candidate.code_blocks` from the model's own `"revised_code"` JSON field -- the paper's `g_sem` (Eq 21) is a
pure, total, binary accept/reject parser over an already-fixed candidate, never a code mutator.

**paper_exact**: `_semantic_alignment_check_paper_exact()` never applies `revised_code`; it returns
`(aligned: bool, gap_desc: str, align_score: 1.0|0.0)` and nothing else. `revised_code`/`gaps` remain available
as repair-prompt *context* for `DIAGNOSTICREPAIR`, just never silently applied by the gate itself.

## 4. Disclosed operational choices and caveats (not bugs -- properties of this port, stated plainly)

### 4.1 `P_s` is candidate-relative, not provision-fixed

The paper's `Q_phi ∩ P_s` framing is itself candidate-relative; this codebase has no provision-fixed interface
to read instead. `paper_harness.get_bool_vars()` operationalizes `P_s` as every `z3.Bool` attribute the
*current* candidate under test declares -- this matches what the pre-existing post-hoc S1-S6 evaluator
(`HPC_ForAbstract/hpc_multiscenario_eval_s6b.py`) already assumed; `paper_harness.py` ports that evaluator's
`classify_vars`/binding-obligation-variable logic rather than reinventing it (credited in `paper_harness.py`'s
own module docstring).

### 4.2 `h_rep`/`h_eval` disjointness (Eq 11) cannot hold for S1/S2 by construction

Under Eq 1, Compliance (all interface props True) and Violation (all False) are each a **singleton** assignment
-- there is exactly one way to construct them for a given variable set. `h_rep`'s and `h_eval`'s S1/S2 are
therefore necessarily the *same concrete instance*; `X_rep ∩ X_eval = ∅` cannot hold for those two categories
under any construction, and no alternative "all-true"/"all-false" assignment is defined by Eq 1 to make them
differ. This is a property of the paper's own formalization for these two categories, not a gap in this port.
For the remaining four categories (Exception/Boundary/Multi-Exception/Compound-Boundary),
`paper_harness.build_heval()` deliberately picks a different concrete witness than `build_hrep()` whenever the
candidate's own variable set gives it room to (documented per-category in `_build()`'s inline comments);
`harness_disjoint_fraction()` reports the true fraction achieved rather than assuming 1.0. Measured across 443
real candidates: histogram `{0.0: 168, 0.17: 69, 0.33: 169, 0.5: 3, 0.67: 31}`.

### 4.3 E4v is mathematically unreachable through the full precedence chain whenever `h_rep` includes S2

This is a **new finding from this bundle's own testing**, not previously documented. `detect_e4v_paper_exact()`
works correctly in isolation (confirmed by a standalone unit test: `Implies(obligation_var, consequence_var)`
alone correctly flags as vacuous when probed directly). But inside the full
`evaluate_candidate_paper_exact()` precedence chain, E4v can never actually be the *returned* diagnostic
whenever `h_rep` includes the standard S2/Violation scenario with the same interface-variable set: S2's own
probe assignment (all interface vars False, expecting `unsat`) is **identical** to E4v's own probe (all
interface vars False, checking for `sat`) -- and per the paper's own Eq 7, E4v is only tested after *all*
scenarios (including S2) have already passed, which requires S2's own probe to be `unsat`, directly
contradicting E4v's `sat`-firing condition for that same assignment. In practice this means any candidate whose
formula is vacuous in the E4v sense gets classified as an S2 mismatch (E2/E3/E4/E5, whichever the top-level
conjunct structure dictates) before E4v is ever reached -- E4v effectively collapses into "S2 in disguise."
This mirrors an earlier, independent finding already on record for this project (the repair study's own
observation that "E4v detection = S2 in disguise"), now confirmed structurally rather than empirically. This is
stated here rather than silently patched (e.g. by special-casing E4v ahead of S2 in the precedence order, which
the paper does not specify and which would be an undisclosed deviation).

### 4.4 `Over_i`'s constraint-removal re-solve is a bounded, disclosed approximation

`over_constrained()` walks `F_phi`'s top-level Z3 AST (`.decl()`/`.children()` on the `BoolRef`, `And` nodes
only) and tests removing each top-level conjunct + re-solving. This is an operational approximation of
"candidate constraints" (top-level conjuncts only, not a full clause-level decomposition of nested Boolean
structure) -- documented as such in `paper_diagnostics.py`'s own docstring, not claimed to be a complete
constraint-lattice search.

## 5. Two small, disclosed fixes requested alongside the algorithm work

### 5.1 Z3 version claim

The paper states "Z3 version 5.1.0." This is not a real `z3-solver` PyPI release (the `z3-solver` package's own
versioning tracks the upstream Z3 project, currently in the 4.x series; there is no 5.1.0). `requirements.txt`
pins `z3-solver>=4.12.0`; this bundle's own dev environment resolves `4.15.4` at the time of writing. **This is
a paper-text correction, not a code fix** -- no `.tex` source for the paper was found in this repository (only
the already-typeset PDF and pasted text were available), so it could not be edited directly here; the paper's
own manuscript (wherever it is maintained, e.g. Overleaf) should have "Z3 version 5.1.0" corrected to the actual
pinned/resolved `z3-solver` version.

### 5.2 theta_impl 0.7 vs 0.8

The `RefineSMT` class's own constructor default and the plain `config.yaml` both set `oracle_threshold: 0.7`.
The actually-reported "headline" experimental numbers were produced from a separately-forked
`config_threshold_08.yaml` (`oracle_threshold: 0.8`) -- confirmed via `Benchmark_S1_S6`'s own manifest citing
the theta08 run as the headline source. `H=6` (scenario battery size) is not itself a tracked/configurable
hyperparameter anywhere in the code -- it is simply the fixed length of the 6-category scenario list
(`paper_harness.CATEGORIES`). This bundle's `config_paper_exact_{hf,ollama}.yaml` unify `theta_impl` at `0.80`
(the paper's own reported operating point) for the `paper_exact` mode, collapsing this split going forward; the
legacy `0.7`/`0.8` config pair remains untouched and exactly reproducible for the already-reported numbers.

## 6. Explicitly out of scope

The `#permission -> Or(phi_1, ..., phi_m)` composition rule (Table 1) is **not** added to the generation prompt
(`Pipeline/{SLM,LLM}/lib/promting.py`). Doing so would change LLM-A's own generation behavior (what candidates
get proposed in the first place), not just the verification/repair machinery this bundle otherwise reimplements
faithfully -- explicitly declined when this scope was confirmed, since it was not requested and would further
diverge already-reported numbers in a way not asked for.

## 7. Ablation code-name mapping

The paper's ablation names and this repo's ablation script names refer to the same axes, under different
labels -- listed once here rather than silently renamed in the code:

| Paper name | Code name | Notes |
|---|---|---|
| M1: candidate-list size | `M1_beam_width` | direct match |
| M2: semantic-alignment interface | `M3_llm_b_variant` | direct match, different index number |
| M3: repair-feedback mode | `M4_feedback_mode` | direct match, different index number |
| M4: repair budget | `M5_cegar_budget` | direct match, different index number |
| A1/A2/A3: generator/aligner/repair-model architecture | `run_ablation_A1/A2/A3.py` | direct match |
| -- (not in the paper's main table) | `M2_oracle_variant` | oracle-scoring-mode ablation, additional to the paper |
| -- (not in the paper's main table) | `V6_model_family` | cross-model-family ablation, additional to the paper |

## 8. Model backend: HuggingFace and Ollama, both first-class

`lib/models.py::ModelCall.ollama_call_model` was upgraded to accept `temperature`, `max_new_tokens`,
`system_message`, `seed` -- the same parameter shape as `HuggingFaceModel.call()` -- adapted from the
already-proven `SLM-Optimisation/ollama_backend/ollama_model.py` pattern (`options={"temperature",
"num_predict", "seed"}`, `ollama.pull()`-based lazy install). Both tier pipelines' `_call_llm` now resolve
per-role temperature/max-tokens/system-message/seed identically for `owner="Ollama"` as for
`owner="HuggingFace"` (`_resolve_temperature`/`_resolve_max_tokens`/`_resolve_system_message`/`_next_seed`,
shared helpers both branches call). Baselines (`Baseline/run_baselines.py`,
`Baseline/new_baseline/run_new_baselines.py`) gained a `--backend huggingface|ollama` flag; rather than editing
all 9 baseline files' `self.HFModel = get_hf_model(tier)` call sites, `baseline_config.get_hf_model()` was made
backend-aware via a module-level flag set once by `set_backend()` before any baseline is constructed --
`get_ollama_model()` is also exposed directly for explicit use. Verified offline (mocked `ollama.chat`/`list`/
`pull`, no real daemon): `test_ollama_backend.py` (both tiers) confirms per-role temperature/max-tokens/
seed/system-message parity between the two backends, and that a not-yet-local model triggers exactly one
`ollama.pull()`. `lib/step_trace.py`'s opt-in per-section trace log (`detailed_logging: true`) had its
`hf = owner == "HuggingFace"` gate widened to `resolvable = owner in ("HuggingFace", "Ollama")` -- previously an
Ollama call's temperature/max-tokens/seed/system-message were silently logged as `None` even though
`ollama_call_model` now genuinely resolves and uses all four; both backends share the same resolver methods, so
both are equally loggable.

### 8.1 A pre-existing finding surfaced while building this test (not fixed -- inherited by both backends identically)

`_resolve_system_message(model)` (both the pre-existing legacy logic this was factored out of, and the new
helper) checks `model == self.corrector_model` **before** `model == self.model`. Every real config in this repo
uses the *same* model string for both LLM-A (`self.model`) and LLM-C (`self.corrector_model`) -- e.g.
`Qwen/Qwen2.5-Coder-32B-Instruct` for both roles in `config.yaml`/`config_threshold_08.yaml`/
`config_paper_exact_hf.yaml`. Because the two model strings are identical, this check has always attributed
LLM-C's ("produce corrected or completed Z3 Python code") system message to LLM-A's own beam-generation calls
too, in every real run to date, both `legacy` and now `paper_exact`, both backends. This is a **pre-existing
property of the legacy code**, unchanged by this bundle (the Ollama branch was built to match the existing
HuggingFace behavior exactly, bugs included, not to silently fix an unrelated latent issue outside this bundle's
requested scope) -- surfaced here for the record, not patched.

## 9. `algorithm_mode="legacy"` removed -- which ablation axes remain live

Per §1, `algorithm_mode` now accepts only `"paper_exact"`; the entry point (`generate_and_execute`, both the base
class and the `{llm,slm}_pipeline.py` tier overrides) unconditionally delegates to
`_generate_and_execute_paper_exact`. Ablation scripts construct `LLMRefineSMT`/`SLMRefineSMT` without ever
passing `algorithm_mode`, so they now go through this same entry point too -- with the following consequences
per ablation axis:

| Ablation | Mechanism | Status under `paper_exact` |
|---|---|---|
| M1 (`M1_beam_width`) | sets `beam_width`, consumed by `_generate_beam` | **live** -- `_generate_and_execute_paper_exact` calls `_generate_beam` the same way |
| M5 (`M5_cegar_budget`) | sets `max_cegar_iterations`, consumed by the repair loop's `range()` | **live** -- `_diagnostic_repair_paper_exact` uses `self.max_cegar_iterations` the same way |
| A1/A2/A3 | swaps which model plays LLM-A/B/C | **live** -- model identity is orthogonal to which algorithm runs |
| V6 (`V6_model_family`) | swaps the model family across all three roles | **live** -- same reason as A1-A3 |
| M2 (`M2_oracle_variant`) | overrides `_compute_oracle_score`, called from the legacy `SemanticOracle`/`_cegar_loop` path | **inert** -- `_generate_and_execute_paper_exact` scores candidates via `paper_diagnostics.evaluate_candidate_paper_exact()` directly; `_compute_oracle_score` is never called |
| M3 (`M3_llm_b_variant`) | overrides `_semantic_alignment_check`, the legacy `g_sem` gate | **inert** -- `paper_exact` always uses `_semantic_alignment_check_paper_exact` |
| M4 (`M4_feedback_mode`) | branches inside the legacy `_cegar_loop`'s counterexample construction | **inert** -- `paper_exact` builds its own Eq-54 counterexample in `_diagnostic_repair_paper_exact`, which does not consult `self._feedback_mode` |

Re-running M2/M3/M4 as configured today will produce ablation variants that are **behaviorally identical to each
other and to the unablated run** -- their knobs no longer reach any code path. Making them meaningful again under
`paper_exact` (e.g. giving `paper_exact` its own oracle-scoring variants, `g_sem`-format variants, and repair-
feedback-mode variants) is a real, separate design task, not attempted here since it was not part of what was
asked -- flagged plainly rather than left for a re-run to silently discover.
