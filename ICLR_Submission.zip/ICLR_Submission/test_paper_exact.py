#!/usr/bin/env python3
"""
test_paper_exact.py -- top-level entry point. Runs every offline (no GPU, no model, no network) test in this
bundle, tier by tier: Pipeline/{SLM,LLM}/test_paper_exact.py (algorithm_mode="paper_exact" Algorithm 1/3
correctness, including a check that "legacy" is rejected as a no-longer-supported option) and
Pipeline/{SLM,LLM}/test_ollama_backend.py (Ollama backend parameter parity). See PAPER_CODE_CORRESPONDENCE.md
for what each test verifies and why.

    python3 test_paper_exact.py
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

SUITES = [
    ("LLM tier: algorithm_mode=paper_exact correctness", HERE / "Pipeline/LLM/test_paper_exact.py"),
    ("LLM tier: Ollama backend parity", HERE / "Pipeline/LLM/test_ollama_backend.py"),
    ("SLM tier: algorithm_mode=paper_exact correctness", HERE / "Pipeline/SLM/test_paper_exact.py"),
    ("SLM tier: Ollama backend parity", HERE / "Pipeline/SLM/test_ollama_backend.py"),
    ("Deterministic no-LLM compiler", HERE / "Deterministic_NoLLM_Baseline/test_deterministic_compiler.py"),
]

results = []
for label, path in SUITES:
    print(f"\n{'=' * 70}\n{label}  ({path.relative_to(HERE)})\n{'=' * 70}")
    if not path.exists():
        print(f"MISSING: {path}")
        results.append((label, False))
        continue
    proc = subprocess.run([sys.executable, str(path)], cwd=str(path.parent))
    results.append((label, proc.returncode == 0))

print(f"\n{'=' * 70}\nSummary\n{'=' * 70}")
all_ok = True
for label, ok in results:
    print(f"  {'PASS' if ok else 'FAIL'}  {label}")
    all_ok = all_ok and ok

print()
print("ALL SUITES PASSED" if all_ok else "SOME SUITES FAILED")
raise SystemExit(0 if all_ok else 1)
