# NeuroFORM / REFINE-SMT -- ICLR supplementary code

Neuro-symbolic legal-rule formalization: an LLM/SLM beam generator, a semantic-alignment gate (g_sem), and a
counterexample-guided (CEGAR) repair loop synthesize Z3 formalizations of privacy-law provisions, evaluated on a
6-scenario behavioral battery (S1-S6). This bundle packages the dataset, the pipeline (both a faithful
reimplementation of the paper's formal algorithm and the exact pipeline that produced the paper's reported
numbers), every baseline (B1-B9), every ablation, the S1-S6 evaluator, and a from-scratch deterministic (no-LLM)
compiler used as a reviewer-requested feasibility check -- self-contained, no dependency on anything outside this
folder.

**Read `PAPER_CODE_CORRESPONDENCE.md` first.** It maps every equation/algorithm in the paper to the code below,
states every divergence a code audit found between the paper's formalization and the pipeline that actually
produced the reported numbers, and discloses every operational choice and finding from building this bundle
(including one genuinely new structural finding about E4v detection, and a pre-existing system-message-routing
property inherited unchanged by the new Ollama backend). Nothing here is silently patched without a note in that
file.

## The algorithm

`algorithm_mode="paper_exact"` is this pipeline's **only** algorithm -- the paper's own Algorithm 1 / Algorithm 3
/ Eq 1-52 formalization, faithfully reimplemented (real per-candidate `h_rep`, `sigma_impl`, the corrected
diagnostic classifier with proper precedence, `phi_best`-tracking repair, `g_sem` re-checked fresh after every
repair). It is set explicitly (redundantly with the constructor default) in every config in this bundle; passing
any other value raises `ValueError`. Verified offline (`test_paper_exact.py`, stub LLM + real Z3) but **not yet
re-run on GPU** -- see `PAPER_CODE_CORRESPONDENCE.md` §1. A small number of ablation knobs (M2/M3/M4) target
machinery this algorithm does not call and are currently inert as a result -- see §9 there.

Runs from any config work with **either** model backend, equally:

```bash
# Option A: HuggingFace                          # Option B: Ollama
cd install && export HF_TOKEN=...                 cd install
./install_models_huggingface.sh --tier llm        ./install_models_ollama.sh --tier llm
cd ../Pipeline/LLM/benchmarking                    cd ../Pipeline/LLM/benchmarking
python3 run_benchmark.py \                         python3 run_benchmark.py \
  --config config_paper_exact_hf.yaml                --config config_paper_exact_ollama.yaml
```

See `install/README.md` for the full side-by-side comparison.

## Offline verification (no GPU, no model, no network)

```bash
python3 test_paper_exact.py
```

Runs every offline test in this bundle: `algorithm_mode="paper_exact"` end-to-end + control-flow correctness
(phi_best/strict-tie/E1-abort/E0-immediate-return), a check that any other `algorithm_mode` value (including the
now-removed `"legacy"`) is rejected, Ollama backend parameter parity (both tiers), and the deterministic no-LLM
compiler's own test suite. All 5 suites pass as of this bundle's assembly.

## Files

| Path | Contents |
|---|---|
| `PAPER_CODE_CORRESPONDENCE.md` | Equation/algorithm-by-algorithm map to the code, every divergence found and fixed, every disclosed caveat and finding. **Read this first.** |
| `requirements.txt` | Python dependencies for both backends. |
| `install/` | `README.md` (Option A/B side by side), `install_models_huggingface.sh`, `install_models_ollama.sh`, `model_registry.yaml` ({model_key: {hf_id, ollama_id}} for every model this bundle uses). |
| `Benchmark/dataset/{GDPR,CCPA,DPDP,PIPD}_Act/` | The 4-act, 238-provision annotated corpus (2322 annotations) -- the only dataset this bundle uses, matching the paper's Table 2/9 exactly. |
| `Benchmark/compare_qa_v2.py` | Label-normalization map, reused by `Deterministic_NoLLM_Baseline/`. |
| `Pipeline/LLM/`, `Pipeline/SLM/` | The two tier pipelines (32B-class / 7B-class models). `lib/SMT_Generation_AAAI_Final.py` (base class), `{llm,slm}_pipeline.py` (tier override), `lib/paper_harness.py` + `lib/paper_diagnostics.py` (the paper_exact machinery), `benchmarking/config*.yaml`, `ablation/` (M1-M5, A1-A3, V6 -- M2/M3/M4 currently inert, see PAPER_CODE_CORRESPONDENCE.md §9), `test_paper_exact.py` + `test_ollama_backend.py` (offline tests). |
| `Baseline/` | B1-B5 (`run_baselines.py --backend huggingface\|ollama`) + B6-B9 (`new_baseline/run_new_baselines.py`, same flag). |
| `S1-S6_Evaluation/` | The canonical post-hoc S1-S6 evaluator (`hpc_multiscenario_eval_s6b.py`) that `paper_harness.py` ports its scenario logic from -- see its own README for what runs standalone vs. what needs a fresh run's output. |
| `Deterministic_NoLLM_Baseline/` | A from-scratch, LLM-free, rule-based â→Z3 compiler answering "can this be compiled without any model at all?" -- see its own README for the STOP-condition finding (7.98% coverage, 57.98% structurally ambiguous). |
| `test_paper_exact.py` | Top-level entry point -- runs every offline test in this bundle in one command. |

## What this bundle does *not* include (and why)

- Model weights (downloaded via `install/`, not vendored).
- `AAAI-Dataset/dataset/PDPA_Singapore_Act/` and `qa_reannotation_sample/` -- not part of the paper's 4-act
  corpus.
- Raw collaborator run-output dumps (the evidence that produced this paper's headline numbers) -- multi-GB,
  not code; a fresh run of `Pipeline/{SLM,LLM}` on `Benchmark/dataset/` reproduces the same pipeline.
- A GPU re-run under `algorithm_mode="paper_exact"` -- this bundle implements and locally verifies the
  algorithm; producing new headline numbers under it is a separate, not-yet-done step (see
  `PAPER_CODE_CORRESPONDENCE.md` §1).
